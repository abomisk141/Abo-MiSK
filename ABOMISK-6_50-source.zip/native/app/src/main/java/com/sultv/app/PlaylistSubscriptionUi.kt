package com.sultv.app

import android.content.Context
import android.widget.ScrollView
import android.widget.TextView
import android.app.DatePickerDialog
import androidx.appcompat.app.AlertDialog
import java.util.Calendar
import java.util.Date
import java.util.concurrent.Executors

object SubscriptionText {
    fun status(c: Context, account: PlaylistSubscription): String = c.getString(if (account.expired()) R.string.account_expired else when (account.status) {
        "active" -> R.string.account_active; "denied" -> R.string.account_denied
        "banned" -> R.string.account_banned; "disabled" -> R.string.account_disabled
        else -> R.string.account_unknown
    })
    fun remaining(c: Context, account: PlaylistSubscription): String = when {
        account.expired() -> c.getString(R.string.account_expired)
        account.unlimited -> c.getString(R.string.account_no_expiry)
        account.expires != null -> c.getString(R.string.account_days_left, account.remainingDays()!!.toInt())
        else -> c.getString(R.string.account_expiry_unknown)
    }
    fun summary(c: Context, p: Playlist): String {
        if (PlaylistSubscriptions.endpoint(p) != null) return PlaylistSubscriptions.cached(p)?.let { remaining(c, it) }
            ?: c.getString(R.string.account_not_checked)
        val expiry = PlaylistSubscriptions.manual(p) ?: return c.getString(R.string.account_expiry_unknown)
        return c.getString(R.string.account_manual_short) + " · " + remaining(c, PlaylistSubscription("unknown", expiry, false, null, null, null, null, 0))
    }
}

class PlaylistSubscriptionUi(private val a: SettingsActivity, private val changed: () -> Unit) {
    private val worker = Executors.newSingleThreadExecutor()
    private var generation = 0
    private var closing = false
    private var dialog: AlertDialog? = null
    fun show(p: Playlist) {
        val token = ++generation
        val supported = PlaylistSubscriptions.endpoint(p) != null
        var account = PlaylistSubscriptions.cached(p)
        var loading = false
        var failed = false
        val text = TextView(a).apply { textSize = 16f; setTextColor(Th.fg); setPadding(a.dp(22), a.dp(12), a.dp(22), a.dp(12)) }
        fun date(t: Long) = android.text.format.DateFormat.getMediumDateFormat(a).format(Date(t)) + " " + android.text.format.DateFormat.getTimeFormat(a).format(Date(t))
        fun render() {
            text.text = buildString {
                append(a.getString(R.string.account_playlist_type)).append(": ").append(if (p.mode == "xt") "Xtream" else "M3U").append("\n\n")
                if (!supported) {
                    append(a.getString(R.string.account_m3u_hint)).append("\n\n")
                    PlaylistSubscriptions.manual(p)?.let { expiry ->
                        append(a.getString(R.string.account_manual_short)).append(": ").append(android.text.format.DateFormat.getMediumDateFormat(a).format(Date(expiry - 1))).append("\n")
                        append(SubscriptionText.remaining(a, PlaylistSubscription("unknown", expiry, false, null, null, null, null, 0)))
                    }
                    return@buildString
                }
                if (loading) append(a.getString(R.string.account_loading)).append("\n\n")
                if (failed) append(a.getString(R.string.account_refresh_failed)).append("\n\n")
                val info = account
                if (info == null) { if (!loading && !failed) append(a.getString(R.string.account_not_checked)); return@buildString }
                append(a.getString(R.string.account_status)).append(": ").append(SubscriptionText.status(a, info)).append("\n")
                append(a.getString(R.string.account_expiry)).append(": ").append(info.expires?.let { date(it) }
                    ?: a.getString(if (info.unlimited) R.string.account_no_expiry else R.string.account_expiry_unknown)).append("\n")
                append(SubscriptionText.remaining(a, info)).append("\n\n")
                info.created?.let { append(a.getString(R.string.account_created)).append(": ").append(date(it)).append("\n") }
                info.trial?.let { append(a.getString(R.string.account_trial)).append(": ").append(a.getString(if (it) R.string.yes else R.string.account_no)).append("\n") }
                info.connections?.let { append(a.getString(R.string.account_connections)).append(": ").append(it).append("\n") }
                info.maximum?.let { append(a.getString(R.string.account_max_connections)).append(": ").append(it).append("\n") }
                append("\n").append(a.getString(R.string.account_checked)).append(": ").append(date(info.checked))
                append("\n\n").append(a.getString(R.string.account_source_hint))
            }
        }
        val scroll = ScrollView(a).apply { addView(text) }
        val d = AlertDialog.Builder(a).setTitle(p.name + " · " + a.getString(R.string.account_info))
            .setView(scroll).setNegativeButton(R.string.feature_close, null)
            .setPositiveButton(if (supported) R.string.account_refresh else R.string.account_manual, null)
            .apply { if (!supported) setNeutralButton(R.string.account_clear_manual, null) }.create()
        dialog = d
        d.setOnDismissListener { generation++; dialog = null; if (!closing) changed() }
        d.show()
        d.window?.setBackgroundDrawable(Designs.panel(a, Th.bgFrom, radius = 24))
        d.window?.setLayout(minOf(a.dp(600), a.resources.displayMetrics.widthPixels - a.dp(32)), (a.resources.displayMetrics.heightPixels * .82f).toInt())
        fun refresh() {
            if (loading) return
            loading = true; failed = false; render()
            d.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
            worker.execute {
                val result = runCatching { PlaylistSubscriptions.fetch(p) }
                a.runOnUiThread {
                    if (generation == token && !a.isFinishing && !a.isDestroyed) {
                        loading = false; failed = result.isFailure; result.getOrNull()?.let { account = it }
                        render(); d.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true
                    }
                }
            }
        }
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (supported) refresh() else {
                val now = Calendar.getInstance()
                PlaylistSubscriptions.manual(p)?.let { now.timeInMillis = it - 1 }
                DatePickerDialog(a, { _, year, month, day ->
                    PlaylistSubscriptions.setManual(p, year, month, day); render()
                }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        if (!supported) d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { PlaylistSubscriptions.clearManual(p); render() }
        render()
        if (supported) refresh()
    }
    fun close() { closing = true; generation++; dialog?.dismiss(); dialog = null; worker.shutdown() }
}
