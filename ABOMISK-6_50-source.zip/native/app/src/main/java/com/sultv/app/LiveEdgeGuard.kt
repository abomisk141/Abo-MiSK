package com.sultv.app

import androidx.media3.common.C

/** Acts only on known seekable live windows, never on plain TS, paused playback or external audio. */
class LiveEdgeGuard {
    private var lagSinceMs: Long? = null
    private var lastJumpMs: Long? = null
    fun reset() { lagSinceMs = null; lastJumpMs = null }
    fun target(nowMs: Long, enabled: Boolean, playing: Boolean, liveWindow: Boolean,
        seekable: Boolean, durationMs: Long, positionMs: Long, desiredOffsetMs: Long): Long? {
        val valid = desiredOffsetMs > 0 && enabled && playing && liveWindow && seekable && durationMs != C.TIME_UNSET &&
            durationMs > desiredOffsetMs && positionMs >= 0 && positionMs <= durationMs
        val lagMs = if (valid) durationMs - positionMs else 0
        if (!valid || lagMs <= desiredOffsetMs + maxOf(6000L, desiredOffsetMs / 3)) { lagSinceMs = null; return null }
        if (lastJumpMs?.let { nowMs - it < 60000L } == true) { lagSinceMs = null; return null }
        val since = lagSinceMs ?: nowMs.also { lagSinceMs = it }
        if (nowMs - since < 10000L) return null
        lastJumpMs = nowMs; lagSinceMs = null
        return (durationMs - desiredOffsetMs).coerceAtLeast(0)
    }
}
