package com.sultv.app

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.*

/** Bounded, scrollable playback menus with the same remote focus treatment in every theme. */
object PlaybackMenus {
    data class Entry(val title: String, val detail: String, val section: String, val icon: Int,
        val selected: Boolean = false, val destructive: Boolean = false, val action: () -> Unit)
    private fun Activity.px(n: Int) = (n * resources.displayMetrics.density + .5f).toInt()
    private fun card(fill: Int = Th.card, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = 18f
        if (stroke != 0) setStroke(2, stroke)
    }
    private fun text(a: Activity, value: String, size: Float = 16f, muted: Boolean = false) = TextView(a).apply {
        text = value; textSize = size; setTextColor(if (muted) Th.mut else Th.fg)
        maxLines = 2; gravity = Gravity.CENTER_VERTICAL
    }
    private fun button(a: Activity, value: String) = Button(a).apply {
        id = View.generateViewId(); text = value; textSize = 15f; isAllCaps = false
        setTextColor(Th.fg); stateListAnimator = null
        background = card(); setPadding(a.px(12), a.px(6), a.px(12), a.px(6))
        setOnFocusChangeListener { v, focused -> v.background = card(if (focused) Th.acc else Th.card, if (focused) Color.WHITE else 0); setTextColor(if (focused) Th.bt else Th.fg) }
    }
    private fun panel(a: Activity, title: String, subtitle: String): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL; layoutDirection = a.resources.configuration.layoutDirection
        setPadding(a.px(20), a.px(16), a.px(20), a.px(16))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Th.bgFrom, Th.bgTo)).apply {
            cornerRadius = a.px(24).toFloat(); setStroke(a.px(1), (Th.acc and 0xFFFFFF) or (0x66 shl 24))
        }
        addView(text(a, title, 22f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2))
        if (subtitle.isNotBlank()) addView(text(a, subtitle, 13f, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.px(4) })
    }
    private fun show(a: Activity, root: View, width: Int = 640): Dialog = Dialog(a).apply {
        requestWindowFeature(Window.FEATURE_NO_TITLE); setContentView(root)
        window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); setDimAmount(.55f) }
        show()
        window?.setLayout(minOf(a.px(width), a.resources.displayMetrics.widthPixels - a.px(32)), minOf(a.px(640), (a.resources.displayMetrics.heightPixels * .9f).toInt()))
    }
    fun options(a: Activity, title: String, subtitle: String, entries: List<Entry>): Dialog {
        val root = panel(a, title, subtitle).apply { tag = "playback-options" }
        val scroll = ScrollView(a).apply { clipToPadding = false; isFillViewport = false }
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, a.px(6)) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = a.px(12) })
        val close = button(a, a.getString(R.string.done))
        root.addView(close, LinearLayout.LayoutParams(-1, a.px(48)).apply { topMargin = a.px(10) })
        val ordered = mutableListOf<View>(); val actions = mutableListOf<Pair<View, () -> Unit>>()
        entries.groupBy { it.section }.forEach { (section, rows) ->
            body.addView(text(a, section, 13f, true).apply { setTextColor(Th.acc); setPadding(a.px(6), a.px(10), 0, a.px(6)) })
            rows.forEach { entry ->
                val row = LinearLayout(a).apply {
                    id = View.generateViewId(); orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    isFocusable = true; isClickable = true; minimumHeight = a.px(66)
                    setPadding(a.px(12), a.px(10), a.px(12), a.px(10))
                    background = card(stroke = if (entry.selected) Th.acc else 0)
                    tag = "playback-option:${entry.title}"; contentDescription = listOf(entry.title, entry.detail).filter { it.isNotBlank() }.joinToString(", ")
                }
                val tone = if (entry.destructive) (if (Th.name == "light") Color.rgb(185, 28, 28) else Color.rgb(255, 128, 148)) else Th.acc
                val icon = ImageView(a).apply { setImageResource(entry.icon); imageTintList = ColorStateList.valueOf(tone) }
                row.addView(icon, LinearLayout.LayoutParams(a.px(28), a.px(28)).apply { marginEnd = a.px(14) })
                val labels = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                val titleView = text(a, entry.title, 16f).apply { if (entry.destructive) setTextColor(tone) }; val detailView = text(a, entry.detail, 12f, true)
                labels.addView(titleView); if (entry.detail.isNotBlank()) labels.addView(detailView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.px(3) })
                row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
                val mark = text(a, if (entry.selected) "✓" else "", 20f).apply { setTextColor(Th.acc) }
                row.addView(mark, LinearLayout.LayoutParams(a.px(28), -2))
                row.setOnFocusChangeListener { _, focused ->
                    val focusedText = if (entry.destructive) Color.WHITE else Th.bt
                    val focusedFill = if (entry.destructive) Color.rgb(162, 28, 48) else Th.acc
                    row.background = card(if (focused) focusedFill else Th.card, if (focused) Color.WHITE else if (entry.selected) Th.acc else 0)
                    titleView.setTextColor(if (focused) focusedText else if (entry.destructive) tone else Th.fg); detailView.setTextColor(if (focused) focusedText else Th.mut)
                    icon.imageTintList = ColorStateList.valueOf(if (focused) focusedText else tone); mark.setTextColor(if (focused) focusedText else tone)
                }
                body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.px(6) })
                ordered.add(row); actions.add(row to entry.action)
            }
        }
        val d = show(a, root)
        actions.forEach { (view, action) -> view.setOnClickListener { d.dismiss(); action() } }
        close.setOnClickListener { d.dismiss() }
        (ordered + close).forEachIndexed { index, view ->
            val list = ordered + close
            view.nextFocusUpId = list[(index - 1).coerceAtLeast(0)].id
            view.nextFocusDownId = list[(index + 1).coerceAtMost(list.lastIndex)].id
        }
        (ordered.firstOrNull() ?: close).requestFocus()
        return d
    }

    fun audio(a: Activity, currentUrl: String, selectedUrl: String?, choose: (AudioChannel) -> Unit, original: () -> Unit, selectedPlaylistId: String? = null): Dialog {
        val accounts = Repo.visiblePlaylists().filter { it.live }
        val root = panel(a, a.getString(R.string.audio_other), a.getString(R.string.audio_playlist_hint)).apply { tag = "audio-picker" }
        val source = button(a, "").apply { tag = "audio-playlist" }
        root.addView(source, LinearLayout.LayoutParams(-1, a.px(48)).apply { topMargin = a.px(12) })
        val input = EditText(a).apply {
            tag = "audio-search"; hint = a.getString(R.string.search); setSingleLine(); textSize = 16f
            setTextColor(Th.fg); setHintTextColor(Th.mut); background = card()
            setPadding(a.px(14), a.px(6), a.px(14), a.px(6))
        }
        root.addView(input, LinearLayout.LayoutParams(-1, a.px(48)).apply { topMargin = a.px(8) })
        val status = text(a, a.getString(R.string.loading), 12f, true).apply { tag = "audio-status" }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.px(6); bottomMargin = a.px(6) })
        val list = ListView(a).apply { tag = "audio-channel-list"; divider = null; selector = card(Color.TRANSPARENT, Th.acc); setDrawSelectorOnTop(true) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(a)
        val restore = button(a, a.getString(R.string.audio_off)); val close = button(a, a.getString(R.string.done))
        footer.addView(restore, LinearLayout.LayoutParams(0, a.px(48), 1f).apply { marginEnd = a.px(8) }); footer.addView(close, LinearLayout.LayoutParams(0, a.px(48), 1f))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.px(10) })
        var all = emptyList<AudioChannel>(); var rows = emptyList<AudioChannel>(); var account = accounts.firstOrNull { it.id == selectedPlaylistId } ?: accounts.firstOrNull { it.id == Repo.active()?.id } ?: accounts.firstOrNull()
        var generation = 0; var filterGeneration = 0; var sourceMenu: Dialog? = null
        val load = LatestWork(); val filter = LatestWork(); val handler = Handler(Looper.getMainLooper())
        val adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int) = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val entry = rows[position]
                val row = (convertView as? LinearLayout) ?: LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL; minimumHeight = a.px(64); gravity = Gravity.CENTER_VERTICAL
                    setPadding(a.px(14), a.px(8), a.px(14), a.px(8))
                    addView(text(a, "", 16f)); addView(text(a, "", 12f, true))
                }
                (row.getChildAt(0) as TextView).text = (if (entry.item.url == selectedUrl) "✓  " else "") + entry.item.name
                (row.getChildAt(1) as TextView).text = entry.playlistName
                row.background = card(stroke = if (entry.item.url == selectedUrl) Th.acc else 0)
                row.contentDescription = entry.item.name + ", " + entry.playlistName
                return row
            }
        }
        list.adapter = adapter
        val d = show(a, root, 720)
        fun render() {
            val request = ++filterGeneration; val snapshot = all; val query = input.text.toString().trim()
            filter.submit {
                val result = snapshot.filter { if (Thread.currentThread().isInterrupted) throw InterruptedException(); it.item.name.contains(query, ignoreCase = true) }
                handler.post { if (d.isShowing && request == filterGeneration) { rows = result; adapter.notifyDataSetChanged(); status.text = if (result.isEmpty()) a.getString(R.string.none) else a.getString(R.string.audio_channel_count, result.size) } }
            }
        }
        fun loadAccount(p: Playlist) {
            account = p; val request = ++generation; filterGeneration++; filter.cancel()
            all = emptyList(); rows = emptyList(); adapter.notifyDataSetChanged()
            source.text = p.name + if (accounts.size > 1) "  ▾" else ""
            status.text = a.getString(R.string.loading)
            load.submit {
                val result = runCatching { Repo.audioChannels(p)?.filter { it.item.url != currentUrl } }.getOrNull()
                handler.post {
                    if (!d.isShowing || request != generation) return@post
                    if (result == null) status.text = a.getString(R.string.loadfail)
                    else { all = result; render() }
                }
            }
        }
        source.setOnClickListener {
            if (accounts.size > 1) sourceMenu = options(a, a.getString(R.string.s_playlists), "", accounts.map { p -> Entry(p.name, "", a.getString(R.string.t_audio), R.drawable.ic_audio_wave, account?.id == p.id) { loadAccount(p) } })
        }
        source.isEnabled = accounts.isNotEmpty()
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        list.setOnItemClickListener { _, _, position, _ -> rows.getOrNull(position)?.let { d.dismiss(); choose(it) } }
        restore.setOnClickListener { d.dismiss(); original() }; close.setOnClickListener { d.dismiss() }
        d.setOnDismissListener { generation++; filterGeneration++; load.close(); filter.close(); handler.removeCallbacksAndMessages(null); sourceMenu?.dismiss() }
        account?.let { loadAccount(it) } ?: run { status.text = a.getString(R.string.no_visible_playlists) }
        source.requestFocus()
        return d
    }
}
