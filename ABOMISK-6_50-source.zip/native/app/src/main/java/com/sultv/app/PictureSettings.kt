package com.sultv.app

import android.view.Gravity
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.media3.common.Effect
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment

/** Global video preferences; never changes the device's screen brightness. */
data class PictureSettings(
    val enabled: Boolean = false,
    val brightness: Int = 0,
    val contrast: Int = 0,
    val saturation: Int = 100
) {
    fun normalized() = copy(brightness = brightness.coerceIn(-50, 50),
        contrast = contrast.coerceIn(-50, 50), saturation = saturation.coerceIn(0, 200))

    fun effects(): List<Effect> {
        val s = normalized()
        if (!s.enabled) return emptyList()
        return buildList {
            if (s.brightness != 0) add(Brightness(s.brightness / 100f))
            if (s.contrast != 0) add(Contrast(s.contrast / 100f))
            if (s.saturation != 100) add(HslAdjustment.Builder().adjustSaturation(s.saturation - 100f).build())
        }
    }

    fun save() {
        val s = normalized()
        Repo.sp.edit().putString("pictureEnabled", if (s.enabled) "1" else "0")
            .putString("pictureBrightness", s.brightness.toString())
            .putString("pictureContrast", s.contrast.toString())
            .putString("pictureSaturation", s.saturation.toString()).apply()
    }

    companion object {
        fun load() = PictureSettings(Repo.b("pictureEnabled", false),
            Repo.s("pictureBrightness", "0").toIntOrNull() ?: 0,
            Repo.s("pictureContrast", "0").toIntOrNull() ?: 0,
            Repo.s("pictureSaturation", "100").toIntOrNull() ?: 100).normalized()
    }
}

/** A narrow remote-friendly panel leaves the video visible while previewing. */
fun PlayerActivity.showPictureControls(apply: (PictureSettings) -> Unit) {
    val original = PictureSettings.load()
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), dp(12))
    }
    box.addView(TextView(this).apply { text = getString(R.string.picture_hint); textSize = 14f })
    val enabled = CheckBox(this).apply {
        text = getString(R.string.picture_enable); isChecked = original.enabled
    }
    box.addView(enabled)
    fun slider(label: Int, min: Int, max: Int, value: Int): SeekBar {
        val title = TextView(this).apply { textSize = 16f; setPadding(0, dp(10), 0, 0) }
        box.addView(title)
        return SeekBar(this).apply {
            this.max = max - min; progress = value - min; keyProgressIncrement = 5
            contentDescription = getString(label)
            fun render(p: Int) { title.text = getString(label) + ": " + (p + min) }
            render(progress)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { render(p) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
            box.addView(this, LinearLayout.LayoutParams(-1, dp(48)))
        }
    }
    val brightness = slider(R.string.picture_brightness, -50, 50, original.brightness)
    val contrast = slider(R.string.picture_contrast, -50, 50, original.contrast)
    val saturation = slider(R.string.picture_saturation, 0, 200, original.saturation)
    val preview = Th.btn(this, getString(R.string.picture_apply))
    preview.setOnClickListener {
        apply(PictureSettings(enabled.isChecked, brightness.progress - 50,
            contrast.progress - 50, saturation.progress))
        enabled.isChecked = PictureSettings.load().enabled
    }
    box.addView(preview, LinearLayout.LayoutParams(-1, dp(48)))
    val reset = Th.btn(this, getString(R.string.picture_reset))
    reset.setOnClickListener {
        enabled.isChecked = false; brightness.progress = 50; contrast.progress = 50; saturation.progress = 100
        apply(PictureSettings())
    }
    box.addView(reset, LinearLayout.LayoutParams(-1, dp(48)))
    val scroll = ScrollView(this).apply { addView(box) }
    val d = AlertDialog.Builder(this).setTitle(R.string.picture_title).setView(scroll)
        .setNegativeButton(R.string.feature_close, null).create()
    d.show()
    d.window?.apply {
        setLayout(dp(390), -1); setGravity(Gravity.END)
        attributes = attributes.apply { dimAmount = .15f }
    }
    enabled.requestFocus()
}
