package com.sultv.app

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.ListView
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.view.ViewGroup

/** TV-friendly dark-glass dialogs. Uses ordinary Android Views; no Compose dependency. */
object ModernDialogs {
    fun categoryVisibility(a: Activity, title: String, categories: List<String>, hidden: Set<String>,
        save: (Set<String>) -> Unit): Dialog {
        val checked = BooleanArray(categories.size) { categories[it] !in hidden }
        val p = panel(a, title)
        p.addView(text(a, a.getString(R.string.category_visibility_hint), 14f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(a, 10) })
        val bulk = LinearLayout(a)
        val all = button(a, a.getString(R.string.category_select_all))
        val none = button(a, a.getString(R.string.category_deselect_all))
        bulk.addView(all, LinearLayout.LayoutParams(0, dp(a, 46), 1f).apply { marginEnd = dp(a, 8) })
        bulk.addView(none, LinearLayout.LayoutParams(0, dp(a, 46), 1f))
        p.addView(bulk)
        val count = text(a, "", 14f, MUTED)
        p.addView(count, LinearLayout.LayoutParams(-1, dp(a, 34)))
        val list = ListView(a).apply {
            divider = null
            selector = shape(Color.TRANSPARENT, dp(a, 12).toFloat(), WHITE)
            setDrawSelectorOnTop(true)
        }
        val adapter = object : BaseAdapter() {
            override fun getCount() = categories.size
            override fun getItem(position: Int) = categories[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row = (convertView as? LinearLayout) ?: LinearLayout(a).apply {
                    gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(a, 52)
                    setPadding(dp(a, 12), dp(a, 4), dp(a, 12), dp(a, 4))
                    addView(CheckBox(a).apply {
                        isFocusable = false; isClickable = false; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                        buttonTintList = ColorStateList.valueOf(ACCENT)
                    }, LinearLayout.LayoutParams(dp(a, 44), -2))
                    addView(text(a, "", 16f, WHITE), LinearLayout.LayoutParams(0, -2, 1f))
                }
                (row.getChildAt(0) as CheckBox).isChecked = checked[position]
                (row.getChildAt(1) as TextView).text = categories[position]
                row.background = shape(if (checked[position]) CARD else Color.TRANSPARENT, dp(a, 12).toFloat())
                row.contentDescription = categories[position] + ": " + a.getString(if (checked[position]) R.string.category_shown else R.string.category_hidden)
                return row
            }
        }
        fun update() { count.text = a.getString(R.string.category_visible_count, checked.count { it }, categories.size); adapter.notifyDataSetChanged() }
        list.adapter = adapter
        list.setOnKeyListener { _, key, event ->
            if (key != android.view.KeyEvent.KEYCODE_DPAD_RIGHT || categories.isEmpty()) false
            else {
                if (event.action == android.view.KeyEvent.ACTION_DOWN && event.repeatCount == 0) list.setSelection(categories.lastIndex)
                true
            }
        }
        list.setOnItemClickListener { _, _, index, _ -> checked[index] = !checked[index]; update() }
        all.setOnClickListener { checked.fill(true); update() }
        none.setOnClickListener { checked.fill(false); update() }
        p.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(a).apply { setPadding(0, dp(a, 12), 0, 0) }
        val cancel = button(a, a.getString(R.string.no))
        val apply = button(a, a.getString(R.string.save), true)
        footer.addView(cancel, LinearLayout.LayoutParams(0, dp(a, 46), 1f).apply { marginEnd = dp(a, 8) })
        footer.addView(apply, LinearLayout.LayoutParams(0, dp(a, 46), 1f))
        p.addView(footer)
        val d = dialog(a, p, 620)
        cancel.setOnClickListener { d.dismiss() }
        apply.setOnClickListener {
            // Keep hidden groups absent from the current provider catalogue intact.
            val result = hidden.toMutableSet()
            categories.forEachIndexed { i, name -> if (checked[i]) result.remove(name) else result.add(name) }
            save(result); d.dismiss()
        }
        update()
        d.show()
        d.window?.setLayout(minOf(dp(a, 620), a.resources.displayMetrics.widthPixels - dp(a, 36)),
            minOf(dp(a, 580), (a.resources.displayMetrics.heightPixels * .9f).toInt()))
        all.requestFocus()
        return d
    }
    private val BG get() = (Th.bgFrom and 0xFFFFFF) or (0xF2 shl 24)
    private val CARD get() = Th.card
    private val ACCENT get() = Th.acc
    private const val WHITE = Color.WHITE
    private val MUTED get() = Th.mut

    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density + .5f).toInt()

    private fun shape(color: Int, radius: Float, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != 0) setStroke(2, stroke)
        }

    fun searchBackground(): GradientDrawable = shape(CARD, 26f, Th.acc)

    private fun text(a: Activity, value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(a).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun dialog(a: Activity, content: View, widthDp: Int): Dialog =
        Dialog(a).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(content)
            window?.apply {
                setBackgroundDrawableResource(android.R.color.transparent)
                addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setDimAmount(.68f)
                setLayout(
                    minOf(dp(a, widthDp), a.resources.displayMetrics.widthPixels - dp(a, 36)),
                    WindowManager.LayoutParams.WRAP_CONTENT
                )
                setGravity(Gravity.CENTER)
            }
        }

    private fun button(a: Activity, title: String, accent: Boolean = false) =
        Button(a).apply {
            text = title
            isAllCaps = false
            textSize = 16f
            setTextColor(WHITE)
            background = shape(if (accent) ACCENT else CARD, dp(a, 14).toFloat())
            setPadding(dp(a, 18), dp(a, 8), dp(a, 18), dp(a, 8))
            stateListAnimator = null
            setOnFocusChangeListener { v, focused ->
                v.background = shape(if (focused) ACCENT else if (accent) Th.acc else CARD,
                    dp(a, 14).toFloat(), if (focused) WHITE else 0)
                v.scaleX = if (focused) 1.035f else 1f
                v.scaleY = if (focused) 1.035f else 1f
            }
        }

    private fun panel(a: Activity, title: String): LinearLayout =
        LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 22), dp(a, 20), dp(a, 22), dp(a, 22))
            background = shape(BG, dp(a, 22).toFloat(), 0xFF7340B4.toInt())
            addView(text(a, title, 20f, WHITE, true),
                LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(a, 16) })
        }

    fun options(a: Activity, title: String, labels: List<String>, actions: List<() -> Unit>) {
        val p = panel(a, title)
        val scroll = ScrollView(a).apply { isFillViewport = false }
        val rows = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val icons = arrayOf("♡", "✎", "⇄", "↑", "↓", "⇈", "⇊", "◉")
        val buttons = mutableListOf<Button>()
        labels.forEachIndexed { index, label ->
            val symbol = when (label) {
                a.getString(R.string.grab_move) -> "↕"
                a.getString(R.string.move_up) -> "↑"
                a.getString(R.string.move_down) -> "↓"
                a.getString(R.string.move_top) -> "⇈"
                a.getString(R.string.move_bottom) -> "⇊"
                else -> icons.getOrElse(index) { "•" }
            }
            val b = button(a, "$symbol   $label")
            rows.addView(b, LinearLayout.LayoutParams(-1, dp(a, 49)).apply {
                bottomMargin = dp(a, 7)
            })
            buttons.add(b)
        }
        scroll.addView(rows)
        p.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        val d = dialog(a, p, 420)
        buttons.forEachIndexed { i, b ->
            b.setOnClickListener { d.dismiss(); actions.getOrNull(i)?.invoke() }
        }
        d.show()
        d.window?.setLayout(
            minOf(dp(a, 420), a.resources.displayMetrics.widthPixels - dp(a, 36)),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        buttons.firstOrNull()?.requestFocus()
    }

    fun confirmExit(a: Activity, onExit: () -> Unit) {
        val p = panel(a, "هل تريد الخروج من التطبيق؟")
        p.addView(text(a, "سيتم إغلاق ABO MISK", 15f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(a, 20) })
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val cancel = button(a, "إلغاء")
        val exit = button(a, "خروج", true)
        row.addView(cancel, LinearLayout.LayoutParams(0, dp(a, 52), 1f).apply { marginEnd = dp(a, 10) })
        row.addView(exit, LinearLayout.LayoutParams(0, dp(a, 52), 1f))
        p.addView(row)
        val d = dialog(a, p, 470)
        cancel.setOnClickListener { d.dismiss() }
        exit.setOnClickListener { d.dismiss(); onExit() }
        d.show()
        d.window?.setLayout(
            minOf(dp(a, 470), a.resources.displayMetrics.widthPixels - dp(a, 36)),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cancel.requestFocus()
    }
}
