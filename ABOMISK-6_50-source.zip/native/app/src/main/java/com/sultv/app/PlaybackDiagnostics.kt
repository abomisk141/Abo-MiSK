package com.sultv.app

import android.content.Context
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale
import javax.net.ssl.SSLException

/** Session-only measurements. No URLs, credentials or raw exception messages are retained. */
class PlaybackDiagnostics(private val clock: () -> Long = { SystemClock.elapsedRealtime() }) {
    var rebufferCount = 0; private set
    var droppedFrames = 0; private set
    var networkBps = 0L; private set
    private var networkAt = 0L
    private var hasNetworkSample = false
    private var startedAt = clock()
    private var firstReadyAt: Long? = null
    private var bufferingAt: Long? = null
    private var bufferingMs = 0L
    private var readyOnce = false
    private var lastState = Player.STATE_IDLE
    private var failure: Failure? = null
    private var failureAt = 0L
    private val events = ArrayDeque<Pair<Long, Failure>>()

    enum class Kind { DNS, TIMEOUT, TLS, HTTP, NETWORK, DECODER, FORMAT, PICTURE, OTHER }
    data class Failure(val kind: Kind, val code: String)

    fun reset() {
        rebufferCount = 0; droppedFrames = 0; networkBps = 0; networkAt = 0; hasNetworkSample = false
        startedAt = clock(); firstReadyAt = null; bufferingAt = null; bufferingMs = 0
        readyOnce = false; lastState = Player.STATE_IDLE; failure = null; events.clear()
    }

    fun state(state: Int) {
        val now = clock()
        if (state != Player.STATE_BUFFERING) {
            bufferingAt?.let { bufferingMs += (now - it).coerceAtLeast(0) }
            bufferingAt = null
        }
        if (state == Player.STATE_BUFFERING && lastState != state) {
            bufferingAt = now
            if (readyOnce) rebufferCount++
        }
        if (state == Player.STATE_READY) {
            if (!readyOnce) firstReadyAt = now
            readyOnce = true
        }
        lastState = state
    }

    fun bandwidth(bps: Long) { if (bps >= 0) { networkBps = bps; networkAt = clock(); hasNetworkSample = true } }
    fun dropped(count: Int) { droppedFrames += count.coerceAtLeast(0) }
    fun error(error: Throwable) {
        val item = classify(error)
        failure = item; failureAt = clock()
        events.addLast(failureAt to item)
        while (events.size > 8) events.removeFirst()
    }

    fun totalBufferMs(): Long = bufferingMs + (bufferingAt?.let { (clock() - it).coerceAtLeast(0) } ?: 0)
    fun startupMs(): Long? = firstReadyAt?.minus(startedAt)
    private fun networkAvailable() = hasNetworkSample && clock() - networkAt <= 15000
    fun recentNetworkBps(): Long = if (networkAvailable()) networkBps else 0

    fun report(c: Context, player: ExoPlayer, latency: Int): String {
        fun t(id: Int) = c.getString(id)
        fun seconds(ms: Long) = String.format(Locale.US, "%.1f s", ms.coerceAtLeast(0) / 1000.0)
        fun mbps(bps: Long, knownZero: Boolean = false) = if (bps > 0 || knownZero) String.format(Locale.US, "%.2f Mb/s", bps / 1_000_000.0) else t(R.string.diag_unavailable)
        fun line(id: Int, value: String) = t(id) + ": " + value + "\n"
        fun describe(f: Failure) = t(when (f.kind) {
            Kind.DNS -> R.string.diag_dns; Kind.TIMEOUT -> R.string.diag_timeout
            Kind.TLS -> R.string.diag_tls; Kind.HTTP -> R.string.diag_http
            Kind.NETWORK -> R.string.diag_network; Kind.DECODER -> R.string.diag_decoder
            Kind.FORMAT -> R.string.diag_format; Kind.PICTURE -> R.string.diag_picture
            Kind.OTHER -> R.string.diag_other
        }) + " (${f.code})"
        val vf = player.videoFormat
        val bps = recentNetworkBps()
        val state = when (player.playbackState) {
            Player.STATE_BUFFERING -> R.string.diag_buffering
            Player.STATE_READY -> if (player.isPlaying) R.string.diag_playing else R.string.diag_paused
            Player.STATE_ENDED -> R.string.diag_ended
            else -> R.string.diag_idle
        }
        val interpretation = when {
            player.playerError != null -> describe(classify(player.playerError!!))
            player.playbackState == Player.STATE_BUFFERING && networkAvailable() && vf != null && vf.bitrate > 0 && bps < vf.bitrate -> t(R.string.diag_low_rate)
            droppedFrames > 15 -> t(R.string.diag_dropped_hint)
            rebufferCount > 0 -> t(R.string.diag_buffer_hint)
            else -> t(R.string.diag_no_issue)
        }
        val counters = player.videoDecoderCounters
        counters?.ensureUpdated()
        return buildString {
            append(line(R.string.diag_state, t(state)))
            append(interpretation).append("\n\n")
            append(line(R.string.diag_transfer, mbps(bps, networkAvailable())))
            append(line(R.string.diag_stream_rate, mbps(vf?.bitrate?.toLong() ?: 0)))
            append(line(R.string.diag_buffer, seconds(player.totalBufferedDuration)))
            append(line(R.string.diag_rebuffers, rebufferCount.toString()))
            append(line(R.string.diag_buffer_time, seconds(totalBufferMs())))
            append(line(R.string.diag_startup, startupMs()?.let { seconds(it) } ?: t(R.string.diag_unavailable)))
            append(line(R.string.diag_dropped, droppedFrames.toString()))
            append(line(R.string.diag_rendered, counters?.renderedOutputBufferCount?.toString() ?: t(R.string.diag_unavailable)))
            append(line(R.string.diag_latency, if (latency >= 0) "$latency ms" else t(R.string.diag_unavailable)))
            append(line(R.string.diag_resolution, if (vf != null && vf.width > 0) "${vf.width} × ${vf.height}" else t(R.string.diag_unavailable)))
            append(line(R.string.diag_codec, vf?.sampleMimeType ?: t(R.string.diag_unavailable)))
            if (player.isCurrentMediaItemLive && player.currentLiveOffset != C.TIME_UNSET)
                append(line(R.string.diag_live_offset, seconds(player.currentLiveOffset)))
            failure?.let { append("\n").append(t(R.string.diag_last_error)).append(": ")
                .append(describe(it)).append(" • ").append(seconds(clock() - failureAt)).append("\n") }
            if (events.isNotEmpty()) {
                append("\n").append(t(R.string.diag_events)).append("\n")
                for ((at, f) in events) append(seconds(at - startedAt)).append(" — ").append(describe(f)).append("\n")
            }
            append("\n").append(t(R.string.diag_note))
        }
    }

    companion object {
        fun classify(error: Throwable): Failure {
            // Bounded traversal also handles malformed/cyclic exception chains.
            val causes = generateSequence(error) { it.cause }.take(12).toList()
            causes.filterIsInstance<HttpDataSource.InvalidResponseCodeException>().firstOrNull()?.let {
                return Failure(Kind.HTTP, "HTTP ${it.responseCode}")
            }
            if (causes.any { it is UnknownHostException }) return Failure(Kind.DNS, "DNS")
            if (causes.any { it is SocketTimeoutException }) return Failure(Kind.TIMEOUT, "TIMEOUT")
            if (causes.any { it is SSLException }) return Failure(Kind.TLS, "TLS")
            val code = (error as? PlaybackException)?.errorCode
            val kind = when (code) {
                in 2000..2999 -> Kind.NETWORK
                in 3000..3999 -> Kind.FORMAT
                in 4000..4999 -> Kind.DECODER
                in 7000..7999 -> Kind.PICTURE
                else -> Kind.OTHER
            }
            return Failure(kind, code?.toString() ?: "IO")
        }
    }
}
