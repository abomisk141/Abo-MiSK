package com.sultv.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.text.TextUtils
import android.view.View

const val EPG_VISIBLE_PROGRAMMES = 2

/** Two explicit slots avoid squeezing many short events into a fixed-duration timeline. */
object GuideProgrammes {
    fun visible(progs: List<Prog>, at: Long): List<Prog?> {
        val current = progs.asSequence().filter { it.stop > it.start && it.start <= at && it.stop > at }.maxByOrNull { it.start }
        val next = progs.asSequence().filter { it.stop > it.start && it.start > at }.minByOrNull { it.start }
        return listOf(current, next)
    }
}

/** Current and next programme, with equal widths and each programme's actual start/end time. */
class EpgView(c: Context) : View(c) {
    private var progs: List<Prog> = emptyList()
    private var winStart = 0L
    private val d = c.resources.displayMetrics.density
    private val fs = c.resources.configuration.fontScale
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val none = c.getString(R.string.no_info)

    init { tag = "epg-cell"; isFocusable = true; isClickable = true; contentDescription = c.getString(R.string.epg_browse_hint) }
    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: android.graphics.Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect); invalidate()
    }
    fun bind(p: List<Prog>, ws: Long) { progs = p; winStart = ws; invalidate() }
    internal fun displayedProgrammes(now: Long = System.currentTimeMillis()): List<Prog?> = GuideProgrammes.visible(progs, maxOf(winStart, now))

    private fun label(cv: Canvas, value: String, x: Float, y: Float, available: Float) {
        if (available <= 0) return
        val text = TextUtils.ellipsize(value, txt, available, TextUtils.TruncateAt.END)
        cv.drawText(text, 0, text.length, x, y, txt)
    }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val gap = 3f * d
        val now = System.currentTimeMillis()
        displayedProgrammes(now).forEachIndexed { index, programme ->
            val left = index * w / EPG_VISIBLE_PROGRAMMES + gap
            val right = (index + 1) * w / EPG_VISIBLE_PROGRAMMES - gap
            val playing = programme != null && programme.start <= now && programme.stop > now
            fill.color = if (Th.name == "cinema") (if (playing) col("#344255") else Th.card) else if (playing) col("#44FFFFFF") else col("#22FFFFFF")
            rect.set(left, gap, right, h - gap); cv.drawRoundRect(rect, 8f * d, 8f * d, fill)
            val x = left + 8f * d; val available = right - left - 16f * d
            txt.textSize = 13f * d * fs; txt.color = if (programme == null) Th.mut else Th.fg
            if (programme == null) {
                label(cv, none, x, h / 2f - (txt.descent() + txt.ascent()) / 2f, available)
            } else {
                label(cv, programme.title, x, 5f * d - txt.ascent(), available)
                txt.textSize = 10f * d * fs; txt.color = Th.mut
                label(cv, hm(programme.start) + " – " + hm(programme.stop), x, h - 5f * d - txt.descent(), available)
                if (playing) {
                    val progress = ((now - programme.start).toFloat() / (programme.stop - programme.start)).coerceIn(0f, 1f)
                    line.color = Th.acc; line.strokeWidth = 2f * d
                    cv.drawLine(left + 5f * d, h - gap, left + 5f * d + (right - left - 10f * d).coerceAtLeast(0f) * progress, h - gap, line)
                }
            }
        }
        if (hasFocus()) {
            line.color = Th.acc; line.strokeWidth = 2f * d; line.style = Paint.Style.STROKE
            rect.set(d, d, w - d, h - d); cv.drawRoundRect(rect, 10f * d, 10f * d, line); line.style = Paint.Style.FILL
        }
    }
}

/** Headings describe the two slots; event-specific clock times appear inside each card. */
class EpgHeader(c: Context) : View(c) {
    var winStart = 0L
    private val d = c.resources.displayMetrics.density
    private val fs = c.resources.configuration.fontScale
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val future = winStart > System.currentTimeMillis()
        val labels = if (future) listOf(R.string.epg_programme_first, R.string.epg_programme_second) else listOf(R.string.epg_programme_current, R.string.epg_programme_next)
        txt.textSize = 12f * d * fs; txt.color = Th.mut
        val y = height / 2f - (txt.descent() + txt.ascent()) / 2f
        labels.forEachIndexed { index, resource ->
            val text = TextUtils.ellipsize(context.getString(resource), txt, (width / 2f - 16f * d).coerceAtLeast(0f), TextUtils.TruncateAt.END)
            cv.drawText(text, 0, text.length, index * width / 2f + 8f * d, y, txt)
        }
    }
}

/** Thin "watched so far" bar under posters and episodes. */
class WatchBar(c: Context) : View(c) {
    var pct = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = col("#55FFFFFF"); r.set(0f, 0f, w, h); cv.drawRoundRect(r, h / 2f, h / 2f, p)
        p.color = Th.acc; r.set(0f, 0f, w * pct.coerceIn(0, 100) / 100f, h); cv.drawRoundRect(r, h / 2f, h / 2f, p)
    }
}

/** Modern on/off switch (drawn by hand so it follows the theme colours). */
class ToggleView(c: Context) : View(c) {
    var checked = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = if (checked) Th.acc else col("#55FFFFFF"); r.set(0f, 0f, w, h)
        cv.drawRoundRect(r, h / 2f, h / 2f, p)
        p.color = if (checked) Th.bt else col("#FFFFFFFF")
        cv.drawCircle(if (checked) w - h / 2f else h / 2f, h / 2f, h / 2f - h * 0.16f, p)
    }
}
