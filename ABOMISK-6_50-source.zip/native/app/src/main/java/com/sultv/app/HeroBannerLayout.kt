package com.sultv.app

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout

/** Artwork fills the banner, but only the text determines its required height. */
class HeroBannerLayout(c: Context, private val textFraction: Float) : FrameLayout(c) {
    lateinit var textColumn: View
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = View.MeasureSpec.getSize(widthMeasureSpec)
        if (!::textColumn.isInitialized) { super.onMeasure(widthMeasureSpec, heightMeasureSpec); return }
        val textWidth = (width * textFraction).toInt().coerceAtLeast(1)
        textColumn.measure(View.MeasureSpec.makeMeasureSpec(textWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val height = resolveSize(maxOf(minimumHeight, textColumn.measuredHeight), heightMeasureSpec)
        (textColumn.layoutParams as LayoutParams).width = textWidth
        setMeasuredDimension(width, height)
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child !== textColumn) child.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
        }
    }
}

/** Button labels keep the selected font size and stack when their natural widths do not fit. */
class HeroActionsLayout(c: Context) : LinearLayout(c) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val available = View.MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
        var required = 0
        for (i in 0 until childCount) {
            getChildAt(i).measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            required += getChildAt(i).measuredWidth
        }
        val gap = context.dp(8)
        val stack = required + gap * (childCount - 1) > available
        orientation = if (stack) VERTICAL else HORIZONTAL
        for (i in 0 until childCount) {
            val lp = getChildAt(i).layoutParams as LayoutParams
            lp.width = if (stack) LayoutParams.MATCH_PARENT else LayoutParams.WRAP_CONTENT
            lp.height = LayoutParams.WRAP_CONTENT
            lp.marginStart = if (!stack && i > 0) gap else 0
            lp.topMargin = if (stack && i > 0) gap else 0
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }
}
