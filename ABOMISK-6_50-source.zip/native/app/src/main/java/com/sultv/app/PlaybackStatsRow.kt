package com.sultv.app

import android.content.Context
import android.view.View
import android.view.ViewGroup

/** Stats wrap as a unit when a large font or a narrow display needs another row. */
class PlaybackStatsRow(c: Context) : ViewGroup(c) {
    private val gap = (8 * resources.displayMetrics.density + .5f).toInt()
    override fun generateDefaultLayoutParams() = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val available = (MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight).coerceAtLeast(0)
        var used = 0; var rowHeight = 0; var totalHeight = 0; var widest = 0
        for (n in 0 until childCount) {
            val child = getChildAt(n); if (child.visibility == GONE) continue
            child.measure(MeasureSpec.makeMeasureSpec(available, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            val needed = child.measuredWidth + if (used > 0) gap else 0
            if (used > 0 && used + needed > available) { widest = maxOf(widest, used); totalHeight += rowHeight + gap; used = 0; rowHeight = 0 }
            used += child.measuredWidth + if (used > 0) gap else 0
            rowHeight = maxOf(rowHeight, child.measuredHeight)
        }
        widest = maxOf(widest, used); totalHeight += rowHeight
        setMeasuredDimension(resolveSize(widest + paddingLeft + paddingRight, widthMeasureSpec), resolveSize(totalHeight + paddingTop + paddingBottom, heightMeasureSpec))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val available = width - paddingLeft - paddingRight
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        var used = 0; var y = paddingTop; var rowHeight = 0
        for (n in 0 until childCount) {
            val child = getChildAt(n); if (child.visibility == GONE) continue
            if (used > 0 && used + gap + child.measuredWidth > available) { y += rowHeight + gap; used = 0; rowHeight = 0 }
            if (used > 0) used += gap
            val x = if (rtl) width - paddingRight - used - child.measuredWidth else paddingLeft + used
            child.layout(x, y, x + child.measuredWidth, y + child.measuredHeight)
            used += child.measuredWidth; rowHeight = maxOf(rowHeight, child.measuredHeight)
        }
    }
}
