package com.sultv.app

import android.content.Context
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Keep repeated vertical remote presses in the channel list while offscreen rows attach. */
class ChannelRecyclerView(c: Context) : RecyclerView(c) {
    var channelNavigation = false
        set(value) { field = value; if (!value) cancelPending() }
    var gridNavigation = false
        set(value) { field = value; if (!value && !channelNavigation) cancelPending() }
    var onGridNeedMore: (() -> Unit)? = null
    var onGridTop: (() -> Boolean)? = null
    var onHorizontalKey: ((Int) -> Boolean)? = null
    private var pendingPosition = NO_POSITION
    private var pendingChildTag: Any? = null
    private var scheduled = false
    private val settle = Runnable {
        scheduled = false
        if ((!channelNavigation && !gridNavigation) || !hasFocus() || !isShown) cancelPending()
        else focusPending()
    }
    init {
        isFocusable = true
        isFocusableInTouchMode = true
        descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
    }
    private fun linearColumn(): Boolean {
        val manager = layoutManager as? LinearLayoutManager ?: return false
        return channelNavigation && manager !is GridLayoutManager && manager.orientation == VERTICAL
    }
    private fun posterGrid(): Boolean = gridNavigation && (layoutManager as? GridLayoutManager)?.orientation == VERTICAL
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if ((linearColumn() || posterGrid()) && hasFocus()) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (event.action == KeyEvent.ACTION_DOWN) {
                        val direction = if (event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN) 1 else -1
                        if (posterGrid()) gridStep(direction) else step(direction)
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (event.action == KeyEvent.ACTION_DOWN) {
                        cancelPending()
                        if (onHorizontalKey?.invoke(event.keyCode) == true) return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
    private fun gridStep(direction: Int) {
        val manager = layoutManager as? GridLayoutManager ?: return
        var count = adapter?.itemCount ?: 0
        if (count == 0) return
        val focused = findFocus()
        val position = focused?.takeIf { it !== this }?.let { findContainingViewHolder(it)?.bindingAdapterPosition } ?: NO_POSITION
        val current = when {
            pendingPosition != NO_POSITION -> pendingPosition
            position != NO_POSITION -> position
            else -> manager.findFirstVisibleItemPosition().coerceAtLeast(0)
        }
        if (direction < 0 && current < manager.spanCount && onGridTop?.invoke() == true) { cancelPending(); return }
        val target = current + direction * manager.spanCount
        if (target >= count) { onGridNeedMore?.invoke(); count = adapter?.itemCount ?: count }
        pendingPosition = if (direction < 0 && current < manager.spanCount) current else target.coerceIn(0, count - 1)
        stopScroll(); focusPending()
    }
    private fun step(delta: Int) {
        val count = adapter?.itemCount ?: 0
        if (count == 0) return
        val focused = findFocus()
        val position = if (focused != null && focused !== this) findContainingViewHolder(focused)?.bindingAdapterPosition ?: NO_POSITION else NO_POSITION
        val current = when {
            pendingPosition != NO_POSITION -> pendingPosition
            position != NO_POSITION -> position
            else -> (layoutManager as LinearLayoutManager).findFirstVisibleItemPosition().coerceAtLeast(0)
        }
        if (focused != null && focused !== this) pendingChildTag = if (focused is EpgView) focused.tag else null
        pendingPosition = (current + delta).coerceIn(0, count - 1)
        stopScroll()
        focusPending()
    }
    private fun focusPending() {
        if (pendingPosition == NO_POSITION) return
        val count = adapter?.itemCount ?: 0
        if (count == 0) { cancelPending(); return }
        pendingPosition = pendingPosition.coerceIn(0, count - 1)
        val row = findViewHolderForAdapterPosition(pendingPosition)?.itemView
        val target = pendingChildTag?.let { row?.findViewWithTag<View>(it) } ?: row
        if (!isComputingLayout && row != null && row.parent === this && target?.requestFocus() == true) {
            cancelPending()
            return
        }
        // Retain focus here rather than let recycling send it into the category column.
        val mode = descendantFocusability
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        requestFocus()
        descendantFocusability = mode
        scrollToPosition(pendingPosition)
        if (!scheduled) { scheduled = true; postOnAnimation(settle) }
    }
    private fun cancelPending() {
        pendingPosition = NO_POSITION
        pendingChildTag = null
        scheduled = false
        removeCallbacks(settle)
    }
    override fun focusSearch(focused: View, direction: Int): View? {
        val candidate = super.focusSearch(focused, direction)
        if ((linearColumn() || posterGrid()) && (direction == View.FOCUS_UP || direction == View.FOCUS_DOWN)) {
            if (candidate == null || candidate !== this && findContainingItemView(candidate) == null) return focused
        }
        return candidate
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (pendingPosition != NO_POSITION && hasFocus()) focusPending()
    }
    override fun onDetachedFromWindow() { cancelPending(); super.onDetachedFromWindow() }
}
