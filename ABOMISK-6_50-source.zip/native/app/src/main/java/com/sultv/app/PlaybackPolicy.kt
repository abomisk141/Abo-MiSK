package com.sultv.app

import androidx.media3.common.MediaItem

/** Buffer ahead is distinct from distance behind the live edge. Configure both independently. */
data class LivePlaybackProfile(
    val minBufferMs: Int, val maxBufferMs: Int,
    val startBufferMs: Int, val rebufferMs: Int,
    val targetOffsetMs: Long, val maxCatchupSpeed: Float
)

object PlaybackPolicy {
    // Buffer ahead absorbs transport jitter; startup and live-edge offset remain separate.
    fun liveProfile(mode: String = Repo.s("liveLatency", "fast")): LivePlaybackProfile = when (mode) {
        "stable" -> LivePlaybackProfile(30000, 60000, 1500, 5000, 10000L, 1.02f)
        "balanced" -> LivePlaybackProfile(15000, 40000, 800, 2500, 6000L, 1.03f)
        else -> LivePlaybackProfile(6000, 20000, 400, 1500, 3000L, 1.03f)
    }
    fun mediaItem(url: String, live: Boolean): MediaItem {
        if (!live) return MediaItem.fromUri(url)
        val profile = liveProfile()
        return MediaItem.Builder().setUri(url).setLiveConfiguration(
            MediaItem.LiveConfiguration.Builder()
                .setTargetOffsetMs(profile.targetOffsetMs)
                .setMinPlaybackSpeed(1f)
                .setMaxPlaybackSpeed(profile.maxCatchupSpeed)
                .build()
        ).build()
    }
    /** Whole-segment HLS needs enough margin for the next completed segment to become available. */
    fun safeCatchupOffsetMs(desiredMs: Long, targetDurationUs: Long, holdBackUs: Long,
        partTargetDurationUs: Long, partHoldBackUs: Long, hasTrailingParts: Boolean): Long? {
        val parts = partTargetDurationUs > 0 && (partHoldBackUs > 0 || hasTrailingParts)
        val safetyUs = when {
            parts -> if (partHoldBackUs > 0) partHoldBackUs else partTargetDurationUs * 3
            targetDurationUs > 0 -> maxOf(targetDurationUs * 2, holdBackUs.takeIf { it > 0 } ?: 0)
            else -> return null
        }
        return maxOf(desiredMs, (safetyUs + 999) / 1000)
    }

    // Only Xtream's generated URLs use this preference. User-supplied M3U URLs remain exact.
    fun xtreamLiveExtension(): String = if (Repo.s("liveFormat", "ts") == "ts") "ts" else "m3u8"
}
