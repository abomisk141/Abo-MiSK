package com.sultv.app

import android.app.Activity
import android.app.Dialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.min

/** A private working copy: moving is visual; only OK invokes the persistence callback. */
data class ReorderEntry(val id: String, val title: String, val logo: String = "")

class GrabReorderDialog(
    private val activity: Activity,
    entries: List<ReorderEntry>,
    heldId: String,
    private val commit: (List<String>, Int) -> Unit
) : Dialog(activity) {
    private val working = entries.toMutableList()
    private var position = working.indexOfFirst { it.id == heldId }.also { require(it >= 0) }
    private val heldTitle = working[position].title
    private val list = RecyclerView(activity)
    private val adapter = Rows()
    private val counter = TextView(activity)
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = activity.resources.configuration.layoutDirection
            setPadding(activity.dp(16), activity.dp(14), activity.dp(16), activity.dp(12))
            background = Th.shape(activity, Th.bgFrom, true, 20)
        }
        panel.addView(Designs.label(activity, activity.getString(R.string.grab_title), 21f).apply { typeface = Typeface.DEFAULT_BOLD })
        panel.addView(Designs.label(activity, "↕  $heldTitle", 17f).apply { setTextColor(Th.acc) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = activity.dp(6) })
        counter.textSize = 14f; counter.setTextColor(Th.mut)
        panel.addView(counter, LinearLayout.LayoutParams(-1, -2).apply { topMargin = activity.dp(4); bottomMargin = activity.dp(8) })
        list.tag = "grab-reorder-list"
        list.layoutManager = LinearLayoutManager(activity)
        list.adapter = adapter; list.itemAnimator = null
        list.isFocusable = true; list.isFocusableInTouchMode = true
        list.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panel.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(Designs.label(activity, activity.getString(R.string.grab_help), 13f, true).apply { maxLines = 3 }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = activity.dp(10) })
        val buttons = LinearLayout(activity)
        buttons.addView(Th.btn(activity, activity.getString(R.string.grab_confirm), true).apply {
            isFocusable = false; setOnClickListener { save() }
        }, LinearLayout.LayoutParams(0, activity.dp(42), 1f))
        buttons.addView(Th.btn(activity, activity.getString(R.string.grab_cancel)).apply {
            isFocusable = false; setOnClickListener { dismiss() }
        }, LinearLayout.LayoutParams(0, activity.dp(42), 1f).apply { marginStart = activity.dp(8) })
        panel.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = activity.dp(8) })
        setContentView(panel)
        window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); setDimAmount(0.6f)
        }
        setOnKeyListener { _, key, event ->
            when (key) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (event.action == KeyEvent.ACTION_DOWN) {
                        val stride = when { event.repeatCount >= 80 -> 50; event.repeatCount >= 30 -> 20; event.repeatCount >= 10 -> 5; else -> 1 }
                        moveTo(position + if (key == KeyEvent.KEYCODE_DPAD_DOWN) stride else -stride)
                    }
                    true
                }
                KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { if (event.action == KeyEvent.ACTION_DOWN) moveTo(position - 20); true }
                KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { if (event.action == KeyEvent.ACTION_DOWN) moveTo(position + 20); true }
                KeyEvent.KEYCODE_MOVE_HOME -> { if (event.action == KeyEvent.ACTION_DOWN) moveTo(0); true }
                KeyEvent.KEYCODE_MOVE_END -> { if (event.action == KeyEvent.ACTION_DOWN) moveTo(working.lastIndex); true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { if (event.action == KeyEvent.ACTION_UP) save(); true }
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> { if (event.action == KeyEvent.ACTION_UP) dismiss(); true }
                // Keep horizontal presses inside move mode; they must not change the active category.
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                else -> false
            }
        }
        updateCounter()
    }
    override fun onStart() {
        super.onStart()
        val dm = activity.resources.displayMetrics
        window?.setLayout(min(activity.dp(640), dm.widthPixels - activity.dp(32)), min(activity.dp(520), dm.heightPixels - activity.dp(24)))
        list.scrollToPosition(position); list.requestFocus()
    }
    private fun updateCounter() { counter.text = activity.getString(R.string.grab_position, position + 1, working.size) }
    private fun moveTo(requested: Int) {
        if (finished) return
        val target = requested.coerceIn(0, working.lastIndex)
        if (target == position) return
        val previous = position
        val held = working.removeAt(previous)
        working.add(target, held); position = target
        adapter.notifyItemMoved(previous, target)
        adapter.notifyItemRangeChanged(min(previous, target), abs(previous - target) + 1)
        updateCounter(); list.stopScroll(); list.scrollToPosition(position)
    }
    private fun save() {
        if (finished) return
        finished = true
        val ids = working.map { it.id }; val target = position
        dismiss(); commit(ids, target)
    }
    private inner class Rows : RecyclerView.Adapter<Rows.Holder>() {
        inner class Holder(val row: LinearLayout, val number: TextView, val image: ImageView, val title: TextView, val handle: TextView) : RecyclerView.ViewHolder(row)
        override fun getItemCount() = working.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val row = LinearLayout(activity).apply {
                gravity = Gravity.CENTER_VERTICAL; layoutDirection = activity.resources.configuration.layoutDirection
                setPadding(activity.dp(10), activity.dp(5), activity.dp(10), activity.dp(5))
                layoutParams = RecyclerView.LayoutParams(-1, activity.dp(48)).apply { bottomMargin = activity.dp(4) }
            }
            val number = Designs.label(activity, "", 14f).apply { gravity = Gravity.CENTER }
            row.addView(number, LinearLayout.LayoutParams(activity.dp(40), -1))
            val image = ImageView(activity).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            row.addView(image, LinearLayout.LayoutParams(activity.dp(40), activity.dp(32)).apply { marginEnd = activity.dp(10) })
            val title = Designs.label(activity, "", 16f).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            row.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            val handle = Designs.label(activity, "↕", 24f).apply { gravity = Gravity.CENTER }
            row.addView(handle, LinearLayout.LayoutParams(activity.dp(30), -1))
            return Holder(row, number, image, title, handle)
        }
        override fun onBindViewHolder(holder: Holder, index: Int) {
            val entry = working[index]; val grabbed = index == position
            holder.row.tag = "grab-item:${entry.id}"
            holder.row.isSelected = grabbed
            holder.row.contentDescription = activity.getString(R.string.grab_entry, index + 1, entry.title)
            holder.row.background = Th.shape(activity, if (grabbed) Th.acc else Th.card, grabbed, 12)
            val ink = if (grabbed) Th.bt else Th.fg
            holder.number.text = (index + 1).toString(); holder.number.setTextColor(ink)
            holder.title.text = entry.title; holder.title.setTextColor(ink)
            holder.title.typeface = if (grabbed) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            holder.handle.visibility = if (grabbed) View.VISIBLE else View.INVISIBLE; holder.handle.setTextColor(ink)
            holder.image.visibility = if (entry.logo.isBlank()) View.GONE else View.VISIBLE
            if (entry.logo.isNotBlank()) Img.load(holder.image, entry.logo)
            holder.row.setOnClickListener { val destination = holder.bindingAdapterPosition; if (destination != RecyclerView.NO_POSITION) moveTo(destination) }
        }
    }
}
