package com.sultv.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** One restrained programme panel; it only presents state supplied by the existing player. */
class PlayerInfoPanel(
    private val c: Context, style: String,
    favouriteAction: () -> Unit, audioAction: () -> Unit, subtitleAction: () -> Unit, settingsAction: () -> Unit
) : LinearLayout(c) {
    val number = label("", 14f).apply { setTextColor(Th.bt); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(c.dp(9), c.dp(4), c.dp(9), c.dp(4)); background = surface(Th.acc, false) }
    val logo = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setImageResource(R.drawable.logo) }
    val channel = label("", 22f).apply { typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
    val programme = label("", 17f).apply { maxLines = 2; typeface = Typeface.DEFAULT_BOLD }
    val quality = label("", 10f).apply { visibility = View.GONE; setPadding(c.dp(6), c.dp(3), c.dp(6), c.dp(3)); background = surface(col("#441B2937"), false) }
    val time = label("", 12f).apply { textDirection = View.TEXT_DIRECTION_LTR }
    val progress = ProgrammeProgressView(c)
    val timing = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
    val next = label("", 12f).apply { visibility = View.GONE; setTextColor(col("#D6DDE5")) }
    val metrics = PlaybackStatsRow(c).apply { tag = "playback-stats-row" }
    val compactStats = label("", 12f).apply { visibility = if (style == "glass") View.VISIBLE else View.GONE; maxLines = if (c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density < 600) 4 else 2 }
    val actions = PlaybackStatsRow(c).apply { tag = "player-overlay-actions" }
    val favourite: ImageButton
    val audio: ImageButton
    val subtitles: ImageButton
    val settings: ImageButton
    private val divider: View
    private fun surface(color: Int, focus: Boolean) = GradientDrawable().apply { setColor(color); cornerRadius = c.dp(10).toFloat(); if (focus) setStroke(c.dp(2), Th.acc) }
    private fun label(value: String, size: Float) = TextView(c).apply { text = value; textSize = size; setTextColor(Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER_VERTICAL or Gravity.START; textDirection = View.TEXT_DIRECTION_LOCALE }
    private fun action(key: String, title: String, icon: Int, run: () -> Unit) = ImageButton(c).apply {
        id = View.generateViewId(); tag = "player-action:$key"; contentDescription = title
        setImageResource(icon); imageTintList = ColorStateList.valueOf(Color.WHITE)
        minimumWidth = c.dp(42); minimumHeight = c.dp(42); setPadding(c.dp(9), c.dp(9), c.dp(9), c.dp(9))
        background = surface(Color.TRANSPARENT, false); setOnClickListener { run() }
        setOnFocusChangeListener { view, focused -> view.background = surface(if (focused) col("#44253446") else Color.TRANSPARENT, focused) }
    }
    init {
        tag = "player-info-panel"; orientation = VERTICAL; layoutDirection = c.resources.configuration.layoutDirection
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        setPadding(c.dp(18), c.dp(12), c.dp(18), c.dp(12))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(col("#F20B1421"), col("#EE151D28"))).apply {
            cornerRadii = floatArrayOf(c.dp(24).toFloat(), c.dp(24).toFloat(), c.dp(24).toFloat(), c.dp(24).toFloat(), c.dp(12).toFloat(), c.dp(12).toFloat(), c.dp(12).toFloat(), c.dp(12).toFloat())
            setStroke(c.dp(1), (Th.acc and 0x00FFFFFF) or (0x44 shl 24))
        }
        val identity = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        identity.addView(logo, LayoutParams(c.dp(52), c.dp(42)).apply { marginEnd = c.dp(10) })
        identity.addView(number, LayoutParams(-2, -2).apply { marginEnd = c.dp(9) })
        val name = LinearLayout(c).apply { orientation = VERTICAL }
        name.addView(channel, LayoutParams(-1, -2))
        val badges = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        badges.addView(label(c.getString(R.string.live_home_badge), 10f).apply { setTextColor(Th.bt); background = surface(Th.acc, false); setPadding(c.dp(7), c.dp(2), c.dp(7), c.dp(2)) }, LayoutParams(-2, -2).apply { marginEnd = c.dp(6) })
        badges.addView(quality, LayoutParams(-2, -2))
        name.addView(badges, LayoutParams(-1, -2).apply { topMargin = c.dp(3) })
        identity.addView(name, LayoutParams(0, -2, 1f))
        favourite = action("favourite", c.getString(R.string.player_favourite_off), R.drawable.ic_bookmark, favouriteAction).apply { isEnabled = false; alpha = .4f }
        audio = action("audio", c.getString(R.string.t_audio), R.drawable.ic_audio_wave, audioAction)
        subtitles = action("subtitles", c.getString(R.string.t_subs), R.drawable.ic_subtitles, subtitleAction)
        settings = action("settings", c.getString(R.string.track_menu), R.drawable.ic_settings, settingsAction)
        val buttons = listOf(favourite, audio, subtitles, settings)
        buttons.forEach { actions.addView(it) }
        buttons.forEachIndexed { index, button ->
            val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
            button.nextFocusLeftId = buttons[(index + if (rtl) 1 else -1).coerceIn(0, buttons.lastIndex)].id
            button.nextFocusRightId = buttons[(index + if (rtl) -1 else 1).coerceIn(0, buttons.lastIndex)].id
            button.nextFocusDownId = button.id
        }
        val header = PlayerPanelHeader(c).apply { this.identity = identity; this.controls = actions }
        header.addView(identity); header.addView(actions)
        addView(header, LayoutParams(-1, -2))
        addView(programme, LayoutParams(-1, -2).apply { topMargin = c.dp(8) })
        timing.addView(time, LayoutParams(-2, -2).apply { marginEnd = c.dp(12) })
        timing.addView(progress, LayoutParams(0, c.dp(30), 1f))
        addView(timing, LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
        addView(next, LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
        divider = View(c).apply { setBackgroundColor((Th.acc and 0x00FFFFFF) or (0x44 shl 24)) }
        addView(divider, LayoutParams(-1, c.dp(1)).apply { topMargin = c.dp(10); bottomMargin = c.dp(5) })
        addView(metrics, LayoutParams(-1, -2)); addView(compactStats, LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
        if (style == "minimal" || style == "glass") { actions.visibility = View.GONE; metrics.visibility = View.GONE; divider.visibility = View.GONE }
        if (style == "minimal") next.visibility = View.GONE
    }
    fun focusControls(): Boolean {
        if (actions.visibility != View.VISIBLE) return false
        descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        return settings.requestFocusFromTouch()
    }
    fun releaseControls() {
        listOf(favourite, audio, subtitles, settings).forEach { it.isPressed = false }
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS; actions.clearFocus()
    }
    fun moveControl(right: Boolean) {
        val available = listOf(favourite, audio, subtitles, settings).filter { it.isEnabled && it.isShown }
        if (available.isEmpty()) return
        available.forEach { it.isPressed = false }
        val index = available.indexOfFirst { it.hasFocus() }.coerceAtLeast(0)
        val forward = right != (layoutDirection == View.LAYOUT_DIRECTION_RTL)
        available[(index + if (forward) 1 else -1).coerceIn(0, available.lastIndex)].requestFocusFromTouch()
    }
    fun controlKey(down: Boolean, repeated: Boolean) {
        val focused = listOf(favourite, audio, subtitles, settings).firstOrNull { it.hasFocus() && it.isEnabled } ?: return
        if (down) { if (!repeated) focused.isPressed = true }
        else if (focused.isPressed) { focused.isPressed = false; focused.performClick() }
    }
    fun favouriteState(on: Boolean, available: Boolean) {
        favourite.isEnabled = available; favourite.alpha = if (available) 1f else .4f
        favourite.isSelected = on; favourite.imageTintList = ColorStateList.valueOf(if (on) Th.acc else Color.WHITE)
        favourite.contentDescription = c.getString(if (on) R.string.player_favourite_on else R.string.player_favourite_off)
    }
}

/** Header controls reflow below channel identity before large fonts can make them collide. */
class PlayerPanelHeader(c: Context) : ViewGroup(c) {
    lateinit var identity: View
    lateinit var controls: View
    private var stacked = false
    private val gap = c.dp(10)
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (!::identity.isInitialized || !::controls.isInitialized) { setMeasuredDimension(0, 0); return }
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val controlWidth = if (controls.visibility != GONE) { controls.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)); controls.measuredWidth } else 0
        stacked = controlWidth > 0 && width - controlWidth - gap < context.dp((290 * context.resources.configuration.fontScale.coerceAtLeast(1f)).toInt())
        val identityWidth = if (stacked || controlWidth == 0) width else width - controlWidth - gap
        identity.measure(MeasureSpec.makeMeasureSpec(identityWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        setMeasuredDimension(width, if (stacked) identity.measuredHeight + gap + controls.measuredHeight else maxOf(identity.measuredHeight, if (controlWidth == 0) 0 else controls.measuredHeight))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        if (!::identity.isInitialized || !::controls.isInitialized) return
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL
        val identityLeft = if (!stacked && rtl) width - identity.measuredWidth else 0
        identity.layout(identityLeft, 0, identityLeft + identity.measuredWidth, identity.measuredHeight)
        if (controls.visibility == GONE) return
        val x = if (rtl) 0 else width - controls.measuredWidth
        val y = if (stacked) identity.measuredHeight + gap else (height - controls.measuredHeight) / 2
        controls.layout(x, y, x + controls.measuredWidth, y + controls.measuredHeight)
    }
}

/** Programme progress with a bounded current-time bubble, not stream download progress. */
class ProgrammeProgressView(c: Context) : View(c) {
    var pct = 0
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = RectF()
    override fun onDraw(canvas: Canvas) {
        val width = width.toFloat(); val barY = height - 4f * d; val x = width * pct.coerceIn(0, 100) / 100f
        paint.color = col("#55FFFFFF"); paint.strokeWidth = 3f * d; paint.strokeCap = Paint.Cap.ROUND
        canvas.drawLine(2f * d, barY, width - 2f * d, barY, paint)
        paint.color = Th.acc; canvas.drawLine(2f * d, barY, x.coerceAtLeast(2f * d), barY, paint)
        text.textSize = 10f * d * resources.configuration.fontScale; text.typeface = Typeface.DEFAULT_BOLD
        val value = hm(System.currentTimeMillis()); val bubbleWidth = (text.measureText(value) + 12f * d).coerceAtMost(width)
        val left = (x - bubbleWidth / 2).coerceIn(0f, (width - bubbleWidth).coerceAtLeast(0f))
        bounds.set(left, 0f, left + bubbleWidth, barY - 5f * d)
        paint.color = Th.acc; canvas.drawRoundRect(bounds, 5f * d, 5f * d, paint)
        text.color = Th.bt; canvas.drawText(value, left + (bubbleWidth - text.measureText(value)) / 2, bounds.centerY() - (text.ascent() + text.descent()) / 2, text)
        paint.color = Color.WHITE; canvas.drawCircle(x.coerceIn(2f * d, (width - 2f * d).coerceAtLeast(2f * d)), barY, 3f * d, paint)
    }
}
