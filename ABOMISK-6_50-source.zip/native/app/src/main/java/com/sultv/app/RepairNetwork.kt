package com.sultv.app

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

internal object RepairNetwork {
    private val helper = OkHttpClient.Builder().callTimeout(4, TimeUnit.SECONDS)
        .followRedirects(false).followSslRedirects(false).build()

    fun endpoint(value: String) = value.toHttpUrlOrNull()?.takeIf {
        it.isHttps && it.username.isEmpty() && it.password.isEmpty() && it.fragment == null
    }

    fun streamClient(value: String): OkHttpClient? {
        val resolver = endpoint(value) ?: return null
        val alternate = DnsOverHttps.Builder().client(helper).url(resolver).post(true).build()
        return OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS)
            .dns(object : Dns {
                override fun lookup(hostname: String): List<java.net.InetAddress> {
                    try { return Dns.SYSTEM.lookup(hostname) }
                    catch (failure: UnknownHostException) {
                        val name = hostname.trimEnd('.')
                        if (!name.contains('.') || name.endsWith(".local", true) || name.endsWith(".internal", true) ||
                            name.endsWith(".localhost", true) || name.endsWith(".home.arpa", true)) throw failure
                        return alternate.lookup(name)
                    }
                }
            }).build()
    }

    fun wake(stream: String): okhttp3.Call? {
        val origin = stream.toHttpUrlOrNull()?.newBuilder()?.username("")?.password("")?.encodedPath("/")
            ?.query(null)?.fragment(null)?.build() ?: return null
        return helper.newCall(Request.Builder().url(origin).head().build())
    }
}
