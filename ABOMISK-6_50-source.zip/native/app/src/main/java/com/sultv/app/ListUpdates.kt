package com.sultv.app

import androidx.recyclerview.widget.AdapterListUpdateCallback
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListUpdateCallback
import androidx.recyclerview.widget.RecyclerView

object ListUpdates {
    const val PAGE = 120
    fun checkCancelled() { if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException() }
    fun limit(total: Int, previous: Int = 0, anchor: Int = -1): Int =
        minOf(total, maxOf(PAGE, previous, if (anchor < 0) 0 else ((anchor / PAGE) + 1) * PAGE))
    class Changes(private val dispatch: (ListUpdateCallback) -> Unit) {
        fun dispatchUpdatesTo(callback: ListUpdateCallback) = dispatch(callback)
        fun dispatchUpdatesTo(adapter: RecyclerView.Adapter<*>) = dispatch(AdapterListUpdateCallback(adapter))
    }
    fun unchanged() = Changes { }
    /** A different category/search is a different scope; avoid an expensive cross-scope diff. */
    fun replace(oldSize: Int, newSize: Int) = Changes {
        if (oldSize > 0) it.onRemoved(0, oldSize)
        if (newSize > 0) it.onInserted(0, newSize)
    }
    fun <T> diff(old: List<T>, new: List<T>, sameId: (T, T) -> Boolean,
        sameContent: (Int, Int) -> Boolean = { a, b -> old[a] == new[b] }): Changes {
        checkCancelled()
        val result = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = new.size
            override fun areItemsTheSame(a: Int, b: Int): Boolean { checkCancelled(); return sameId(old[a], new[b]) }
            override fun areContentsTheSame(a: Int, b: Int): Boolean { checkCancelled(); return sameContent(a, b) }
        }, false)
        checkCancelled()
        return Changes { result.dispatchUpdatesTo(it) }
    }
}
