package com.sultv.app

import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Remote-control layer: every action can be bound to up to two buttons of the remote.
 * Remotes differ a lot (some have CH+/CH-, colour buttons, Menu, Info, Page keys, others only arrows + OK),
 * so the user can re-learn any button and test what his remote sends.
 */
object Remote {
    class Act(val id: String, val group: String, val name: Int, val defaults: List<Int>)

    private const val UP = KeyEvent.KEYCODE_DPAD_UP
    private const val DOWN = KeyEvent.KEYCODE_DPAD_DOWN
    private const val LEFT = KeyEvent.KEYCODE_DPAD_LEFT
    private const val RIGHT = KeyEvent.KEYCODE_DPAD_RIGHT
    private const val OK = KeyEvent.KEYCODE_DPAD_CENTER

    val acts: List<Act> = listOf(
        Act("l_next", "live", R.string.l_next, listOf(DOWN, KeyEvent.KEYCODE_CHANNEL_UP)),
        Act("l_prev", "live", R.string.l_prev, listOf(UP, KeyEvent.KEYCODE_CHANNEL_DOWN)),
        Act("l_list", "live", R.string.l_list, listOf(LEFT)),
        Act("l_last", "live", R.string.l_last, listOf(KeyEvent.KEYCODE_LAST_CHANNEL)),
        Act("l_info", "live", R.string.l_info, listOf(OK, KeyEvent.KEYCODE_INFO)),
        Act("l_menu", "live", R.string.l_menu, listOf(KeyEvent.KEYCODE_MENU)),
        Act("l_fav", "live", R.string.l_fav, listOf(KeyEvent.KEYCODE_PROG_RED)),
        Act("v_back", "vod", R.string.v_back, listOf(LEFT, KeyEvent.KEYCODE_MEDIA_REWIND)),
        Act("v_fwd", "vod", R.string.v_fwd, listOf(RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)),
        Act("v_play", "vod", R.string.v_play, listOf(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)),
        Act("v_next", "vod", R.string.v_next, listOf(KeyEvent.KEYCODE_MEDIA_NEXT)),
        Act("v_menu", "vod", R.string.l_menu, listOf(KeyEvent.KEYCODE_MENU)),
        Act("b_search", "browse", R.string.b_search, listOf(KeyEvent.KEYCODE_SEARCH)),
        Act("b_settings", "browse", R.string.b_settings, listOf(KeyEvent.KEYCODE_SETTINGS)),
        Act("b_menu", "browse", R.string.b_menu, listOf(KeyEvent.KEYCODE_MENU)),
        Act("b_fav", "browse", R.string.b_fav, listOf(KeyEvent.KEYCODE_PROG_RED)),
        Act("b_pgup", "browse", R.string.b_pgup, listOf(KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP)),
        Act("b_pgdn", "browse", R.string.b_pgdn, listOf(KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN)),
        Act("b_home", "browse", R.string.b_home, emptyList()),
        Act("b_live", "browse", R.string.b_live, emptyList()),
        Act("b_movies", "browse", R.string.b_movies, emptyList()),
        Act("b_series", "browse", R.string.b_series, emptyList()),
        Act("b_list", "browse", R.string.b_list, emptyList())
    )

    private val cache = HashMap<String, HashMap<Int, String>>()

    /** Enter / numpad Enter behave exactly like OK */
    fun canon(c: Int): Int = if (c == KeyEvent.KEYCODE_ENTER || c == KeyEvent.KEYCODE_NUMPAD_ENTER) OK else c

    fun digit(c: Int): Int = if (c in 7..16) c - 7 else if (c in 144..153) c - 144 else -1
    fun numJump(): Boolean = Repo.b("numJump", true)

    fun keys(id: String): List<Int> {
        val key = "rk:$id"
        if (Repo.sp.contains(key)) return Repo.s(key).split(",").mapNotNull { it.trim().toIntOrNull() }
        return acts.firstOrNull { it.id == id }?.defaults ?: emptyList()
    }

    fun clearCache() { cache.clear() }
    fun saveKeys(id: String, l: List<Int>) { Repo.put("rk:$id", l.joinToString(",")); cache.clear() }
    fun resetAct(id: String) { Repo.sp.edit().remove("rk:$id").apply(); cache.clear() }
    fun clearAll() { val e = Repo.sp.edit(); for (a in acts) e.remove("rk:${a.id}"); e.apply(); cache.clear() }

    /** Which action is bound to this button in this situation (live / vod / browse)? */
    fun resolve(group: String, code: Int): String? {
        val m = cache.getOrPut(group) {
            val h = HashMap<Int, String>()
            for (a in acts) if (a.group == group) for (k in keys(a.id)) if (!h.containsKey(k)) h[k] = a.id
            h
        }
        return m[canon(code)]
    }

    /** buttons the app needs for moving around can not be re-assigned */
    fun reserved(group: String, c: Int): Boolean =
        c == KeyEvent.KEYCODE_BACK || c == KeyEvent.KEYCODE_HOME || c == KeyEvent.KEYCODE_POWER ||
            (group == "browse" && c in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_CENTER) ||
            (group == "live" && numJump() && digit(c) >= 0)

    /** Puts `code` on button slot 0 or 1 of an action; returns the action it was taken from (if any). */
    fun setSlot(id: String, slot: Int, code: Int): Act? {
        val cur = ArrayList(keys(id))
        while (cur.size <= slot) cur.add(0)
        cur[slot] = code
        saveKeys(id, cur.filter { it != 0 }.distinct())
        val g = acts.first { it.id == id }.group
        var from: Act? = null
        for (o in acts) if (o.group == g && o.id != id) {
            val k = keys(o.id)
            if (code in k) { saveKeys(o.id, k.filter { it != code }); if (from == null) from = o }
        }
        return from
    }

    fun preset(name: String) {
        clearAll()
        val m: Map<String, List<Int>> = when (name) {
            "color" -> mapOf(
                "b_search" to listOf(KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_SEARCH),
                "b_settings" to listOf(KeyEvent.KEYCODE_PROG_YELLOW, KeyEvent.KEYCODE_SETTINGS),
                "b_menu" to listOf(KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_MENU),
                "b_fav" to listOf(KeyEvent.KEYCODE_PROG_RED),
                "l_menu" to listOf(KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_MENU),
                "l_fav" to listOf(KeyEvent.KEYCODE_PROG_RED),
                "l_last" to listOf(KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_LAST_CHANNEL),
                "v_menu" to listOf(KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_MENU),
                "v_next" to listOf(KeyEvent.KEYCODE_PROG_YELLOW, KeyEvent.KEYCODE_MEDIA_NEXT))
            "page" -> mapOf(
                "l_next" to listOf(DOWN, KeyEvent.KEYCODE_PAGE_DOWN),
                "l_prev" to listOf(UP, KeyEvent.KEYCODE_PAGE_UP),
                "b_pgup" to listOf(KeyEvent.KEYCODE_PAGE_UP),
                "b_pgdn" to listOf(KeyEvent.KEYCODE_PAGE_DOWN))
            else -> emptyMap()
        }
        for ((id, l) in m) saveKeys(id, l)
    }

    fun keyName(c: Int): String = when (c) {
        UP -> "▲"; DOWN -> "▼"; LEFT -> "◀"; RIGHT -> "▶"; OK -> "OK"
        KeyEvent.KEYCODE_MENU -> "Menu"
        KeyEvent.KEYCODE_CHANNEL_UP -> "CH +"; KeyEvent.KEYCODE_CHANNEL_DOWN -> "CH −"
        KeyEvent.KEYCODE_PROG_RED -> "Red"; KeyEvent.KEYCODE_PROG_GREEN -> "Green"
        KeyEvent.KEYCODE_PROG_YELLOW -> "Yellow"; KeyEvent.KEYCODE_PROG_BLUE -> "Blue"
        else -> KeyEvent.keyCodeToString(c).removePrefix("KEYCODE_").replace('_', ' ')
    }

    fun label(c: android.content.Context, id: String): String {
        val k = keys(id)
        return if (k.isEmpty()) c.getString(R.string.rc_none) else k.joinToString("  •  ") { keyName(it) }
    }

    /** "Press the button you want" window. */
    fun capture(a: AppCompatActivity, group: String, onKey: (Int) -> Unit) {
        val tv = TextView(a).apply { text = a.getString(R.string.rc_press); textSize = 18f; gravity = Gravity.CENTER; setPadding(a.dp(24), a.dp(24), a.dp(24), a.dp(16)) }
        val dlg = AlertDialog.Builder(a).setView(tv).setNegativeButton(R.string.cancel, null).create()
        val h = Handler(Looper.getMainLooper())
        val kill = Runnable { if (dlg.isShowing) dlg.dismiss() }
        dlg.setOnKeyListener { d, kc, ev ->
            if (kc == KeyEvent.KEYCODE_BACK) false
            else if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                val c = canon(kc)
                if (reserved(group, c)) { Toast.makeText(a, R.string.rc_reserved, Toast.LENGTH_SHORT).show(); true }
                else { h.removeCallbacks(kill); d.dismiss(); onKey(c); true }
            } else true
        }
        dlg.show(); h.postDelayed(kill, 15000)
    }

    /** Shows what the remote really sends (useful with unusual remotes). */
    fun test(a: AppCompatActivity) {
        val tv = TextView(a).apply { text = a.getString(R.string.rc_test_press); textSize = 17f; setPadding(a.dp(26), a.dp(18), a.dp(26), a.dp(10)) }
        val dlg = AlertDialog.Builder(a).setTitle(R.string.rc_test).setView(tv).setNegativeButton(R.string.done, null).create()
        dlg.setOnKeyListener { _, kc, ev ->
            if (kc == KeyEvent.KEYCODE_BACK) false
            else {
                val c = canon(kc)
                val used = acts.filter { c in keys(it.id) }.joinToString(", ") { a.getString(it.name) }
                tv.text = keyName(c) + "\n\n" + a.getString(R.string.rc_t_code) + ": " + kc + "   (" + ev.scanCode + ")\n" +
                    a.getString(R.string.rc_t_dev) + ": " + (ev.device?.name ?: "?") + "\n" +
                    (if (ev.repeatCount > 0) a.getString(R.string.rc_t_hold) + " x" + ev.repeatCount + "\n" else "") +
                    (if (used.isNotEmpty()) "\n" + used else "")
                true
            }
        }
        dlg.show()
    }
}
