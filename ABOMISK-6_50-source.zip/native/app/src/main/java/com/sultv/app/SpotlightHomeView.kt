package com.sultv.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*

/** Editorial VOD home: real catalogue picks, debounced artwork and no stream connection. */
class SpotlightHomeView(
    private val c: Context, private val open: (Item) -> Unit, private val play: (Item) -> Unit,
    private val menu: (Item) -> Unit, private val account: () -> Unit
) : HomeLike {
    override val root = ScrollView(c).apply { isVerticalScrollBarEnabled = false; clipToPadding = false }
    private val body = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; layoutDirection = c.resources.configuration.layoutDirection; setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(24)) }
    private val handler = Handler(Looper.getMainLooper())
    private val work = LatestWork()
    private val metadata = LatestWork()
    private var generation = 0
    private var heroToken = 0
    private var running = false
    private var destroyed = false
    private var selected: Item? = null
    private var focusTask: Runnable? = null
    private var artwork: ImageView? = null
    private var title: TextView? = null
    private var details: TextView? = null
    private var synopsis: TextView? = null
    private val picks = linkedMapOf<View, Item>()
    private data class Data(val movies: List<Item>, val shows: List<Item>, val recent: List<Item>)
    init { root.addView(body) }
    override fun start() { if (!destroyed) running = true }
    override fun stop() {
        running = false; generation++; heroToken++; work.cancel(); metadata.cancel()
        focusTask?.let { handler.removeCallbacks(it) }; focusTask = null
    }
    override fun destroy() { if (destroyed) return; stop(); destroyed = true; work.close(); metadata.close(); handler.removeCallbacksAndMessages(null) }
    override fun render() {
        if (destroyed) return
        val token = ++generation
        work.submit {
            val movies = Repo.list("movie"); val shows = Repo.list("series")
            val recentIds = Repo.recent().take(60); val wanted = recentIds.toHashSet()
            val visible = (movies.asSequence() + shows.asSequence()).filter { it.id in wanted }.associateBy { it.id }
            val data = Data(movies.take(24), shows.take(24), recentIds.mapNotNull { visible[it] }.take(20))
            handler.post { if (!destroyed && token == generation) show(data) }
        }
    }
    private fun surface(focused: Boolean = false, selected: Boolean = false, radius: Int = 12) = GradientDrawable().apply {
        setColor(col("#CC16213A")); cornerRadius = c.dp(radius).toFloat()
        if (focused || selected) setStroke(c.dp(if (focused) 2 else 1), Th.acc)
    }
    private fun text(value: String, size: Float, muted: Boolean = false) = Designs.label(c, value, size, muted)
    private fun show(data: Data) {
        val focus = root.findFocus()?.tag as? String
        focusTask?.let { handler.removeCallbacks(it) }; focusTask = null
        val available = data.movies + data.shows
        selected = available.firstOrNull { it.id == selected?.id } ?: available.firstOrNull()
        body.removeAllViews(); picks.clear()
        if (selected == null) {
            heroToken++; metadata.cancel()
            body.addView(text(c.getString(R.string.spotlight_empty), 20f).apply { maxLines = 4; gravity = Gravity.CENTER; setPadding(c.dp(24), c.dp(48), c.dp(24), c.dp(48)) })
            return
        }
        hero(available.distinctBy { it.id }.take(3))
        shelf(c.getString(R.string.cont_watch), data.recent, true, "list")
        shelf(c.getString(R.string.spotlight_selections), data.movies, false, "movie")
        shelf(c.getString(R.string.spotlight_series), data.shows, false, "series")
        activate(selected!!)
        if (focus != null) root.findViewWithTag<View>(focus)?.requestFocus()
    }
    private fun hero(candidates: List<Item>) {
        val hero = SpotlightHeroLayout(c).apply { tag = "spotlight-hero"; background = surface(radius = 16); clipToOutline = true }
        artwork = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; tag = "spotlight-artwork" }
        hero.addView(artwork, FrameLayout.LayoutParams(-1, -1))
        val rtl = c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        hero.addView(View(c).apply { background = GradientDrawable(if (rtl) GradientDrawable.Orientation.RIGHT_LEFT else GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(col("#FA0A0F1A"), col("#B30A0F1A"), col("#150A0F1A"))) }, FrameLayout.LayoutParams(-1, -1))
        hero.addView(View(c).apply { background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Th.bgFrom, Color.TRANSPARENT)) }, FrameLayout.LayoutParams(-1, -1))
        val labels = LinearLayout(c).apply { tag = "spotlight-hero-text"; orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(12), c.dp(8), c.dp(12), c.dp(12)) }
        labels.addView(text(c.getString(R.string.spotlight_featured), 12f).apply { setTextColor(Th.acc); letterSpacing = .12f })
        title = text("", 34f).apply { tag = "spotlight-hero-title"; maxLines = 2; typeface = Typeface.DEFAULT_BOLD }
        labels.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(8) })
        details = text("", 13f, true).apply { maxLines = 2 }
        labels.addView(details, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(5) })
        synopsis = text("", 14f, true).apply { maxLines = 3 }
        labels.addView(synopsis, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(9) })
        val actions = HeroActionsLayout(c).apply { tag = "spotlight-hero-actions" }
        val height = c.dp((44 * c.resources.configuration.fontScale.coerceAtLeast(1f)).toInt())
        actions.addView(Designs.action(c, c.getString(R.string.spotlight_watch), R.drawable.ic_n_play, true) { selected?.let(play) }.apply { tag = "hero-play"; minimumHeight = height }, LinearLayout.LayoutParams(-2, -2))
        actions.addView(Designs.action(c, c.getString(R.string.cinema_details), R.drawable.ic_n_info) { selected?.let(open) }.apply { tag = "spotlight-details"; minimumHeight = height }, LinearLayout.LayoutParams(-2, -2))
        labels.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(12) })
        hero.textColumn = labels; hero.addView(labels)
        val choices = LinearLayout(c).apply { tag = "spotlight-picks"; orientation = LinearLayout.VERTICAL }
        choices.addView(text(c.getString(R.string.spotlight_picks), 15f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(8) })
        val pickRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = c.resources.configuration.layoutDirection }
        candidates.forEach { item ->
            val choice = LinearLayout(c).apply {
                tag = "spot-pick:${item.id}"; isFocusable = true; isClickable = true; orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(c.dp(3), c.dp(3), c.dp(3), c.dp(4)); background = surface(selected = selected?.id == item.id)
                contentDescription = item.name; setOnClickListener { view -> cancelFocus(); view.requestFocusFromTouch(); cancelFocus(); activate(item) }; setOnLongClickListener { menu(item); true }
                setOnFocusChangeListener { view, focused ->
                    view.background = surface(focused, selected?.id == item.id)
                    if (focused) {
                        cancelFocus()
                        focusTask = Runnable { if (!destroyed && running && view.hasFocus() && selected?.id != item.id) activate(item) }.also { handler.postDelayed(it, 180) }
                    } else if (focusTask != null) cancelFocus()
                }
            }
            val poster = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = surface(); clipToOutline = true }
            choice.addView(poster, LinearLayout.LayoutParams(c.dp(58), c.dp(86))); Img.load(poster, item.logo)
            choice.addView(text(item.name, 10f).apply { maxLines = 2; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(c.dp(58), -2).apply { topMargin = c.dp(3) })
            pickRow.addView(choice, LinearLayout.LayoutParams(c.dp(64), -2).apply { marginEnd = c.dp(6) }); picks[choice] = item
        }
        choices.addView(pickRow, LinearLayout.LayoutParams(-2, -2))
        hero.picksColumn = choices; hero.addView(choices)
        val chrome = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4)) }
        chrome.addView(TextClock(c).apply { format24Hour = "HH:mm"; format12Hour = "HH:mm"; textDirection = View.TEXT_DIRECTION_LTR; setTextColor(Th.fg); textSize = 16f }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = c.dp(12) })
        chrome.addView(ImageButton(c).apply {
            tag = "spotlight-account"; setImageResource(R.drawable.ic_cinema_profile); imageTintList = ColorStateList.valueOf(Th.fg)
            background = surface(); setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(4)); contentDescription = c.getString(R.string.settings)
            setOnClickListener { account() }; setOnFocusChangeListener { _, focused -> background = surface(focused) }
        }, LinearLayout.LayoutParams(c.dp(32), c.dp(32)))
        hero.chrome = chrome; hero.addView(chrome)
        body.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(8) })
    }
    private fun cancelFocus() { focusTask?.let { handler.removeCallbacks(it) }; focusTask = null }
    private fun activate(item: Item) {
        selected = item; val token = ++heroToken
        title?.text = item.name
        fun describe(info: Info?) {
            details?.text = listOf(item.year, info?.genre.orEmpty(), item.dur, item.rate.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty()).filter { it.isNotBlank() }.joinToString("  ·  ")
            synopsis?.text = info?.plot?.takeIf { it.isNotBlank() } ?: c.getString(R.string.cinema_hero_hint)
        }
        describe(Repo.info[item.id]); artwork?.let { Img.load(it, Repo.info[item.id]?.back.orEmpty().ifBlank { item.logo }, 1) }
        picks.forEach { (view, candidate) -> view.isSelected = candidate.id == item.id; view.background = surface(view.hasFocus(), candidate.id == item.id) }
        metadata.submit {
            try {
                if (item.kind == "movie" && item.sid.isNotEmpty() && Repo.info[item.id] == null) Repo.loadMovieInfo(item)
                val info = Repo.info[item.id]
                val backdrop = info?.back.orEmpty().ifBlank { if (Tmdb.enabled()) Tmdb.backdrop(item.kind, info?.tmdb.orEmpty(), item.name, item.year) else "" }
                handler.post {
                    if (!destroyed && token == heroToken && selected?.id == item.id) {
                        describe(info); if (backdrop.isNotBlank()) artwork?.let { Img.load(it, backdrop, 1) }
                    }
                }
            } catch (_: Exception) { /* Catalogue artwork and text stay usable when metadata is unavailable. */ }
        }
    }
    private fun shelf(title: String, items: List<Item>, resume: Boolean, key: String) {
        if (items.isEmpty()) return
        body.addView(LinearLayout(c).apply {
            tag = "home-section:$key"; addView(text(title, 19f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(12); bottomMargin = c.dp(8) })
        val scroll = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false; setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(7)) }
        val cards = LinearLayout(c)
        items.take(20).forEach { item -> cards.addView(card(item, resume), LinearLayout.LayoutParams(c.dp(if (resume) 270 else 128), -2).apply { marginEnd = c.dp(11) }) }
        scroll.addView(cards); body.addView(scroll, LinearLayout.LayoutParams(-1, -2))
    }
    private fun card(item: Item, resume: Boolean): View {
        val card = LinearLayout(c).apply {
            tag = "item:${item.id}"; orientation = if (resume) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true; background = surface(); clipToOutline = true
            setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(2)); contentDescription = item.name
            setOnClickListener { open(item) }; setOnLongClickListener { menu(item); true }; setOnFocusChangeListener { _, focused -> background = surface(focused) }
        }
        val image = VisiblePosterView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = surface(); clipToOutline = true }
        card.addView(image, LinearLayout.LayoutParams(if (resume) c.dp(108) else -1, c.dp(if (resume) 86 else 150))); image.setPoster(item.logo)
        val labels = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(c.dp(9), c.dp(7), c.dp(9), c.dp(7)) }
        labels.addView(text(item.name, 14f).apply { maxLines = if (resume) 2 else 1; typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2))
        if (resume) {
            val progress = Repo.progressOf(item)
            labels.addView(text(listOf(c.getString(if (item.kind == "series") R.string.spotlight_type_series else R.string.spotlight_type_movie), progress.second).filter { it.isNotBlank() }.joinToString(" · "), 11f, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(3) })
            if (progress.first > 0) labels.addView(WatchBar(c).apply { pct = progress.first }, LinearLayout.LayoutParams(-1, c.dp(3)).apply { topMargin = c.dp(8) })
            val uri = if (item.kind == "series") Repo.s("le:" + item.id) else item.url
            Repo.prog(uri)?.let { saved ->
                val minutes = (saved.second - saved.first).coerceAtLeast(0) / 60000
                if (minutes > 0) labels.addView(text(c.getString(R.string.spotlight_minutes_left, minutes), 10f, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
            }
        }
        card.addView(labels, if (resume) LinearLayout.LayoutParams(0, -2, 1f) else LinearLayout.LayoutParams(-1, -2))
        return card
    }
}

/** Content determines height; picks mirror with locale and stack underneath on narrower displays. */
class SpotlightHeroLayout(c: Context) : FrameLayout(c) {
    lateinit var textColumn: View
    lateinit var picksColumn: View
    lateinit var chrome: View
    private var wide = false
    private var topInset = 0
    private var gap = 0
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (!::textColumn.isInitialized || !::picksColumn.isInitialized || !::chrome.isInitialized) { super.onMeasure(widthMeasureSpec, heightMeasureSpec); return }
        val width = MeasureSpec.getSize(widthMeasureSpec); wide = width >= context.dp(650); gap = context.dp(16)
        chrome.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        topInset = chrome.measuredHeight + context.dp(4)
        val picksWidth = if (wide) (width * .24f).toInt().coerceAtLeast(context.dp(212)) else width
        val textWidth = if (wide) minOf((width * .57f).toInt(), width - picksWidth - gap) else width
        textColumn.measure(MeasureSpec.makeMeasureSpec(textWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        picksColumn.measure(MeasureSpec.makeMeasureSpec(picksWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val required = topInset + if (wide) maxOf(textColumn.measuredHeight, picksColumn.measuredHeight) else textColumn.measuredHeight + gap + picksColumn.measuredHeight
        val height = maxOf(context.dp(240), required)
        setMeasuredDimension(width, height)
        for (n in 0 until childCount) {
            val child = getChildAt(n)
            if (child !== textColumn && child !== picksColumn && child !== chrome) child.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY))
        }
    }
    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        if (!::textColumn.isInitialized || !::picksColumn.isInitialized || !::chrome.isInitialized) return
        for (n in 0 until childCount) {
            val child = getChildAt(n)
            if (child !== textColumn && child !== picksColumn && child !== chrome) child.layout(0, 0, width, height)
        }
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        val chromeLeft = if (rtl) 0 else width - chrome.measuredWidth
        chrome.layout(chromeLeft, 0, chromeLeft + chrome.measuredWidth, chrome.measuredHeight)
        val textLeft = if (wide && rtl) width - textColumn.measuredWidth else 0
        textColumn.layout(textLeft, topInset, textLeft + textColumn.measuredWidth, topInset + textColumn.measuredHeight)
        val picksLeft = if (wide && !rtl) width - picksColumn.measuredWidth else 0
        val picksTop = if (wide) topInset else textColumn.bottom + gap
        picksColumn.layout(picksLeft, picksTop, picksLeft + picksColumn.measuredWidth, picksTop + picksColumn.measuredHeight)
    }
}
