package com.sultv.app

import android.os.SystemClock
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import androidx.media3.exoplayer.ExoPlayer
import java.util.WeakHashMap
import java.util.concurrent.atomic.AtomicLong

/** Counts incoming bytes while a connection is still open (including continuous MPEG-TS). */
class StreamTraffic(private val clock: () -> Long = { SystemClock.elapsedRealtime() }) : TransferListener {
    private val total = AtomicLong()
    private val samples = ArrayDeque<Pair<Long, Long>>()
    fun bytesReceived() = total.get()
    init { reset() }
    fun reset() { samples.clear(); samples.addLast(clock() to total.get()) }
    fun sampleBps(): Long? {
        val now = clock()
        if (now - samples.last().first < 900) return null
        val bytes = total.get()
        samples.addLast(now to bytes)
        while (samples.size > 6) samples.removeFirst()
        val base = samples.first()
        val duration = now - base.first
        return if (duration > 0) (bytes - base.second).coerceAtLeast(0) * 8000 / duration else null
    }
    override fun onTransferInitializing(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
    override fun onTransferStart(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
    override fun onBytesTransferred(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean, bytesTransferred: Int) {
        if (isNetwork && bytesTransferred > 0) total.addAndGet(bytesTransferred.toLong())
    }
    override fun onTransferEnd(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
}

object PlaybackTraffic {
    // Accessed on the player application thread; byte counters themselves are atomic.
    private val meters = WeakHashMap<ExoPlayer, StreamTraffic>()
    fun bytesReceived(player: ExoPlayer) = meters[player]?.bytesReceived()
    fun register(player: ExoPlayer, meter: StreamTraffic) { meters[player] = meter }
    fun sampleBps(player: ExoPlayer) = meters[player]?.sampleBps()
    fun reset(player: ExoPlayer) { meters[player]?.reset() }
}

/** Media time acquired equals time played plus the change in buffered duration. */
internal class ChannelRates {
    private val window = ArrayDeque<Pair<Long, Long>>()
    private var rx = -1L
    private var timestamp = -1L
    var download = -1L
        private set
    var bitrate = -1L
        private set
    fun sample(now: Long, received: Long, streamBytes: Long?, mediaEnd: Long) {
        if (rx >= 0 && received >= rx && now > timestamp) {
            val rate = (received - rx) * 8000 / (now - timestamp)
            download = if (download < 0) rate else (download * 6 + rate * 4) / 10
        } else download = -1
        rx = received
        timestamp = now
        if (streamBytes == null || mediaEnd < 0) { clearMedia(); return }
        val last = window.lastOrNull()
        if (last != null && (streamBytes < last.first || mediaEnd < last.second - 500)) clearMedia()
        window.addLast(streamBytes to mediaEnd)
        while (window.size > 9) window.removeFirst()
        val (bytes, end) = window.first()
        val duration = mediaEnd - end
        bitrate = if (duration >= 2000 && streamBytes > bytes) (streamBytes - bytes) * 8000 / duration else -1
    }
    fun clearMedia() { window.clear(); bitrate = -1 }
}
