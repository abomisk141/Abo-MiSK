package com.sultv.app

internal class TsCatchup {
    private var fast = false
    private var cooling = false
    private var stableSince: Long? = null

    fun interrupt() {
        fast = false
        stableSince = null
    }

    fun stall() {
        interrupt()
        cooling = true
    }

    fun speed(now: Long, playing: Boolean, bufferMs: Long): Float {
        if (!playing) { interrupt(); return 1f }
        if (cooling) {
            val start = stableSince ?: now.also { stableSince = it }
            if (now - start < 60000L) return 1f
            cooling = false
        }
        if (bufferMs > 6000) fast = true
        if (bufferMs <= 3000) fast = false
        return if (fast) 1.03f else 1f
    }
}
