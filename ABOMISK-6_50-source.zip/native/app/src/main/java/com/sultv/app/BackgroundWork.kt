package com.sultv.app

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Future
import java.util.concurrent.FutureTask
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** One running job plus the newest pending job; obsolete results must still check their token. */
class LatestWork {
    private val executor = ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, LinkedBlockingQueue())
    private var current: Future<*>? = null
    @Volatile private var running: Thread? = null
    @Synchronized fun submit(work: () -> Unit) {
        cancel()
        current = executor.submit {
            running = Thread.currentThread()
            try { work() } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            catch (_: java.util.concurrent.CancellationException) { }
            finally { running = null }
        }
    }
    @Synchronized fun cancel() {
        current?.cancel(true); running?.let { NetworkWork.cancel(it) }
        current = null; executor.queue.clear()
    }
    fun close() { cancel(); executor.shutdownNow() }
}

object NetworkWork {
    private val connections = ConcurrentHashMap<Thread, MutableSet<java.net.HttpURLConnection>>()
    private val closer = java.util.concurrent.Executors.newSingleThreadExecutor()
    fun track(c: java.net.HttpURLConnection) {
        val thread = Thread.currentThread()
        if (thread.isInterrupted) throw java.io.InterruptedIOException()
        val set = connections[thread] ?: java.util.Collections.newSetFromMap(ConcurrentHashMap<java.net.HttpURLConnection, Boolean>()).let {
            connections.putIfAbsent(thread, it) ?: it
        }
        set.add(c)
        if (thread.isInterrupted) { finish(c); throw java.io.InterruptedIOException() }
    }
    fun finish(c: java.net.HttpURLConnection) {
        val thread = Thread.currentThread(); val set = connections[thread]
        set?.remove(c)
        if (set != null && set.isEmpty()) connections.remove(thread, set)
        c.disconnect()
    }
    fun cancel(thread: Thread) {
        val old = connections.remove(thread)?.toList().orEmpty()
        if (old.isNotEmpty()) closer.execute { old.forEach { runCatching { it.disconnect() } } }
    }
}

/** Concurrent consumers share one operation. Completed failures are not retained. */
object SingleFlight {
    private val jobs = ConcurrentHashMap<Any, FutureTask<Any?>>()
    fun <T> run(key: Any, work: () -> T): T {
        val candidate = FutureTask<Any?> {
            val value = work()
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            value
        }
        val existing = jobs.putIfAbsent(key, candidate)
        val task = existing ?: candidate
        if (existing == null) candidate.run()
        try {
            @Suppress("UNCHECKED_CAST") return task.get() as T
        } catch (e: java.util.concurrent.ExecutionException) {
            if (existing != null && e.cause is InterruptedException && !Thread.currentThread().isInterrupted) {
                jobs.remove(key, task)
                return run(key, work)
            }
            throw e.cause ?: e
        } finally { if (existing == null) jobs.remove(key, candidate) }
    }
}

/** Serialized catalogue summaries: opening several accounts never creates a thread per account. */
class SerialWork {
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
    @Volatile private var running: Thread? = null
    fun submit(work: () -> Unit) {
        executor.submit {
            running = Thread.currentThread()
            try { work() } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            catch (_: java.util.concurrent.CancellationException) { }
            finally { running = null }
        }
    }
    fun close() { executor.shutdownNow(); running?.let { NetworkWork.cancel(it) } }
}
