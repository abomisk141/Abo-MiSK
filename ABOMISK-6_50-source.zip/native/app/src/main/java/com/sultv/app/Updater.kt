package com.sultv.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class UpdInfo(val tag: String, val version: String, val notes: String, val size: Long, val url: String, val forced: Boolean, val newer: Boolean)

/** Looks for a newer release in the GitHub repository and downloads / installs its APK. */
object Updater {
    const val DEFAULT_REPO = "abomisk141/ABO-MISK-Updates"
    @Volatile var lastErr = ""

    fun repo(): String = Repo.s("updRepo", DEFAULT_REPO).trim().ifEmpty { DEFAULT_REPO }

    fun currentVersion(c: Context): String =
        try { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "0" } catch (e: Exception) { "0" }

    private fun nums(v: String): List<Int> = Regex("\\d+").findAll(v).map { it.value.toIntOrNull() ?: 0 }.toList()

    /** > 0 when a is newer than b */
    fun cmp(a: String, b: String): Int {
        val x = nums(a); val y = nums(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }; val q = y.getOrElse(i) { 0 }
            if (p != q) return p.compareTo(q)
        }
        return 0
    }

    fun mb(b: Long): String = if (b <= 0) "?" else String.format(Locale.US, "%.1f MB", b / 1048576.0)

    /** Blocking: call from a thread. */
    fun fetch(c: Context): UpdInfo? {
        lastErr = ""
        return try {
            val conn = URL("https://api.github.com/repos/" + repo() + "/releases/latest").openConnection() as HttpURLConnection
            conn.connectTimeout = 10000; conn.readTimeout = 15000
            conn.setRequestProperty("Accept", "application/vnd.github+json"); conn.setRequestProperty("User-Agent", "ABOMISK-updater")
            if (conn.responseCode != 200) { lastErr = "HTTP " + conn.responseCode; return null }
            val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = o.optString("tag_name")
            var url = ""; var size = 0L
            val a = o.optJSONArray("assets")
            if (a != null) for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                if (x.optString("name").endsWith(".apk", true)) { url = x.optString("browser_download_url"); size = x.optLong("size"); break }
            }
            val body = o.optString("body")
            val cur = currentVersion(c)
            val newer = cmp(tag, cur) > 0
            val mark = Regex("FORCE_UPDATE\\s*[:=]\\s*true", RegexOption.IGNORE_CASE).containsMatchIn(body)
            val min = Regex("MIN_VERSION\\s*[:=]\\s*([0-9][0-9.]*)", RegexOption.IGNORE_CASE).find(body)?.groupValues?.get(1)
            val forced = newer && (mark || (min != null && cmp(min, cur) > 0))
            val notes = body.lines()
                .filterNot { val t = it.trim(); t.startsWith("FORCE_UPDATE", true) || t.startsWith("MIN_VERSION", true) || t.startsWith("<!--") || t.startsWith("-->") || t.startsWith("<!") }
                .joinToString("\n") { l -> l.replace(Regex("^\\s*#+\\s*"), "").replace(Regex("^\\s*[-*]\\s+"), "• ").replace("**", "") }.trim()
            UpdInfo(tag, tag.removePrefix("v").removePrefix("V"), notes, size, url, forced, newer)
        } catch (e: Exception) { lastErr = e.javaClass.simpleName; null }
    }
}

/** The "update available" window: versions, size, change log, Update / Later (no Later when the update is required). */
fun AppCompatActivity.showUpdateDialog(info: UpdInfo) {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(12), dp(22), dp(6)) }
    box.addView(TextView(this).apply { text = getString(R.string.upd_versions, Updater.currentVersion(this@showUpdateDialog), info.version); textSize = 18f; typeface = android.graphics.Typeface.DEFAULT_BOLD })
    box.addView(TextView(this).apply { text = getString(R.string.upd_size, Updater.mb(info.size)); textSize = 14f; setPadding(0, dp(4), 0, dp(10)) })
    if (info.notes.isNotBlank()) {
        box.addView(TextView(this).apply { text = getString(R.string.upd_changes); textSize = 15f; typeface = android.graphics.Typeface.DEFAULT_BOLD })
        box.addView(TextView(this).apply { text = info.notes; textSize = 14f; setPadding(0, dp(4), 0, dp(10)) })
    }
    box.addView(TextView(this).apply { text = getString(R.string.upd_kept); textSize = 12f; alpha = 0.7f })
    val sv = ScrollView(this); sv.addView(box)
    val b = AlertDialog.Builder(this).setTitle(if (info.forced) R.string.upd_required else R.string.upd_available)
        .setView(sv).setCancelable(!info.forced)
        .setPositiveButton(R.string.update_now) { _, _ ->
            if (info.url.isEmpty()) Toast.makeText(this, R.string.upd_noapk, Toast.LENGTH_LONG).show() else downloadAndInstall(info)
        }
    if (info.forced) b.setNegativeButton(R.string.exit) { _, _ -> finishAffinity() } else b.setNegativeButton(R.string.upd_later, null)
    b.show()
}

fun AppCompatActivity.downloadAndInstall(info: UpdInfo) {
    val f = File(cacheDir, "updates/abomisk.apk")
    f.parentFile?.mkdirs()
    if (f.exists() && info.size > 0 && f.length() == info.size) { installApk(f); return }
    val cancel = BooleanArray(1)
    val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
    val tv = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)); text = "0%" }
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(16), dp(24), dp(8)) }
    box.addView(tv); box.addView(bar, LinearLayout.LayoutParams(-1, -2))
    val dlg = AlertDialog.Builder(this).setTitle(R.string.upd_downloading).setView(box).setCancelable(false)
        .setNegativeButton(if (info.forced) R.string.exit else R.string.cancel) { _, _ -> cancel[0] = true; if (info.forced) finishAffinity() }.create()
    dlg.show()
    Thread {
        var ok = false
        try {
            val conn = URL(info.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "ABOMISK-updater")
            val total = if (conn.contentLength > 0) conn.contentLength.toLong() else info.size
            conn.inputStream.use { ins ->
                FileOutputStream(f).use { out ->
                    val buf = ByteArray(65536); var done = 0L; var last = 0L
                    while (!cancel[0]) {
                        val n = ins.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 300) {
                            last = now
                            val d = done
                            runOnUiThread { val p = if (total > 0) (d * 100 / total).toInt() else 0; bar.progress = p; tv.text = Updater.mb(d) + " / " + Updater.mb(total) + "   (" + p + "%)" }
                        }
                    }
                    ok = !cancel[0] && done > 0 && (total <= 0 || done >= total)
                }
            }
        } catch (e: Exception) { ok = false }
        runOnUiThread {
            if (dlg.isShowing) dlg.dismiss()
            if (cancel[0]) { f.delete(); return@runOnUiThread }
            if (ok) installApk(f)
            else { f.delete(); Toast.makeText(this, R.string.upd_fail, Toast.LENGTH_LONG).show(); if (info.forced && !isFinishing) showUpdateDialog(info) }
        }
    }.start()
}

fun AppCompatActivity.installApk(f: File) {
    if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
        Toast.makeText(this, R.string.upd_allow, Toast.LENGTH_LONG).show()
        try { startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
        return
    }
    try {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { Toast.makeText(this, R.string.upd_fail, Toast.LENGTH_LONG).show() }
}

/** Checks once when the app starts (if the user did not turn it off). */
fun AppCompatActivity.autoUpdateCheck() {
    if (Repo.updChecked || !Repo.b("autoUpd", true)) return
    Repo.updChecked = true
    Thread {
        val r = Updater.fetch(this)
        if (r != null && r.newer && r.url.isNotEmpty()) runOnUiThread { if (!isFinishing) showUpdateDialog(r) }
    }.start()
}
