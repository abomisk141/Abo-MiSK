package com.sultv.app

import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** A bounded last-frame capture for the short period when an output surface changes. */
object VideoFrames {
    fun capture(view: PlayerView?, done: (Bitmap?) -> Unit) {
        val video = view?.videoSurfaceView
        if (view == null || !view.isShown || (view.player?.videoSize?.width ?: 0) <= 0 || video == null || video.width <= 0 || video.height <= 0) { done(null); return }
        val width = minOf(video.width, 640)
        val height = (width.toLong() * video.height / video.width).toInt().coerceIn(1, 640)
        val bitmap = try { Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888) } catch (_: OutOfMemoryError) { done(null); return }
        if (video is TextureView && video.isAvailable) {
            val result = runCatching { video.getBitmap(bitmap) }.getOrNull()
            if (result == null) bitmap.recycle()
            done(result); return
        }
        if (Build.VERSION.SDK_INT < 24 || video !is SurfaceView || !video.holder.surface.isValid) { bitmap.recycle(); done(null); return }
        val handler = Handler(Looper.getMainLooper())
        var completed = false
        val timeout = Runnable { if (!completed) { completed = true; done(null) } }
        handler.postDelayed(timeout, 250)
        try {
            PixelCopy.request(video, bitmap, { status ->
                handler.removeCallbacks(timeout)
                if (completed) { bitmap.recycle() }
                else {
                    completed = true
                    if (status == PixelCopy.SUCCESS) done(bitmap) else { bitmap.recycle(); done(null) }
                }
            }, handler)
        } catch (_: RuntimeException) {
            handler.removeCallbacks(timeout); bitmap.recycle()
            if (!completed) { completed = true; done(null) }
        }
    }
}

/** Holds a real previous frame until the new surface renders, then releases the bitmap/listener. */
class VideoFrameBridge(private val player: ExoPlayer, target: PlayerView, frame: Bitmap?) : Player.Listener {
    private var image: ImageView? = null
    private var bitmap: Bitmap? = frame
    private var closed = false
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { close() }
    init {
        target.setKeepContentOnPlayerReset(true)
        if (frame != null) {
            image = ImageView(target.context).apply {
                tag = "video-transition-frame"; scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(frame); isFocusable = false; isClickable = false
            }
            (target.overlayFrameLayout ?: target).addView(image, FrameLayout.LayoutParams(-1, -1))
        }
        player.addListener(this)
        handler.postDelayed(timeout, 5000)
    }
    override fun onRenderedFirstFrame() { close() }
    override fun onPlayerError(error: PlaybackException) { close() }
    fun close() {
        if (closed) return
        closed = true; handler.removeCallbacks(timeout); player.removeListener(this)
        image?.apply { setImageDrawable(null); (parent as? android.view.ViewGroup)?.removeView(this) }; image = null
        bitmap?.let { if (!it.isRecycled) it.recycle() }; bitmap = null
    }
}
