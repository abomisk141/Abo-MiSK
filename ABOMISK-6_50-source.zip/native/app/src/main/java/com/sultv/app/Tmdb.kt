package com.sultv.app

import org.json.JSONObject
import org.json.JSONArray
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Actor(val name: String, val role: String, val photo: String)

/** Cast photos from TMDB. Needs the user's own free API key (Settings > General). */
object Tmdb {
    private val cache = ConcurrentHashMap<String, List<Actor>>()
    @Volatile var lastErr = ""

    fun key(): String = Repo.s("tmdb").trim()
    /** Auto: use IPTV fields first; IPTV: never call TMDB; Fill: fetch missing fields. */
    fun mode(): String = Repo.s("metadataMode", "auto")
    fun enabled(): Boolean = Repo.b("tmdbOn", true) && mode() != "iptv" && key().isNotEmpty()
    fun needsBackdrop(info: Info?): Boolean = enabled() && info?.back.isNullOrBlank()
    fun needsCastPhotos(): Boolean = enabled() // IPTV cast names are not actor photos

    private const val TTL = 30L * 24 * 60 * 60 * 1000
    private fun diskKey(k: String): String = "md_" + MessageDigest.getInstance("SHA-256")
        .digest(k.toByteArray()).take(12).joinToString("") { "%02x".format(it) }
    private fun readCache(k: String): String? {
        val raw = Repo.sp.getString(diskKey(k), null) ?: return null
        return try {
            val o = JSONObject(raw)
            if (System.currentTimeMillis() - o.optLong("t") > TTL) null else o.optString("v")
        } catch (_: Exception) { null }
    }
    private fun writeCache(k: String, v: String) {
        // Bounded persistent cache: avoid growing SharedPreferences indefinitely.
        val all = Repo.sp.all.keys.filter { it.startsWith("md_") }
        if (all.size >= 1200) {
            val editor = Repo.sp.edit()
            all.take(250).forEach { editor.remove(it) }
            editor.apply()
        }
        Repo.sp.edit().putString(diskKey(k), JSONObject().put("t", System.currentTimeMillis()).put("v", v).toString()).apply()
    }

    private fun call(path: String, q: String): JSONObject? =
        SingleFlight.run(listOf("tmdb", key(), Locale.getDefault().language, path, q)) { callOnce(path, q) }
    private fun callOnce(path: String, q: String): JSONObject? {
        val k = key()
        val jwt = k.length > 60 || k.count { it == '.' } == 2          // v4 "read access token"
        val lg = Locale.getDefault().language.ifBlank { "en" }
        var u = "https://api.themoviedb.org/3$path?language=$lg" + (if (q.isNotEmpty()) "&$q" else "")
        if (!jwt) u += "&api_key=" + URLEncoder.encode(k, "UTF-8")
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 15000
            if (jwt) c.setRequestProperty("Authorization", "Bearer $k")
            NetworkWork.track(c)
            try {
                if (c.responseCode != 200) { lastErr = "HTTP " + c.responseCode; null }
                else { lastErr = ""; JSONObject(c.inputStream.bufferedReader().use { it.readText() }) }
            } finally { NetworkWork.finish(c) }
        } catch (e: Exception) { lastErr = e.javaClass.simpleName; null }
    }

    /** returns "" when the key works, otherwise the reason */
    fun test(): String { call("/configuration", "") ?: return lastErr.ifEmpty { "?" }; return "" }

    private val reJunk = Regex("\\(\\d{4}\\)|\\[[^\\]]*\\]|\\([^)]*\\)")
    private val rePrefix = Regex("^[A-Za-z]{2,3}\\s*[-|:]\\s*")
    private val reTags = Regex("\\b(4K|UHD|FHD|HD|1080p|720p|HDR)\\b", RegexOption.IGNORE_CASE)

    private fun clean(n: String): String =
        n.replace(reJunk, " ").replace(rePrefix, "").replace(reTags, " ").replace(Regex("\\s+"), " ").trim()

    private fun find(type: String, title: String, year: String): String {
        val q = "query=" + URLEncoder.encode(clean(title), "UTF-8") +
            (if (year.isNotEmpty()) (if (type == "tv") "&first_air_date_year=$year" else "&year=$year") else "")
        val r = call("/search/$type", q)
        return r?.optJSONArray("results")?.optJSONObject(0)?.optInt("id", 0)?.takeIf { it > 0 }?.toString() ?: ""
    }

    private val bdCache = ConcurrentHashMap<String, String>()

    /** Wide background picture (backdrop) for a movie / series, or "" if none. */
    fun backdrop(kind: String, tmdbId: String, title: String, year: String): String {
        val type = if (kind == "series") "tv" else "movie"
        val ck = "bd:$type:$tmdbId:" + clean(title) + ":" + year
        bdCache[ck]?.let { return it }
        readCache(ck)?.let { bdCache[ck] = it; return it }
        var id = tmdbId.trim().takeIf { it.isNotEmpty() && it != "0" && it.all { c -> c.isDigit() } } ?: ""
        if (id.isEmpty()) { id = find(type, title, year); if (id.isEmpty() && year.isNotEmpty()) id = find(type, title, "") }
        if (id.isEmpty()) return ""
        val o = call("/$type/$id", "") ?: return ""
        val p = o.optString("backdrop_path")
        val u = if (p.isNotBlank() && p != "null") "https://image.tmdb.org/t/p/w1280$p" else ""
        bdCache[ck] = u
        if (u.isNotBlank()) writeCache(ck, u)
        return u
    }

    fun cast(kind: String, tmdbId: String, title: String, year: String): List<Actor> {
        val type = if (kind == "series") "tv" else "movie"
        var id = tmdbId.trim().takeIf { it.isNotEmpty() && it != "0" && it.all { c -> c.isDigit() } } ?: ""
        val ck = if (id.isNotEmpty()) "$type:$id" else "$type:t:" + clean(title) + ":" + year
        cache[ck]?.let { return it }
        readCache("cast:$ck")?.let { raw ->
            try {
                val a = JSONArray(raw)
                val out = (0 until a.length()).map { n -> a.getJSONObject(n) }.map { o -> Actor(o.optString("name"), o.optString("role"), o.optString("photo")) }
                cache[ck] = out
                return out
            } catch (_: Exception) { }
        }
        if (id.isEmpty()) {
            id = find(type, title, year)
            if (id.isEmpty() && year.isNotEmpty()) id = find(type, title, "")
        }
        if (id.isEmpty()) return emptyList()
        val c = call("/$type/$id/credits", "") ?: return emptyList()
        val a = c.optJSONArray("cast") ?: return emptyList()
        val out = ArrayList<Actor>()
        for (i in 0 until minOf(a.length(), 14)) {
            val o = a.getJSONObject(i)
            val pp = o.optString("profile_path")
            out.add(Actor(o.optString("name"), o.optString("character"), if (pp.isNotBlank() && pp != "null") "https://image.tmdb.org/t/p/w185$pp" else ""))
        }
        cache[ck] = out
        val serialized = JSONArray()
        out.forEach { serialized.put(JSONObject().put("name", it.name).put("role", it.role).put("photo", it.photo)) }
        writeCache("cast:$ck", serialized.toString())
        return out
    }
}
