package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder

/** Tiny web server on the TV: the phone opens a page, fills the form, the data arrives here. */
class PhoneServer(private val page: () -> String, private val onData: (Map<String, String>) -> Unit) {
    private var ss: ServerSocket? = null
    @Volatile private var run = false
    var port = 0

    fun start(): Boolean {
        return try {
            val s = ServerSocket(0); ss = s; port = s.localPort; run = true
            Thread {
                while (run) {
                    try { val c = s.accept(); Thread { handle(c) }.start() } catch (e: Exception) { if (!run) break }
                }
            }.start()
            true
        } catch (e: Exception) { false }
    }

    fun stop() { run = false; try { ss?.close() } catch (e: Exception) { } }

    private fun handle(s: Socket) {
        try {
            s.soTimeout = 8000
            val bin = BufferedInputStream(s.getInputStream())
            val hb = ByteArrayOutputStream(); var last = 0
            while (hb.size() < 16384) {
                val b = bin.read(); if (b < 0) break
                hb.write(b); last = (last shl 8) or b
                if (last == 0x0D0A0D0A) break
            }
            val lines = hb.toString("UTF-8").split("\r\n")
            val req = lines[0].split(" ")
            var len = 0
            for (h in lines) if (h.lowercase().startsWith("content-length:")) len = h.substring(15).trim().toIntOrNull() ?: 0
            if (req.size >= 2 && req[0] == "POST") {
                val body = ByteArray(minOf(len, 16384)); var off = 0
                while (off < body.size) { val r = bin.read(body, off, body.size - off); if (r < 0) break; off += r }
                val m = HashMap<String, String>()
                for (kv in String(body, 0, off, Charsets.UTF_8).split("&")) {
                    val i = kv.indexOf('=')
                    if (i > 0) m[URLDecoder.decode(kv.substring(0, i), "UTF-8")] = URLDecoder.decode(kv.substring(i + 1), "UTF-8")
                }
                onData(m)
                send(s, "200 OK", "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><body style='font-family:sans-serif;background:#0f1233;color:#fff;text-align:center;padding:40px'><h2>&#10003;</h2><p>OK</p></body>")
            } else send(s, "200 OK", page())
        } catch (e: Exception) { } finally { try { s.close() } catch (e: Exception) { } }
    }

    private fun send(s: Socket, code: String, body: String) {
        val b = body.toByteArray(Charsets.UTF_8)
        val o = s.getOutputStream()
        o.write(("HTTP/1.1 $code\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n").toByteArray())
        o.write(b); o.flush()
    }
}

class AddPlaylistActivity : BaseActivity() {
    private var step = 1
    private var mode = "m3u"           // m3u | xt
    private var editing: Playlist? = null
    private var vLink = ""; private var vSrv = ""; private var vUser = ""; private var vPass = ""; private var vName = ""
    private var vLive = true; private var vVod = true
    private var cancelled = false
    private var loading = false
    private var server: PhoneServer? = null

    private lateinit var ttl: TextView
    private lateinit var body: FrameLayout
    private lateinit var btns: LinearLayout
    private val pills = ArrayList<TextView>()
    private var status: TextView? = null
    private var etLink: EditText? = null; private var etSrv: EditText? = null; private var etUser: EditText? = null
    private var etPass: EditText? = null; private var etName: EditText? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Repo.init(this); Th.load()
        val id = intent.getStringExtra("id")
        if (id != null) editing = Repo.playlists().firstOrNull { it.id == id }
        editing?.let { e ->
            mode = e.mode; vLink = e.m3u; vSrv = e.xs; vUser = e.xu; vPass = e.xp; vName = e.name; vLive = e.live; vVod = e.vod; step = 2
        }
        val wide = resources.displayMetrics.widthPixels / resources.displayMetrics.density >= 600
        val root = FrameLayout(this); root.background = Th.bg()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = Th.shape(this@AddPlaylistActivity, Th.card, false, 30)
            setPadding(dp(28), dp(22), dp(28), dp(22))
        }
        root.addView(card, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(if (wide) 40 else 10), dp(if (wide) 28 else 10), dp(if (wide) 40 else 10), dp(if (wide) 28 else 10)) })

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(52), dp(52)))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        for (k in 0 until 3) {
            val t = TextView(this).apply { textSize = 13f; setPadding(dp(14), dp(6), dp(14), dp(6)) }
            pills.add(t); top.addView(t, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        }
        card.addView(top)
        ttl = TextView(this).apply { setTextColor(Th.fg); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, dp(10)) }
        card.addView(ttl)
        body = FrameLayout(this)
        card.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        btns = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        card.addView(btns)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBack() }
        })
        render()
    }

    private fun goBack() {
        when {
            loading -> { cancelled = true; finish() }
            step == 3 -> { step = 2; render() }
            step == 2 && editing == null -> { stopServer(); step = 1; render() }
            else -> finish()
        }
    }

    override fun onDestroy() { super.onDestroy(); cancelled = true; stopServer(); Repo.onStage = null }
    private fun stopServer() { server?.stop(); server = null }

    // ---------------- helpers ----------------
    private fun pill(i: Int, txt: String, on: Boolean, done: Boolean) {
        val t = pills[i]
        t.text = (if (done) "✓ " else "${i + 1} ") + txt
        t.setTextColor(if (on) Th.bt else Th.mut)
        t.background = Th.shape(this, if (on) Th.acc else Th.card, false, 30)
    }

    private fun updatePills() {
        pill(0, getString(R.string.wz_s1), step == 1, step > 1)
        pill(1, getString(R.string.wz_s2), step == 2, step > 2)
        pill(2, getString(R.string.wz_s3), step == 3, false)
    }

    private fun lab(s: String) = TextView(this).apply { text = s; setTextColor(Th.mut); textSize = 14f; setPadding(dp(4), dp(8), 0, dp(4)) }

    private fun field(init: String, hint: String, type: Int): EditText {
        val e = EditText(this).apply {
            setText(init); this.hint = hint; setSingleLine(true); inputType = type
            setTextColor(Th.fg); setHintTextColor(Th.mut); textSize = 17f; setPadding(dp(18), 0, dp(18), 0)
        }
        e.background = Th.shape(this, Th.card, false, 18)
        e.setOnFocusChangeListener { v, f -> v.background = Th.shape(this, Th.card, f, 18) }
        return e
    }

    private fun button(txt: String, primary: Boolean, click: () -> Unit): Button {
        val b = Th.btn(this, txt, primary); b.setOnClickListener { click() }
        btns.addView(b, LinearLayout.LayoutParams(-2, dp(48)).apply { marginEnd = dp(10) })
        return b
    }

    private fun switchRow(text: String, on: Boolean, set: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        r.addView(TextView(this).apply { this.text = text; setTextColor(Th.fg); textSize = 17f }, LinearLayout.LayoutParams(0, -2, 1f))
        val t = ToggleView(this); t.checked = on
        r.addView(t, LinearLayout.LayoutParams(dp(54), dp(30)))
        r.background = Th.shape(this, col("#00000000"), false, 16)
        r.setOnFocusChangeListener { v, f -> v.background = Th.shape(this, col("#00000000"), f, 16) }
        r.setOnClickListener { t.checked = !t.checked; set(t.checked) }
        return r
    }

    private fun readFields() {
        etLink?.let { vLink = it.text.toString().trim() }
        etSrv?.let { vSrv = it.text.toString().trim() }
        etUser?.let { vUser = it.text.toString().trim() }
        etPass?.let { vPass = it.text.toString().trim() }
        etName?.let { vName = it.text.toString().trim() }
    }

    // ---------------- steps ----------------
    private fun render() {
        body.removeAllViews(); btns.removeAllViews()
        etLink = null; etSrv = null; etUser = null; etPass = null; etName = null; status = null
        updatePills()
        when (step) { 1 -> stepType(); 2 -> stepDetails(); else -> stepProcess() }
    }

    private fun stepType() {
        ttl.setText(R.string.wz_type_title)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        var first: View? = null
        val items = listOf(
            Triple(R.drawable.ic_link, "M3U" to getString(R.string.wz_m3u_sub), 0),
            Triple(R.drawable.ic_login, "Xtream Codes" to getString(R.string.wz_xt_sub), 1),
            Triple(R.drawable.ic_qr, getString(R.string.wz_phone) to getString(R.string.wz_phone_sub), 2))
        for ((ic, ts, k) in items) {
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; setPadding(dp(14), dp(14), dp(14), dp(14)) }
            c.background = Th.shape(this, Th.card, false, 24)
            c.setOnFocusChangeListener { v, f -> v.background = Th.shape(this, if (f) ((Th.acc and 0xFFFFFF) or (0x55 shl 24)) else Th.card, f, 24) }
            c.addView(ImageView(this).apply { setImageDrawable(Th.icon(this@AddPlaylistActivity, ic, Th.fg)) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            c.addView(TextView(this).apply { text = ts.first; setTextColor(Th.fg); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(4)) })
            c.addView(TextView(this).apply { text = ts.second; setTextColor(Th.mut); textSize = 13f; gravity = Gravity.CENTER })
            c.setOnClickListener {
                when (k) { 0 -> { mode = "m3u"; step = 2; render() }; 1 -> { mode = "xt"; step = 2; render() }; else -> phone() }
            }
            row.addView(c, LinearLayout.LayoutParams(0, dp(170), 1f).apply { setMargins(dp(6), 0, dp(6), 0) })
            if (first == null) first = c
        }
        body.addView(row, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL))
        button(getString(R.string.cancel), false) { finish() }
        first?.requestFocus()
    }

    private fun stepDetails() {
        ttl.text = if (mode == "xt") "Xtream Codes" else "M3U"
        val wide = resources.displayMetrics.widthPixels / resources.displayMetrics.density >= 600
        val cols = LinearLayout(this).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val uri = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val txt = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val lp = LinearLayout.LayoutParams(-1, dp(52))
        if (mode == "xt") {
            left.addView(lab(getString(R.string.wz_server))); etSrv = field(vSrv, "http://host:port", uri); left.addView(etSrv, lp)
            left.addView(lab(getString(R.string.wz_user))); etUser = field(vUser, "", txt); left.addView(etUser, lp)
            left.addView(lab(getString(R.string.wz_pass))); etPass = field(vPass, "", txt); left.addView(etPass, lp)
        } else {
            left.addView(lab(getString(R.string.wz_link))); etLink = field(vLink, "http://.../playlist.m3u", uri); left.addView(etLink, lp)
        }
        left.addView(lab(getString(R.string.pl_name_opt))); etName = field(vName, "", InputType.TYPE_CLASS_TEXT); left.addView(etName, lp)
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        right.addView(switchRow(getString(R.string.opt_live), vLive) { vLive = it })
        right.addView(switchRow(getString(R.string.opt_vod), vVod) { vVod = it })
        cols.addView(left, if (wide) LinearLayout.LayoutParams(0, -2, 3f) else LinearLayout.LayoutParams(-1, -2))
        cols.addView(right, if (wide) LinearLayout.LayoutParams(0, -1, 2f).apply { marginStart = dp(30) } else LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val sv = ScrollView(this); sv.addView(cols)
        body.addView(sv, FrameLayout.LayoutParams(-1, -1))
        button(getString(R.string.next), true) {
            readFields()
            val ok = if (mode == "xt") vSrv.isNotBlank() && vUser.isNotBlank() && vPass.isNotBlank() else vLink.isNotBlank()
            if (!ok) Toast.makeText(this, R.string.wz_fill, Toast.LENGTH_SHORT).show() else if (!vLive && !vVod) Toast.makeText(this, R.string.wz_pick, Toast.LENGTH_SHORT).show() else process()
        }
        button(getString(R.string.back), false) { readFields(); goBack() }
        (etSrv ?: etLink)?.requestFocus()
    }

    private fun stepProcess() {
        ttl.setText(R.string.wz_s3)
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        c.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(56), dp(56)))
        val st = TextView(this).apply { setTextColor(Th.fg); textSize = 18f; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0); setText(R.string.wz_processing) }
        status = st; c.addView(st)
        body.addView(c, FrameLayout.LayoutParams(-1, -1))
        button(getString(R.string.cancel), false) { goBack() }.requestFocus()
    }

    private fun process() {
        step = 3; loading = true; render()
        val id = editing?.id ?: System.currentTimeMillis().toString()
        val n = Repo.playlists().size + 1
        val name = vName.ifBlank { if (mode == "xt") vSrv.removePrefix("http://").removePrefix("https://").substringBefore("/").substringBefore(":") else "Playlist $n" }
        val pl = Playlist(id, name, mode, vLink, vSrv, vUser, vPass, vLive, vVod)
        Repo.onStage = { k ->
            runOnUiThread { status?.text = getString(R.string.wz_processing) + "\n" + getString(if (k == "live") R.string.live else if (k == "movie") R.string.movies else R.string.series) }
        }
        Thread {
            val ok = Repo.load(true, pl)
            runOnUiThread {
                Repo.onStage = null; loading = false
                if (cancelled || isFinishing) { Repo.dirty = true; return@runOnUiThread }
                if (ok) {
                    val l = Repo.playlists().toMutableList()
                    val at = l.indexOfFirst { it.id == id }
                    if (at >= 0) l[at] = pl else l.add(pl)
                    Repo.savePlaylists(l); Repo.put("act", id)
                    Repo.dirty = false; Repo.loadEpg(true)
                    Toast.makeText(this, R.string.wz_done, Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Repo.dirty = true
                    status?.text = getString(R.string.wz_failed) + (if (Repo.err.isNotEmpty()) "\n" + Repo.err else "")
                    btns.removeAllViews()
                    button(getString(R.string.back), true) { step = 2; render() }.requestFocus()
                }
            }
        }.start()
    }

    // ---------------- from phone (QR code) ----------------
    private fun localIp(): String? {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress
            }
        } catch (e: Exception) { }
        return null
    }

    private fun h(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun webPage(): String {
        val rtl = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        return """<!doctype html><html dir="${if (rtl) "rtl" else "ltr"}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:sans-serif;background:#0f1233;color:#fff;margin:0;padding:22px}h2{margin-top:0}label{display:block;margin:14px 0 6px;color:#b9c4ff}
input,select{width:100%;box-sizing:border-box;padding:14px;border-radius:12px;border:1px solid #4b52a8;background:#1b1f5a;color:#fff;font-size:16px}
button{margin-top:22px;width:100%;padding:15px;border:0;border-radius:14px;background:#7c5cff;color:#fff;font-size:18px;font-weight:bold}</style></head><body>
<h2>${h(getString(R.string.add_pl))}</h2>
<form method="post" action="/">
<label>${h(getString(R.string.wz_type_title))}</label>
<select name="t" id="t" onchange="f()"><option value="m3u">M3U</option><option value="xt">Xtream Codes</option></select>
<div id="a"><label>${h(getString(R.string.wz_link))}</label><input name="l" type="url" autocapitalize="off"></div>
<div id="b" style="display:none"><label>${h(getString(R.string.wz_server))}</label><input name="s" placeholder="http://host:port" autocapitalize="off">
<label>${h(getString(R.string.wz_user))}</label><input name="u" autocapitalize="off"><label>${h(getString(R.string.wz_pass))}</label><input name="p" autocapitalize="off"></div>
<label>${h(getString(R.string.pl_name_opt))}</label><input name="n">
<button type="submit">${h(getString(R.string.wz_send))}</button></form>
<script>function f(){var x=document.getElementById('t').value;document.getElementById('a').style.display=x=='m3u'?'block':'none';document.getElementById('b').style.display=x=='xt'?'block':'none'}</script>
</body></html>"""
    }

    private fun phone() {
        stopServer()
        step = 2
        body.removeAllViews(); btns.removeAllViews()
        etLink = null; etSrv = null; etUser = null; etPass = null; etName = null; status = null
        updatePills()
        ttl.setText(R.string.wz_phone_title)
        val srv = PhoneServer({ webPage() }) { m ->
            runOnUiThread {
                if (isFinishing || loading) return@runOnUiThread
                mode = if (m["t"] == "xt") "xt" else "m3u"
                vLink = m["l"] ?: ""; vSrv = m["s"] ?: ""; vUser = m["u"] ?: ""; vPass = m["p"] ?: ""; vName = m["n"] ?: ""
                val ok = if (mode == "xt") vSrv.isNotBlank() && vUser.isNotBlank() && vPass.isNotBlank() else vLink.isNotBlank()
                if (ok) { stopServer(); process() }
            }
        }
        val ip = localIp()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        if (ip != null && srv.start()) {
            server = srv
            val url = "http://$ip:${srv.port}/"
            val size = 480
            val bm = QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, size, size)
            val px = IntArray(size * size)
            for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (bm.get(x, y)) Color.BLACK else Color.WHITE
            val bmp = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
            val iv = ImageView(this).apply { setImageBitmap(bmp); setBackgroundColor(Color.WHITE); setPadding(dp(10), dp(10), dp(10), dp(10)) }
            row.addView(iv, LinearLayout.LayoutParams(dp(210), dp(210)).apply { marginEnd = dp(26) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply { text = getString(R.string.wz_phone_sub2); setTextColor(Th.fg); textSize = 17f })
            col.addView(TextView(this).apply { text = url; setTextColor(Th.acc); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(12), 0, dp(12)) })
            col.addView(TextView(this).apply { text = getString(R.string.wz_phone_wait); setTextColor(Th.mut); textSize = 15f })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        } else {
            row.addView(TextView(this).apply { text = getString(R.string.wz_no_net); setTextColor(Th.fg); textSize = 18f })
        }
        body.addView(row, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER_VERTICAL))
        button(getString(R.string.back), true) { stopServer(); step = 1; render() }.requestFocus()
    }
}
