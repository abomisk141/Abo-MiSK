package com.sultv.app

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

data class PlaylistSubscription(val status: String, val expires: Long?, val unlimited: Boolean,
    val created: Long?, val trial: Boolean?, val connections: Int?, val maximum: Int?, val checked: Long) {
    fun remainingDays(now: Long = System.currentTimeMillis()): Long? = expires?.let {
        if (it <= now) 0 else (it - now + 86399999L) / 86400000L
    }
    fun expired(now: Long = System.currentTimeMillis()) = status == "expired" || expires?.let { it <= now } == true
}

object PlaylistSubscriptions {
    data class Endpoint(val server: String, val username: String, val password: String) {
        fun url(): String {
            fun enc(v: String) = URLEncoder.encode(v, "UTF-8")
            return "$server/player_api.php?username=${enc(username)}&password=${enc(password)}"
        }
    }
    fun endpoint(p: Playlist): Endpoint? {
        if (p.mode == "xt") {
            var server = p.xs.trim().trimEnd('/')
            if (!server.startsWith("http://") && !server.startsWith("https://")) server = "http://$server"
            val u = Uri.parse(server)
            if (u.scheme !in listOf("http", "https") || u.host.isNullOrBlank() || p.xu.isBlank() || p.xp.isBlank()) return null
            return Endpoint(server, p.xu, p.xp)
        }
        return try {
            val u = Uri.parse(p.m3u)
            if (u.scheme !in listOf("http", "https") || u.host.isNullOrBlank() || !u.path.orEmpty().endsWith("/get.php")) return null
            val name = u.getQueryParameter("username").orEmpty(); val password = u.getQueryParameter("password").orEmpty()
            if (name.isBlank() || password.isBlank()) return null
            val base = u.buildUpon().path(u.path!!.removeSuffix("/get.php")).clearQuery().fragment(null).build().toString().trimEnd('/')
            Endpoint(base, name, password)
        } catch (_: Exception) { null }
    }
    private fun identity(p: Playlist, includeAgent: Boolean = true): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest((p.id + "\u0000" + p.mode + "\u0000" + p.xs + "\u0000" + p.xu + "\u0000" + p.xp + "\u0000" + p.m3u + if (includeAgent) "\u0000" + RequestIdentity.userAgent() else "").toByteArray())
        .joinToString("") { "%02x".format(it) }
    private fun key(p: Playlist) = "subscription:" + identity(p)
    private fun manualKey(p: Playlist) = "subscriptionManual:" + identity(p, false)
    private fun epoch(value: Any?): Long? {
        val n = value?.toString()?.toLongOrNull() ?: return null
        if (n <= 0) return null
        val ms = if (n >= 1000000000000L) n else if (n <= 253402300799L) n * 1000 else return null
        return ms.takeIf { it <= 253402300799999L }
    }
    private fun flag(o: JSONObject, key: String): Boolean? = when (o.opt(key)?.toString()?.lowercase(Locale.ROOT)) {
        "1", "true" -> true; "0", "false" -> false; else -> null
    }
    fun parse(o: JSONObject, now: Long = System.currentTimeMillis()): PlaylistSubscription {
        val user = o.optJSONObject("user_info") ?: throw IllegalArgumentException("Unsupported account response")
        val auth = flag(user, "auth")
        val status = if (auth == false) "denied" else when (user.optString("status").lowercase(Locale.ROOT)) {
            "active" -> "active"; "expired" -> "expired"; "banned" -> "banned"; "disabled" -> "disabled"; else -> "unknown"
        }
        val expiry = epoch(user.opt("exp_date"))
        val noLimit = status == "active" && user.has("exp_date") &&
            (user.isNull("exp_date") || user.optString("exp_date").isBlank())
        fun count(k: String) = user.optString(k).toIntOrNull()?.takeIf { it >= 0 }
        return PlaylistSubscription(status, expiry, noLimit, epoch(user.opt("created_at")), flag(user, "is_trial"), count("active_cons"), count("max_connections"), now)
    }
    fun fetch(p: Playlist): PlaylistSubscription {
        val endpoint = endpoint(p) ?: throw IllegalArgumentException("No account endpoint")
        val connection = URL(endpoint.url()).openConnection() as HttpURLConnection
        connection.connectTimeout = 8000; connection.readTimeout = 10000
        connection.setRequestProperty("User-Agent", RequestIdentity.userAgent())
        try {
            if (connection.responseCode !in 200..299) throw java.io.IOException("Account request failed")
            val text = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream(); val bytes = ByteArray(8192)
                while (true) { val n = input.read(bytes); if (n < 0) break; if (output.size() + n > 512 * 1024) throw java.io.IOException(); output.write(bytes, 0, n) }
                String(output.toByteArray(), Charsets.UTF_8)
            }
            val account = parse(JSONObject(text))
            val saved = JSONObject().put("status", account.status).put("expires", account.expires ?: JSONObject.NULL)
                .put("unlimited", account.unlimited).put("created", account.created ?: JSONObject.NULL)
                .put("trial", account.trial ?: JSONObject.NULL).put("connections", account.connections ?: JSONObject.NULL)
                .put("maximum", account.maximum ?: JSONObject.NULL).put("checked", account.checked)
            Repo.put(key(p), saved.toString())
            return account
        } finally { connection.disconnect() }
    }
    fun cached(p: Playlist): PlaylistSubscription? = try {
        val o = JSONObject(Repo.s(key(p)))
        fun long(k: String) = if (o.isNull(k)) null else o.optLong(k).takeIf { it > 0 }
        fun int(k: String) = if (o.isNull(k)) null else o.optInt(k).takeIf { it >= 0 }
        PlaylistSubscription(o.optString("status", "unknown"), long("expires"), o.optBoolean("unlimited"), long("created"),
            if (o.isNull("trial")) null else o.optBoolean("trial"), int("connections"), int("maximum"), o.getLong("checked"))
    } catch (_: Exception) { null }

    fun manual(p: Playlist): Long? = try {
        val parts = Repo.s(manualKey(p)).split('-').map { it.toInt() }
        Calendar.getInstance().apply {
            isLenient = false; clear(); set(parts[0], parts[1] - 1, parts[2], 0, 0, 0)
            timeInMillis; add(Calendar.DAY_OF_MONTH, 1)
        }.timeInMillis
    } catch (_: Exception) { null }
    fun setManual(p: Playlist, year: Int, month: Int, day: Int) { Repo.put(manualKey(p), "$year-${month + 1}-$day") }
    fun clearManual(p: Playlist) { Repo.sp.edit().remove(manualKey(p)).apply() }
}
