package com.sultv.app

/** Shared by playback and subscription downloads so providers see the same identity. */
object RequestIdentity {
    const val DEFAULT = "Mozilla/5.0"
    data class Preset(val name: String, val value: String)
    val presets = listOf(
        Preset("VLC", "VLC/3.0.20 LibVLC/3.0.20"),
        Preset("Chrome", "Mozilla/5.0 (Linux; Android 11; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"),
        Preset("OkHttp", "okhttp/4.12.0")
    )
    fun valid(value: String) = value.length <= 512 && value.all { it.code in 32..126 }
    fun resolve(value: String): String = if (valid(value) && value.isNotBlank()) value.trim() else DEFAULT
    fun userAgent() = resolve(Repo.s("userAgent"))
}
