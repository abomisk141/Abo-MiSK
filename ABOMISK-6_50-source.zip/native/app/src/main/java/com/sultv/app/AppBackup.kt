package com.sultv.app

import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Portable, authenticated backup. Playlist caches and diagnostic messages are excluded. */
object AppBackup {
    const val MAX_BYTES = 16 * 1024 * 1024
    private const val ROUNDS = 210000
    private const val MAGIC = "ABOMISK-BACKUP"
    private val aad = "$MAGIC:1".toByteArray(Charsets.UTF_8)
    private val setKeys = setOf("fav", "hid", "hc_live", "hc_movie", "hc_series", "lc_live", "lc_movie", "lc_series")
    private fun portable(k: String) = k != "crash" && k != "pl_last_refresh" && !k.startsWith("st:")
    class InvalidBackup : Exception()
    data class Snapshot(val values: Map<String, Any>, val created: Long) {
        val favourites get() = (values["fav"] as? Set<*>)?.size ?: 0
        val playlists get() = JSONArray(values["pls"] as? String ?: "[]").length()
    }

    fun read(input: InputStream): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            if (output.size() + n > MAX_BYTES) throw InvalidBackup()
            output.write(buffer, 0, n)
        }
        return output.toByteArray()
    }

    private fun key(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, ROUNDS, 256)
        try {
            val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
            return try { SecretKeySpec(raw, "AES") } finally { raw.fill(0) }
        } finally { spec.clearPassword() }
    }

    fun export(preferences: SharedPreferences, password: CharArray): ByteArray {
        require(password.size in 8..256)
        val data = JSONObject()
        for ((k, v) in preferences.all) {
            if (!portable(k)) continue
            when (v) {
                is String -> data.put(k, JSONObject().put("type", "string").put("value", v))
                is Set<*> -> data.put(k, JSONObject().put("type", "set").put("value", JSONArray(v.sortedBy { it.toString() })))
                else -> throw InvalidBackup()
            }
        }
        val plain = JSONObject().put("schema", 1).put("created", System.currentTimeMillis()).put("values", data)
            .toString().toByteArray(Charsets.UTF_8)
        try {
            if (plain.size > MAX_BYTES / 2) throw InvalidBackup()
            val salt = ByteArray(16); val iv = ByteArray(12)
            SecureRandom().apply { nextBytes(salt); nextBytes(iv) }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
            cipher.updateAAD(aad)
            fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
            return JSONObject().put("format", MAGIC).put("version", 1).put("salt", b64(salt))
                .put("iv", b64(iv)).put("data", b64(cipher.doFinal(plain))).toString().toByteArray(Charsets.UTF_8)
        } finally { plain.fill(0) }
    }

    fun decode(bytes: ByteArray, password: CharArray): Snapshot {
        if (bytes.size > MAX_BYTES) throw InvalidBackup()
        val plain = try {
            val o = JSONObject(String(bytes, Charsets.UTF_8))
            if (o.getString("format") != MAGIC || o.getInt("version") != 1) throw InvalidBackup()
            fun b64(k: String) = Base64.decode(o.getString(k), Base64.NO_WRAP)
            val salt = b64("salt"); val iv = b64("iv"); val data = b64("data")
            if (salt.size != 16 || iv.size != 12 || data.size < 16) throw InvalidBackup()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
            cipher.updateAAD(aad)
            cipher.doFinal(data)
        } catch (_: Exception) { throw InvalidBackup() }
        return try {
            val o = JSONObject(String(plain, Charsets.UTF_8))
            if (o.getInt("schema") != 1) throw InvalidBackup()
            val result = LinkedHashMap<String, Any>()
            val values = o.getJSONObject("values")
            if (values.length() > 100000) throw InvalidBackup()
            for (k in values.keys()) {
                if (!portable(k) || k.length > 8192) throw InvalidBackup()
                val item = values.getJSONObject(k)
                result[k] = if (k in setKeys) {
                    if (item.getString("type") != "set") throw InvalidBackup()
                    val a = item.getJSONArray("value")
                    (0 until a.length()).map { i -> a.get(i) as? String ?: throw InvalidBackup() }.toSet()
                } else {
                    if (item.getString("type") != "string") throw InvalidBackup()
                    item.get("value") as? String ?: throw InvalidBackup()
                }
            }
            // Validate account JSON before offering a restore; never trust file-controlled paths.
            val playlists = JSONArray(result["pls"] as? String ?: "[]")
            val ids = HashSet<String>()
            for (i in 0 until playlists.length()) {
                val p = playlists.getJSONObject(i); val id = p.getString("id")
                if (!id.matches(Regex("[A-Za-z0-9_-]{1,128}")) || !ids.add(id)) throw InvalidBackup()
                if (p.getString("mode") !in setOf("xt", "m3u")) throw InvalidBackup()
            }
            result["ovr"]?.let { JSONObject(it as String) }
            result["catren"]?.let { JSONObject(it as String) }
            Snapshot(result, o.getLong("created"))
        } catch (_: Exception) { throw InvalidBackup() } finally { plain.fill(0) }
    }

    fun restore(preferences: SharedPreferences, snapshot: Snapshot) {
        val old = preferences.all
        fun write(values: Map<String, *>) : Boolean {
            val e = preferences.edit().clear()
            for ((k, v) in values) when (v) {
                is String -> e.putString(k, v)
                is Set<*> -> { @Suppress("UNCHECKED_CAST") e.putStringSet(k, v as Set<String>) }
                else -> throw InvalidBackup()
            }
            return e.commit()
        }
        if (!write(snapshot.values)) { write(old); throw java.io.IOException() }
    }
}
