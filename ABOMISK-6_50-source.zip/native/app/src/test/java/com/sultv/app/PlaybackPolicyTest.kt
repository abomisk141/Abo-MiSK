package com.sultv.app

import androidx.media3.common.C
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PlaybackPolicyTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication())
        Repo.sp.edit().clear().commit()
    }
    @Test fun vodBufferChoiceDoesNotAddLatencyToLivePlayback() {
        Repo.put("buf", "h")
        val liveWithLargeVodBuffer = PlaybackPolicy.liveProfile()
        Repo.put("buf", "l")
        assertEquals(liveWithLargeVodBuffer, PlaybackPolicy.liveProfile())
        val p = PlaybackPolicy.liveProfile()
        assertTrue(p.startBufferMs < p.minBufferMs)
        assertTrue(p.rebufferMs <= p.minBufferMs)
        assertTrue(p.minBufferMs < p.maxBufferMs)
    }
    @Test fun liveModeChangesHlsStartingOffsetButLeavesVodMediaItemsUntouched() {
        val url = "https://example.test/channel.m3u8?token=example"
        Repo.put("liveLatency", "fast")
        val fast = PlaybackPolicy.mediaItem(url, true)
        val vod = PlaybackPolicy.mediaItem(url, false)
        Repo.put("liveLatency", "stable")
        val stable = PlaybackPolicy.mediaItem(url, true)
        assertTrue(fast.liveConfiguration.targetOffsetMs < stable.liveConfiguration.targetOffsetMs)
        assertEquals(1f, fast.liveConfiguration.minPlaybackSpeed)
        assertTrue(fast.liveConfiguration.maxPlaybackSpeed > 1f)
        assertEquals(url, fast.localConfiguration!!.uri.toString())
        assertEquals(url, stable.localConfiguration!!.uri.toString())
        assertEquals(C.TIME_UNSET, vod.liveConfiguration.targetOffsetMs)
        assertEquals(vod, PlaybackPolicy.mediaItem(url, false))
        for (mode in listOf("fast", "balanced", "stable")) {
            val p = PlaybackPolicy.liveProfile(mode)
            assertTrue(p.maxBufferMs >= p.minBufferMs && p.minBufferMs >= p.rebufferMs)
            assertTrue(p.targetOffsetMs > 0)
        }
    }
    @Test fun xtreamFormatPreferenceNeverRewritesUserM3uUrls() {
        for (format in listOf("ts", "m3u8")) {
            Repo.put("liveFormat", format)
            for (url in listOf("https://example.test/stream.m3u8?quality=hd", "https://example.test/stream.ts?token=example")) {
                val entry = Item("raw", "Channel", "", "Live", "live", u = url)
                assertEquals(url, entry.url)
                assertEquals(url, PlaybackPolicy.mediaItem(entry.url, true).localConfiguration!!.uri.toString())
            }
            assertEquals(format, PlaybackPolicy.xtreamLiveExtension())
        }
        Repo.put("liveFormat", "unknown")
        assertEquals("m3u8", PlaybackPolicy.xtreamLiveExtension())
    }
    @Test fun playerFactoriesKeepAudioPreferencesForBothLiveAndVod() {
        Repo.put("alang", "ar")
        for (live in listOf(false, true)) {
            val player = makePlayer(RuntimeEnvironment.getApplication(), live)
            try {
                assertTrue(player.trackSelectionParameters.preferredAudioLanguages.contains("ar"))
                val item = PlaybackPolicy.mediaItem("https://example.test/media.m3u8", live)
                player.setMediaItem(item)
                assertEquals(item, player.currentMediaItem)
            } finally { player.release() }
        }
    }
}
