package com.sultv.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class StatsGuideTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.putB("autoPrev", false)
        Repo.putB("referenceLayoutV52", true); Repo.updChecked = true; Repo.dirty = false; Repo.put("pl_refresh_hours", "0")
    }
    private fun field(a: Any, name: String) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun layout(root: View) {
        root.measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
        root.layout(0, 0, 960, 540); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))
    }
    private fun screenshot(root: View, file: String, crop: Rect? = null) {
        val bitmap = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888); root.draw(Canvas(bitmap))
        val output = if (crop != null) Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height()) else bitmap
        File("build/stats-guide-previews/$file.png").apply { parentFile?.mkdirs() }.outputStream().use { output.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (output !== bitmap) output.recycle(); bitmap.recycle()
    }
    @Test fun allSixStatsHaveIconsAndStayVisibleWithNormalAndLargeFontsInBothLanguages() {
        for (lang in listOf("en", "ar")) for (size in listOf("1.0", "1.3")) {
            Repo.put("lang", lang); Repo.put("ts", size); Repo.put("liveplayer", "full")
            val context = RuntimeEnvironment.getApplication()
            val controller = Robolectric.buildActivity(PlayerActivity::class.java, Intent(context, PlayerActivity::class.java)
                .putExtra("url", "file:///stats-preview.mp4").putExtra("name", "Preview").putExtra("live", true)).create().start().resume().visible()
            val a = controller.get(); val root = a.window.decorView
            try {
                layout(root)
                val chips = listOf("chDl", "chUl", "chLat", "chBr", "chFr", "chQuality").map { field(a, it) as TextView }
                val labels = listOf(R.string.dl, R.string.ul, R.string.lat, R.string.bitrate, R.string.frames, R.string.stat_quality)
                val values = listOf("8.4 Mb/s", "12 kb/s", "48 ms", "6200 kb/s", "50 fps", "FHD 1080p (1920×1080)")
                chips.forEachIndexed { n, chip ->
                    chip.text = a.getString(labels[n]) + "\n" + values[n]
                    assertNotNull(chip.compoundDrawablesRelative[0]); assertTrue(chip.compoundDrawablesRelative[0].bounds.width() > 0)
                }
                (field(a, "ovName") as TextView).text = if (lang == "ar") "معاينة مؤشرات البث" else "Playback statistics preview"
                (field(a, "ovNow") as TextView).text = if (lang == "ar") "قيم توضيحية، وليست قياسًا فعليًا" else "Illustrative values, not a live measurement"
                (field(a, "ovNum") as TextView).text = "12"
                (field(a, "ovLogo") as ImageView).setImageResource(R.drawable.logo)
                repeat(2) { layout(root) }
                val overlay = field(a, "ov") as View; overlay.visibility = View.VISIBLE
                (field(a, "recoveryBox") as View).visibility = View.GONE
                val rect = Rect()
                chips.forEach { assertTrue(it.getGlobalVisibleRect(rect)); assertEquals(it.height, rect.height()); assertEquals(it.width, rect.width()) }
                if (lang == "ar" && size == "1.0") screenshot(root, "stats-icons-ar", Rect(0, overlay.top, root.width, overlay.bottom))
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun glassStatsUseIconsWithoutChangingTheDisplayedMetrics() {
        Repo.put("liveplayer", "glass")
        val context = RuntimeEnvironment.getApplication()
        val controller = Robolectric.buildActivity(PlayerActivity::class.java, Intent(context, PlayerActivity::class.java).putExtra("url", "file:///stats-glass.mp4").putExtra("live", true)).create()
        val a = controller.get()
        try {
            PlayerActivity::class.java.getDeclaredMethod("stats").apply { isAccessible = true }.invoke(a)
            val text = (field(a, "ovStat") as TextView).text as android.text.Spanned
            assertEquals(4, text.getSpans(0, text.length, android.text.style.ImageSpan::class.java).size)
        } finally { controller.destroy() }
    }
    @Test fun twoProgrammeGuideBrowsesFutureAndKeepsRemoteFocusInEnglish() = guide("en")
    @Test fun twoProgrammeGuideBrowsesFutureAndKeepsRemoteFocusInArabic() = guide("ar")
    private fun guide(lang: String) {
        Repo.put("lang", lang)
        Repo.savePlaylists(listOf(Playlist("guide", "Fixture", "m3u", "https://example.test/list.m3u", "", "", "")))
        Repo.items = (0 until 60).map { Item("ch-$it", "Channel $it", "", "Live", "live", u = "https://example.test/$it.ts", epg = "guide-$it") }
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo); Repo.dirty = false
        val base = System.currentTimeMillis().let { it - it % 1800000L }
        Repo.epg = (0 until 60).associate { n -> "guide-$n" to (0 until 24).map { t -> Prog(base + t * 1800000L, base + (t + 1) * 1800000L, "Programme $t") } }
        assertEquals(2, EPG_VISIBLE_PROGRAMMES)
        for (design in Designs.ids) {
            Repo.put("ui", design)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get(); val root = a.window.decorView
            try {
                MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, "live")
                repeat(5) { layout(root) }
                val list = field(a, "rv") as RecyclerView
                val row = list.findViewHolderForAdapterPosition(0)!!.itemView
                assertTrue(row.requestFocusFromTouch())
                val start = field(a, "ws") as Long
                val towardGuide = if (lang == "en") KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, towardGuide))
                assertTrue("$design/$lang: enter guide", list.findFocus() is EpgView)
                repeat(3) { a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT)) }
                assertEquals(start + 3 * 1800000L, field(a, "ws"))
                (field(a, "tickRun") as Runnable).run(); layout(root)
                assertEquals("Minute refresh must not reset the requested time", start + 3 * 1800000L, field(a, "ws"))
                repeat(40) { n -> a.dispatchKeyEvent(KeyEvent(0, n * 6L, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, n)); assertTrue(list.hasFocus()) }
                repeat(6) { layout(root) }
                assertTrue("$design/$lang: retain guide focus while rows attach", list.findFocus() is EpgView)
                assertEquals(start + 3 * 1800000L, field(a, "ws"))
                if (design == "reference" && lang == "ar") screenshot(root, "two-programme-guide-ar")
                a.onBackPressedDispatcher.onBackPressed(); repeat(2) { layout(root) }
                assertFalse(list.findFocus() is EpgView)
                assertTrue(list.hasFocus()); assertEquals(false, field(a, "guideBrowsing"))
                val side = if (lang == "en") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, side)); layout(root)
                assertTrue((field(a, "sideRv") as RecyclerView).hasFocus())
            } finally { controller.pause().stop().destroy() }
        }
    }
}
