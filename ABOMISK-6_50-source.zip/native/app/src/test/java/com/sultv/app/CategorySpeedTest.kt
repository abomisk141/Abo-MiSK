package com.sultv.app

import android.os.Looper
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class CategorySpeedTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("referenceLayoutV52", true); Repo.putB("autoUpd", false); Repo.putB("autoPrev", false)
        Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.put("pl_refresh_hours", "0"); Repo.updChecked = true
    }
    private fun build(items: List<Item>) {
        Repo.items = items
        Repo::class.java.getDeclaredField("rawItems").apply { isAccessible = true }.set(Repo, items)
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo)
        Repo.dirty = false
    }
    private fun field(a: MainActivity, name: String) = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun layout(a: MainActivity) {
        a.window.decorView.apply { measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY)); layout(0, 0, 960, 540) }
        shadowOf(Looper.getMainLooper()).idle()
    }
    private fun waitFor(a: MainActivity, condition: () -> Boolean) {
        val deadline = System.nanoTime() + 6_000_000_000L
        do { layout(a); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(16)); Thread.sleep(2) } while (!condition() && System.nanoTime() < deadline)
        assertTrue("Timed out: category=${field(a, "cat")}", condition())
    }
    @Test fun sixHundredFastCategoryFocusChangesOnlyPublishTheFinalCategoryInEnglish() = rapid("en", "reference", false)
    @Test fun sixHundredFastCategoryFocusChangesOnlyPublishTheFinalCategoryInArabicWithGroupedPlaylists() = rapid("ar", "cinema", true)
    private fun rapid(lang: String, style: String, grouped: Boolean) {
        Repo.put("lang", lang); Repo.put("ui", style)
        val one = Playlist("fixture", "Dino", "m3u", "https://example.test/list.m3u", "", "", "")
        Repo.savePlaylists(if (grouped) listOf(one, one.copy(id = "second", name = "Dream")) else listOf(one))
        build((0 until 2000).flatMap { group -> (0 until 10).map { n ->
            Item("$group:$n", "Channel $group-$n", "", "Group" + group.toString().padStart(4, '0'), "live", u = "file:///$group-$n.ts")
        } })
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
        try {
            MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, "live")
            waitFor(a) { field(a, "filtering") == false }
            val grid = field(a, "rv") as RecyclerView; val side = field(a, "sideRv") as RecyclerView
            assertEquals(20000, grid.adapter!!.itemCount)
            val events = AtomicInteger(); val global = AtomicInteger()
            grid.adapter!!.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
                override fun onChanged() { global.incrementAndGet() }
                override fun onItemRangeInserted(positionStart: Int, itemCount: Int) { events.incrementAndGet() }
                override fun onItemRangeRemoved(positionStart: Int, itemCount: Int) { events.incrementAndGet() }
            })
            @Suppress("UNCHECKED_CAST") val cats = field(a, "cats") as List<MainActivity.Cat>
            for (group in 1..600) {
                val key = "Group" + group.toString().padStart(4, '0')
                val index = cats.indexOfFirst { it.key == key && !it.header }
                val mode = side.descendantFocusability; side.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                side.requestFocusFromTouch(); side.scrollToPosition(index); layout(a)
                side.descendantFocusability = mode
                val row = side.findViewHolderForAdapterPosition(index)!!.itemView
                assertTrue(row.requestFocusFromTouch())
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(1))
            }
            assertEquals("Hovering past categories must not publish intermediate datasets", 0, events.get())
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(220))
            waitFor(a) { field(a, "filtering") == false && field(a, "cat") == "Group0600" }
            assertEquals(10, grid.adapter!!.itemCount)
            @Suppress("UNCHECKED_CAST") val data = field(a, "data") as List<Item>
            assertTrue(data.all { it.grp == "Group0600" })
            assertTrue(side.hasFocus()); assertEquals(0, global.get())
            assertEquals("Only remove the old scope and insert the final scope", 2, events.get())
        } finally { controller.pause().stop().destroy() }
    }
    @Test fun pressingOkOnThePendingCategoryCancelsOldWorkAndEntersItsActualContent() {
        Repo.savePlaylists(listOf(Playlist("fixture", "Fixture", "m3u", "https://example.test/list.m3u", "", "", "")))
        build((0 until 2000).map { Item("$it", "Channel $it", "", "Group$it", "live", u = "file:///$it.ts") })
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
        val started = CountDownLatch(1); val stopped = CountDownLatch(1)
        try {
            MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, "live")
            waitFor(a) { field(a, "filtering") == false }
            (field(a, "filterWork") as LatestWork).submit {
                started.countDown()
                try { CountDownLatch(1).await() } finally { stopped.countDown() }
            }
            assertTrue(started.await(2, TimeUnit.SECONDS))
            MainActivity::class.java.getDeclaredField("cat").apply { isAccessible = true }.set(a, "Group600")
            for (name in listOf("filtering", "filteringCategoryPreview")) MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.setBoolean(a, true)
            val side = field(a, "sideRv") as RecyclerView
            @Suppress("UNCHECKED_CAST") val cats = field(a, "cats") as List<MainActivity.Cat>
            val pos = cats.indexOfFirst { it.key == "Group600" }
            side.scrollToPosition(pos); layout(a)
            val row = side.findViewHolderForAdapterPosition(pos)!!.itemView
            assertTrue(row.requestFocusFromTouch()); row.performClick()
            assertTrue(stopped.await(2, TimeUnit.SECONDS))
            val grid = field(a, "rv") as RecyclerView
            waitFor(a) { field(a, "filtering") == false && grid.hasFocus() }
            assertEquals("Group600", field(a, "cat")); assertEquals(1, grid.adapter!!.itemCount)
            @Suppress("UNCHECKED_CAST") val data = field(a, "data") as List<Item>
            assertEquals("600", data.single().id)
        } finally { controller.pause().stop().destroy() }
    }
    @Test fun obsoleteDiffCanBeInterruptedSoNewestWorkDoesNotWaitForIt() {
        val running = CountDownLatch(1); val latest = CountDownLatch(1); val worker = LatestWork()
        try {
            worker.submit { ListUpdates.diff((0 until 30000).toList(), (30000 until 60000).toList(), { a, b -> running.countDown(); a == b }) }
            assertTrue(running.await(2, TimeUnit.SECONDS))
            worker.submit { latest.countDown() }
            assertTrue("Newest request was blocked by obsolete diff", latest.await(2, TimeUnit.SECONDS))
        } finally { worker.close() }
    }
    @Test fun categoryIndexUsesVisibleItemsAndRebuildsForRenameAndRestoredCatalogues() {
        val source = listOf(
            Item("a", "A", "", "News", "live", u = "file:///a"), Item("b", "B", "", "News", "live", u = "file:///b"),
            Item("m", "Movie", "", "Action", "movie", u = "file:///m"),
            Item("e1", "Show S01E01", "", "Drama", "series", u = "file:///e1", show = "Show"),
            Item("e2", "Show S01E02", "", "Drama", "series", u = "file:///e2", show = "Show"))
        build(source)
        assertEquals(2, Repo.list("live", "News").size)
        assertEquals(1, Repo.list("series", "Drama").size)
        Repo.hide("a"); assertEquals(listOf("b"), Repo.list("live", "News").map { it.id })
        Repo.setHiddenCats("live", setOf("News")); assertTrue(Repo.list("live", "News").isEmpty())
        Repo.clearHidden(); Repo.setPin("1234"); Repo.setLockedCats("live", setOf("News"))
        assertTrue(Repo.list("live", "News").isEmpty()); Repo.unlock("live", "News")
        assertEquals(2, Repo.list("live", "News").size)
        Repo.renameCat("movie", "Action", "Renamed")
        assertFalse(Repo.hasCategory("movie", "Action")); assertEquals(1, Repo.list("movie", "Renamed").size)
        Repo.afterBackupRestore(); assertFalse(Repo.hasCategory("movie", "Renamed")); assertTrue(Repo.list("movie", "Renamed").isEmpty())
    }
}
