package com.sultv.app

import android.app.Dialog
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class CategoryVisibilityTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit()
        Repo.put("lang", "en"); Th.load()
    }
    private fun views(v: View): List<View> = listOf(v) + if (v is ViewGroup)
        (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
    private fun click(d: Dialog, title: String) {
        views(d.window!!.decorView).filterIsInstance<Button>().first { it.text.toString() == title }.performClick()
    }

    @Test fun selectAllShowsCurrentCategoriesAndPreservesHiddenGroupsMissingFromCatalogue() {
        val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup()
        val a = controller.get()
        Repo.setHiddenCats("movie", setOf("Movie category"))
        Repo.setHiddenCats("live", setOf("Sport", "Old missing category"))
        val d = ModernDialogs.categoryVisibility(a, "Live", listOf("Sport", "News"), Repo.hiddenCats("live")) {
            Repo.setHiddenCats("live", it)
        }
        try {
            click(d, a.getString(R.string.category_select_all))
            assertTrue("Sport" in Repo.hiddenCats("live")) // still pending until Save
            click(d, a.getString(R.string.save))
            assertEquals(setOf("Old missing category"), Repo.hiddenCats("live"))
            assertEquals(setOf("Movie category"), Repo.hiddenCats("movie"))
        } finally { d.dismiss(); controller.pause().stop().destroy() }
    }

    @Test fun deselectAllCanBeCancelledWithoutChangingVisibility() {
        val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup()
        val a = controller.get()
        var result: Set<String>? = null
        val d = ModernDialogs.categoryVisibility(a, "Live", listOf("Sport", "News"), setOf("News")) { result = it }
        try {
            click(d, a.getString(R.string.category_deselect_all))
            click(d, a.getString(R.string.no))
            assertNull(result)
        } finally { d.dismiss(); controller.pause().stop().destroy() }
    }

    @Test fun individualSelectionAfterDeselectAllKeepsOnlyTheChosenCategoryVisible() {
        val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup()
        val a = controller.get()
        var result: Set<String>? = null
        val d = ModernDialogs.categoryVisibility(a, "Series", listOf("Drama", "Comedy", "Kids"), emptySet()) { result = it }
        try {
            click(d, a.getString(R.string.category_deselect_all))
            val list = views(d.window!!.decorView).filterIsInstance<ListView>().single()
            list.performItemClick(null, 1, 1)
            click(d, a.getString(R.string.save))
            assertEquals(setOf("Drama", "Kids"), result)
        } finally { d.dismiss(); controller.pause().stop().destroy() }
    }
}
