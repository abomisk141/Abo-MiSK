package com.sultv.app

import android.content.Intent
import android.graphics.Rect
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowDialog
import java.net.ServerSocket
import java.time.Duration
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class PlaybackMenusTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.updChecked = true
    }
    private fun views(v: View): List<View> = listOf(v) + if (v is ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
    private fun layout(d: android.app.Dialog) {
        val root = d.window!!.decorView
        root.measure(View.MeasureSpec.makeMeasureSpec(d.window!!.attributes.width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(d.window!!.attributes.height, View.MeasureSpec.EXACTLY))
        root.layout(0, 0, root.measuredWidth, root.measuredHeight)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))
    }
    private fun screenshot(d: android.app.Dialog, name: String) {
        val root = d.window!!.decorView
        val bitmap = android.graphics.Bitmap.createBitmap(root.width, root.height, android.graphics.Bitmap.Config.ARGB_8888)
        root.draw(android.graphics.Canvas(bitmap))
        val folder = java.io.File("build/playback-previews").apply { mkdirs() }
        java.io.FileOutputStream(java.io.File(folder, "$name.png")).use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
    }
    private fun waitFor(d: android.app.Dialog, condition: () -> Boolean) {
        val end = System.nanoTime() + 5_000_000_000L
        do { layout(d); Thread.sleep(3) } while (!condition() && System.nanoTime() < end)
        assertTrue("Timed out waiting for playback menu", condition())
    }
    @Test fun modernOptionsScrollWithLargeFontsAndExecuteTheSelectedActionInBothLanguages() {
        for (lang in listOf("en", "ar")) for (size in listOf("1.0", "1.3")) {
            Repo.put("lang", lang); Repo.put("ts", size)
            val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup(); val a = controller.get()
            var result = -1
            val entries = (0 until 25).map { n -> PlaybackMenus.Entry("Option $n", "Channel · Dino", if (n < 12) "Video" else "Audio", R.drawable.ic_audio_wave, n == 2) { result = n } }
            val d = PlaybackMenus.options(a, a.getString(R.string.track_menu), "Channel · Dino", entries)
            try {
                layout(d)
                val last = d.window!!.decorView.findViewWithTag<View>("playback-option:Option 24")
                assertTrue(last.requestFocusFromTouch()); repeat(4) { layout(d) }
                val rect = Rect(); assertTrue(last.getGlobalVisibleRect(rect)); assertEquals(last.height, rect.height())
                val close = views(d.window!!.decorView).filterIsInstance<android.widget.Button>().single()
                assertTrue(close.getGlobalVisibleRect(rect)); assertEquals(close.height, rect.height())
                assertTrue(last.performClick()); assertEquals(24, result); assertFalse(d.isShowing)
            } finally { d.dismiss(); controller.pause().stop().destroy() }
        }
    }
    @Test fun playerAutoQualityActionStillClearsOverridesWithoutReplacingTheStream() {
        val context = RuntimeEnvironment.getApplication()
        val controller = Robolectric.buildActivity(PlayerActivity::class.java, Intent(context, PlayerActivity::class.java).putExtra("url", "file:///no-test-video.mp4").putExtra("name", "Test")).create()
        val a = controller.get()
        val player = PlayerActivity::class.java.getDeclaredField("player").apply { isAccessible = true }.get(a) as ExoPlayer
        try {
            val group = TrackGroup(Format.Builder().setSampleMimeType(MimeTypes.VIDEO_H264).setHeight(1080).build())
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setOverrideForType(TrackSelectionOverride(group, 0)).build()
            val original = player.currentMediaItem
            PlayerActivity::class.java.getDeclaredMethod("tracksDialog").apply { isAccessible = true }.invoke(a)
            val d = ShadowDialog.getLatestDialog(); layout(d)
            assertNotNull(d.window!!.decorView.findViewWithTag<View>("playback-options"))
            screenshot(d, "player-options")
            d.window!!.decorView.findViewWithTag<View>("playback-option:${a.getString(R.string.q_auto)}").performClick()
            assertTrue(player.trackSelectionParameters.overrides.values.none { it.type == C.TRACK_TYPE_VIDEO })
            assertEquals(original, player.currentMediaItem)
        } finally { controller.destroy() }
    }
    private fun install(fixture: XtreamFixture): Pair<Playlist, Playlist> {
        val one = Playlist("dino", "Dino", "xt", "", fixture.url, "first", "first-pass", vod = false)
        val two = Playlist("dream", "Dream", "xt", "", fixture.url, "second", "second-pass", vod = false)
        Repo.savePlaylists(listOf(one, two)); Repo.put("act", one.id); assertTrue(Repo.load()); Repo.dirty = false
        return one to two
    }
    @Test fun otherPlaylistAudioUrlsArePinnedToTheirOwnAccountWithoutChangingVideo() {
        XtreamFixture().use { fixture ->
            val (one, two) = install(fixture)
            val original = Repo.items; val version = Repo.catalogueVersion
            for (format in listOf("ts", "m3u8")) {
                Repo.put("liveFormat", format)
                val videoUrl = Repo.list("live").single().url
                val candidate = Repo.audioChannels(two)!!.single()
                assertEquals("Dream", candidate.playlistName); assertEquals("dream", candidate.playlistId)
                assertTrue(candidate.item.url.endsWith("/live/second/second-pass/42.$format"))
                assertTrue(videoUrl.endsWith("/live/first/first-pass/42.$format"))
                assertEquals(one, Repo.active()); assertEquals(original, Repo.items); assertEquals(version, Repo.catalogueVersion)
                assertEquals(videoUrl, Repo.list("live").single().url)
            }
            assertEquals(2, fixture.liveDownloads.get())
            Repo.setPlaylistVisible(two.id, false)
            assertTrue(Repo.audioChannels(two)!!.isEmpty()); assertEquals(2, fixture.liveDownloads.get())
        }
    }
    @Test fun audioPickerShowsPlaylistUnderDuplicateChannelNameAndSelectsItsCorrectUrl() {
        XtreamFixture().use { fixture ->
            val (_, two) = install(fixture); Repo.put("liveFormat", "ts"); Repo.put("lang", "ar")
            val originalUrl = Repo.list("live").single().url
            val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup(); val a = controller.get()
            var chosen: AudioChannel? = null
            val d = PlaybackMenus.audio(a, originalUrl, null, { chosen = it }, {})
            try {
                d.window!!.decorView.findViewWithTag<View>("audio-playlist").performClick()
                val menu = ShadowDialog.getLatestDialog(); layout(menu)
                menu.window!!.decorView.findViewWithTag<View>("playback-option:Dream").performClick()
                val list = d.window!!.decorView.findViewWithTag<ListView>("audio-channel-list")
                waitFor(d) { list.adapter.count == 1 }
                screenshot(d, "audio-picker-source")
                val row = list.adapter.getView(0, null, list)
                val labels = views(row).filterIsInstance<TextView>().map { it.text.toString() }
                assertTrue("Shared channel" in labels); assertTrue("Dream" in labels)
                list.performItemClick(null, 0, 0)
                assertEquals(two.id, chosen!!.playlistId)
                assertTrue(chosen!!.item.url.endsWith("/live/second/second-pass/42.ts"))
                assertEquals("dino", Repo.active()!!.id); assertEquals(originalUrl, Repo.list("live").single().url)
            } finally { d.dismiss(); controller.pause().stop().destroy() }
        }
    }
    private class XtreamFixture : AutoCloseable {
        private val socket = ServerSocket(0)
        @Volatile private var running = true
        val liveDownloads = AtomicInteger()
        val url = "http://127.0.0.1:${socket.localPort}"
        private val thread = Thread {
            while (running) try { socket.accept().use { client ->
                val input = client.getInputStream().bufferedReader(); val first = input.readLine().orEmpty()
                while (!input.readLine().isNullOrEmpty()) { }
                val body = if (first.contains("action=get_live_streams")) {
                    liveDownloads.incrementAndGet(); """[{"stream_id":42,"name":"Shared channel","category_id":1}]"""
                } else """[{"category_id":1,"category_name":"Live"}]"""
                client.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: ${body.toByteArray().size}\r\nConnection: close\r\n\r\n$body".toByteArray())
            } } catch (_: Exception) { }
        }.apply { isDaemon = true; start() }
        override fun close() { running = false; socket.close(); thread.interrupt(); thread.join(1000) }
    }
}
