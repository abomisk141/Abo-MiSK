package com.sultv.app

import android.os.Bundle
import android.os.Looper
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class BrowseReturnTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit()
        Repo.putB("referenceLayoutV52", true); Repo.putB("autoUpd", false); Repo.putB("autoPrev", false)
        Repo.putB("welcome", false); Repo.putB("tmdbOn", false); Repo.put("pl_refresh_hours", "0")
        Repo.updChecked = true; Repo.splashShown = true
        Repo.savePlaylists(listOf(Playlist("browse-test", "Fixture", "xt", "", "https://example.invalid", "test", "test")))
        val items = ArrayList<Item>()
        for (kind in listOf("movie", "series")) for (group in 0..13) for (n in 0..35) {
            val id = "$kind-$group-$n"
            items.add(Item(id, "$kind $group $n", "", "Turkish $group", kind, sid = id))
            Repo.info[id] = Info("Test plot", "", "", "", "")
        }
        Repo.items = items
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo)
        Repo.dirty = false
    }
    private fun field(a: MainActivity, name: String): Any? = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun layout(a: MainActivity) {
        val root = a.window.decorView
        repeat(2) {
            root.measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 960, 540); shadowOf(Looper.getMainLooper()).idle()
        }
    }
    private fun settle(a: MainActivity) {
        val deadline = System.currentTimeMillis() + 2000
        while (field(a, "filtering") == true && System.currentTimeMillis() < deadline) { layout(a); Thread.sleep(2) }
        repeat(5) { layout(a); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(100)) } }
    private fun anchor(rv: RecyclerView): Pair<Int, Int> {
        val lm = rv.layoutManager as LinearLayoutManager
        val pos = lm.findFirstVisibleItemPosition()
        return pos to (lm.findViewByPosition(pos)?.let { lm.getDecoratedTop(it) } ?: 0)
    }
    private fun choose(a: MainActivity, kind: String): RecyclerView {
        MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, kind)
        settle(a)
        val side = field(a, "sideRv") as RecyclerView
        side.scrollToPosition(13); layout(a)
        val row = side.findViewHolderForAdapterPosition(13)!!.itemView
        assertEquals("category:Turkish 10", row.tag)
        row.requestFocusFromTouch(); row.performClick(); settle(a)
        assertEquals("Turkish 10", field(a, "cat"))
        val rv = field(a, "rv") as RecyclerView
        // A programmatic test jump must not recycle the currently focused first card;
        // real remote navigation moves focus along with the scroll instead.
        side.findViewHolderForAdapterPosition(13)!!.itemView.requestFocusFromTouch()
        (rv.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(24, 0); layout(a)
        val target = rv.findViewHolderForAdapterPosition(25)
        assertNotNull("${Repo.s("ui")}/$kind category=${field(a, "cat")} count=${rv.adapter!!.itemCount} size=${rv.width}x${rv.height} anchor=${anchor(rv)}", target)
        assertTrue(target!!.itemView.requestFocusFromTouch())
        settle(a)
        return rv
    }

    @Test fun moviesAndSeriesReturnToTheirSelectedCardAndBothScrollPositionsInAllDesigns() {
        for (style in Designs.ids) for (kind in listOf("movie", "series")) {
            Repo.put("ui", style); Repo.put("lang", if (style == "spotlight") "ar" else "en")
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get()
            try {
                val rv = choose(a, kind); val side = field(a, "sideRv") as RecyclerView
                val contentAnchor = anchor(rv); val sideAnchor = anchor(side)
                rv.findViewHolderForAdapterPosition(25)!!.itemView.performClick()
                assertEquals(SeriesActivity::class.java.name, shadowOf(a).nextStartedActivity.component!!.className)
                controller.pause().stop()
                // Reproduce a framework/category-list rebuild that tries to focus the first group.
                side.scrollToPosition(0); layout(a)
                side.findViewHolderForAdapterPosition(0)?.itemView?.requestFocusFromTouch()
                controller.start().resume().visible(); settle(a)
                assertEquals("$style/$kind", "Turkish 10", field(a, "cat"))
                assertTrue("$style/$kind", rv.findViewHolderForAdapterPosition(25)!!.itemView.hasFocus())
                assertEquals(contentAnchor, anchor(rv)); assertEquals(sideAnchor, anchor(side))
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(600)); layout(a)
                assertEquals("Turkish 10", field(a, "cat"))
            } finally { controller.pause().stop().destroy() }
        }
    }

    @Test fun savedActivityStateKeepsTheCategoryAndSelectedSeriesAfterRecreation() {
        Repo.put("ui", "spotlight"); Repo.put("lang", "ar")
        val first = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
        val a = first.get(); val rv = choose(a, "series")
        rv.findViewHolderForAdapterPosition(25)!!.itemView.performClick()
        val state = Bundle(); first.saveInstanceState(state).pause().stop().destroy()
        val second = Robolectric.buildActivity(MainActivity::class.java).create(state).start().restoreInstanceState(state).resume().visible()
        try {
            val restored = second.get(); settle(restored)
            assertEquals("series", field(restored, "tab")); assertEquals("Turkish 10", field(restored, "cat"))
            val grid = field(restored, "rv") as RecyclerView
            assertTrue(grid.findViewHolderForAdapterPosition(25)!!.itemView.hasFocus())
        } finally { second.pause().stop().destroy() }
    }
}
