package com.sultv.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelRatesTest {
    @Test fun burstDownloadsEightSecondsOfMediaInOneSecond() {
        val rates = ChannelRates()
        rates.sample(0, 0, 0, 0)
        rates.sample(1000, 6000000, 6000000, 8000)
        assertEquals(48000000L, rates.download)
        assertEquals(6000000L, rates.bitrate)
        rates.clearMedia()
        assertEquals(-1L, rates.bitrate)
    }
}
