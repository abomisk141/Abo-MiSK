package com.sultv.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class LiveChannelReturnTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("referenceLayoutV52", true); Repo.putB("autoUpd", false); Repo.putB("autoPrev", false)
        Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.put("pl_refresh_hours", "0"); Repo.updChecked = true
        Repo.savePlaylists(listOf(Playlist("live-return", "Fixture", "m3u", "https://example.test/list.m3u", "", "", "")))
        Repo.items = (0 until 260).map { Item("channel-$it", "Channel $it", "", if (it < 200) "Group" else "Other", "live", u = "file:///channel-$it.ts") }
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo); Repo.dirty = false
    }
    private fun field(a: Any, name: String) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun layout(a: MainActivity) {
        a.window.decorView.apply { measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY)); layout(0, 0, 960, 540) }
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(30))
    }
    private fun settle(a: MainActivity) {
        val until = System.nanoTime() + 4_000_000_000L
        do { layout(a); Thread.sleep(2) } while ((field(a, "filtering") == true || field(a, "restoringBrowse") == true) && System.nanoTime() < until)
        repeat(4) { layout(a) }
    }
    private fun choose(a: MainActivity): RecyclerView {
        MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, "live"); settle(a)
        val side = field(a, "sideRv") as RecyclerView
        @Suppress("UNCHECKED_CAST") val categories = field(a, "cats") as List<MainActivity.Cat>
        val pos = categories.indexOfFirst { it.key == "Group" }
        side.scrollToPosition(pos); layout(a)
        side.findViewHolderForAdapterPosition(pos)!!.itemView.performClick(); settle(a)
        return field(a, "rv") as RecyclerView
    }
    private fun directPlay(a: MainActivity, item: Item) = MainActivity::class.java.getDeclaredMethod("play", Item::class.java).apply { isAccessible = true }.invoke(a, item)
    @Test fun upAndDownReturnToLastWatchedChannelInEnglishAcrossAllThemes() = exercise("en")
    @Test fun upAndDownReturnToLastWatchedChannelInArabicAcrossAllThemes() = exercise("ar")
    private fun exercise(lang: String) {
        for (style in Designs.ids) for (key in listOf(KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_UP)) {
            Repo.put("lang", lang); Repo.put("ui", style)
            Repo.putB("autoPrev", key == KeyEvent.KEYCODE_DPAD_DOWN)
            val mainController = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = mainController.get()
            var child: org.robolectric.android.controller.ActivityController<PlayerActivity>? = null
            try {
                val list = choose(a)
                if (key == KeyEvent.KEYCODE_DPAD_UP) {
                    // Exercise the preview-player handoff as well as a normal launch.
                    val row = list.findViewHolderForAdapterPosition(0)!!.itemView
                    row.performClick(); row.performClick()
                } else directPlay(a, Repo.items[0])
                val launch = shadowOf(a).nextStartedActivityForResult; assertNotNull(launch)
                mainController.pause().stop()
                child = Robolectric.buildActivity(PlayerActivity::class.java, launch.intent).create().start().resume()
                val player = child.get()
                val presses = if (key == KeyEvent.KEYCODE_DPAD_DOWN) 3 else 1
                repeat(presses) {
                    PlayerActivity::class.java.getDeclaredField("lastZapAt").apply { isAccessible = true }.setLong(player, -1000L)
                    player.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
                }
                val expected = if (key == KeyEvent.KEYCODE_DPAD_DOWN) 3 else 199
                val result = shadowOf(player).resultIntent
                assertEquals("channel-$expected", result.getStringExtra(PlayerActivity.RETURN_CHANNEL))
                player.finish(); child.pause().stop().destroy(); child = null
                assertTrue(a.activityResultRegistry.dispatchResult(launch.requestCode, Activity.RESULT_OK, result))
                mainController.start().resume().visible(); settle(a)
                assertEquals("$style/$lang", "Group", field(a, "cat"))
                assertTrue("$style/$lang/$expected", list.findViewHolderForAdapterPosition(expected)!!.itemView.hasFocus())
                assertEquals("channel-$expected", field(a, "previewId"))
                if (key == KeyEvent.KEYCODE_DPAD_DOWN) {
                    val preview = field(a, "prev") as androidx.media3.exoplayer.ExoPlayer
                    assertEquals(Repo.items[expected].url, preview.currentMediaItem!!.localConfiguration!!.uri.toString())
                    assertEquals("channel-$expected", Repo.s("lastLive"))
                }
            } finally { child?.pause()?.stop()?.destroy(); mainController.pause().stop().destroy() }
        }
    }
    @Test fun choosingAnotherPlayerGroupReturnsToThatChannelAndClearsAnIncompatibleSearch() {
        val main = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = main.get()
        var child: org.robolectric.android.controller.ActivityController<PlayerActivity>? = null
        try {
            choose(a); (field(a, "search") as android.widget.EditText).setText("Channel 0"); settle(a)
            directPlay(a, Repo.items[0]); val launch = shadowOf(a).nextStartedActivityForResult
            main.pause().stop()
            child = Robolectric.buildActivity(PlayerActivity::class.java, launch.intent).create()
            val player = child.get()
            PlayerActivity::class.java.getDeclaredMethod("switchTo", Item::class.java).apply { isAccessible = true }.invoke(player, Repo.items[250])
            val result = shadowOf(player).resultIntent
            child.destroy(); child = null
            a.activityResultRegistry.dispatchResult(launch.requestCode, Activity.RESULT_OK, result)
            main.start().resume().visible(); settle(a)
            assertEquals("Other", field(a, "cat")); assertEquals("", (field(a, "search") as android.widget.EditText).text.toString())
            val list = field(a, "rv") as RecyclerView
            assertTrue(list.findViewHolderForAdapterPosition(50)!!.itemView.hasFocus())
        } finally { child?.destroy(); main.pause().stop().destroy() }
    }
    @Test fun oldSessionOrDifferentPlaylistResultsDoNotReplaceTheReturnBookmark() {
        val main = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = main.get()
        try {
            choose(a); directPlay(a, Repo.items[0]); val launch = shadowOf(a).nextStartedActivityForResult
            val original = field(a, "browseReturn") as Bundle
            val method = MainActivity::class.java.getDeclaredMethod("consumeLiveReturn", Intent::class.java).apply { isAccessible = true }
            val data = Intent().putExtra(PlayerActivity.RETURN_CHANNEL, "channel-9")
                .putExtra(PlayerActivity.RETURN_PLAYLIST, Repo.active()!!.id).putExtra(PlayerActivity.RETURN_TOKEN, "old-session")
            method.invoke(a, data); assertEquals("channel-0", original.getString("item"))
            data.putExtra(PlayerActivity.RETURN_TOKEN, launch.intent.getStringExtra(PlayerActivity.RETURN_TOKEN)).putExtra(PlayerActivity.RETURN_PLAYLIST, "other-playlist")
            method.invoke(a, data); assertEquals("channel-0", original.getString("item"))
        } finally { main.pause().stop().destroy() }
    }
    @Test fun playerRecreationPublishesTheLatestChannelInsteadOfTheInitialLaunch() {
        Repo.zap = Repo.list("live")
        val intent = Intent(RuntimeEnvironment.getApplication(), PlayerActivity::class.java).putExtra("url", Repo.items[0].url).putExtra("rid", "channel-0").putExtra("live", true)
            .putExtra(PlayerActivity.RETURN_PLAYLIST, Repo.active()!!.id).putExtra(PlayerActivity.RETURN_TOKEN, "session")
        val first = Robolectric.buildActivity(PlayerActivity::class.java, intent).create()
        PlayerActivity::class.java.getDeclaredMethod("switchTo", Item::class.java).apply { isAccessible = true }.invoke(first.get(), Repo.items[75])
        val state = Bundle(); first.saveInstanceState(state).destroy()
        val second = Robolectric.buildActivity(PlayerActivity::class.java, intent).create(state)
        try {
            assertEquals("channel-75", shadowOf(second.get()).resultIntent.getStringExtra(PlayerActivity.RETURN_CHANNEL))
            assertEquals(Repo.items[75].url, (field(second.get(), "player") as androidx.media3.exoplayer.ExoPlayer).currentMediaItem!!.localConfiguration!!.uri.toString())
        } finally { second.destroy() }
    }
}
