package com.sultv.app

import android.os.Looper
import android.view.View
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class LargeCatalogueTest {
    @Test fun cachedThreeHundredThousandTitlesLoadAndIndex() {
        Repo.init(RuntimeEnvironment.getApplication())
        Repo.sp.edit().clear().commit()
        Repo.afterBackupRestore()
        val playlist = Playlist("stress", "Stress", "xt", "", "https://example.invalid", "test", "test")
        val rows = object : AbstractList<Item>() {
            override val size = 300000
            override fun get(index: Int): Item {
                val movie = index < 200000
                val kind = if (movie) "movie" else "series"
                return Item((if (movie) "xm" else "xs") + index, "Title $index", "https://example.invalid/poster/$index.jpg",
                    "Category " + index % 1000, kind, sid = index.toString())
            }
        }
        try {
            Repo::class.java.getDeclaredMethod("writeCache", Playlist::class.java, List::class.java).apply { isAccessible = true }.invoke(Repo, playlist, rows)
            assertTrue(Repo.err, Repo.load(false, playlist))
            assertEquals(300000, Repo.items.size)
            assertEquals(100000, Repo.shows.size)
            assertEquals("xs299999", Repo.shows.last().id)
        } finally { Repo.invalidate(playlist); Repo.afterBackupRestore() }
    }

    @Test fun all1800MoviesCanBeReachedAndLatestSearchFindsAnItemBeyondTheOldCap() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        for (k in listOf("autoUpd", "autoPrev", "welcome", "tmdbOn")) Repo.putB(k, false)
        Repo.putB("referenceLayoutV52", true); Repo.put("ui", "reference"); Repo.put("lang", "en"); Repo.put("pl_refresh_hours", "0")
        Repo.updChecked = true; Repo.splashShown = true
        Repo.savePlaylists(listOf(Playlist("large", "Large", "m3u", "https://example.invalid/list", "", "", "")))
        Repo.items = (0 until 1800).map { Item("movie-$it", "Movie $it", "", "Movies", "movie", u = "https://example.invalid/movie/$it") }
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo); Repo.dirty = false
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
        val a = controller.get(); val root = a.window.decorView
        fun field(name: String) = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(a)
        fun layout() {
            root.measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 960, 540); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(50))
        }
        fun await(condition: () -> Boolean) {
            val end = System.currentTimeMillis() + 4000
            do { layout(); Thread.sleep(2) } while (!condition() && System.currentTimeMillis() < end)
            assertTrue("Catalogue update did not finish", condition())
        }
        try {
            MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, "movie")
            val rv = field("rv") as RecyclerView
            await { field("filtering") == false && rv.adapter!!.itemCount >= 120 }
            assertEquals(120, rv.adapter!!.itemCount)
            (field("search") as EditText).requestFocusFromTouch()
            while (rv.adapter!!.itemCount < 1800) {
                val old = rv.adapter!!.itemCount; rv.scrollToPosition(old - 1)
                await { rv.adapter!!.itemCount > old }
            }
            assertEquals(1800, rv.adapter!!.itemCount)
            rv.scrollToPosition(1799)
            await { rv.findViewHolderForAdapterPosition(1799) != null }
            assertTrue(rv.findViewHolderForAdapterPosition(1799)!!.itemView.requestFocusFromTouch())
            rv.findViewHolderForAdapterPosition(1799)!!.itemView.performClick()
            controller.pause().stop()
            controller.start().resume().visible()
            await { field("filtering") == false && rv.findViewHolderForAdapterPosition(1799)?.itemView?.hasFocus() == true }
            (field("search") as EditText).requestFocusFromTouch()
            val global = AtomicInteger(); val changed = AtomicInteger()
            rv.adapter!!.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
                override fun onChanged() { global.incrementAndGet() }
                override fun onItemRangeChanged(start: Int, count: Int) { changed.addAndGet(count) }
            })
            Repo.toggleFav("movie-0")
            MainActivity::class.java.getDeclaredMethod("refresh", Boolean::class.javaPrimitiveType, Boolean::class.javaPrimitiveType, Boolean::class.javaPrimitiveType).apply { isAccessible = true }.invoke(a, true, true, false)
            await { field("filtering") == false && changed.get() > 0 }
            assertEquals(0, global.get()); assertEquals(1, changed.get())
            val search = field("search") as EditText
            search.setText("does not exist"); search.setText("Movie 1799")
            await { field("filtering") == false && rv.adapter!!.itemCount == 1 }
            @Suppress("UNCHECKED_CAST") val data = field("data") as List<Item>
            assertEquals("movie-1799", data.single().id)
            assertEquals(0, global.get())
        } finally { controller.pause().stop().destroy() }
    }
}
