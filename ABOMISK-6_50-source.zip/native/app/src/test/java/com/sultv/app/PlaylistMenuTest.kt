package com.sultv.app

import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowDialog
import java.io.File
import java.io.FileOutputStream
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class PlaylistMenuTest {
    private val first = Playlist("menu-one", "Dino", "xt", "", "https://example.test", "fixture", "fixture")
    private val second = Playlist("menu-two", "Dream", "m3u", "https://example.test/list", "", "", "")
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.putB("referenceLayoutV52", true); Repo.updChecked = true
        Repo.savePlaylists(listOf(first, second)); Repo.put("act", first.id)
    }
    private fun views(v: View): List<View> = listOf(v) + if (v is ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
    private fun layout(d: Dialog) {
        val root = d.window!!.decorView
        root.measure(View.MeasureSpec.makeMeasureSpec(d.window!!.attributes.width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(d.window!!.attributes.height, View.MeasureSpec.EXACTLY))
        root.layout(0, 0, root.measuredWidth, root.measuredHeight)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))
    }
    private fun open(a: SettingsActivity, p: Playlist): Dialog {
        SettingsActivity::class.java.getDeclaredMethod("plMenu", Playlist::class.java).apply { isAccessible = true }.invoke(a, p)
        return ShadowDialog.getLatestDialog().also { layout(it) }
    }
    private fun row(a: SettingsActivity, d: Dialog, label: Int): View = d.window!!.decorView.findViewWithTag("playback-option:${a.getString(label)}")
    @Test fun menuIsRemoteFocusableBilingualAndSupportsLargeFontsWithPreview() {
        for (lang in listOf("en", "ar")) for (size in listOf("1.0", "1.3")) {
            Repo.put("lang", lang); Repo.put("ts", size); Repo.put("ui", "cinema")
            val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup(); val a = controller.get()
            val d = open(a, first)
            try {
                val root = d.window!!.decorView
                val options = views(root).filter { (it.tag as? String)?.startsWith("playback-option:") == true }
                assertEquals(6, options.size); assertTrue(options.all { it.isFocusable && it.isClickable })
                options.first().requestFocusFromTouch(); layout(d)
                assertTrue(options.first().hasFocus()); assertEquals(options[1].id, options[0].nextFocusDownId)
                assertEquals(a.resources.configuration.layoutDirection, root.findViewWithTag<View>("playback-options").layoutDirection)
                options.forEach { assertTrue(it.height >= a.dp(66)); assertTrue(it.contentDescription.isNotBlank()) }
                options.last().requestFocusFromTouch(); layout(d)
                assertTrue(options.last().hasFocus())
                if (lang == "ar" && size == "1.0") {
                    options.first().requestFocusFromTouch(); layout(d)
                    val image = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888)
                    root.draw(Canvas(image))
                    val target = File("build/playlist-previews/menu-ar.png"); target.parentFile!!.mkdirs()
                    FileOutputStream(target).use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }; image.recycle()
                }
            } finally { d.dismiss(); controller.pause().stop().destroy() }
        }
    }
    @Test fun visibilityAndSwitchActionsPreservePlaylists() {
        val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup(); val a = controller.get()
        try {
            var d = open(a, second); row(a, d, R.string.hide_playlist_ui).performClick()
            assertFalse(Repo.isPlaylistVisible(second.id)); assertEquals(2, Repo.playlists().size)
            d = open(a, second); assertNotNull(row(a, d, R.string.show_playlist_ui))
            row(a, d, R.string.use_pl).performClick()
            assertEquals(second.id, Repo.active()!!.id); assertTrue(Repo.isPlaylistVisible(second.id))
        } finally { controller.pause().stop().destroy() }
    }
    @Test fun deleteRequiresConfirmationAndKeepsOtherPlaylists() {
        val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup(); val a = controller.get()
        try {
            var d = open(a, first); row(a, d, R.string.delete).performClick()
            var confirm = ShadowDialog.getLatestDialog() as AlertDialog
            assertEquals(2, Repo.playlists().size)
            confirm.getButton(AlertDialog.BUTTON_NEGATIVE).performClick(); assertEquals(2, Repo.playlists().size)
            d = open(a, first); row(a, d, R.string.delete).performClick()
            confirm = ShadowDialog.getLatestDialog() as AlertDialog; confirm.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
            shadowOf(Looper.getMainLooper()).idle()
            assertEquals(listOf(second.id), Repo.playlists().map { it.id }); assertEquals(second.id, Repo.active()!!.id)
        } finally { controller.pause().stop().destroy() }
    }
}
