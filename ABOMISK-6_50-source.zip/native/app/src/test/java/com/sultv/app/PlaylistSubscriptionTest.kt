package com.sultv.app

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.net.ServerSocket
import java.util.Calendar
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PlaylistSubscriptionTest {
    @Before fun setup() { Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit() }
    private fun parse(user: JSONObject) = PlaylistSubscriptions.parse(JSONObject().put("user_info", user), 1000)

    @Test fun parsesXtreamFieldsAndRoundsOnlyPositiveRemainingTimeUp() {
        val expiry = 2000000000L
        val account = parse(JSONObject().put("auth", "1").put("status", "Active").put("exp_date", expiry.toString())
            .put("created_at", "1700000000").put("active_cons", "1").put("max_connections", "3").put("is_trial", "0"))
        assertEquals(expiry * 1000, account.expires)
        assertEquals(1700000000000L, account.created)
        assertEquals(1, account.connections); assertEquals(3, account.maximum); assertEquals(false, account.trial)
        assertEquals(1L, account.remainingDays(expiry * 1000 - 1))
        assertEquals(2L, account.remainingDays(expiry * 1000 - 86400001))
        assertEquals(0L, account.remainingDays(expiry * 1000))
        assertTrue(account.expired(expiry * 1000))
    }

    @Test fun unknownExpiryIsNeverReportedAsUnlimitedAndRejectedAuthOverridesActive() {
        val missing = parse(JSONObject().put("auth", 1).put("status", "Active"))
        assertNull(missing.expires); assertFalse(missing.unlimited)
        assertFalse(parse(JSONObject().put("status", "Active").put("exp_date", "0")).unlimited)
        assertTrue(parse(JSONObject().put("status", "Active").put("exp_date", JSONObject.NULL)).unlimited)
        val denied = parse(JSONObject().put("auth", 0).put("status", "Active").put("exp_date", JSONObject.NULL))
        assertEquals("denied", denied.status); assertFalse(denied.unlimited)
        assertEquals("banned", parse(JSONObject().put("status", "Banned")).status)
        assertEquals("disabled", parse(JSONObject().put("status", "Disabled")).status)
    }

    @Test fun genericM3uIsNotAssumedToBeXtreamButGeneratedLinksCanExposeAccountInfo() {
        fun m3u(url: String) = Playlist("p", "P", "m3u", url, "", "", "")
        assertNull(PlaylistSubscriptions.endpoint(m3u("https://example.test/list.m3u?token=private")))
        val endpoint = PlaylistSubscriptions.endpoint(m3u("https://example.test:8443/folder/get.php?username=a%2Bb&password=p%26q&type=m3u_plus"))!!
        assertEquals("https://example.test:8443/folder", endpoint.server)
        assertEquals("a+b", endpoint.username); assertEquals("p&q", endpoint.password)
        assertEquals("https://example.test:8443/folder/player_api.php?username=a%2Bb&password=p%26q", endpoint.url())
    }

    @Test fun manualDateIsTheEndOfTheChosenLocalDayAndDoesNotLeakAcrossAccountEdits() {
        val p = Playlist("p", "P", "m3u", "https://example.test/list.m3u", "", "", "")
        PlaylistSubscriptions.setManual(p, 2027, Calendar.JANUARY, 20)
        val end = PlaylistSubscriptions.manual(p)!!
        val cal = Calendar.getInstance().apply { timeInMillis = end }
        assertEquals(21, cal.get(Calendar.DAY_OF_MONTH)); assertEquals(0, cal.get(Calendar.HOUR_OF_DAY))
        Repo.put("userAgent", "AnotherPlayer/1")
        assertEquals(end, PlaylistSubscriptions.manual(p))
        assertNull(PlaylistSubscriptions.manual(p.copy(m3u = "https://different.test/list.m3u")))
        PlaylistSubscriptions.clearManual(p); assertNull(PlaylistSubscriptions.manual(p))
    }

    @Test fun fetchingNonActivePlaylistSendsItsOwnCredentialsAndCachesOnlySafeAccountFields() {
        ServerSocket(0).use { server ->
            server.soTimeout = 5000
            val request = AtomicReference("")
            val body = JSONObject().put("user_info", JSONObject().put("auth", 1).put("status", "Active")
                .put("exp_date", "2000000000").put("username", "secret-user").put("password", "secret-pass")).toString().toByteArray()
            val worker = Thread {
                server.accept().use { socket ->
                    socket.soTimeout = 5000
                    val reader = socket.getInputStream().bufferedReader(); val lines = ArrayList<String>()
                    while (true) { val line = reader.readLine() ?: break; if (line.isEmpty()) break; lines.add(line) }
                    request.set(lines.joinToString("\n"))
                    socket.getOutputStream().apply {
                        write("HTTP/1.1 200 OK\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray()); write(body); flush()
                    }
                }
            }
            val active = Playlist("active", "Active", "xt", "", "http://127.0.0.1:${server.localPort}", "first-user", "first-pass")
            val other = active.copy(id = "other", xu = "secret-user", xp = "secret-pass")
            Repo.savePlaylists(listOf(active)); Repo.put("act", active.id); Repo.put("userAgent", "ProviderPlayer/2")
            worker.start()
            val result = PlaylistSubscriptions.fetch(other)
            worker.join(5000)
            assertEquals("active", Repo.active()!!.id)
            assertTrue(request.get().contains("username=secret-user&password=secret-pass"))
            assertTrue(request.get().contains("User-Agent: ProviderPlayer/2", true))
            assertEquals(result, PlaylistSubscriptions.cached(other)); assertNull(PlaylistSubscriptions.cached(active))
            val cached = Repo.sp.all.filterKeys { it.startsWith("subscription:") }.toString()
            assertFalse(cached.contains("secret-user")); assertFalse(cached.contains("secret-pass"))
            Repo.put("userAgent", "OtherPlayer/3"); assertNull(PlaylistSubscriptions.cached(other))
            assertNull(PlaylistSubscriptions.cached(other.copy(xp = "new-password")))
        }
    }

    @Test fun malformedAccountResponsesAreNotAcceptedOrCached() {
        try { PlaylistSubscriptions.parse(JSONObject().put("error", "not authenticated")); fail("Missing user_info accepted") }
        catch (_: IllegalArgumentException) { }
        val overflow = parse(JSONObject().put("status", "Active").put("exp_date", "9223372036854775807"))
        assertNull(overflow.expires); assertFalse(overflow.unlimited)
    }
}
