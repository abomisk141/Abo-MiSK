package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class CinemaScreenTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("welcome", false); Repo.putB("autoPrev", false)
        Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.putB("referenceLayoutV52", true)
        Repo.put("pl_refresh_hours", "0"); Repo.put("ui", "cinema")
        Repo.updChecked = true; Repo.splashShown = true
        Repo.savePlaylists(listOf(Playlist("cinema-screen", "Design preview", "m3u", "https://example.test/fixture", "", "", "")))
        val groups = listOf("Sports", "News", "Movies", "Documentaries", "Kids", "Entertainment")
        val channels = groups.flatMapIndexed { g, group -> (1..5).map { n -> Item("channel-$g-$n", "AM $group $n", "", group, "live", u = "file:///fixture-$g-$n.ts", epg = "programme-$g-$n") } }
        val movies = (0..7).map { Item("movie-$it", listOf("Beyond the Dunes", "The Deep Current", "After the Fall", "The Last Summer")[it % 4], "", "Movies", "movie", u = "file:///movie-$it.mp4", year = "2026", rate = "8.2") }
        val shows = (0..7).map { Item("series-$it", listOf("The Hollow Crown", "Aurora", "Northern Lights", "The Frontier")[it % 4], "", "Series", "series", u = "file:///series-$it.mp4", year = "2026") }
        Repo.items = channels + movies + shows
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo); Repo.dirty = false
        val start = System.currentTimeMillis() / 1800000L * 1800000L
        Repo.epg = channels.associate { it.epg to (0..4).map { n -> Prog(start + (n - 1) * 1800000L, start + n * 1800000L, listOf("Sports studio", "Match preview", "Live match", "Highlights", "Sports news")[n], "Design preview programme") } }
        Repo.saveProg(movies[0].url, 30000, 120000); Repo.touch(movies[0].id)
        Repo.saveProg(shows[0].url, 40000, 120000); Repo.put("le:" + Repo.list("series").first().id, shows[0].url); Repo.touch(Repo.list("series").first().id)
        Repo.touch(channels[0].id)
    }
    private fun field(a: Any, name: String) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun views(v: View): List<View> = listOf(v) + if (v is ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
    private fun layout(a: MainActivity) {
        a.window.decorView.apply { measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY)); layout(0, 0, 960, 540) }
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))
    }
    private fun settle(a: MainActivity, ready: () -> Boolean) {
        val end = System.nanoTime() + 5_000_000_000L
        do { layout(a); Thread.sleep(3) } while (!ready() && System.nanoTime() < end)
        assertTrue(ready()); repeat(3) { layout(a) }
    }
    private fun shot(a: MainActivity, name: String) {
        val root = a.window.decorView
        val bitmap = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888); root.draw(Canvas(bitmap))
        File("build/cinema-previews/$name.png").apply { parentFile!!.mkdirs() }.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
    }
    @Test fun cinemaUsesVodOnlyShelvesAndEndsWithSeriesInBothLanguages() {
        for (lang in listOf("en", "ar")) {
            Repo.put("lang", lang)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                val root = a.window.decorView
                settle(a) { root.findViewWithTag<View>("home-section:series") != null }
                val headers = views(root).filter { (it.tag as? String)?.startsWith("home-section:") == true }
                assertEquals(listOf("home-section:list", "home-section:movie", "home-section:series"), headers.map { it.tag })
                assertNull(root.findViewWithTag<View>("item:channel-0-1"))
                val home = field(a, "home") as HomeLike
                assertNotNull(home.root.findViewWithTag<View>("item:${Repo.list("movie").first().id}")); assertNotNull(home.root.findViewWithTag<View>("item:${Repo.list("series").first().id}"))
                val hero = root.findViewWithTag<HeroBannerLayout>("movie-hero")
                val text = root.findViewWithTag<View>("hero-text")
                assertEquals(lang == "en", text.left == 0); assertTrue(text.bottom <= hero.height)
                assertNotNull(root.findViewWithTag<View>("cinema-account"))
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun channelScreenKeepsMirroredGuideAndIconOnlyRailWithPreviews() {
        for (lang in listOf("en", "ar")) {
            Repo.put("lang", lang)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                val root = a.window.decorView
                val nav = views(root).filterIsInstance<DesignNav>().first { it.contentDescription == a.getString(R.string.live) }
                nav.performClick()
                val list = root.findViewWithTag<RecyclerView>("channel-list")
                settle(a) { field(a, "filtering") == false && list.childCount > 0 }
                list.getChildAt(0).requestFocusFromTouch(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(a)
                (field(a, "previewLogo") as ImageView).setImageResource(R.drawable.logo)
                val rail = root.findViewWithTag<View>("cinema-rail")
                val category = root.findViewWithTag<View>("category-panel"); val content = root.findViewWithTag<View>("content-panel")
                assertEquals(72, rail.width)
                fun x(v: View): Int = IntArray(2).also { v.getLocationOnScreen(it) }[0]
                assertEquals(lang == "en", x(category) < x(content))
                val navs = views(rail).filterIsInstance<DesignNav>()
                assertTrue(navs.all { button -> views(button).filterIsInstance<TextView>().all { it.visibility == View.GONE } })
                assertTrue(views(list).any { it is EpgView })
                shot(a, "cinema-channels-$lang")
                nav.requestFocusFromTouch(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(a)
                assertEquals(224, rail.width)
                assertTrue(navs.all { button -> views(button).filterIsInstance<TextView>().all { it.visibility == View.VISIBLE } })
                shot(a, "cinema-channels-expanded-$lang")
            } finally { controller.pause().stop().destroy() }
        }
    }
}
