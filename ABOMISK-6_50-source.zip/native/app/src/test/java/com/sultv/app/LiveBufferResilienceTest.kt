package com.sultv.app

import androidx.media3.common.C
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.analytics.PlayerId
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId
import androidx.media3.exoplayer.DefaultLoadControl
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class LiveBufferResilienceTest {
    @Test fun fastModeKeepsFetchingPastFiveSecondsWithoutWaitingLongerToStart() {
        val profile = PlaybackPolicy.liveProfile("fast")
        val control = DefaultLoadControl.Builder().setBufferDurationsMs(profile.minBufferMs,
            profile.maxBufferMs, profile.startBufferMs, profile.rebufferMs)
            .setPrioritizeTimeOverSizeThresholds(true).build()
        val player = PlayerId("buffer-test")
        fun parameters(bufferedUs: Long, rebuffering: Boolean = false) = LoadControl.Parameters(
            player, Timeline.EMPTY, MediaPeriodId("live"), 0L, bufferedUs, 1f, true, rebuffering, C.TIME_UNSET)
        control.onPrepared(player)
        // Five and a half seconds of healthy incoming data should not stop loading as the old 5s cap did.
        assertTrue(control.shouldContinueLoading(parameters(5_500_000L)))
        assertTrue(control.shouldStartPlayback(parameters(400_000L, false)))
        // After a stall, accumulate a useful cushion instead of immediately stalling again.
        assertFalse(control.shouldStartPlayback(parameters(400_000L, true)))
        assertTrue(control.shouldStartPlayback(parameters(1_500_000L, true)))
        control.onReleased(player)
    }
}
