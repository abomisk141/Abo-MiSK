package com.sultv.app

import android.content.Intent
import android.view.KeyEvent
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
@LooperMode(LooperMode.Mode.PAUSED)
class LiveLatencyImprovementTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.updChecked = true
    }
    private fun field(a: PlayerActivity, name: String) = PlayerActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun call(a: PlayerActivity, name: String) = PlayerActivity::class.java.getDeclaredMethod(name).apply { isAccessible = true }.invoke(a)
    private fun controller(live: Boolean) = Robolectric.buildActivity(PlayerActivity::class.java,
        Intent(RuntimeEnvironment.getApplication(), PlayerActivity::class.java).putExtra("url", "file:///latency-test.mp4").putExtra("name", "Test").putExtra("live", live)).create().start().resume()

    @Test fun freshXtreamDefaultsToTsAndExplicitHlsAndM3uUrlsRemainAvailable() {
        assertEquals("ts", PlaybackPolicy.xtreamLiveExtension())
        Repo.put("liveFormat", "m3u8"); assertEquals("m3u8", PlaybackPolicy.xtreamLiveExtension())
        Repo.put("liveFormat", "ts"); assertEquals("ts", PlaybackPolicy.xtreamLiveExtension())
        val direct = "https://example.test/channel.m3u8?quality=hd"
        assertEquals(direct, Item("raw", "Channel", "", "", "live", u = direct).url)
        val fast = PlaybackPolicy.liveProfile("fast")
        assertTrue(fast.maxBufferMs < PlaybackPolicy.liveProfile("balanced").maxBufferMs)
        assertTrue(fast.rebufferMs <= fast.minBufferMs); assertTrue(fast.startBufferMs < fast.rebufferMs)
    }
    @Test fun guardWaitsForSustainedLagAndLimitsRepeatedSeeks() {
        val guard = LiveEdgeGuard()
        fun sample(t: Long) = guard.target(t, true, true, true, true, 60000, 40000, 3000)
        assertNull(sample(0)); assertNull(sample(9999)); assertEquals(57000L, sample(10000))
        assertNull(sample(20000)); assertNull(sample(69999)); assertNull(sample(70000))
        assertEquals(57000L, sample(80000))
    }
    @Test fun guardNeverSeeksUnknownTsPausedDisabledOrAlreadyNearEdge() {
        val guard = LiveEdgeGuard()
        for (t in listOf(0L, 20000L, 80000L)) {
            assertNull(guard.target(t, true, true, false, false, C.TIME_UNSET, 10000, 3000))
            assertNull(guard.target(t, true, false, true, true, 60000, 10000, 3000))
            assertNull(guard.target(t, false, true, true, true, 60000, 10000, 3000))
            assertNull(guard.target(t, true, true, true, true, 60000, 55000, 3000))
            assertNull(guard.target(t, true, true, true, true, 60000, 65000, 3000))
        }
        assertNull(guard.target(90000, true, true, true, true, 60000, 10000, 3000))
        assertEquals(57000L, guard.target(100000, true, true, true, true, 60000, 10000, 3000))
    }
    @Test fun legacyHlsKeepsSegmentSafetyAndLowLatencyHlsHonoursPartHoldback() {
        assertEquals(22000L, PlaybackPolicy.safeCatchupOffsetMs(3000, 11000000, C.TIME_UNSET, C.TIME_UNSET, C.TIME_UNSET, false))
        assertEquals(33000L, PlaybackPolicy.safeCatchupOffsetMs(3000, 11000000, 33000000, C.TIME_UNSET, C.TIME_UNSET, false))
        assertEquals(3000L, PlaybackPolicy.safeCatchupOffsetMs(3000, 10000000, 30000000, 333000, 1000000, true))
        assertEquals(3000L, PlaybackPolicy.safeCatchupOffsetMs(3000, 10000000, C.TIME_UNSET, 333000, C.TIME_UNSET, true))
        assertNull(PlaybackPolicy.safeCatchupOffsetMs(3000, C.TIME_UNSET, C.TIME_UNSET, C.TIME_UNSET, C.TIME_UNSET, false))
    }
    @Test fun returningFromBackgroundResetsLiveQueueButRetainsVodPosition() {
        for (live in listOf(true, false)) {
            val controller = controller(live); val a = controller.get(); val player = field(a, "player") as ExoPlayer
            try {
                player.seekTo(12000)
                val item = player.currentMediaItem
                controller.pause().stop(); controller.start().resume()
                assertEquals(item, player.currentMediaItem)
                assertEquals(if (live) 0L else 12000L, player.currentPosition)
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun manualPauseIsRespectedUntilReturnToLiveAndTrackPreferencesSurviveReconnect() {
        val controller = controller(true); val a = controller.get(); val player = field(a, "player") as ExoPlayer
        try {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setPreferredAudioLanguage("ar").build()
            player.volume = .4f
            a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
            assertFalse(player.playWhenReady); assertEquals(true, field(a, "manualLivePause"))
            a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            assertTrue(player.playWhenReady); assertEquals(true, field(a, "manualLivePause"))
            player.seekTo(12000); call(a, "returnToLive")
            assertEquals(0L, player.currentPosition); assertEquals(false, field(a, "manualLivePause"))
            assertTrue(player.trackSelectionParameters.preferredAudioLanguages.contains("ar")); assertEquals(.4f, player.volume)
        } finally { controller.pause().stop().destroy() }
    }
    @Test fun scheduledRetryDiscardsOldLivePositionWithoutResettingTheBackoffCounter() {
        val controller = controller(true); val a = controller.get(); val player = field(a, "player") as ExoPlayer
        try {
            player.seekTo(12000); call(a, "scheduleStreamRecovery")
            assertEquals(1, field(a, "retryCount"))
            (field(a, "retryTask") as Runnable).run()
            assertEquals(0L, player.currentPosition); assertEquals(1, field(a, "retryCount"))
            assertTrue(player.playWhenReady)
        } finally { controller.pause().stop().destroy() }
    }
}
