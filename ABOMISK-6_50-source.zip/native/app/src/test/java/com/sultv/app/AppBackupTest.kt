package com.sultv.app

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.json.JSONObject
import java.io.InputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class AppBackupTest {
    private val password = "backup-password-123".toCharArray()
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication())
        Repo.sp.edit().clear().commit()
        Repo.afterBackupRestore()
    }

    private fun populate() {
        Repo.savePlaylists(listOf(Playlist("p-123", "اشتراكي", "xt", "", "https://example.test", "private-user", "private-password")))
        Repo.put("act", "p-123")
        Repo.sp.edit().putStringSet("fav", setOf("l_1", "m_5")).commit()
        Repo.setOrder("cat|live", listOf("رياضة", "أخبار"))
        Repo.setOrder("live|رياضة", listOf("l_3", "l_1"))
        Repo.hide("l_9"); Repo.setHiddenCats("live", setOf("hidden-category"))
        Repo.setPin("5678"); Repo.setLockedCats("movie", setOf("locked-category"))
        Repo.saveProg("https://example.test/private-user/private-password/movie.mp4", 12000, 100000)
        Repo.put("ui", "cinema"); Repo.put("userAgent", "VLC/3.0.20 LibVLC/3.0.20")
        PictureSettings(true, 5, 10, 120).save()
        Repo.put("crash", "diagnostic-secret"); Repo.put("st:p-123", "1|2|3|100")
    }

    @Test fun encryptedRoundTripRestoresAccountsFavouritesOrderProgressPinAndSettings() {
        populate()
        val bytes = AppBackup.export(Repo.sp, password)
        val text = String(bytes, Charsets.UTF_8)
        for (secret in listOf("private-user", "private-password", "diagnostic-secret", "cinema", "رياضة"))
            assertFalse(text.contains(secret))
        val snapshot = AppBackup.decode(bytes, password)
        assertEquals(1, snapshot.playlists); assertEquals(2, snapshot.favourites)
        Repo.sp.edit().clear().putString("new-only", "remove-me").commit()
        AppBackup.restore(Repo.sp, snapshot)
        Repo.afterBackupRestore()
        assertEquals("private-password", Repo.active()!!.xp)
        assertEquals(setOf("l_1", "m_5"), Repo.favs())
        assertEquals(listOf("رياضة", "أخبار"), Repo.order("cat|live"))
        assertEquals(listOf("l_3", "l_1"), Repo.order("live|رياضة"))
        assertTrue("l_9" in Repo.hidden()); assertTrue("hidden-category" in Repo.hiddenCats("live"))
        assertTrue(Repo.checkPin("5678")); assertTrue("locked-category" in Repo.lockedCats("movie"))
        assertEquals(12000L, Repo.prog("https://example.test/private-user/private-password/movie.mp4")!!.first)
        assertEquals(PictureSettings(true, 5, 10, 120), PictureSettings.load())
        assertEquals("cinema", Repo.s("ui")); assertFalse(Repo.sp.contains("new-only"))
        assertEquals("", Repo.s("crash")); assertTrue(Repo.items.isEmpty()); assertTrue(Repo.dirty)
    }

    @Test fun wrongPasswordCorruptionAndUnsupportedVersionNeverChangeCurrentPreferences() {
        populate()
        val bytes = AppBackup.export(Repo.sp, password)
        val before = Repo.sp.all
        fun reject(data: ByteArray, pass: CharArray = password) {
            try { AppBackup.decode(data, pass); fail("Invalid backup accepted") }
            catch (_: AppBackup.InvalidBackup) { }
            assertEquals(before, Repo.sp.all)
        }
        reject(bytes, "wrong-password".toCharArray())
        val objectJson = JSONObject(String(bytes, Charsets.UTF_8))
        val data = objectJson.getString("data")
        objectJson.put("data", (if (data[0] == 'A') "B" else "A") + data.substring(1))
        reject(objectJson.toString().toByteArray())
        reject(JSONObject(String(bytes, Charsets.UTF_8)).put("version", 999).toString().toByteArray())
        reject("not a backup".toByteArray())
    }

    @Test fun eachExportUsesFreshSaltAndIvAndDoesNotIncludeCachedStatus() {
        populate()
        val first = AppBackup.export(Repo.sp, password)
        val second = AppBackup.export(Repo.sp, password)
        assertFalse(first.contentEquals(second))
        val values = AppBackup.decode(first, password).values
        assertFalse(values.containsKey("crash")); assertFalse(values.containsKey("st:p-123"))
        assertTrue(values["fav"] is Set<*>)
    }

    @Test fun oversizedDocumentIsRejectedWithoutReadingTheWholeStream() {
        var consumed = 0
        val input = object : InputStream() {
            override fun read(): Int { consumed++; return 0 }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                consumed += len; java.util.Arrays.fill(b, off, off + len, 0.toByte()); return len
            }
        }
        try { AppBackup.read(input); fail("Oversized stream accepted") }
        catch (_: AppBackup.InvalidBackup) { }
        assertTrue(consumed <= AppBackup.MAX_BYTES + 8192)
    }

    @Test fun restoredCatalogueIsDownloadedAgainInsteadOfUsingExistingDeviceCache() {
        populate()
        val app = RuntimeEnvironment.getApplication()
        val file = java.io.File(app.filesDir, "pl_p-123.bin")
        file.writeText("old-cache")
        Repo.items = listOf(Item("old", "Old channel", "", "Old", "live"))
        Repo.unlock("movie", "locked-category"); Repo.settingsOk = true
        Repo.afterBackupRestore()
        assertFalse(file.exists()); assertTrue(Repo.items.isEmpty())
        assertTrue(Repo.unlocked.isEmpty()); assertFalse(Repo.settingsOk)
    }
}
