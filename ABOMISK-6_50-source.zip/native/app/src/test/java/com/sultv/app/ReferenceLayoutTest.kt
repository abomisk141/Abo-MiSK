package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import java.time.Duration
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class ReferenceLayoutTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit()
        Repo.putB("autoUpd", false); Repo.putB("autoPrev", false); Repo.putB("welcome", false)
        Repo.putB("tmdbOn", false); Repo.put("pl_refresh_hours", "0")
        Repo.updChecked = true; Repo.splashShown = true; Repo.dirty = false
    }
    @Test fun referenceMirrorsBothColumnsAndOverlayAndPreservesCategoryPosition() {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("direction", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            for (lang in listOf("en", "ar")) {
                Repo.sp.edit().putString("lang", lang).putString("ui", "reference").putString("referenceLayoutV52", "1").commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val decor = a.window.decorView
                try {
                    layout(decor)
                    val category = decor.findViewWithTag<View>("category-panel")
                    val content = decor.findViewWithTag<View>("content-panel")
                    val rail = decor.findViewWithTag<View>("reference-rail")
                    assertNotNull(category); assertNotNull(content); assertNotNull(rail)
                    assertEquals(if (lang == "en") View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL, category.layoutDirection)
                    assertEquals(lang == "en", x(category) < x(content))
                    assertEquals(lang == "en", x(rail) < x(category))
                    val categoryX = x(category)
                    val categoryRow = decor.findViewWithTag<View>("category:")
                    assertNotNull(categoryRow); assertTrue(categoryRow.requestFocusFromTouch())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(decor)
                    assertEquals(72, rail.width)
                    screenshot(decor, "reference-$lang-collapsed")
                    val movies = decor.findViewWithTag<ReferenceNav>("ref-nav:movie")
                    assertTrue(movies.requestFocusFromTouch())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(decor)
                    assertEquals(224, rail.width)
                    assertEquals(categoryX, x(category))
                    assertEquals(lang == "en", x(rail) < x(content))
                    screenshot(decor, "reference-$lang-expanded")
                    // Leaving the menu using the correct mirrored arrow collapses it again.
                    val exitKey = if (lang == "en") KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                    movies.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, exitKey))
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(decor)
                    assertEquals(72, rail.width)
                    assertEquals(categoryX, x(category))
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun previousDesignsPutCategoriesOnLeftWhenAppLanguageIsEnglish() { previousDesignsDirection("en") }
    @Test fun previousDesignsPutCategoriesOnRightWhenAppLanguageIsArabic() { previousDesignsDirection("ar") }
    private fun previousDesignsDirection(lang: String) {
        for (design in listOf("cinema", "studio", "spotlight")) {
            Repo.sp.edit().putString("lang", lang).putString("ui", design).putString("referenceLayoutV52", "1").commit()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get()
            try {
                val movie = views(a.window.decorView).filterIsInstance<DesignNav>().first { it.contentDescription == a.getString(R.string.movies) }
                movie.performClick(); shadowOf(Looper.getMainLooper()).idle(); layout(a.window.decorView)
                val category = a.window.decorView.findViewWithTag<View>("category-panel")
                val content = a.window.decorView.findViewWithTag<View>("content-panel")
                screenshot(a.window.decorView, "previous-$design-$lang")
                assertEquals("$design $lang: dir=${category.layoutDirection}, config=${a.resources.configuration.layoutDirection}, saved=${Repo.s("lang")}, actual=${a.getSharedPreferences("sul", 0).getString("lang", "")}, catX=${x(category)}, catW=${category.width}, mainX=${x(content)}, visibility=${category.visibility}", lang == "en", x(category) < x(content))
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun threeDesignsShareChannelGuideInEnglish() { sharedChannelGuide("en") }
    @Test fun threeDesignsShareChannelGuideInArabic() { sharedChannelGuide("ar") }
    private fun sharedChannelGuide(lang: String) {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("shared", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            for (design in listOf("cinema", "studio", "spotlight")) {
                Repo.sp.edit().putString("lang", lang).putString("ui", design).putString("referenceLayoutV52", "1").putString("livestyle", "triple").commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val root = a.window.decorView
                try {
                    views(root).filterIsInstance<DesignNav>().first { it.contentDescription == a.getString(R.string.live) }.performClick()
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(250)); layout(root)
                    val category = root.findViewWithTag<View>("category-panel")
                    val content = root.findViewWithTag<View>("content-panel")
                    val search = root.findViewWithTag<View>("channel-search")
                    val preview = root.findViewWithTag<View>("channel-preview")
                    val header = root.findViewWithTag<View>("channel-timeline-header")
                    val list = root.findViewWithTag<RecyclerView>("channel-list")
                    assertTrue(search.isShown); assertTrue(preview.isShown); assertTrue(header.isShown)
                    assertEquals(lang == "en", x(category) < x(content))
                    val p = IntArray(2); val h = IntArray(2); val l = IntArray(2)
                    preview.getLocationOnScreen(p); header.getLocationOnScreen(h); list.getLocationOnScreen(l)
                    assertTrue(p[1] + preview.height <= h[1]); assertTrue(h[1] + header.height <= l[1])
                    assertEquals(280, preview.width); assertEquals(158, preview.height)
                    assertTrue(list.childCount > 0); assertEquals(44, list.getChildAt(0).height)
                    assertTrue(views(list.getChildAt(0)).any { it is EpgView })
                    assertEquals(design, Repo.s("ui"))
                    screenshot(root, "guide-$design-$lang")
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun rapidChannelNavigationStaysInChannelsInEnglish() { rapidChannelNavigation("en") }
    @Test fun rapidChannelNavigationStaysInChannelsInArabic() { rapidChannelNavigation("ar") }
    private fun rapidChannelNavigation(lang: String) {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("focus", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            for (design in Designs.ids) {
                Repo.sp.edit().putString("lang", lang).putString("ui", design).putString("referenceLayoutV52", "1").commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val root = a.window.decorView
                try {
                    if (design != "reference") views(root).filterIsInstance<DesignNav>().first { it.contentDescription == a.getString(R.string.live) }.performClick()
                    layout(root)
                    val channels = root.findViewWithTag<RecyclerView>("channel-list")
                    assertTrue(channels.getChildAt(0).requestFocusFromTouch())
                    val downTime = android.os.SystemClock.uptimeMillis()
                    fun burst(key: Int, count: Int) {
                        repeat(count) { n ->
                            a.dispatchKeyEvent(KeyEvent(downTime, downTime + n * 8L, KeyEvent.ACTION_DOWN, key, n))
                            assertTrue("$design $lang: focus left channels during a repeated key", channels.hasFocus())
                        }
                        a.dispatchKeyEvent(KeyEvent(downTime, downTime + count * 8L, KeyEvent.ACTION_UP, key, 0))
                        repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                        assertTrue(channels.hasFocus())
                    }
                    burst(KeyEvent.KEYCODE_DPAD_DOWN, 80)
                    val last = channels.findContainingViewHolder(channels.findFocus()!!)
                    assertNotNull("$design $lang focus=${channels.findFocus()?.javaClass?.simpleName}, visible=${(0 until channels.childCount).map { channels.getChildAdapterPosition(channels.getChildAt(it)) }}", last)
                    assertEquals(channels.adapter!!.itemCount - 1, last!!.bindingAdapterPosition)
                    burst(KeyEvent.KEYCODE_DPAD_UP, 80)
                    assertEquals(0, channels.findContainingViewHolder(channels.findFocus()!!)!!.bindingAdapterPosition)
                    // Leave the column before the offscreen target attaches.
                    repeat(20) { n -> a.dispatchKeyEvent(KeyEvent(downTime, downTime + n * 8L, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, n)) }
                    val sideways = if (lang == "en") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                    a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, sideways))
                    repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                    val categories = views(root.findViewWithTag<View>("category-panel")).filterIsInstance<RecyclerView>().first()
                    assertTrue("Explicit horizontal navigation still works", categories.hasFocus())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200))
                    assertTrue("Pending channel movement must not steal focus back", categories.hasFocus())
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun referenceRailReachesSettingsWithoutSelectingMyListInEnglish() { referenceRailSettings("en") }
    @Test fun referenceRailReachesSettingsWithoutSelectingMyListInArabic() { referenceRailSettings("ar") }
    private fun referenceRailSettings(lang: String) {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("rail", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            for (palette in listOf("slate", "midnight", "copper")) {
                Repo.sp.edit().putString("lang", lang).putString("ui", "reference").putString("referenceLayoutV52", "1").putString("referencePalette", palette).commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val root = a.window.decorView
                try {
                    layout(root)
                    val rail = root.findViewWithTag<View>("reference-rail")
                    val myList = root.findViewWithTag<ReferenceNav>("ref-nav:list")
                    val settings = root.findViewWithTag<ReferenceNav>("ref-nav:settings")
                    val live = root.findViewWithTag<ReferenceNav>("ref-nav:live")
                    assertTrue(myList.requestFocusFromTouch())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                    myList.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN))
                    assertTrue("Down from My list must reach Settings", settings.hasFocus())
                    assertTrue("Moving focus must not activate My list", live.isSelected)
                    assertFalse(myList.isSelected)
                    repeat(20) { settings.dispatchKeyEvent(KeyEvent(0L, it * 8L, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, it)) }
                    assertTrue(settings.hasFocus()); assertTrue(rail.hasFocus())
                    settings.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_UP))
                    assertTrue(myList.hasFocus())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                    screenshot(root, "gradient-$palette-$lang")
                    myList.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN))
                    settings.performClick()
                    assertEquals(SettingsActivity::class.java.name, shadowOf(a).nextStartedActivity.component!!.className)
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun categoriesPreviewOnFocusAndOkEntersContentInEnglish() { categoryPreviewNavigation("en") }
    @Test fun categoriesPreviewOnFocusAndOkEntersContentInArabic() { categoryPreviewNavigation("ar") }
    private fun categoryPreviewNavigation(lang: String) {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("hover", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            for (design in Designs.ids) {
                Repo.sp.edit().putString("lang", lang).putString("ui", design).putString("referenceLayoutV52", "1").commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val root = a.window.decorView
                try {
                    if (design != "reference") views(root).filterIsInstance<DesignNav>().first { it.contentDescription == a.getString(R.string.live) }.performClick()
                    layout(root)
                    val channels = root.findViewWithTag<RecyclerView>("channel-list")
                    val first = root.findViewWithTag<View>("category:4K UHD")
                    val second = root.findViewWithTag<View>("category:4K UHD RELAX")
                    assertTrue(first.requestFocusFromTouch())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(220)); layout(root)
                    assertEquals(4, channels.adapter!!.itemCount); assertTrue(first.hasFocus())
                    assertTrue(views(channels).filterIsInstance<android.widget.TextView>().any { it.text.toString() == "TV - CHANNEL 1" })
                    assertTrue(second.requestFocusFromTouch())
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(220)); layout(root)
                    assertEquals(4, channels.adapter!!.itemCount); assertTrue(second.hasFocus())
                    assertTrue(views(channels).filterIsInstance<android.widget.TextView>().any { it.text.toString() == "TV - CHANNEL 5" })
                    second.performClick()
                    repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                    assertTrue("OK should enter the previewed content", channels.hasFocus())
                    assertEquals(0, channels.findContainingViewHolder(channels.findFocus()!!)!!.bindingAdapterPosition)
                    assertNull("OK on a category must not start playback", shadowOf(a).nextStartedActivity)
                    // Focus two categories quickly, then press OK before the preview delay.
                    assertTrue(second.requestFocusFromTouch())
                    assertTrue(first.requestFocusFromTouch())
                    first.performClick()
                    repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                    assertTrue(channels.hasFocus())
                    assertTrue(views(channels).filterIsInstance<android.widget.TextView>().any { it.text.toString() == "TV - CHANNEL 1" })
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(250)); layout(root)
                    assertEquals(4, channels.adapter!!.itemCount); assertTrue(channels.hasFocus())
                    val panel = root.findViewWithTag<View>("category-panel")
                    assertTrue(first.requestFocusFromTouch())
                    val into = if (lang == "en") KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                    val back = if (lang == "en") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                    first.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, into))
                    repeat(4) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                    assertEquals(design !in listOf("reference", "studio"), panel.isShown)
                    assertTrue(channels.hasFocus())
                    if (design == "reference") a.onBackPressedDispatcher.onBackPressed()
                    else channels.findFocus()!!.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, back))
                    layout(root)
                    assertTrue(panel.isShown); assertTrue(first.hasFocus())
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun lockedCategoryDoesNotPreviewUntilPinIsEntered() {
        Fixture().use { fixture ->
            Repo.setPin("1234"); Repo.unlocked.clear(); Repo.setLockedCats("live", setOf("[EU] LITHUANIA"))
            Repo.savePlaylists(listOf(Playlist("locked-hover", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            Repo.sp.edit().putString("lang", "en").putString("ui", "reference").putString("referenceLayoutV52", "1").commit()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get(); val root = a.window.decorView
            try {
                layout(root)
                val channels = root.findViewWithTag<RecyclerView>("channel-list")
                val categories = views(root.findViewWithTag<View>("category-panel")).filterIsInstance<RecyclerView>().first()
                val count = channels.adapter!!.itemCount
                categories.scrollToPosition(categories.adapter!!.itemCount - 1); layout(root)
                val locked = root.findViewWithTag<View>("category:lock:[EU] LITHUANIA")
                assertTrue(locked.requestFocusFromTouch())
                val before = org.robolectric.shadows.ShadowDialog.getLatestDialog()
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(250)); layout(root)
                assertEquals(count, channels.adapter!!.itemCount); assertTrue(locked.hasFocus())
                assertSame(before, org.robolectric.shadows.ShadowDialog.getLatestDialog())
                locked.performClick()
                val dialog = org.robolectric.shadows.ShadowDialog.getLatestDialog()
                assertNotNull(dialog); assertTrue(dialog.isShowing)
                assertEquals(count, channels.adapter!!.itemCount)
                dialog.dismiss()
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun railActivationEntersCategoriesInEveryThemeAndLanguage() {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("activate", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            for (lang in listOf("en", "ar")) for (design in Designs.ids) {
                Repo.sp.edit().putString("lang", lang).putString("ui", design).putString("referenceLayoutV52", "1").commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val root = a.window.decorView
                try {
                    layout(root)
                    val button = views(root).first { (it is DesignNav || it is ReferenceNav) && it.contentDescription == a.getString(R.string.series) }
                    assertTrue(button.requestFocusFromTouch())
                    button.performClick()
                    repeat(6) { shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(50)); layout(root) }
                    val categories = views(root.findViewWithTag<View>("category-panel")).filterIsInstance<RecyclerView>().first()
                    assertTrue("$design $lang", categories.hasFocus())
                    val rail = root.findViewWithTag<View>(if (design == "reference") "reference-rail" else "cinema-rail")
                    if (rail != null) assertEquals(72, rail.width)
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun cinemaRailExpandsAndCollapsesInEnglish() { cinemaExpandingRail("en") }
    @Test fun cinemaRailExpandsAndCollapsesInArabic() { cinemaExpandingRail("ar") }
    private fun cinemaExpandingRail(lang: String) {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("cinema-rail", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            Repo.sp.edit().putString("lang", lang).putString("ui", "cinema").putString("referenceLayoutV52", "1").commit()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get(); val root = a.window.decorView
            try {
                val deadline = System.nanoTime() + 3_000_000_000L
                while (root.findViewWithTag<View>("hero-play") == null && System.nanoTime() < deadline) {
                    shadowOf(Looper.getMainLooper()).idle(); Thread.sleep(5)
                }
                layout(root)
                val heroPlay = root.findViewWithTag<View>("hero-play")
                assertNotNull(heroPlay); assertTrue(heroPlay.requestFocusFromTouch())
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                val rail = root.findViewWithTag<View>("cinema-rail")
                val content = root.findViewWithTag<View>("content-panel")
                val originalX = x(content)
                assertEquals(72, rail.width)
                assertEquals(col("#E7C477"), Th.acc)
                val nav = views(rail).filterIsInstance<DesignNav>().toList()
                assertEquals(7, nav.size)
                assertTrue(nav.all { button -> views(button).filterIsInstance<android.widget.TextView>().all { it.visibility == View.GONE } })
                val home = nav.first { it.contentDescription == a.getString(R.string.home) }
                assertTrue(home.requestFocusFromTouch())
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                assertEquals(224, rail.width); assertEquals(originalX, x(content))
                val towardContent = if (lang == "en") KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                home.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, towardContent))
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                assertTrue(heroPlay.hasFocus()); assertEquals(72, rail.width)
                val live = nav.first { it.contentDescription == a.getString(R.string.live) }
                assertTrue(live.requestFocusFromTouch()); live.performClick()
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                assertEquals(72, rail.width)
                val activatedCategories = views(root.findViewWithTag<View>("category-panel")).filterIsInstance<RecyclerView>().first()
                assertTrue("OK must enter categories", activatedCategories.hasFocus())
                assertTrue(live.requestFocusFromTouch())
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                assertEquals(224, rail.width)
                screenshot(root, "cinema-rail-expanded-$lang")
                live.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, towardContent))
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                val categories = views(root.findViewWithTag<View>("category-panel")).filterIsInstance<RecyclerView>().first()
                assertTrue(categories.hasFocus()); assertEquals(72, rail.width)
                screenshot(root, "cinema-rail-collapsed-$lang")
                fun pointer(action: Int) {
                    val event = android.view.MotionEvent.obtain(0, 1, action, 20f, 20f, 0).apply { source = android.view.InputDevice.SOURCE_MOUSE }
                    rail.dispatchGenericMotionEvent(event); event.recycle()
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                }
                pointer(android.view.MotionEvent.ACTION_HOVER_ENTER)
                assertEquals(224, rail.width); assertTrue(categories.hasFocus())
                live.performClick()
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                assertEquals(72, rail.width); assertTrue(categories.hasFocus())
                pointer(android.view.MotionEvent.ACTION_HOVER_MOVE)
                assertEquals("Pointer must leave before reopening", 72, rail.width)
                pointer(android.view.MotionEvent.ACTION_HOVER_EXIT)
                assertEquals(72, rail.width); assertTrue(categories.hasFocus())
                val towardRail = if (lang == "en") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                categories.findFocus()!!.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, towardRail))
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(200)); layout(root)
                assertTrue(live.hasFocus()); assertEquals(224, rail.width)
            } finally { controller.pause().stop().destroy() }
        }
    }
    private fun pressMove(dialog: android.app.Dialog, key: Int, repeat: Int = 0) {
        dialog.dispatchKeyEvent(KeyEvent(0L, repeat * 8L, KeyEvent.ACTION_DOWN, key, repeat))
        dialog.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
    }
    private fun selectGrabAction(a: MainActivity): GrabReorderDialog {
        val menu = org.robolectric.shadows.ShadowDialog.getLatestDialog()
        val button = views(menu.window!!.decorView).filterIsInstance<android.widget.Button>().first { it.text.toString().endsWith(a.getString(R.string.grab_move)) }
        button.performClick()
        return org.robolectric.shadows.ShadowDialog.getLatestDialog() as GrabReorderDialog
    }
    @Test fun channelsCanBePickedMovedAndPlacedAcrossAllDesigns() {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("grab-channels", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            val original = Repo.list("live").map { it.id }
            for (design in Designs.ids) {
                Repo.setOrder("live|", emptyList())
                Repo.sp.edit().putString("lang", "ar").putString("ui", design).putString("referenceLayoutV52", "1").commit()
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
                val a = controller.get(); val root = a.window.decorView
                try {
                    if (design != "reference") views(root).filterIsInstance<DesignNav>().first { it.contentDescription == a.getString(R.string.live) }.performClick()
                    layout(root)
                    val channels = root.findViewWithTag<RecyclerView>("channel-list")
                    val held = channels.findViewHolderForAdapterPosition(1)!!.itemView
                    assertTrue(held.requestFocusFromTouch()); held.performLongClick()
                    val move = selectGrabAction(a)
                    repeat(3) { pressMove(move, KeyEvent.KEYCODE_DPAD_DOWN) }
                    assertTrue("Moving alone must not save", Repo.order("live|").isEmpty())
                    pressMove(move, KeyEvent.KEYCODE_DPAD_CENTER)
                    val expected = original.toMutableList().apply { add(4, removeAt(1)) }
                    assertEquals(expected, Repo.order("live|"))
                    assertEquals(expected, Repo.applyOrder("live|", Repo.list("live")).map { it.id })
                    repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                    assertTrue(views(channels.findViewHolderForAdapterPosition(4)!!.itemView).filterIsInstance<android.widget.TextView>().any { it.text.toString() == "TV - CHANNEL 2" })
                    assertFalse(move.isShowing)
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun cancellingGrabKeepsThePreviouslySavedChannelOrder() {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("grab-cancel", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            val before = Repo.list("live").map { it.id }.reversed()
            Repo.setOrder("live|", before)
            Repo.sp.edit().putString("lang", "en").putString("ui", "reference").putString("referenceLayoutV52", "1").commit()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get(); val root = a.window.decorView
            try {
                layout(root)
                val channels = root.findViewWithTag<RecyclerView>("channel-list")
                val held = channels.findViewHolderForAdapterPosition(0)!!.itemView
                assertTrue(held.requestFocusFromTouch()); held.performLongClick()
                val move = selectGrabAction(a)
                repeat(40) { n -> move.dispatchKeyEvent(KeyEvent(0L, n * 8L, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, n)) }
                assertEquals(before, Repo.order("live|"))
                pressMove(move, KeyEvent.KEYCODE_BACK)
                assertEquals(before, Repo.order("live|")); assertFalse(move.isShowing)
                assertEquals(before, Repo.applyOrder("live|", Repo.list("live")).map { it.id })
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun categoriesCanBePickedAndPlacedWithoutMovingPinnedCategories() {
        Fixture().use { fixture ->
            Repo.savePlaylists(listOf(Playlist("grab-category", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            val before = Repo.categories("live")
            Repo.sp.edit().putString("lang", "ar").putString("ui", "reference").putString("referenceLayoutV52", "1").commit()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get(); val root = a.window.decorView
            try {
                layout(root)
                val category = root.findViewWithTag<View>("category:4K UHD")
                assertTrue(category.requestFocusFromTouch())
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(220)); layout(root)
                category.performLongClick()
                val move = selectGrabAction(a)
                repeat(2) { pressMove(move, KeyEvent.KEYCODE_DPAD_DOWN) }
                assertTrue(Repo.order("cat|live").isEmpty())
                pressMove(move, KeyEvent.KEYCODE_DPAD_CENTER)
                val expected = before.toMutableList().apply { add(2, removeAt(0)) }
                assertEquals(expected, Repo.order("cat|live"))
                repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                val categories = views(root.findViewWithTag<View>("category-panel")).filterIsInstance<RecyclerView>().first()
                assertEquals("category:4K UHD", categories.findFocus()?.tag)
                categories.scrollToPosition(0); layout(root)
                assertEquals("category:fav", categories.findViewHolderForAdapterPosition(0)!!.itemView.tag)
                assertEquals("category:recent", categories.findViewHolderForAdapterPosition(1)!!.itemView.tag)
                assertEquals("category:", categories.findViewHolderForAdapterPosition(2)!!.itemView.tag)
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun acceleratedGrabCanPlaceAChannelBeyondTheOldListLimits() {
        Fixture(channelsPerGroup = 300).use { fixture ->
            Repo.savePlaylists(listOf(Playlist("grab-large", "Fixture", "m3u", fixture.url, "", "", "")))
            assertTrue(Repo.load(true)); Repo.dirty = false
            val original = Repo.list("live").map { it.id }
            assertEquals(2700, original.size)
            Repo.sp.edit().putString("lang", "en").putString("ui", "reference").putString("referenceLayoutV52", "1").commit()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = controller.get(); val root = a.window.decorView
            try {
                layout(root)
                val channels = root.findViewWithTag<RecyclerView>("channel-list")
                val readyDeadline = System.nanoTime() + java.util.concurrent.TimeUnit.SECONDS.toNanos(5)
                while (channels.adapter!!.itemCount != 2700 && System.nanoTime() < readyDeadline) {
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(16))
                    Thread.sleep(2)
                    layout(root)
                }
                assertEquals(2700, channels.adapter!!.itemCount)
                channels.scrollToPosition(2001); layout(root)
                val held = channels.findViewHolderForAdapterPosition(2001)!!.itemView
                assertTrue(held.requestFocusFromTouch()); held.performLongClick()
                val move = selectGrabAction(a)
                repeat(40) { n -> move.dispatchKeyEvent(KeyEvent(0L, n * 8L, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, n)) }
                assertTrue(views(move.window!!.decorView).filterIsInstance<android.widget.TextView>().any { it.text.toString() == a.getString(R.string.grab_position, 2312, 2700) })
                pressMove(move, KeyEvent.KEYCODE_MOVE_END)
                pressMove(move, KeyEvent.KEYCODE_DPAD_UP)
                assertTrue(Repo.order("live|").isEmpty())
                pressMove(move, KeyEvent.KEYCODE_DPAD_CENTER)
                val saved = Repo.order("live|")
                assertEquals(2700, saved.size); assertEquals(original[2001], saved[2698]); assertEquals(original.last(), saved.last())
                repeat(3) { layout(root); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32)) }
                val reorderDeadline = System.nanoTime() + java.util.concurrent.TimeUnit.SECONDS.toNanos(5)
                while (channels.adapter!!.itemCount != 2700 && System.nanoTime() < reorderDeadline) {
                    shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(16))
                    Thread.sleep(2)
                    layout(root)
                }
                assertEquals(2700, channels.adapter!!.itemCount)
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun upgradeReplacesLiveWithStudioWithoutChangingSavedMedia() {
        val playlist = Playlist("existing", "Saved list", "m3u", "https://example.test/playlist", "", "", "")
        Repo.savePlaylists(listOf(playlist)); Repo.toggleFav("saved-id"); Repo.saveProg("saved-url", 5000, 20000)
        Repo.put("ui", "live"); Designs.migrate()
        assertEquals("studio", Repo.s("ui")); assertEquals(listOf(playlist), Repo.playlists())
        assertTrue(Repo.isFav("saved-id")); assertEquals(Pair(5000L, 20000L), Repo.prog("saved-url"))
        Repo.put("ui", "cinema"); Designs.migrate(); assertEquals("cinema", Repo.s("ui"))
    }
    private fun views(v: View): Sequence<View> = sequence {
        yield(v); if (v is ViewGroup) for (n in 0 until v.childCount) yieldAll(views(v.getChildAt(n)))
    }
    private fun layout(v: View) {
        repeat(2) {
            v.measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
            v.layout(0, 0, 960, 540); shadowOf(Looper.getMainLooper()).idle()
        }
    }
    private fun x(v: View): Int { val xy = IntArray(2); v.getLocationOnScreen(xy); return xy[0] }
    private fun screenshot(v: View, name: String) {
        val bitmap = Bitmap.createBitmap(960, 540, Bitmap.Config.ARGB_8888)
        v.draw(Canvas(bitmap))
        val file = File("build/reference-previews/$name.png").apply { parentFile?.mkdirs() }
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
    private class Fixture(private val channelsPerGroup: Int = 4) : AutoCloseable {
        private val server = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
        private val base = "http://127.0.0.1:${server.localPort}"
        val url = "$base/list"
        private val groups = listOf("4K UHD", "4K UHD RELAX", "[EU] LITHUANIA", "[EU] LATVIA", "[EU] DAZN LA LIGA", "[EU] DISNEY+ PPV", "[EU] FRANCE HEVC", "[EU] FRANCE GENERAL", "[EU] FRANCE SPORTS")
        private val list = buildString {
            append("#EXTM3U\n")
            for ((groupId, group) in groups.withIndex()) for (n in 1..channelsPerGroup) {
                append("#EXTINF:-1 tvg-logo=\"$base/logo\" group-title=\"$group\",TV - CHANNEL ${groupId * channelsPerGroup + n}\n$base/live/${groupId * channelsPerGroup + n}.ts\n")
            }
        }.toByteArray()
        private val logo: ByteArray = ByteArrayOutputStream().use { out ->
            val b = Bitmap.createBitmap(100, 60, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(b); canvas.drawColor(Color.rgb(220, 229, 237))
            canvas.drawText("TV", 22f, 43f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(92, 70, 157); textSize = 40f })
            b.compress(Bitmap.CompressFormat.PNG, 100, out); out.toByteArray()
        }
        private val thread = Thread {
            while (!server.isClosed) try {
                server.accept().use { socket ->
                    val reader = socket.getInputStream().bufferedReader()
                    val path = reader.readLine().orEmpty().split(' ').getOrNull(1).orEmpty()
                    while (!reader.readLine().isNullOrEmpty()) { }
                    val bytes = if (path == "/logo") logo else list
                    socket.getOutputStream().apply {
                        write("HTTP/1.1 200 OK\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray()); write(bytes); flush()
                    }
                }
            } catch (_: java.io.IOException) { }
        }.apply { isDaemon = true; start() }
        override fun close() { server.close(); thread.join(1000) }
    }
}
