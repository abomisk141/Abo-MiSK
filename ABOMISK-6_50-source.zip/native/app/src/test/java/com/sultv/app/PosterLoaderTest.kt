package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.os.Looper
import android.widget.ImageView
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.ByteArrayOutputStream
import java.net.ServerSocket
import java.time.Duration
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class PosterLoaderTest {
    @Before fun setup() { Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit() }
    private fun view() = ImageView(RuntimeEnvironment.getApplication()).apply {
        layoutParams = LinearLayout.LayoutParams(120, 180); scaleType = ImageView.ScaleType.CENTER_CROP
    }
    private fun waitFor(condition: () -> Boolean) {
        val end = System.currentTimeMillis() + 8000
        while (!condition() && System.currentTimeMillis() < end) {
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(20)); Thread.sleep(10)
        }
        assertTrue("Image request did not finish", condition())
    }
    private fun pixel(v: ImageView): Int? = (v.drawable as? BitmapDrawable)?.bitmap?.let { it.getPixel(it.width / 2, it.height / 2) }

    @Test fun repeatedPostersShareOneDownloadAndStillLoadFromDiskAfterMemoryIsCleared() {
        Server().use { server ->
            val a = view(); val b = view()
            Img.load(a, server.url + "/blue"); Img.load(b, server.url + "/blue")
            waitFor { pixel(a) == Color.BLUE && pixel(b) == Color.BLUE }
            assertEquals(1, server.requests.get())
            Img.clear(a); Img.clear(b)
            Glide.get(RuntimeEnvironment.getApplication()).clearMemory()
            val c = view(); Img.load(c, server.url + "/blue")
            waitFor { pixel(c) == Color.BLUE }
            assertEquals("Disk cache must avoid another network download", 1, server.requests.get())
            Img.clear(c)
        }
    }

    @Test fun providerUserAgentChangesDoNotReuseThePreviousIdentityResponse() {
        Server().use { server ->
            Repo.put("userAgent", "ProviderOne/1")
            val v = view(); Img.load(v, server.url + "/blue"); waitFor { pixel(v) == Color.BLUE }
            assertTrue(server.lastHeaders.get().contains("User-Agent: ProviderOne/1", true))
            Img.clear(v); Repo.put("userAgent", "ProviderTwo/2")
            Img.load(v, server.url + "/blue"); waitFor { pixel(v) == Color.BLUE && server.requests.get() == 2 }
            assertTrue(server.lastHeaders.get().contains("User-Agent: ProviderTwo/2", true))
            Img.clear(v)
        }
    }

    @Test fun recycledCardCannotReceiveAnEarlierSlowPoster() {
        Server().use { server ->
            val v = view(); Img.load(v, server.url + "/slow-red")
            waitFor { server.requests.get() >= 1 }
            Img.load(v, server.url + "/blue")
            waitFor { pixel(v) == Color.BLUE }
            Thread.sleep(450); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(500))
            assertEquals(Color.BLUE, pixel(v)); assertEquals(server.url + "/blue", v.tag)
            Img.load(v, ""); assertNull(v.drawable)
        }
    }

    @Test fun thumbnailSizingOnlyChangesPublicTmdbImagesAndKeepsExistingSmallImages() {
        assertEquals("https://image.tmdb.org/t/p/w342/a.jpg", Img.sourceUrl("https://image.tmdb.org/t/p/original/a.jpg", 2))
        assertEquals("https://image.tmdb.org/t/p/w1280/a.jpg", Img.sourceUrl("https://image.tmdb.org/t/p/original/a.jpg", 1))
        assertEquals("https://image.tmdb.org/t/p/w185/a.jpg", Img.sourceUrl("https://image.tmdb.org/t/p/w185/a.jpg", 2))
        val privateUrl = "https://provider.test/original/a.jpg?username=u&password=p"
        assertEquals(privateUrl, Img.sourceUrl(privateUrl, 2))
    }

    @Test fun lowPriorityPrefetchStartsBeforeTheCardNeedsThePosterAndSharesItsDownload() {
        Server().use { server ->
            val context = RuntimeEnvironment.getApplication()
            val target = Img.prefetch(context, server.url + "/blue", 120, 180)!!
            waitFor { server.requests.get() == 1 }
            val v = view(); Img.load(v, server.url + "/blue")
            waitFor { pixel(v) == Color.BLUE }
            assertEquals(1, server.requests.get())
            Img.clear(v); Glide.with(context).clear(target)
        }
    }

    @Test fun offscreenHomePosterIsNotDownloadedUntilItBecomesVisible() {
        Server().use { server ->
            val controller = org.robolectric.Robolectric.buildActivity(android.app.Activity::class.java).setup().visible()
            val activity = controller.get()
            val column = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
            val first = VisiblePosterView(activity).apply { layoutParams = LinearLayout.LayoutParams(120, 180); setPoster(server.url + "/blue") }
            val last = VisiblePosterView(activity).apply { layoutParams = LinearLayout.LayoutParams(120, 180); setPoster(server.url + "/hidden-blue") }
            column.addView(first); column.addView(android.view.View(activity), LinearLayout.LayoutParams(1, 1200)); column.addView(last)
            val scroll = android.widget.ScrollView(activity).apply { addView(column, android.widget.FrameLayout.LayoutParams(-1, -2)) }
            activity.setContentView(scroll)
            try {
                val root = activity.window.decorView
                root.measure(android.view.View.MeasureSpec.makeMeasureSpec(300, android.view.View.MeasureSpec.EXACTLY), android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY))
                root.layout(0, 0, 300, 400)
                first.updatePosterVisibility(); last.updatePosterVisibility()
                waitFor { pixel(first) == Color.BLUE }
                assertNull(last.drawable); assertEquals(1, server.requests.get())
                scroll.scrollTo(0, 1200); first.updatePosterVisibility(); last.updatePosterVisibility()
                waitFor { pixel(last) == Color.BLUE }
                assertEquals(2, server.requests.get())
            } finally { controller.pause().stop().destroy() }
        }
    }

    private class Server : AutoCloseable {
        private val server = ServerSocket(0)
        val url = "http://127.0.0.1:${server.localPort}"
        val requests = AtomicInteger()
        val lastHeaders = AtomicReference("")
        private val clients = Executors.newFixedThreadPool(3)
        private fun png(color: Int) = ByteArrayOutputStream().use { out ->
            val b = Bitmap.createBitmap(60, 90, Bitmap.Config.ARGB_8888); b.eraseColor(color)
            b.compress(Bitmap.CompressFormat.PNG, 100, out); b.recycle(); out.toByteArray()
        }
        private val blue = png(Color.BLUE); private val red = png(Color.RED)
        private val accepting = Thread {
            while (!server.isClosed) try {
                val socket = server.accept()
                clients.execute {
                    try { socket.use {
                        val reader = it.getInputStream().bufferedReader(); val headers = ArrayList<String>()
                        val first = reader.readLine().orEmpty(); headers.add(first)
                        while (true) { val line = reader.readLine() ?: break; if (line.isEmpty()) break; headers.add(line) }
                        lastHeaders.set(headers.joinToString("\n")); requests.incrementAndGet()
                        if (first.contains("slow-red")) Thread.sleep(350)
                        val bytes = if (first.contains("slow-red")) red else blue
                        it.getOutputStream().apply {
                            write("HTTP/1.1 200 OK\r\nContent-Type: image/png\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray()); write(bytes); flush()
                        }
                    } } catch (_: Exception) { }
                }
            } catch (_: Exception) { }
        }.apply { isDaemon = true; start() }
        override fun close() { server.close(); accepting.join(1000); clients.shutdownNow() }
    }
}
