package com.sultv.app

import android.graphics.Bitmap
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.ui.PlayerView
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
@LooperMode(LooperMode.Mode.PAUSED)
class LivePlayerHandoffTest {
    private val context get() = RuntimeEnvironment.getApplication()
    @Before fun setup() { Repo.init(context); Repo.sp.edit().clear().commit(); LivePlayerHandoff.clear() }
    @After fun cleanup() { LivePlayerHandoff.clear() }
    @Test fun bothDirectionsKeepTheSamePlayerStreamPositionAndPreferences() {
        val player = makePlayer(context, true)
        val preview = PlayerView(context); val full = PlayerView(context)
        try {
            player.setMediaItem(MediaItem.fromUri("file:///fixture.ts")); player.seekTo(12500)
            player.volume = .7f; player.playWhenReady = true; preview.player = player
            LivePlayerHandoff.offer("channel", player, preview)
            assertTrue(LivePlayerHandoff.owns(preview))
            val transfer = LivePlayerHandoff.take("channel")!!
            assertSame(player, transfer.player)
            transfer.attach(full).close()
            assertNull(preview.player); assertSame(player, full.player)
            LivePlayerHandoff.offer("channel", player, full, LivePlayerHandoff.Destination.PREVIEW, "session")
            assertNull(LivePlayerHandoff.take("channel", LivePlayerHandoff.Destination.PREVIEW, "wrong-session"))
            assertNull(LivePlayerHandoff.take("other", LivePlayerHandoff.Destination.PREVIEW, "session"))
            assertNull(LivePlayerHandoff.take("channel"))
            LivePlayerHandoff.take("channel", LivePlayerHandoff.Destination.PREVIEW, "session")!!.attach(preview).close()
            assertNull(full.player); assertSame(player, preview.player)
            assertEquals(12500L, player.currentPosition); assertEquals(.7f, player.volume)
            assertTrue(player.playWhenReady); assertEquals("file:///fixture.ts", player.currentMediaItem!!.localConfiguration!!.uri.toString())
        } finally { preview.player = null; full.player = null; player.release() }
    }
    @Test fun lastFrameIsRemovedAndFreedWhenNewSurfaceRenders() {
        val player = makePlayer(context, true); val target = PlayerView(context)
        val bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
        try {
            val bridge = VideoFrameBridge(player, target, bitmap)
            assertNotNull(target.findViewWithTag<android.view.View>("video-transition-frame"))
            bridge.onRenderedFirstFrame(); bridge.close()
            assertNull(target.findViewWithTag<android.view.View>("video-transition-frame")); assertTrue(bitmap.isRecycled)
        } finally { player.release() }
    }
    @Test fun abandonedTransferExpiresAndDetachesItsSurface() {
        val player = makePlayer(context, true); val source = PlayerView(context); source.player = player
        LivePlayerHandoff.offer("channel", player, source)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(11))
        assertFalse(LivePlayerHandoff.hasPending("channel", LivePlayerHandoff.Destination.FULLSCREEN)); assertNull(source.player)
    }
}
