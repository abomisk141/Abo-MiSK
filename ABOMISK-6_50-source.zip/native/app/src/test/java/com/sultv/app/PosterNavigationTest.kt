package com.sultv.app

import android.os.Looper
import android.view.KeyEvent
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class PosterNavigationTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("referenceLayoutV52", true); Repo.putB("autoUpd", false); Repo.putB("autoPrev", false)
        Repo.putB("tmdbOn", false); Repo.put("pl_refresh_hours", "0"); Repo.updChecked = true
        Repo.savePlaylists(listOf(Playlist("fixture", "Fixture", "m3u", "https://example.test/fixture.m3u", "", "", "")))
        Repo.items = listOf("movie", "series").flatMap { kind -> (0 until 700).map { n -> Item("$kind-$n", "$kind $n", "", "Group", kind, sid = "$kind-$n") } }
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo)
        Repo.dirty = false
    }
    private fun field(a: MainActivity, name: String) = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun layout(a: MainActivity) {
        a.window.decorView.apply {
            measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
            layout(0, 0, 960, 540)
        }
        shadowOf(Looper.getMainLooper()).idle()
    }
    private fun settle(a: MainActivity) {
        val deadline = System.nanoTime() + 5_000_000_000L
        while (field(a, "filtering") == true && System.nanoTime() < deadline) { layout(a); Thread.sleep(3) }
        repeat(7) { layout(a); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40)) }
    }
    @Test fun rapidMovieAndSeriesNavigationNeverJumpsIntoCategoriesInEnglish() = exercise("en")
    @Test fun rapidMovieAndSeriesNavigationNeverJumpsIntoCategoriesInArabic() = exercise("ar")
    private fun exercise(lang: String) {
        for (style in Designs.ids) for (kind in listOf("movie", "series")) {
            Repo.put("ui", style); Repo.put("lang", lang)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, kind)
                settle(a)
                val grid = field(a, "rv") as RecyclerView
                assertTrue(grid.findViewHolderForAdapterPosition(0)!!.itemView.requestFocusFromTouch())
                fun burst(key: Int) {
                    val start = android.os.SystemClock.uptimeMillis()
                    repeat(80) { n ->
                        a.dispatchKeyEvent(KeyEvent(start, start + n * 6, KeyEvent.ACTION_DOWN, key, n))
                        assertTrue("$style/$kind/$lang: repeated key left the poster grid", grid.hasFocus())
                    }
                    a.dispatchKeyEvent(KeyEvent(start, start + 480, KeyEvent.ACTION_UP, key, 0))
                    settle(a)
                    assertTrue("$style/$kind/$lang: layout moved focus out of the grid", grid.hasFocus())
                }
                repeat(4) { burst(KeyEvent.KEYCODE_DPAD_DOWN) }
                val last = grid.findContainingViewHolder(grid.findFocus()!!)
                assertNotNull(last); assertEquals(699, last!!.bindingAdapterPosition)
                repeat(4) { burst(KeyEvent.KEYCODE_DPAD_UP) }
                val span = (grid.layoutManager as GridLayoutManager).spanCount
                assertEquals(699 % span, grid.findContainingViewHolder(grid.findFocus()!!)!!.bindingAdapterPosition)
                assertTrue(grid.findViewHolderForAdapterPosition(0)!!.itemView.requestFocusFromTouch())
                // Intentional horizontal exit still works and queued moves cannot steal focus back.
                val sideKey = if (lang == "en") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, sideKey)); settle(a)
                assertTrue((field(a, "sideRv") as RecyclerView).hasFocus())
                // Exit horizontally while rapid vertical requests are still waiting for layout.
                assertTrue(grid.findViewHolderForAdapterPosition(0)!!.itemView.requestFocusFromTouch())
                repeat(30) { a.dispatchKeyEvent(KeyEvent(0, it * 6L, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, it)) }
                a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, sideKey)); settle(a)
                assertTrue("Queued vertical movement must not reclaim focus", (field(a, "sideRv") as RecyclerView).hasFocus())
            } finally { controller.pause().stop().destroy() }
        }
    }
}
