package com.sultv.app

import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.ByteArrayDataSource
import androidx.media3.datasource.DataSpec
import android.net.Uri
import android.content.Intent
import org.robolectric.Robolectric
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PlaybackFeaturesTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication())
        Repo.sp.edit().clear().commit()
    }

    @Test fun pictureSettingsPersistAndClampWithoutChangingOtherPreferences() {
        Repo.put("act", "my-playlist"); Repo.put("fav", "saved-favourites")
        PictureSettings(true, 900, -900, 900).save()
        assertEquals(PictureSettings(true, 50, -50, 200), PictureSettings.load())
        assertEquals(3, PictureSettings.load().effects().size)
        PictureSettings().save()
        assertEquals(PictureSettings(), PictureSettings.load())
        assertTrue(PictureSettings.load().effects().isEmpty())
        assertEquals("my-playlist", Repo.s("act")); assertEquals("saved-favourites", Repo.s("fav"))
    }

    @Test fun originalPictureDoesNotEnableProcessingAndMalformedValuesAreSafe() {
        assertTrue(PictureSettings(enabled = true).effects().isEmpty())
        assertTrue(PictureSettings(false, 50, 50, 200).effects().isEmpty())
        Repo.put("pictureBrightness", "broken"); Repo.put("pictureSaturation", "-90")
        assertEquals(0, PictureSettings.load().brightness)
        assertEquals(0, PictureSettings.load().saturation)
    }

    @Test fun diagnosticsSeparateStartupFromRebufferingAndResetForNextStream() {
        var now = 100L
        val d = PlaybackDiagnostics { now }
        d.state(Player.STATE_BUFFERING)
        now += 500; d.state(Player.STATE_BUFFERING)
        now += 500; d.state(Player.STATE_READY)
        assertEquals(1000L, d.startupMs())
        assertEquals(0, d.rebufferCount)
        now += 2000; d.state(Player.STATE_BUFFERING)
        now += 200; d.state(Player.STATE_BUFFERING)
        now += 300
        assertEquals(1500L, d.totalBufferMs())
        d.state(Player.STATE_READY)
        assertEquals(1, d.rebufferCount)
        d.dropped(20); d.bandwidth(12000000)
        assertEquals(12000000, d.recentNetworkBps())
        now += 16000; assertEquals(0, d.recentNetworkBps())
        d.reset()
        assertEquals(0, d.droppedFrames); assertEquals(0, d.rebufferCount)
        assertEquals(0, d.totalBufferMs()); assertNull(d.startupMs())
    }

    @Test fun errorClassificationUsesCauseRatherThanLeakingRawMessages() {
        val dns = PlaybackException("secret-url", UnknownHostException("secret-server"), 2001)
        val timeout = PlaybackException("secret-token", SocketTimeoutException("private"), 2002)
        assertEquals(PlaybackDiagnostics.Kind.DNS, PlaybackDiagnostics.classify(dns).kind)
        assertEquals(PlaybackDiagnostics.Kind.TIMEOUT, PlaybackDiagnostics.classify(timeout).kind)
        assertEquals(PlaybackDiagnostics.Kind.DECODER,
            PlaybackDiagnostics.classify(PlaybackException("private", null, 4001)).kind)
        assertEquals(PlaybackDiagnostics.Kind.PICTURE,
            PlaybackDiagnostics.classify(PlaybackException("private", null, 7000)).kind)
    }

    @Test fun reportOmitsUrlsPasswordsAndRawExceptionMessages() {
        val context = RuntimeEnvironment.getApplication()
        val p = makePlayer(context)
        try {
            p.setMediaItem(MediaItem.fromUri("https://private-server.test/live/private-user/private-password/1.ts?token=private-token"))
            val d = PlaybackDiagnostics()
            d.error(PlaybackException("private-password private-token", UnknownHostException("private-server"), 2001))
            val report = d.report(context, p, -1)
            for (secret in listOf("private-server", "private-user", "private-password", "private-token", "https://"))
                assertFalse(report.contains(secret))
            assertTrue(report.contains("DNS"))
        } finally { p.release() }
    }

    @Test fun userAgentRejectsHeaderInjectionAndKeepsTheOriginalDefault() {
        assertEquals("Mozilla/5.0", RequestIdentity.userAgent())
        for (bad in listOf("VLC\r\nX-Injected: yes", "bad\u0000value", "a".repeat(513), "مشغل")) {
            assertFalse(RequestIdentity.valid(bad))
            Repo.put("userAgent", bad)
            assertEquals("Mozilla/5.0", RequestIdentity.userAgent())
        }
        Repo.put("userAgent", " VLC/3.0.21 LibVLC/3.0.21 ")
        assertEquals("VLC/3.0.21 LibVLC/3.0.21", RequestIdentity.userAgent())
        Repo.put("userAgent", " "); assertEquals("Mozilla/5.0", RequestIdentity.userAgent())
    }

    @Test fun subscriptionHttpActuallySendsTheConfiguredUserAgent() {
        Repo.put("userAgent", "ProviderPlayer/2.5")
        ServerSocket(0).use { server ->
            server.soTimeout = 5000
            val received = AtomicReference("")
            val worker = Thread {
                server.accept().use { socket ->
                    socket.soTimeout = 5000
                    val input = socket.getInputStream().bufferedReader()
                    val headers = ArrayList<String>()
                    while (true) { val line = input.readLine() ?: break; if (line.isEmpty()) break; headers.add(line) }
                    received.set(headers.joinToString("\n"))
                    socket.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK".toByteArray())
                }
            }
            worker.start()
            assertEquals("OK", Repo.http("http://127.0.0.1:${server.localPort}/playlist"))
            worker.join(5000)
            assertTrue(received.get().contains("User-Agent: ProviderPlayer/2.5", ignoreCase = true))
        }
    }

    @Test fun continuousTsDownloadIsMeasuredBeforeConnectionCloses() {
        var now = 1000L
        val meter = StreamTraffic { now }
        val source = ByteArrayDataSource(byteArrayOf(0))
        val spec = DataSpec(Uri.parse("https://example.test/live.ts"))
        // No onTransferEnd: a live TS connection can remain open for hours.
        meter.onBytesTransferred(source, spec, true, 100000)
        now += 1000
        assertEquals(800000L, meter.sampleBps())
        meter.onBytesTransferred(source, spec, false, 900000) // local bytes must not count
        now += 1000
        assertEquals(400000L, meter.sampleBps())
        meter.reset()
        now += 1000
        assertEquals(0L, meter.sampleBps())
    }

    @Test fun resettingPictureReplacesTheRendererAndPreservesPlaybackState() {
        val context = RuntimeEnvironment.getApplication()
        Repo.putB("resumeVod", false)
        val intent = Intent(context, PlayerActivity::class.java)
            .putExtra("url", "file:///nonexistent-test-video.mp4").putExtra("name", "Test")
        val controller = Robolectric.buildActivity(PlayerActivity::class.java, intent).create()
        val activity = controller.get()
        val field = PlayerActivity::class.java.getDeclaredField("player").apply { isAccessible = true }
        val apply = PlayerActivity::class.java.getDeclaredMethod("applyPicture", PictureSettings::class.java).apply { isAccessible = true }
        try {
            val original = field.get(activity) as androidx.media3.exoplayer.ExoPlayer
            original.playWhenReady = false
            original.seekTo(12000)
            original.volume = 0f
            original.trackSelectionParameters = original.trackSelectionParameters.buildUpon().setPreferredAudioLanguage("ar").build()
            val item = original.currentMediaItem
            apply.invoke(activity, PictureSettings())
            val replacement = field.get(activity) as androidx.media3.exoplayer.ExoPlayer
            assertNotSame(original, replacement)
            assertEquals(item, replacement.currentMediaItem)
            assertEquals(12000L, replacement.currentPosition)
            assertFalse(replacement.playWhenReady)
            assertEquals(0f, replacement.volume)
            assertTrue(replacement.trackSelectionParameters.preferredAudioLanguages.contains("ar"))
            assertEquals(PictureSettings(), PictureSettings.load())
        } finally { controller.destroy() }
    }
}
