package com.sultv.app
import org.junit.Assert.assertEquals
import org.junit.Test

class TsCatchupTest {
    @Test fun thresholdsAndContinuousRecovery() {
        val t = TsCatchup()
        fun check(time: Long, buffer: Long, expected: Float) = assertEquals(expected, t.speed(time,true,buffer),0f)
        check(0,6000,1f); check(1000,6001,1.03f); check(2000,4000,1.03f); check(3000,3000,1f)
        t.stall(); check(80000,8000,1f); check(130000,8000,1f)
        t.interrupt(); check(150000,8000,1f); check(209999,8000,1f); check(210000,8000,1.03f)
    }
}
