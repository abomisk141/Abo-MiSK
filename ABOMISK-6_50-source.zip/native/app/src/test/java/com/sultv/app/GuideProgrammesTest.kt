package com.sultv.app

import org.junit.Assert.*
import org.junit.Test

class GuideProgrammesTest {
    @Test fun manyShortProgrammesStillShowOnlyCurrentAndNext() {
        val events = (0 until 30).map { Prog(it * 300000L, (it + 1) * 300000L, "Programme $it") }
        assertEquals(listOf(events[2], events[3]), GuideProgrammes.visible(events, 650000L))
        assertEquals(listOf(events[8], events[9]), GuideProgrammes.visible(events, 2400000L))
    }
    @Test fun longCurrentProgrammeDoesNotHideItsNextProgramme() {
        val current = Prog(0, 10800000L, "Three-hour match")
        val next = Prog(10800000L, 14400000L, "Next show")
        assertEquals(listOf(current, next), GuideProgrammes.visible(listOf(next, current), 1000))
    }
    @Test fun gapsEmptyAndEndOfProgrammeNeverInventCurrentContent() {
        val past = Prog(0, 1000, "Ended"); val future = Prog(3000, 4000, "Next")
        assertEquals(listOf(null, future), GuideProgrammes.visible(listOf(past, future), 2000))
        assertEquals(listOf(null, null), GuideProgrammes.visible(emptyList(), 0))
        assertEquals(listOf(future, null), GuideProgrammes.visible(listOf(past, future), 3000))
        assertEquals(listOf(null, null), GuideProgrammes.visible(listOf(past, future), 4000))
    }
    @Test fun invalidAndOverlappingEntriesChooseTheMostRecentValidCurrentProgramme() {
        val older = Prog(0, 5000, "Older overlap"); val current = Prog(1000, 4000, "Current")
        val next = Prog(4500, 6000, "Following")
        assertEquals(listOf(current, next), GuideProgrammes.visible(listOf(older, next, Prog(0, -1, "Invalid"), current), 2000))
    }
}
