package com.sultv.app

import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import java.net.ServerSocket
import java.net.InetAddress
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "ar-rSA-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class DesignNavigationTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication())
        Repo.sp.edit().clear().commit()
        Repo.putB("referenceLayoutV52", true); Repo.putB("autoUpd", false); Repo.putB("welcome", false); Repo.putB("autoPrev", false)
        Repo.putB("tmdbOn", false); Repo.put("pl_refresh_hours", "0")
        Repo.updChecked = true; Repo.splashShown = true; Repo.dirty = false
    }
    @Test fun legacyDesignMigratesWithoutLosingPlaylistAndFavourites() {
        val playlist = Playlist("test", "My list", "m3u", "https://example.test/list", "", "", "")
        Repo.savePlaylists(listOf(playlist)); Repo.toggleFav("movie-1")
        for (legacy in listOf("atlas", "redcinema", "v50sul", "v50sidebar", "unknown")) {
            Repo.put("ui", legacy); Designs.migrate()
            assertEquals("studio", Repo.s("ui"))
            assertEquals(listOf(playlist), Repo.playlists())
            assertTrue(Repo.isFav("movie-1"))
        }
        for (id in Designs.ids) { Repo.put("ui", id); Designs.migrate(); assertEquals(id, Repo.s("ui")) }
    }
    @Test fun allDesignsRenderPlaylistAndNavigateWithRemoteTargets() {
        val server = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
        val base = "http://127.0.0.1:${server.localPort}"
        val fixture = """#EXTM3U
#EXTINF:-1 group-title="Live",Test Channel
$base/live/test.ts
#EXTINF:-1 group-title="Movies",Test Movie
$base/movie/test.mp4
#EXTINF:-1 group-title="Series",Test Show S01E01
$base/series/test.mp4
"""
        val serving = Thread {
            while (!server.isClosed) {
                try {
                    server.accept().use { socket ->
                        val reader = socket.getInputStream().bufferedReader()
                        while (!reader.readLine().isNullOrEmpty()) { }
                        val bytes = fixture.toByteArray()
                        socket.getOutputStream().apply {
                            write("HTTP/1.1 200 OK\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
                            write(bytes); flush()
                        }
                    }
                } catch (_: java.io.IOException) { }
            }
        }.apply { isDaemon = true; start() }
        try {
            val playlist = Playlist("nav", "Fixture", "m3u", "$base/list", "", "", "")
            Repo.savePlaylists(listOf(playlist)); assertTrue(Repo.load(true)); Repo.dirty = false
            val channel = Repo.list("live").first()
            for (item in Repo.list("live") + Repo.list("movie") + Repo.list("series")) Repo.touch(item.id)
            for (id in Designs.ids.filter { it != "reference" }) {
                Repo.put("ui", id)
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
                val activity = controller.get()
                val root = activity.window.decorView
                try {
                    awaitText(root, if (id == "studio") activity.getString(R.string.my_list) else "Test Movie")
                    if (id == "cinema" || id == "spotlight") {
                        val continueLabel = activity.getString(R.string.cont_watch)
                        awaitText(root, continueLabel)
                        val title = allViews(root).filterIsInstance<TextView>().first { it.text.toString() == continueLabel && (it.parent as? View)?.tag == "home-section:list" }
                        val header = title.parent as ViewGroup
                        val container = header.parent as ViewGroup
                        val continueRow = container.getChildAt(container.indexOfChild(header) + 1)
                        assertNull(continueRow.findViewWithTag<View>("item:${channel.id}"))
                        for (movie in Repo.list("movie")) assertNotNull(continueRow.findViewWithTag<View>("item:${movie.id}"))
                        for (series in Repo.list("series")) assertNotNull(continueRow.findViewWithTag<View>("item:${series.id}"))
                        if (id == "cinema" || id == "spotlight") {
                            assertNull(root.findViewWithTag<View>("item:${channel.id}"))
                            val seriesHeader = root.findViewWithTag<View>("home-section:series")
                            assertNotNull(seriesHeader); assertSame(container, seriesHeader.parent)
                            assertEquals(container.childCount - 2, container.indexOfChild(seriesHeader))
                        } else {
                            val channelTitle = allViews(root).filterIsInstance<TextView>().first { it.text.toString() == "قنوات مباشرة" }
                            val channelHeader = channelTitle.parent as ViewGroup
                            assertSame(container, channelHeader.parent)
                            assertEquals(container.childCount - 2, container.indexOfChild(channelHeader))
                            assertNotNull(root.findViewWithTag<View>("item:${channel.id}"))
                        }
                    }
                    val navs = allViews(root).filterIsInstance<DesignNav>().toList()
                    assertEquals(if (id in listOf("cinema", "studio", "spotlight")) 7 else 8, navs.size) // Cinema matches the approved rail: tabs, search, settings.
                    assertTrue(navs.all { it.isFocusable && it.isClickable && !it.contentDescription.isNullOrBlank() })
                    val movieTab = navs.first { it.contentDescription == activity.getString(R.string.movies) }
                    movieTab.performClick(); shadowOf(Looper.getMainLooper()).idle()
                    assertTrue(movieTab.isSelected)
                    val homeTab = navs.first { it.contentDescription == activity.getString(R.string.home) }
                    homeTab.performClick(); awaitText(root, if (id == "studio") activity.getString(R.string.my_list) else "Test Movie")
                    assertTrue(homeTab.isSelected)
                    // A stop/resume cycle must not leave an activity rendering after destruction.
                    controller.pause().stop().start().resume()
                } finally { controller.pause().stop().destroy() }
            }
        } finally { server.close(); serving.join(1000) }
    }
    @Test @Config(qualifiers = "ar-rSA-w360dp-h640dp-port-mdpi")
    fun allDesignsOpenOnNarrowScreens() {
        for (id in Designs.ids.filter { it != "reference" }) {
            Repo.put("ui", id); Repo.dirty = false
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
            try { assertEquals(if (id in listOf("cinema", "studio", "spotlight")) 7 else 8, allViews(controller.get().window.decorView).filterIsInstance<DesignNav>().count()) }
            finally { controller.pause().stop().destroy() }
        }
    }
    private fun allViews(view: View): Sequence<View> = sequence {
        yield(view)
        if (view is ViewGroup) for (i in 0 until view.childCount) yieldAll(allViews(view.getChildAt(i)))
    }
    private fun awaitText(root: View, text: String) {
        val deadline = System.nanoTime() + 5_000_000_000L
        while (System.nanoTime() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            if (allViews(root).filterIsInstance<TextView>().any { it.text.toString() == text }) return
            Thread.sleep(10)
        }
        fail("Missing playlist title: $text")
    }
}
