# ABO MISK 6.26

Approved fullscreen live-player panel: channel identity, LIVE/actual-quality badges, current programme, real schedule times/progress/current-clock bubble and next programme sit in one dark rounded panel. Six existing metrics retain their data sources with outline icons; the footer separates resolution from the quality badge and labels the TCP measurement as Server. Favourite, audio-only menu, subtitle-only menu and complete settings buttons are functional. With the default unmapped Right key users enter controls; Up exits controls, Back hides the panel while controls are focused, and normal channel zapping/custom remote mappings remain intact outside controls. Focused controls keep the panel visible. Header controls reflow and metrics wrap for large fonts/narrow screens. Minimal and Glass preferences remain supported, and playback/VOD/handoff behavior is unchanged.

Replaced Spotlight home with the approved charcoal/burgundy/copper editorial design. A cinematic hero is driven by three visible movie/series picks; click selects immediately and remote focus debounces artwork/metadata work by 180 ms, with stale-result rejection. Watch and Details operate on the selected title. Shelves contain VOD-only Continue watching with real progress/episode/remaining-time information, Spotlight selections and series; no live shelf. The labelled sidebar uses matching outline icons and bounded remote traversal to Settings. Hero artwork and picks mirror in Arabic and stack on narrower screens without shrinking accessibility fonts. Only catalogue/TMDB artwork is used; no fictional films or broadcast feeds are bundled. Cinema, Live, guide policy and playback settings remain unchanged.

# ABO MISK 6.25

Replaced Live home with the approved charcoal/mint dashboard: branded top navigation and clock, a large live preview with adjacent current-programme details, progress and Watch live/TV guide actions, a favourites channel carousel (honestly labelled Your channels when no favourites exist), playlist-derived category filters and a bounded six-row current/next guide. All content comes from visible configured playlists and parental/visibility rules. Only one muted preview is owned by Live home; it is released before fullscreen playback and when leaving home/background. Publishing the same channel catalogue reuses the player while moving its output surface; filter changes and guide ticks preserve preview and focus. Responsive hero measurement preserves video aspect and readable controls with large fonts and mirrored Arabic layout. Refresh remains in playlist settings. Cinema, Spotlight, saved progress and player configuration remain unchanged.

# ABO MISK 6.24

Replaced Cinema’s home with the approved navy/champagne-gold composition: directional cinematic hero, quieter landscape resume cards, Movies for you and Series for you. Removed live-channel and favourites shelves from Cinema home; favourites and channels remain available via navigation. Spotlight and Live home shelf ordering remains unchanged. Cinema rail now uses the approved outline icon set (TV/reel/clapper/bookmark), icon-only collapsed state, brand header and labelled expanded state; hover/remote expansion, collapse and content-entry behavior remain. Playlist refresh remains accessible in playlist settings. Cinema’s category/channel selection uses quieter gold focus on dark surfaces; other themes retain their palettes. Arabic/English direction is preserved. The shared programme guide now displays exactly two equal-width slots (current and next), each with its actual start/end time, rather than packing every event in a two-hour window. Missing/current-gapped data uses explicit placeholders; future browsing and focus remain available. Screenshots use fixture content, not live subscriber playback. Playback and stream policy are unchanged.

# ABO MISK 6.23

Applied the approved champagne-gold AM/play monogram on navy to the launcher icons at all five Android density sizes, the in-app brand image (welcome, account setup and reference navigation) and the Android TV banner. Cinema and Spotlight rails now show the same image; Cinema exposes the ABO MISK wordmark when expanded. Package identity/signing are unchanged. No playback, saved-data or theme-layout changes.

# ABO MISK 6.22

Playlist options now use the themed rounded, icon-based remote-friendly menu rather than the plain system item list. The header identifies the playlist type, visibility and current status. Use, account details, refresh, edit and show/hide are grouped together; delete is placed last in its own section with red emphasis and retains explicit confirmation. Click and long press open the same menu. Menus are scrollable for large fonts, follow Arabic/English direction and are dismissed when settings closes. No playback policy changes.

# ABO MISK 6.21

Removed the embedded VLC library, fullscreen activity, engine-selection setting, routing and VLC-specific resources/tests at the user’s request. All fullscreen playback uses the existing Media3 player, including installations whose old preferences still select VLC. Existing buffer resilience, bidirectional preview/fullscreen handoff and category-browsing improvements remain. The app package and signing identity remain unchanged.

# ABO MISK 6.20

Embedded VLC 3.6.5: Settings → Playback → Video player selects Media3 (default) or VLC for fullscreen live/VOD/episodes. VLC uses the configured User-Agent, preferred audio language, hardware decoding, audio/subtitle track selection, remote pause/seek/channel switching, VOD resume/progress, episode-next, session-validated live return, bounded reconnect backoff, audio focus and lifecycle release. Preview remains Media3 and is stopped before a VLC launch to avoid concurrent account streams. Media3-only picture effects/external audio are described in the settings hint. Unavailable native libraries fall back once to Media3 without changing the preference. Official universal LibVLC binaries are bundled, increasing APK size. Native decoder/network playback requires physical-device verification; activity/control tests use a fake native-engine boundary.

Live buffer resilience: fast mode now buffers ahead between 6–20 s (previously 1.5–5 s), retaining the 400 ms startup threshold and 3 s requested live offset, with 1.5 s recovery after a stall. Balanced uses 15–40 s / 800 ms startup / 2.5 s recovery; stable uses 30–60 s / 1.5 s startup / 5 s recovery. These limits govern fetching ahead, not a fixed delay behind live. Changes apply to newly created players. Existing format/mode selections remain unchanged. The low/normal/high buffer settings inspected in the SUL APK also allow substantially more forward buffering than the old fast/balanced profiles here; this is a plausible contributor, not a verified diagnosis of the user’s device.

Bidirectional preview/fullscreen transfer now attaches the new video output before detaching the old one, retaining the same player and stream buffer. A bounded capture of the last real frame bridges surface transitions where supported. Returning from fullscreen can transfer the player back with playlist/session validation and expiring ownership. Activity listeners are detached on transfer; picture effects are configured before initial playback and no longer stop/reprepare a healthy transferred player. Physical-device decoder transitions and provider buffering still require device testing.

Faster category browsing for large catalogues:

- Build an active-catalogue index by media type and category once during catalogue publication/reapplication. Normal category selection looks up that bucket directly and applies current visibility/parental rules, rather than scanning the entire catalogue. Series buckets contain shows rather than duplicate episodes. Index state is cleared during backup restore and rebuilt after category renaming.
- Stop obsolete hover-generated work immediately on a new category focus, while retaining the 180 ms settle delay. Restore the rendered selection when cancelling an unfinished preview; explicit OK still starts the selected category if work is pending. General catalogue/visibility refreshes are not cancelled by this hover shortcut.
- Diff comparisons, filtering, ordering and decoration loops respond to interruption. Changing category/search scope uses two range notifications instead of computing a large cross-scope diff. In-scope updates remain incremental and unchanged category lists skip diffing.
- Live rows no longer read VOD progress for decoration. Category changes avoid redundant whole-layout requests when pane weights are unchanged.

Validation includes 2,000 categories/20,000 channels, passing 600 categories rapidly and publishing only the final selection, grouped Arabic and English browsing, interrupting an obsolete 30,000-item diff, OK during pending work, and index visibility/locks/rename/restore behavior, plus the full regression suite. These are automated correctness/work-avoidance checks, not a physical-TV FPS or latency benchmark. Playback format selections are unchanged; choose HLS where it opens faster on the provider.

# ABO MISK 6.19

Returning from fullscreen live playback now selects the last tuned channel rather than the channel initially opened. The player publishes its current channel after every switch; the browse screen consumes it through a lifecycle-aware activity result tied to the originating playback session and playlist. Both direct playback and preview handoff use the same return contract.

The original category and search remain when they contain the final channel, and the content scroll moves to that channel even when it is offscreen. Choosing a different group inside the player returns to the final channel’s group and clears only an incompatible search. Old-session or other-account results are ignored. Preview identity follows the returned channel. Automatic preview waits for the return bookmark to finish restoring, so it does not briefly reconnect the originally opened channel. Preview lookup also respects visible live items. The current live channel is also saved for activity recreation while the catalogue is available. Movie/series bookmarks retain their existing behavior.

Validation covers Up/Down zapping including wraparound to a distant channel, direct launch and preview handoff in four themes and both languages, changing groups/search, unrelated result rejection, player recreation, and the full regression suite.

# ABO MISK 6.18

Reduced avoidable client-side live delay:

- Fresh Xtream preferences default to MPEG-TS; explicit TS/HLS selections and supplied M3U URLs remain intact. Playback settings and the browse configuration key use the same default.
- Fast mode retains 400 ms startup buffering, reduces the load-control maximum target from 8 to 5 seconds, and uses 1 second after rebuffering. These are loading thresholds, not guaranteed end-to-end latency or strict whole-segment memory bounds. Balanced/stable and VOD profiles remain available.
- Live recovery and returning from background discard the old media position and reconnect to the latest source state. Background live playback closes its loaders/sockets; returning also restarts the chosen external audio source. VOD keeps its saved position. Retry backoff limits remain intact.
- Added Return to live in playback options for an explicit fresh connection.
- Optional accumulated-delay correction operates only in Fast mode on a known seekable HLS window during active playback, after ten seconds of sustained excess lag, with at least sixty seconds between corrections. It skips intentional manual-pause/time-shift sessions, external-channel audio, retrying, paused and unknown/unseekable sources. Whole-segment HLS retains at least two target durations or the advertised holdback; low-latency HLS respects part holdback. An unknown manifest disables the correction. The switch is in Playback settings.

Validation covers fresh/explicit stream format preferences, preserved direct URLs, sustained-lag/cooldown/invalid-window cases, legacy and low-latency HLS margins, live background restart versus VOD position, intentional pause, track/volume retention and retry counter preservation, plus the complete regression suite. No claim is made for a measured reduction in broadcast-to-screen seconds: provider encoding/relay delays and actual TV decoding remain outside this automated verification.

# ABO MISK 6.17

Added themed vector icons beside download, upload, connection latency, bitrate, frame rate and quality values in the full live overlay. Stats wrap into additional rows when large fonts need more width; icons also accompany the four existing glass-overlay metrics. Measurement calculations and the minimal overlay composition are preserved. Quality labels are localized.

The channel guide now displays a two-hour window with half-hour labels aligned to the channel rows. Move toward the guide to focus it; Right advances the shared window by 30 minutes, Left returns toward now, and Left at now returns to the channel. Back from the guide returns the window to now and focuses its channel. Future browsing is retained across minute refreshes and vertical channel navigation, while existing horizontal category exits stay available from channel rows. Navigation covers the existing cached guide horizon (up to a window beginning 10 hours ahead); no additional EPG download or merged timeline is introduced. Empty future slots show the no-information placeholder.

Validation covers all six icons in Arabic/English and normal/large fonts, glass inline icons, a real rendered overlay preview with illustrative values, two-hour browsing in all four themes and both languages, preserving guide focus during repeated Down, minute-refresh behavior, Back-to-now and category exit, plus the full regression suite.

# ABO MISK 6.16

A single visible playlist uses plain categories with no playlist heading/arrow, regardless of previously managed visibility. Two or more visible playlists retain expandable headings.

Movie/series/favourites grids now explicitly handle rapid vertical remote input, retaining focus while offscreen cards attach and appending the next catalogue page when needed. Vertical movement follows the grid span and stays inside the poster grid at the bottom. Horizontal exit remains available and clears queued navigation. First-row Up can still enter Continue watching. The existing channel-navigation path is retained.

Playback quality/audio/subtitle options now use bounded, scrollable themed cards with section headings, icons, selection marks and explicit remote focus order. Large fonts can wrap labels while the footer remains accessible. Existing track overrides, automatic quality, subtitle toggles, picture controls and diagnostics remain connected to their actions; choosing a native audio track restores original audio when external channel audio was active.

The alternate-channel audio picker has a playlist selector, asynchronous per-account loading/search and a source name beneath every channel. Only visible live-enabled playlists are offered. Each audio candidate pins its stream URL to its own account before playback, including Xtream TS/HLS preference, without changing the active video account. Hidden/locked categories stay excluded. Dialog dismissal cancels obsolete work.

Validation covers rapid 700-card movie/series navigation through pagination in four themes and both languages, intentional horizontal exits with queued movement, single/two-playlist visibility, large-font menu scrolling, automatic-quality action wiring, and duplicate channel IDs/names in two local Xtream accounts. No actual TV playback-latency or audio-sync benchmark was performed.

# ABO MISK 6.15

Replaced the global grouped-playlists switch with Show/Hide in each playlist’s settings menu. Saved playlists appear together by default when more than one is available; each has expandable categories. A single untouched account retains its compact category layout. Previously saved grouping preferences no longer control visibility.

Hidden accounts remain in Settings with credentials, cache, favourites and progress intact, and can be shown again. Hiding the current account selects another visible account when available; hiding every account leaves an empty browse/home state. A failed replacement-account load never exposes the hidden account’s items. Use playlist also shows that account. Visibility preferences are included in existing encrypted backups. Global search also respects account visibility.

Validation covers independent visibility, both menu actions in Arabic/English, empty state with all accounts hidden, replacement-account failure, preserved account/cache/favourite/progress data, backup inclusion and search hiding/restoration, plus the complete regression suite.

# ABO MISK 6.14

Optional grouped playlist categories (Settings → Playlists → Show playlists together), disabled by default. Channels, movies and series each show playlist headings with independent expand/collapse state. Opening a heading reads its cached catalogue, fetching it in the background only when missing; it does not change the active account. Other-account category summaries use one serialized worker. Collapsing retains the current content and expansion state survives reopening.

Selecting or dwelling on another account’s category loads and commits that account before displaying/playing its content. Failed account loads retain the previous active catalogue. Existing per-item identities, favourites and progress are preserved without migration; this is grouped account browsing, not a merged cross-account home/favourites catalogue. Detail/player and EPG requests use the selected account; stale EPG results cannot overwrite a newer catalogue. Remote category management applies only to the active account’s actual categories, excluding playlist headings.

Validation uses two local M3U accounts with matching category names across live/movies/series, expanded state restoration, default-off behavior, cached expansion and account failure. Real TV/provider testing is still required.

# ABO MISK 6.13

Activating a sidebar section now collapses expanding rails and moves focus into that section’s categories after its results are ready. Cinema pointer expansion stays dismissed until the pointer leaves the rail. Arabic and English navigation are covered.

# ABO MISK 6.12

Improved catalogue reliability and UI responsiveness:

- Playlist replacement is staged and written with AtomicFile before publication. Empty, malformed or partially failed Xtream downloads retain the last good catalogue/cache. The settings refresh action no longer deletes the cache or silently switches the active playlist. Background refreshes share concurrent downloads, and M3U guide URLs are staged separately from the active guide.
- Removed the silent 600-item VOD display cap. Movies/series/favourites display 120 items initially and append batches near the scroll boundary. All catalogue metadata is still obtained through the existing provider APIs; this is presentation pagination, not server pagination. Saved item identity and scroll state expand the window as needed when returning to a distant item. Manual ordering no longer truncates at 500 items.
- Large catalogue/category filtering, sorting, search and list differences run on a bounded latest-request worker. Obsolete searches are interrupted/discarded. Category entry waits for its own results to prevent focus drifting into another category during asynchronous updates.
- DiffUtil updates changed rows rather than rebuilding unchanged content/category/continue-watching lists. A full refresh remains only when switching between structurally different channel-row and poster-grid layouts. Page appends use range insertion notifications.
- Home horizontal rows defer offscreen posters and clear detached/hidden requests. Idle poster grids preload only the next two images at low priority; changing position or leaving cancels preloads. Existing image caching and User-Agent isolation remain.
- Detail/artwork/search workers are bounded and cancelled on destruction/dismissal. Tracked provider/TMDB connections are disconnected off the main thread on cancellation. Concurrent metadata calls share a single request; cancelled results cannot overwrite a newer catalogue. Metadata maps are concurrent.

Validation includes a 1,800-item catalogue, searching and returning to its last item, incremental favourite updates, failed/empty/partial refresh rollback, concurrent refresh/episode request sharing, latest-task cancellation, offscreen image deferral and prefetch sharing, plus all existing navigation, backup, picture, account and font-size checks. No physical-TV FPS, long-running playback or live-provider speed comparison was available; device validation remains necessary.

# ABO MISK 6.11

Removed the See all buttons from home rows in Cinema and Spotlight, as requested. Section titles and content cards remain.

Fixed the TV settings sidebar clipping its last sections, including Backup and restore and About, at normal or enlarged text sizes. The section list now scrolls vertically within the space below the fixed Settings heading. Explicit Up/Down focus links keep remote navigation in section order, with scroll-to-focused-row behavior. Content uses explicit wrap-content measurements; visibility is rechecked after layout so early focus requests cannot leave a row partially clipped. Recreating Settings restores focus to the selected section instead of falling back to General. Existing font sizes and themes are preserved.

Validation covers Arabic/English, all four configured text sizes, 480/540-pixel TV test heights, fully visible focused bottom sections, and remote traversal through all sections in both directions.

# ABO MISK 6.10

Replaced the memory-only four-worker poster loader with Glide 4.16.0. Artwork now uses a bounded 128 MiB private disk cache, heap-aware memory/bitmap-pool limits, shared in-flight requests and lifecycle-aware request cancellation. Rebinding or recycling a card clears its old image request. Decode targets follow display dimensions rather than a fixed sampling factor; hero/backdrop requests have higher priority. Known oversized public TMDB image URLs request suitable thumbnail/backdrop sizes; provider URLs remain unchanged.

The configured subscription User-Agent is retained and included in the image-cache identity, preventing reuse of responses from a different identity. Blank URLs clear the image, and late callbacks cannot start requests on destroyed activities. Playback and catalogue behavior are unchanged.

Validation checks shared downloads, loading from disk after clearing memory, User-Agent isolation, stale-image prevention during rapid rebinding, and conservative TMDB URL resizing. Local HTTP fixtures establish cache behavior; no controlled first-load speed comparison with SUL or a live provider was performed. Initial downloads still depend on the image server and connection.

# ABO MISK 6.9

Fixed returning from movie/series details or playback losing the selected category and card. Before opening content, the browser captures the current playlist, media tab, category, search query, stable item ID and both RecyclerView scroll states. Returning restores those states and focuses the same item; automatic category-focus previews are suppressed until restoration completes, preventing an initial category from replacing the saved category. Browse state also survives activity recreation. Changed playlists discard the old return state, and a removed item falls back to a valid position.

Validation reproduces a category list trying to focus its first row on return, then checks the selected movie/series, category and both scroll anchors across all four designs, including RTL. A separate recreation check restores the selected series from saved activity state. Existing navigation, ordering, backup, playback and account-information checks remain required. Physical-TV remote behavior still benefits from device testing.

# ABO MISK 6.8

Added per-playlist Subscription information under Settings → Playlists → playlist menu. Xtream accounts (including recognizable get.php M3U links) query their own player_api.php account endpoint, without changing the active playlist. The view shows provider status, expiry date, remaining days, account creation/trial status and active/maximum connections when supplied. Cached remaining-time summaries appear under playlist names after checking an account. Refresh failures retain and label the last successful reading.

Only an explicitly empty/null expiry on an active provider account is labelled as no reported expiry; missing, invalid and zero dates remain unknown. Remaining days are rounded upward and calculated from the device clock. Unsupported M3U links can have a clearly labelled manual date, with a clear action. Manual dates end at local midnight after the chosen day and are scoped to the account identity. Account caches contain only selected status fields, not credentials, and are invalidated by account or User-Agent changes.

Validation covers account parsing, missing/unlimited/expired/denied cases, encoded Xtream URLs derived from M3U, local manual dates, cache isolation, and a local HTTP request for a non-active playlist with its own credentials and configured User-Agent. No live provider account was supplied for integration testing. The cancelled sports schedule was not included.

# ABO MISK 6.7

Fixed Cinema and Spotlight hero banners at larger text sizes. The banner now derives its height from measured text content, keeping the existing hero height as a minimum; artwork fills the resulting frame without determining its height. The text column uses the actual available banner width instead of an estimated screen/sidebar width. Action buttons use scalable minimum heights and switch to a vertical layout when their natural widths do not fit, preserving the chosen font size.

Validation covers long Arabic/English titles and descriptions, both styles, all four configured font sizes, narrow/wide banner widths, and action reflow back to a horizontal row when widened. Existing title/description line limits remain in place. The live-preview hero is unchanged.

# ABO MISK 6.6

Replaced the category visibility picker used for live TV, movies and series with a rounded, theme-aware native TV dialog. Added Select all, Deselect all and a visible-category count, plus an explicit explanation that a checked category is shown. Changes remain pending until Save; Cancel/Back discards them. Previously hidden categories absent from the current provider catalogue are preserved. The list reuses rows for large catalogues and supports remote selection.

Validation covers selecting all without affecting other media types, cancelling bulk changes, and individual selection after deselecting all. The supplied design image is an approximate mockup; actual colours follow the active app theme.

# ABO MISK 6.5

Added Settings → Backup and restore. Portable password-protected files include accounts, favourites, category/channel order, hidden/locked items, parental PIN settings, watch progress, themes, playback settings and User-Agent. Cached catalogues, images and diagnostic messages are excluded. Device document pickers save/open files; the latest encrypted copy can also be shared, including as an export fallback when a TV lacks a document-creation provider.

The versioned format uses a fresh 16-byte salt and 12-byte IV, PBKDF2-HMAC-SHA1 (210,000 iterations, 256-bit key) and AES-GCM authenticated encryption. Passwords are not stored. Wrong-password, tampering, oversized and unsupported files are rejected before changing preferences. Validated files show their date and account/favourite counts before a replacement confirmation. Successful restore clears old in-memory state and invalidates restored playlist caches, then reloads the application. Export uses atomic writes for the private encrypted copy; restoring preferences uses one synchronous transaction with an attempted rollback on storage failure.

Validation includes encrypted round trips of accounts/favourites/order/progress/parental settings, rejection without data changes, fresh cryptographic parameters, bounded file reads and catalogue invalidation. Physical-TV file-manager integration still requires device testing.

# ABO MISK 6.4

Added ready-made VLC, Chrome and OkHttp User-Agent choices alongside the original default and custom entry. Preset values match the corresponding options observed in SUL. Existing custom preferences are preserved and recognized when they match a preset. The choice changes HTTP identity, not the playback engine.

# ABO MISK 6.3

Added an in-player diagnostics panel for live TV and VOD: rolling incoming stream-data rate (including continuous TS transfers), declared video bitrate, buffered duration, startup readiness, buffering events/time, dropped/rendered frames, resolution, format and recent classified errors. Reports can be copied without URLs, credentials or raw exception text. Measurements and hints do not establish the exact source of a network fault or measure end-to-end broadcast delay.

Added optional video brightness, contrast and saturation controls, with a narrow remote-friendly preview panel, explicit Apply/save, and an original-picture reset. Adjustments are off by default and use Media3 GPU effects. Applying changes can briefly reload playback while preserving position and pause state. Frame-processing failures automatically disable adjustments and retry with the original picture; protected content is excluded when identified.

Added Settings → Playback → User-Agent. The supplied identity is shared by playback, playlist/Xtream requests, EPG and image downloads; blank restores the previous Mozilla/5.0 default. Invalid control characters and oversized values are rejected. Returning from settings rebuilds previews with the new identity. Reopen a stream and refresh a previously failed playlist after editing it.

The app name, application ID, update signing key, saved favourites, playlists and progress are preserved. Unit/Robolectric checks cover measurement timing, continuous transfers, privacy, preference persistence and an actual local HTTP request carrying the configured User-Agent. Physical-TV rendering and subscription streams still require device validation.

# ABO MISK 6.2

Separated live-stream buffering from movie/series buffering. Low-delay mode is the new live default, with a shorter startup buffer and an explicit 3-second HLS live-edge target plus gentle catch-up. Balanced and stable modes remain available under Settings → Playback. The target is a client setting, not a guarantee of end-to-end broadcast delay; HLS segment availability and provider latency still apply.

The same live policy is used by channel previews, home previews, full-screen playback, channel switching and secondary live audio. VOD buffering and resume positions are retained.

Added an optional Xtream-only HLS/TS selector. HLS remains the format default for compatibility. Switching to TS changes generated Xtream live URLs only; existing M3U playlist URLs and VOD URLs are preserved. Returning from settings recreates previews when a playback setting changes.

Validation covers independent live/VOD policies, unchanged M3U URLs, audio preferences and all existing UI/ordering checks. No provider stream or competing app was available for an actual delay measurement.
