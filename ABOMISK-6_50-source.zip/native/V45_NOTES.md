ABO MISK v4.5: player recovery overlay with 5 attempts and countdown; manual retry after exhaustion; bitrate network-estimate fallback and measured FPS fallback. Build and device testing required.
