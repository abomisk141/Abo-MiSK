# ABO MISK v4.9 source candidate

Built on v4.6-rebuilt-from-v4.5 source. Added optional Red Cinema theme and UI style, cinematic backdrop asset, remote-focusable home tiles, and manual refresh button in top bar. Existing playlist refresh cache method preserves current playback and existing saved preferences; refreshed data becomes visible after normal playlist reload.

Limitations: Replay tile currently routes to existing My List because native catch-up/replay functionality is not implemented. Background is an edited crop of the approved generated mockup, not the original full-resolution cinema photograph. No Android APK build or on-device functional test performed. Keystore is included as in supplied project; keep source private. Signing configuration has credentials in build.gradle and should be moved to secrets.

Select theme Red Cinema and UI style Red Cinema in Settings > Appearance to activate. Both are opt-in to preserve existing appearance.
