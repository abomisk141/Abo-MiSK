# ABO MISK — Smart Metadata (source patch)

- IPTV info remains the primary source for synopsis, rating, year, genre, cast names and backdrop.
- TMDB is queried on detail/hero demand for missing backdrop or actor photos, not for every item during playlist import.
- Three modes: Auto, IPTV only, Fill missing. Auto and Fill currently use the same on-demand strategy.
- Successful actor-photo and backdrop results cached in SharedPreferences for 30 days; capped at ~1200 entries.
- TMDB API key is still entered through Settings. No key has been embedded. For a shared app-wide key, implement a server proxy; never ship the private key in APK.
- No Android SDK/build verification in this environment; test on device before release.
