# ABO MISK v4.3 — source merge (uncompiled)

Base: Claude native-v4.2, retaining Remote.kt, custom button mapping, numeric channel jump, last-channel action, settings and resources.

Added from Smart Metadata: Tmdb.kt with 30-day bounded disk cache and metadata mode, SeriesActivity on-demand missing-data logic, Smart Metadata choice in SettingsActivity.

Added from performance branch: M3U connection cleanup, bounded stream recovery, probe de-duplication, rapid-zap throttle, player lifecycle cleanup and play/pause media key.

No API secret embedded. No Android SDK or device testing performed. Please build with existing GitHub Actions and test on Android TV before release.
