# ABO MISK v5.0 — TV UI rebuild (working source)

- Reworked the v50sidebar and v50top TV layouts with a fixed dark cinematic violet palette, a larger navigational rail/top bar, and vector settings/refresh controls.
- Home dashboard now uses full content width instead of retaining an empty category sidebar, a taller backdrop hero, four working category shortcuts, and larger horizontal poster cards.
- Replaced the movie and series icons with new vector clapperboard and film-reel artwork.
- Legacy styles and the IPTV player, playlists, signing configuration, favorites, and quality overlay were left in place.

This is a source-level implementation, **not** a visually verified 1:1 reproduction. No APK was compiled or tested on a TV in this environment. The home hero and poster rows depend on playlist metadata and available backdrop images.

## v5.0 rebuild #2 — matched to the approved mock-up
- New `V50.kt`: side panel (design 1), single rounded top bar (design 2), round search/bell buttons, clock + wifi, hero pills, and `V50HomeView`.
- Design 1: left side menu (8 entries), hero with purple frame, 4 colour tiles (live / movies / series / categories), "continue watching" landscape cards with S/E label, % and progress bar.
- Design 2: top bar with logo + 6 pills + search/bell/clock/wifi, big hero with side arrows and dots, "most watched" poster row.
- New outline icons `ic_n_*`. Bell = refresh playlist. "Downloads" shows a "coming soon" toast (no downloads feature exists yet).
- Not compiled here (no Android SDK) — build with the existing GitHub workflow and report any compile error.
