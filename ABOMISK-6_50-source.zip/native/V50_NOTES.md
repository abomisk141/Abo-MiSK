# ABO MISK v5.0 TV source

Based on v4.9 quality and playing-channel source. Added two selectable home layouts in Settings > Appearance: V5 Cinema Sidebar (labeled side rail) and V5 Cinema Top (horizontal navigation). Both reuse the existing working HomeView hero and rows, rather than static mockup graphics. Choose the existing Aurora/Premium purple theme in Settings > Appearance for the reference palette. Existing Live TV/player code is retained.

The mockup artwork is illustrative and is not bundled; posters are loaded from the user's configured content/metadata. Android APK compilation and TV remote QA have not been performed in this environment.
