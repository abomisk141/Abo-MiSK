# ABO MISK Premium UI v4.4 — initial integration

- New optional theme: Settings > Appearance > Theme > ABO MISK Premium.
- Original themes retained. Existing playlists, favorites, playback and update logic not intentionally modified.
- Dark navy/purple palette with rounded focus controls, and modern long-press and exit dialogs from prior v4.4 draft.
- Search field styling retained from prior draft.

## Still pending
- Full visual parity with the concept image: channel list layout, top navigation, search overlay, responsive layouts, and animation.
- Kotlin/Gradle build and device tests.
- Version remains 4.3 until a verified release build.

Do not publish as official v4.4 before testing.
