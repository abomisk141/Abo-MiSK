package com.sultv.app

import android.content.res.Configuration
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.view.ContextThemeWrapper
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class HeroBannerLayoutTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit()
        Repo.putB("referenceLayoutV52", true); Repo.putB("tmdbOn", false)
    }
    private fun views(v: View): List<View> = listOf(v) + if (v is ViewGroup)
        (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()

    @Test fun longArabicAndEnglishBannersFitEveryConfiguredFontSizeInBothDesigns() {
        val item = Item("hero-test", "A very long movie title — عنوان فيلم طويل لاختبار وضوح الخط وتوزيع البنر", "", "Movies", "movie", year = "2026", rate = "8.7")
        Repo.info[item.id] = Info("وصف طويل لاختبار مساحة النص داخل البنر عند تكبير الخط. ".repeat(20), "", "", "", "")
        val base = RuntimeEnvironment.getApplication()
        for (style in listOf("cinema", "spotlight")) for (lang in listOf("ar", "en"))
            for (scale in listOf(.9f, 1f, 1.15f, 1.3f)) {
                Repo.put("ui", style); Th.load()
                val config = Configuration(base.resources.configuration).apply { fontScale = scale; setLayoutDirection(Locale(lang)) }
                val context = ContextThemeWrapper(base.createConfigurationContext(config), R.style.AppTheme)
                val home = DesignHomeView(context, style, {}, {}, {}, {})
                try {
                    val container = (home.root as ViewGroup).getChildAt(0) as LinearLayout
                    DesignHomeView::class.java.getDeclaredMethod("movieHero", Item::class.java, LinearLayout::class.java, Int::class.javaPrimitiveType)
                        .apply { isAccessible = true }.invoke(home, item, container, 240)
                    for (width in listOf(420, 760)) {
                        home.root.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
                        home.root.layout(0, 0, width, 540)
                        val hero = home.root.findViewWithTag<HeroBannerLayout>("movie-hero")
                        val text = home.root.findViewWithTag<LinearLayout>("hero-text")
                        val actions = home.root.findViewWithTag<HeroActionsLayout>("hero-actions")
                        val title = home.root.findViewWithTag<TextView>("hero-title")
                        val message = "$style/$lang/$scale/$width"
                        assertTrue(message, text.top >= 0 && text.bottom <= hero.height)
                        assertTrue(message, text.left >= 0 && text.right <= hero.width)
                        assertTrue(message, actions.bottom <= text.height - text.paddingBottom)
                        assertTrue(message, title.textSize >= 34f * scale - .1f) // no silent font shrinking
                        for (button in views(actions).filterIsInstance<Button>()) {
                            assertTrue(message, button.right <= actions.width && button.bottom <= actions.height)
                            assertTrue(message, button.height >= (44 * scale.coerceAtLeast(1f)).toInt())
                        }
                    }
                } finally { home.destroy() }
            }
    }

    @Test fun actionButtonsReflowWhenNarrowAndReturnToOneRowWhenWidened() {
        val c = RuntimeEnvironment.getApplication()
        val actions = HeroActionsLayout(c)
        for (text in listOf("Watch this movie now", "Full movie details")) actions.addView(Button(c).apply { this.text = text }, LinearLayout.LayoutParams(-2, -2))
        fun measure(width: Int) { actions.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)); actions.layout(0, 0, width, actions.measuredHeight) }
        measure(220); assertEquals(LinearLayout.VERTICAL, actions.orientation)
        measure(900); assertEquals(LinearLayout.HORIZONTAL, actions.orientation)
    }
}
