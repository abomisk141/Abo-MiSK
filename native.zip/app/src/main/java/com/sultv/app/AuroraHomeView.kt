package com.sultv.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.widget.Button
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

internal fun Context.auroraGlass(focused: Boolean = false, radius: Int = 16, accent: Boolean = false) =
    GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, when {
        focused -> intArrayOf(col("#D56CDBE1"), col("#D323697D"), col("#DC102D43"), col("#D4295B70"))
        accent -> intArrayOf(col("#BC657D96"), col("#BB25465D"), col("#D518293F"), col("#C4445777"))
        else -> intArrayOf(col("#B46A7893"), col("#B3324059"), col("#C51B243C"), col("#BD343E5B"))
    }).apply {
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(if (focused) 2 else 1), when {
            focused -> col("#70FFFF")
            accent -> col("#AE50BEBE")
            else -> col("#858EABD0")
        })
    }

internal fun Button.supportGlassBackground(accent: Boolean) {
    background = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), context.auroraGlass(true, 12))
        addState(intArrayOf(android.R.attr.state_pressed), context.auroraGlass(true, 12))
        addState(intArrayOf(), context.auroraGlass(radius = 12, accent = accent))
    }
}

internal class AuroraHomeView(
    private val c: Context,
    private val navigate: (String) -> Unit,
    private val open: (Item) -> Unit,
    private val resume: (Item) -> Unit,
    private val more: () -> Unit,
    private val bannerOnly: Boolean = false
) : HomeLike {
    private val compact = bannerOnly || c.resources.configuration.screenHeightDp < 500
    override val root = LinearLayout(c).apply {
        layoutDirection = c.resources.configuration.layoutDirection
        orientation = if (c.resources.configuration.screenWidthDp >= 600) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        clipChildren = false
    }
    private val handler = Handler(Looper.getMainLooper())
    private val work = LatestWork()
    private val list = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(c.dp(10), c.dp(if (compact) 12 else 32), c.dp(16), c.dp(8))
    }
    private val preview = FrameLayout(c).apply { tag = "aurora-home-artwork" }
    private val artwork = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val poster = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
    private val title = label(if (compact) 25f else 37f, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
    private val meta = label(14f).apply { setTextColor(col("#95EDE7")); maxLines = 1 }
    private val summary = label(if (compact) 13f else 16f).apply { maxLines = if (compact) 2 else 3; ellipsize = TextUtils.TruncateAt.END }
    private var activate: () -> Unit = {}
    private val action = Designs.action(c, "", R.drawable.ic_n_play, true) { activate() }.apply { textSize = if (compact) 14f else 17f; minimumHeight = c.dp(if (compact) 38 else 50); tag = "hero-play" }
    private var generation = 0
    private var recent = emptyList<Item>()
    private var recentIndex = 0
    private var shownKey: String? = null
    private var running = false
    private val progressText = label(13f)
    private val progressBar = WatchBar(c)
    private val recentTabs = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
    private val rotate = object : Runnable {
        override fun run() {
            if (!running || recent.size < 2 || shownKey != "recent") return
            if (!recentTabs.hasFocus() && !action.hasFocus()) {
                recentIndex = (recentIndex + 1) % recent.size
                show("recent")
            }
            handler.postDelayed(this, 8000)
        }
    }
    private var picks: Map<String, Item> = emptyMap()

    init {
        val wide = root.orientation == LinearLayout.HORIZONTAL
        val choices = ScrollView(c).apply { isFillViewport = true; addView(list) }
        if (!bannerOnly) root.addView(choices, if (wide) LinearLayout.LayoutParams(0, -1, 32f) else LinearLayout.LayoutParams(-1, -2))
        root.addView(preview, if (bannerOnly) LinearLayout.LayoutParams(-1, -1) else if (wide) LinearLayout.LayoutParams(0, -1, 68f) else LinearLayout.LayoutParams(-1, 0, 1f))
        preview.addView(artwork, FrameLayout.LayoutParams(-1, -1))
        val rtl = c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        preview.addView(View(c).apply {
            background = GradientDrawable(
                if (rtl) GradientDrawable.Orientation.RIGHT_LEFT else GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(col("#F4101A30"), col("#66101930"), Color.TRANSPARENT))
        }, FrameLayout.LayoutParams(-1, -1))
        preview.addView(View(c).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, col("#5C060D1C"), col("#FA091124")))
        }, FrameLayout.LayoutParams(-1, -1))
        val details = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(24), c.dp(8), c.dp(24), c.dp(if (compact) 12 else 22))
            addView(title)
            addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(5) })
            addView(summary, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(8) })
            addView(progressText)
            addView(progressBar, LinearLayout.LayoutParams(-1, c.dp(4)).apply { topMargin = c.dp(5) })
            addView(action, LinearLayout.LayoutParams(-1, c.dp(if (compact) 38 else 50)).apply { topMargin = c.dp(if (compact) 8 else 14) })
            addView(recentTabs, LinearLayout.LayoutParams(-1, c.dp(if (compact) 38 else 55)).apply { topMargin = c.dp(8) })
        }
        if (bannerOnly || wide) {
            val columns = LinearLayout(c).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(details, LinearLayout.LayoutParams(0, -2, 75f))
                addView(poster, LinearLayout.LayoutParams(0, -1, 25f).apply {
                    marginEnd = c.dp(10); topMargin = c.dp(30); bottomMargin = c.dp(10)
                })
            }
            preview.addView(columns, FrameLayout.LayoutParams(-1, -1))
        } else preview.addView(details, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val clock = label(15f, true).apply {
            text = hm(System.currentTimeMillis())
            background = c.auroraGlass(radius = 20)
            setPadding(c.dp(12), c.dp(5), c.dp(12), c.dp(5))
        }
        preview.addView(clock, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = c.dp(16); marginEnd = c.dp(16)
        })
        buildChoices()
    }

    override fun start() {
        if (running) return
        running = true
        handler.postDelayed(rotate, 8000)
    }
    override fun stop() { running = false; handler.removeCallbacks(rotate); generation++; work.cancel() }
    override fun destroy() { stop(); work.close(); handler.removeCallbacksAndMessages(null) }

    override fun render() {
        val token = ++generation
        work.submit {
            val movies = Repo.list("movie")
            val shows = Repo.list("series")
            val ids = Repo.recent()
            val wanted = ids.toHashSet()
            val available = shows.asSequence().filter { it.id in wanted }.associateBy { it.id }
            val next = ids.mapNotNull { available[it] }.take(6)
            val featured = mapOf("movie" to movies.firstOrNull(), "series" to shows.firstOrNull(), "live" to Repo.list("live").firstOrNull())
                .mapNotNull { (key, item) -> item?.let { key to it } }.toMap()
            handler.post {
                if (generation != token) return@post
                val previous = recent.getOrNull(recentIndex)?.id
                recent = next.take(5)
                recentIndex = recent.indexOfFirst { it.id == previous }.coerceAtLeast(0)
                buildRecentTabs(next.size > 5)
                picks = featured
                if (bannerOnly) show("recent") else buildChoices()
            }
        }
    }

    private fun buildChoices() {
        val focused = list.findFocus()?.tag as? String
        val configured = HomePreferences.custom("aurora")
        val rows = if (configured) HomePreferences.rows("aurora") else listOf("live", "movie", "series", "recent")
        val choices = rows.filter { it != "matches" && (it != "recent" || recent.isNotEmpty()) }
        val chosen = focused?.takeIf { it in choices } ?: choices.lastOrNull()
        list.removeAllViews()
        list.addView(label(if (compact) 25f else 32f, true).apply { text = c.getString(R.string.home) },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(if (compact) 6 else 16) })
        choices.forEach { key ->
            val row = label(if (compact) 15f else 18f, true).apply {
                tag = key
                text = HomePreferences.label(c, key)
                isFocusable = true
                gravity = Gravity.CENTER_VERTICAL
                val icon = when (key) {
                    "live" -> R.drawable.ic_tv
                    "movie" -> R.drawable.ic_n_movie
                    "series" -> R.drawable.ic_n_series
                    else -> R.drawable.ic_n_play
                }
                setCompoundDrawablesRelativeWithIntrinsicBounds(Th.icon(c, icon, Th.fg), null, null, null)
                compoundDrawablePadding = c.dp(10)
                setPadding(c.dp(14), c.dp(6), c.dp(14), c.dp(6))
                background = c.auroraGlass()
                setOnFocusChangeListener { view, hasFocus ->
                    view.background = c.auroraGlass(hasFocus)
                    if (hasFocus) show(key)
                }
                setOnClickListener { destination(key) }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, c.dp(if (compact) 42 else 57)).apply { topMargin = c.dp(if (compact) 5 else 8) })
            if (focused == key) row.requestFocus()
        }
        show(chosen)
    }

    private fun destination(key: String) {
        if (key == "recent") recent.getOrNull(recentIndex)?.let(open) else navigate(key)
    }

    private fun show(key: String?) {
        if (shownKey != key && running) {
            handler.removeCallbacks(rotate)
            if (key == "recent") handler.postDelayed(rotate, 8000)
        }
        shownKey = key
        recentTabs.visibility = if (key == "recent" && recent.isNotEmpty()) View.VISIBLE else View.GONE
        for (index in recent.indices) {
            val tab = recentTabs.getChildAt(index) as FrameLayout
            tab.foreground = c.auroraGlass(tab.hasFocus() || index == recentIndex, 9).apply {
                setColor(Color.TRANSPARENT)
            }
        }
        val item = if (key == "recent") recent.getOrNull(recentIndex) else picks[key]
        if (poster.parent != null) Img.load(poster, item?.logo.orEmpty(), 1)
        title.text = item?.name ?: key?.let { HomePreferences.label(c, it) } ?: c.getString(R.string.home)
        val info = item?.let { Repo.info[it.id] }
        val episode = if (key == "recent" && item?.kind == "series") Repo.s("lt:" + item.id) else ""
        meta.text = listOf(episode, item?.year.orEmpty(), info?.genre.orEmpty()).filter(String::isNotBlank).joinToString("  ·  ")
        meta.visibility = if (meta.text.isEmpty()) View.GONE else View.VISIBLE
        summary.text = info?.plot.orEmpty()
        summary.visibility = if (summary.text.isEmpty()) View.GONE else View.VISIBLE
        val progress = if (key == "recent" && item != null) Repo.prog(Repo.s("le:" + item.id)) else null
        progressText.text = auroraProgressText(progress)
        progressText.visibility = if (progressText.text.isEmpty()) View.GONE else View.VISIBLE
        progressBar.visibility = if (progress != null && progress.second > 0 && progress.first > 0) View.VISIBLE else View.GONE
        progressBar.pct = auroraProgressPercent(progress)
        progressBar.invalidate()
        action.visibility = if (key == null) View.GONE else View.VISIBLE
        action.text = if (key == "recent") c.getString(R.string.aurora_resume, episode) else c.getString(R.string.aurora_details)
        action.contentDescription = action.text
        activate = {
            if (key == "recent" && item != null) resume(item)
            else if (key != null) destination(key)
        }
        val fallback = when (item?.kind ?: key) {
            "movie" -> R.drawable.home_cinema_movie
            "series" -> R.drawable.home_cinema_series
            else -> R.drawable.home_cinema_live
        }
        val url = item?.let { Repo.info[it.id]?.back.orEmpty() }.orEmpty()
        if (url.isNotBlank()) {
            if (artwork.tag != url) Img.load(artwork, url, 1, fallback)
        } else {
            Img.clear(artwork)
            artwork.setImageResource(fallback)
        }
    }

    private fun buildRecentTabs(hasMore: Boolean) {
        val previousFocus = recentTabs.indexOfChild(recentTabs.findFocus())
        recentTabs.removeAllViews()
        recent.forEachIndexed { index, item ->
            val tab = FrameLayout(c).apply {
                isFocusable = true
                clipToOutline = true
                background = c.auroraGlass(radius = 9)
                addView(ImageView(c).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    Img.load(this, item.logo, 2, R.drawable.home_cinema_series)
                    if (item.logo.isBlank()) setImageResource(R.drawable.home_cinema_series)
                }, FrameLayout.LayoutParams(-1, -1))
                addView(label(if (compact) 10f else 13f, true).apply {
                    text = item.name
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                    setBackgroundColor(col("#D3091124"))
                }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
                setOnFocusChangeListener { _, focused ->
                    if (focused) { recentIndex = index; show("recent") }
                }
                setOnClickListener { open(item) }
            }
            recentTabs.addView(tab, LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = c.dp(4) })
        }
        if (hasMore) recentTabs.addView(Designs.action(c, c.getString(R.string.aurora_more), 0) { more() }.apply {
            textSize = if (compact) 10f else 13f
            minimumWidth = 0
            setPadding(c.dp(5), 0, c.dp(5), 0)
        }, LinearLayout.LayoutParams(0, -1, 1f))
        if (previousFocus >= 0) recentTabs.getChildAt(previousFocus)?.requestFocus()
    }

    private fun label(size: Float, bold: Boolean = false) = TextView(c).apply {
        textSize = size
        setTextColor(Th.fg)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
}


internal fun auroraProgressPercent(progress: Pair<Long, Long>?): Int =
    if (progress != null && progress.second > 0)
        (100.0 * progress.first / progress.second).toInt().coerceIn(0, 100) else 0

internal fun auroraProgressText(progress: Pair<Long, Long>?): String {
    if (progress == null || progress.first <= 0) return ""
    fun time(ms: Long): String {
        val sec = ms / 1000
        return if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, sec / 60 % 60, sec % 60)
        else "%d:%02d".format(sec / 60, sec % 60)
    }
    return if (progress.second > 0) "${time(progress.first)} / ${time(progress.second)}" else time(progress.first)
}
