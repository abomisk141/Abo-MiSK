package com.sultv.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

internal fun Context.playerInfoChip(icon: Int, key: String): TextView = TextView(this).apply {
        tag = "playback-stat:$key"
        setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(dp(8), dp(5), dp(8), dp(5)); minimumWidth = dp(82); maxWidth = dp(220)
        background = null
        compoundDrawablePadding = dp(6)
        val drawable = Th.icon(this@playerInfoChip, icon, col("#84AAFF"))?.apply { setBounds(0, 0, dp(16), dp(16)) }
        setCompoundDrawablesRelative(drawable, null, null, null)
    }

internal fun Context.playerInfoStat(label: Int, value: String): CharSequence = android.text.SpannableString(value + "\n" + getString(label)).apply {
        setSpan(android.text.style.StyleSpan(Typeface.BOLD), 0, value.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

/** One restrained programme panel; it only presents state supplied by the existing player. */
class PlayerInfoPanel(
    private val c: Context, style: String,
    favouriteAction: () -> Unit, audioAction: () -> Unit, subtitleAction: () -> Unit, settingsAction: () -> Unit, diagnosticsAction: () -> Unit = {}
) : LinearLayout(c) {
    private val full = style == "full"
    private val aurora = Th.name == "aurora"
    val number = label("", 14f).apply { setTextColor(Th.bt); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(c.dp(9), c.dp(4), c.dp(9), c.dp(4)); background = surface(Th.acc, false) }
    val logo = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setImageResource(R.drawable.logo) }
    val channel = label("", 22f).apply {
        typeface = Typeface.DEFAULT_BOLD
        maxLines = Int.MAX_VALUE
        ellipsize = null
        setHorizontallyScrolling(false)
    }
    val programme = label("", 17f).apply { maxLines = 2; typeface = Typeface.DEFAULT_BOLD }
    val quality = label("", 10f).apply { visibility = View.GONE; setPadding(c.dp(6), c.dp(3), c.dp(6), c.dp(3)); background = surface(col("#441B2937"), false) }
    val time = label("", 12f).apply { textDirection = View.TEXT_DIRECTION_LTR }
    val progress = ProgrammeProgressView(c)
    val timing = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
    val next = label("", 12f).apply { visibility = View.GONE; setTextColor(col("#D6DDE5")) }
    val metrics = PlaybackStatsRow(c).apply { tag = "playback-stats-row" }
    private val startTime = label("", 12f)
    private val endTime = label("", 12f)
    private val receptionMeter = ProgrammeProgressView(c).apply {
        simple = true
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }
    val compactStats = label("", 12f).apply { visibility = if (style == "glass") View.VISIBLE else View.GONE; maxLines = if (c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density < 600) 4 else 2 }
    val actions = PlaybackStatsRow(c).apply { tag = "player-overlay-actions" }
    val favourite: ImageButton
    val audio: ImageButton
    val subtitles: ImageButton
    val settings: ImageButton
    private val controls: List<ImageButton>
    private fun surface(color: Int, focus: Boolean, radius: Int = if (full) 24 else 10) = GradientDrawable().apply { setColor(color); cornerRadius = c.dp(radius).toFloat(); if (focus) setStroke(c.dp(2), Th.acc) }
    private fun label(value: String, size: Float) = TextView(c).apply { text = value; textSize = size; setTextColor(Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER_VERTICAL or Gravity.START; textDirection = View.TEXT_DIRECTION_LOCALE }
    private fun action(key: String, title: String, icon: Int, run: () -> Unit) = ImageButton(c).apply {
        id = View.generateViewId(); tag = "player-action:$key"; contentDescription = title
        setImageResource(icon); imageTintList = ColorStateList.valueOf(Color.WHITE)
        minimumWidth = c.dp(42); minimumHeight = c.dp(42); setPadding(c.dp(9), c.dp(9), c.dp(9), c.dp(9))
        val idle = Color.TRANSPARENT
        background = if (aurora) c.auroraGlass(radius = 12) else surface(idle, false, 12); setOnClickListener { run() }
        setOnFocusChangeListener { view, focused -> view.background = if (aurora) c.auroraGlass(focused, 12) else surface(if (focused) col("#44253446") else idle, focused, 12) }
    }
    init {
        tag = "player-info-panel"; orientation = VERTICAL; layoutDirection = c.resources.configuration.layoutDirection
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        setPadding(c.dp(18), c.dp(8), c.dp(18), c.dp(12))
        background = if (aurora && full) c.auroraGlass(radius = 22) else if (full) GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, col("#F0031120"))
        ) else GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(col("#F20B1421"), col("#EE151D28"))).apply {
            cornerRadii = floatArrayOf(c.dp(24).toFloat(), c.dp(24).toFloat(), c.dp(24).toFloat(), c.dp(24).toFloat(), c.dp(12).toFloat(), c.dp(12).toFloat(), c.dp(12).toFloat(), c.dp(12).toFloat())
            setStroke(c.dp(1), if (full) col("#455881") else (Th.acc and 0x00FFFFFF) or (0x44 shl 24))
        }
        val identity = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        identity.addView(logo, LayoutParams(c.dp(if (full) 72 else 52), c.dp(if (full) 68 else 42)).apply { marginEnd = c.dp(10) })
        identity.addView(number, LayoutParams(-2, -2).apply { marginEnd = c.dp(9) })
        val name = LinearLayout(c).apply { orientation = VERTICAL }
        name.addView(channel, LayoutParams(-1, -2))
        val badges = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        badges.addView(label(c.getString(R.string.live_home_badge), 10f).apply { setTextColor(if (full) Color.WHITE else Th.bt); background = surface(if (full) col("#C93559") else Th.acc, false); setPadding(c.dp(7), c.dp(2), c.dp(7), c.dp(2)) }, LayoutParams(-2, -2).apply { marginEnd = c.dp(6) })
        if (!full) badges.addView(quality, LayoutParams(-2, -2))
        if (!full) name.addView(badges, LayoutParams(-1, -2).apply { topMargin = c.dp(3) })
        identity.addView(name, LayoutParams(0, -2, 1f))
        favourite = action("favourite", c.getString(R.string.player_favourite_off), if (aurora) R.drawable.ic_aurora_heart else R.drawable.ic_bookmark, favouriteAction).apply { isEnabled = false; alpha = .4f }
        audio = action("audio", c.getString(R.string.t_audio), R.drawable.ic_audio_wave, audioAction)
        subtitles = action("subtitles", c.getString(R.string.t_subs), R.drawable.ic_subtitles, subtitleAction)
        settings = action("settings", c.getString(R.string.track_menu), R.drawable.ic_settings, settingsAction)
        controls = listOf(favourite, audio, subtitles, settings) + if (full) {
            listOf(action("diagnostics", c.getString(R.string.diag_title), R.drawable.ic_n_info, diagnosticsAction))
        } else emptyList()
        if (full && !aurora) actions.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val buttons = controls
        buttons.forEach { actions.addView(it) }
        buttons.forEachIndexed { index, button ->
            val rtl = (!full || aurora) && c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
            button.nextFocusLeftId = buttons[(index + if (rtl) 1 else -1).coerceIn(0, buttons.lastIndex)].id
            button.nextFocusRightId = buttons[(index + if (rtl) -1 else 1).coerceIn(0, buttons.lastIndex)].id
            button.nextFocusDownId = button.id
        }
        if (full) {
            progress.simple = true
            name.addView(programme, LayoutParams(-1, -2))
            name.addView(next, LayoutParams(-1, -2))
            addView(identity, LayoutParams(-1, -2))
            metrics.distribute = true
            actions.distribute = true
            val readings = LinearLayout(c).apply {
                orientation = VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(c.dp(6), 0, c.dp(6), 0)
                addView(metrics, LayoutParams(-1, -2))
                addView(receptionMeter, LayoutParams(-1, c.dp(8)))
            }
            val beside = c.resources.configuration.screenWidthDp >= 710 * c.resources.configuration.fontScale
            val controlsRow = LinearLayout(c).apply {
                tag = "player-overlay-unified-bar"
                orientation = if (beside) HORIZONTAL else VERTICAL
                layoutDirection = if (aurora) c.resources.configuration.layoutDirection else View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(c.dp(8), c.dp(3), c.dp(8), c.dp(5))
                background = if (aurora) c.auroraGlass(radius = 16) else GradientDrawable().apply {
                    setColor(col("#EE101C34"))
                    cornerRadius = c.dp(17).toFloat()
                    setStroke(c.dp(1), col("#648CCA"))
                }
                if (beside) {
                    addView(if (aurora) readings else actions, LayoutParams(0, -2, if (aurora) 59f else 43f))
                    addView(View(c).apply {
                        setBackgroundColor(col("#465979"))
                        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    }, LayoutParams(c.dp(1), c.dp(38)))
                    addView(if (aurora) actions else readings, LayoutParams(0, -2, if (aurora) 41f else 57f))
                } else {
                    addView(readings, LayoutParams(-1, -2))
                    addView(actions, LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
                }
            }
            addView(controlsRow, LayoutParams(-1, -2).apply { topMargin = c.dp(5) })
            timing.layoutDirection = View.LAYOUT_DIRECTION_LTR
            timing.addView(startTime, LayoutParams(-2, -2).apply { marginEnd = c.dp(8) })
            timing.addView(progress, LayoutParams(0, c.dp(14), 1f))
            timing.addView(endTime, LayoutParams(-2, -2).apply { marginStart = c.dp(8) })
            addView(timing, LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
        } else {
            val header = PlayerPanelHeader(c).apply { this.identity = identity; this.controls = actions }
            header.addView(identity); header.addView(actions)
            addView(header, LayoutParams(-1, -2))
            addView(programme, LayoutParams(-1, -2).apply { topMargin = c.dp(8) })
            timing.addView(time, LayoutParams(-2, -2).apply { marginEnd = c.dp(12) })
            timing.addView(progress, LayoutParams(0, c.dp(30), 1f))
            addView(timing, LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
            addView(next, LayoutParams(-1, -2).apply { topMargin = c.dp(4) })
            addView(compactStats, LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
            actions.visibility = View.GONE
            metrics.visibility = View.GONE
        }
    }
    fun showForPlayback(channelChanged: Boolean) {
        if (channelChanged) {
            resetTransition()
            when (Repo.s("anim", "fade")) {
                "fade" -> alpha = 0f
                "slide" -> translationY = c.dp(12).toFloat()
                "zoom" -> { scaleX = .98f; scaleY = .98f }
            }
        }
        visibility = View.VISIBLE
        if (channelChanged && (alpha != 1f || translationY != 0f || scaleX != 1f)) {
            animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(180).start()
        }
    }

    fun hideAfterPlayback() {
        resetTransition()
        visibility = View.GONE
    }

    private fun resetTransition() {
        animate().cancel()
        alpha = 1f
        translationY = 0f
        scaleX = 1f
        scaleY = 1f
    }

    fun setProgrammeTimes(programme: Prog?) {
        val start = programme?.let { hm(it.start) }.orEmpty()
        val end = programme?.let { hm(it.stop) }.orEmpty()
        if (full) {
            startTime.text = start
            endTime.text = end
        } else time.text = if (programme == null) "" else "$start – $end"
    }

    fun setReception(received: Long, recommended: Long) {
        if (!full) return
        receptionMeter.pct = if (received >= 0 && recommended > 0) {
            (100.0 * received / recommended).coerceIn(0.0, 100.0).toInt()
        } else 0
        receptionMeter.invalidate()
    }

    fun focusControls(): Boolean {
        if (actions.visibility != View.VISIBLE) return false
        descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        return settings.requestFocusFromTouch()
    }
    fun releaseControls() {
        controls.forEach { it.isPressed = false }
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS; actions.clearFocus()
    }
    fun moveControl(right: Boolean) {
        val available = controls.filter { it.isEnabled && it.isShown }
        if (available.isEmpty()) return
        available.forEach { it.isPressed = false }
        val index = available.indexOfFirst { it.hasFocus() }.coerceAtLeast(0)
        val forward = right != (actions.layoutDirection == View.LAYOUT_DIRECTION_RTL)
        available[(index + if (forward) 1 else -1).coerceIn(0, available.lastIndex)].requestFocusFromTouch()
    }
    fun controlKey(down: Boolean, repeated: Boolean) {
        val focused = controls.firstOrNull { it.hasFocus() && it.isEnabled } ?: return
        if (down) { if (!repeated) focused.isPressed = true }
        else if (focused.isPressed) { focused.isPressed = false; focused.performClick() }
    }
    fun favouriteState(on: Boolean, available: Boolean) {
        favourite.isEnabled = available; favourite.alpha = if (available) 1f else .4f
        favourite.isSelected = on; favourite.imageTintList = ColorStateList.valueOf(if (on) Th.acc else Color.WHITE)
        favourite.contentDescription = c.getString(if (on) R.string.player_favourite_on else R.string.player_favourite_off)
    }
}

/** Header controls reflow below channel identity before large fonts can make them collide. */
class PlayerPanelHeader(c: Context) : ViewGroup(c) {
    lateinit var identity: View
    lateinit var controls: View
    private var stacked = false
    private val gap = c.dp(10)
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (!::identity.isInitialized || !::controls.isInitialized) { setMeasuredDimension(0, 0); return }
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val controlWidth = if (controls.visibility != GONE) { controls.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)); controls.measuredWidth } else 0
        stacked = controlWidth > 0 && width - controlWidth - gap < context.dp((290 * context.resources.configuration.fontScale.coerceAtLeast(1f)).toInt())
        val identityWidth = if (stacked || controlWidth == 0) width else width - controlWidth - gap
        identity.measure(MeasureSpec.makeMeasureSpec(identityWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        setMeasuredDimension(width, if (stacked) identity.measuredHeight + gap + controls.measuredHeight else maxOf(identity.measuredHeight, if (controlWidth == 0) 0 else controls.measuredHeight))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        if (!::identity.isInitialized || !::controls.isInitialized) return
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL
        val identityLeft = if (!stacked && rtl) width - identity.measuredWidth else 0
        identity.layout(identityLeft, 0, identityLeft + identity.measuredWidth, identity.measuredHeight)
        if (controls.visibility == GONE) return
        val x = if (rtl) 0 else width - controls.measuredWidth
        val y = if (stacked) identity.measuredHeight + gap else (height - controls.measuredHeight) / 2
        controls.layout(x, y, x + controls.measuredWidth, y + controls.measuredHeight)
    }
}

/** Programme progress with a bounded current-time bubble, not stream download progress. */
class ProgrammeProgressView(c: Context) : View(c) {
    var simple = false
    var pct = 0
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = RectF()
    override fun onDraw(canvas: Canvas) {
        val width = width.toFloat(); val barY = if (simple) height / 2f else height - 4f * d; val x = width * pct.coerceIn(0, 100) / 100f
        paint.color = col("#55FFFFFF"); paint.strokeWidth = 3f * d; paint.strokeCap = Paint.Cap.ROUND
        canvas.drawLine(2f * d, barY, width - 2f * d, barY, paint)
        paint.color = if (simple) col("#84AAFF") else Th.acc; canvas.drawLine(2f * d, barY, x.coerceAtLeast(2f * d), barY, paint)
        if (simple) {
            paint.color = Color.WHITE
            canvas.drawCircle(x.coerceIn(2f * d, (width - 2f * d).coerceAtLeast(2f * d)), barY, 4f * d, paint)
            return
        }
        text.textSize = 10f * d * resources.configuration.fontScale; text.typeface = Typeface.DEFAULT_BOLD
        val value = hm(System.currentTimeMillis()); val bubbleWidth = (text.measureText(value) + 12f * d).coerceAtMost(width)
        val left = (x - bubbleWidth / 2).coerceIn(0f, (width - bubbleWidth).coerceAtLeast(0f))
        bounds.set(left, 0f, left + bubbleWidth, barY - 5f * d)
        paint.color = Th.acc; canvas.drawRoundRect(bounds, 5f * d, 5f * d, paint)
        text.color = Th.bt; canvas.drawText(value, left + (bubbleWidth - text.measureText(value)) / 2, bounds.centerY() - (text.ascent() + text.descent()) / 2, text)
        paint.color = Color.WHITE; canvas.drawCircle(x.coerceIn(2f * d, (width - 2f * d).coerceAtLeast(2f * d)), barY, 3f * d, paint)
    }
}
