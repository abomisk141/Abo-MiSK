package com.sultv.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : BaseActivity() {
    data class Cat(val key: String, val label: String, val n: Int, val playlist: String = "", val header: Boolean = false, val busy: Boolean = false)

    private var tabs: List<Triple<String, Int, Int>> = emptyList()
    private val playerLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) consumeLiveReturn(result.data)
    }
    private val tabBtns = HashMap<String, View>()
    private val counts = HashMap<String, Int>()
    private lateinit var search: EditText
    private lateinit var titleTv: TextView
    private lateinit var metaTv: TextView
    private lateinit var tcol: LinearLayout
    private lateinit var status: TextView
    private lateinit var rv: RecyclerView
    private lateinit var liveBox: LinearLayout
    private lateinit var epgHdrRow: LinearLayout
    private lateinit var hdr: EpgHeader
    private lateinit var dateTv: TextView
    private lateinit var infoNum: TextView
    private lateinit var infoName: TextView
    private lateinit var infoNow: TextView
    private lateinit var infoTime: TextView
    private var pvw: PlayerView? = null
    private var prev: ExoPlayer? = null
    private var previewId = ""
    private var previewPlaceholder: View? = null
    private var previewLogo: ImageView? = null
    private var sideRv: RecyclerView? = null
    private var categoryPanel: LinearLayout? = null
    private var categorySearchHeader: TextView? = null
    private var referenceRail: ReferenceRail? = null
    private var cinemaShell: DesignShell? = null
    private val reference get() = uiStyle == "reference"
    private var spin: Spinner? = null
    private var tab = "live"
    private var uiStyle = "cinema"
    private var liveStyle = "timeline"
    private var railMode = false
    private lateinit var home: HomeLike
    private var refreshingPlaylist = false
    private lateinit var body: LinearLayout
    private lateinit var main: LinearLayout
    private lateinit var rightPane: LinearLayout
    private var auroraMedia: LinearLayout? = null
    private var auroraArtwork: ImageView? = null
    private var auroraTitle: TextView? = null
    private var auroraDescription: TextView? = null
    private var auroraMeta: TextView? = null
    private var auroraProgress: TextView? = null
    private var auroraSelection: Item? = null
    private val auroraMetadataWork = LatestWork()
    private var auroraMetadataTask: Runnable? = null
    private fun auroraMediaPanel() = wide && uiStyle == "aurora" && tab == "movie"

    private fun showAuroraMedia(item: Item?) {
        val changed = auroraSelection?.id != item?.id
        auroraSelection = item
        paintAuroraMedia(item)
        auroraArtwork?.let { artwork ->
            val url = item?.logo.orEmpty()
            if (artwork.tag != url) Img.load(artwork, url, 1)
        }
        if (!changed) return
        cancelAuroraMetadata()
        if (item == null || item.sid.isBlank() || Repo.info[item.id] != null) return
        auroraMetadataTask = Runnable {
            auroraMetadataWork.submit {
                if (item.kind == "series") Repo.episodes(item) else Repo.loadMovieInfo(item)
                hd.post {
                    if (started && auroraMediaPanel() && auroraSelection?.id == item.id) paintAuroraMedia(item)
                }
            }
        }.also { hd.postDelayed(it, 700) }
    }

    private fun cancelAuroraMetadata() {
        auroraMetadataTask?.let(hd::removeCallbacks)
        auroraMetadataTask = null
        auroraMetadataWork.cancel()
    }

    private fun paintAuroraMedia(item: Item?) {
        val info = item?.let { Repo.info[it.id] }
        auroraTitle?.text = item?.name.orEmpty()
        val seasons = if (item?.kind == "series") Repo.eps[item.id].orEmpty().asSequence()
            .map { it.ep.substringBefore('E') }.filter { it.startsWith('S') }.distinct().count() else 0
        val rating = item?.rate.orEmpty().ifBlank { info?.rating.orEmpty() }.toDoubleOrNull()
        val facts = listOf(
            item?.year.orEmpty().ifBlank { info?.year.orEmpty() },
            rating?.takeIf { it > 0 }?.let { "★ ${fmt(it)}" }.orEmpty(),
            info?.genre.orEmpty(),
            if (seasons > 0) resources.getQuantityString(R.plurals.aurora_seasons, seasons, seasons) else ""
        ).filter(String::isNotBlank).joinToString("  ·  ")
        auroraMeta?.apply { text = facts; visibility = if (facts.isBlank()) View.GONE else View.VISIBLE }
        auroraDescription?.apply {
            text = info?.plot.orEmpty()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
        }
        val progress = item?.takeIf { it.kind == "series" }?.let {
            val label = Repo.s("lt:" + it.id)
            val time = auroraProgressText(Repo.prog(Repo.s("le:" + it.id)))
            listOf(label, time).filter(String::isNotBlank).joinToString("  ·  ")
        }.orEmpty()
        auroraProgress?.apply { text = progress; visibility = if (progress.isBlank()) View.GONE else View.VISIBLE }
    }
    private var studioRoot: View? = null
    private var studioHomeArt: android.graphics.drawable.Drawable? = null
    private var studioBrowseArt: android.graphics.drawable.Drawable? = null
    private val studioFilters = linkedMapOf<String, TextView>()
    private lateinit var prevFrame: FrameLayout
    private var videoHost: FrameLayout? = null
    private var inlineFullscreen = false
    private var previousPreviewId = ""
    private var checkedPreviousExit = false
    private val liveMarkerPayload = Any()
    private val liveGuidePayload = Any()
    private lateinit var catalogueProgress: android.widget.ProgressBar
    private var inlineInfo: InlinePlaybackInfo? = null
    private var previewItem: Item? = null
    private val previewPosition = IntArray(2)
    private val hostPosition = IntArray(2)
    private lateinit var infoCol: LinearLayout
    private lateinit var infoDesc: TextView
    private lateinit var guideBox: LinearLayout
    private var placed = ""
    private var settingsBtn: View? = null
    private var fullList: List<Item> = emptyList()
    private val filterWork = LatestWork()
    private val loadWork = LatestWork()
    private var loadGeneration = 0
    private val refreshWork = LatestWork()
    private var preloadScope = ""
    private val preloads = ArrayList<com.bumptech.glide.request.target.Target<android.graphics.Bitmap>>()
    private var filterGeneration = 0
    private var filtering = false
    private var pageScope = ""
    private var pageAppendPosted = false
    private var renderKeys: List<String> = emptyList()
    private var continuationKeys: List<String> = emptyList()
    private var sideFocusKey: String? = null
    private var referenceCategoriesHidden = false
    private var hideCategoriesOnEntry = false
    private fun referenceCategoryReveal() = wide && when (tab) {
        "live" -> Repo.b("hideLiveCategories", Designs.hideLiveCategoriesByDefault(uiStyle))
        "movie", "series" -> uiStyle == "studio"
        else -> false
    }
    private var cat = ""
    private val favouriteQueueWork = SerialWork()
    private var openingLastCategory = false
    private var data: List<Item> = emptyList()
    private var cats: List<Cat> = emptyList()
    private var lastLabels: List<String> = emptyList()
    private var lm = ""
    private var applied = ""
    private var asked = false
    private var wide = true
    private var started = false
    private var backAt = 0L
    private var focusPos = 0
    private var browseReturn: Bundle? = null
    private var restoringBrowse = false
    private var browseRestoreTask: Runnable? = null
    private lateinit var head: LinearLayout
    private var searchBtn: View? = null
    private lateinit var contBox: LinearLayout
    private lateinit var contRv: RecyclerView
    private var cont: List<Item> = emptyList()
    private val contAdapter = C()
    private var lastMenu = 0L
    private var ws = 0L
    private var guideBrowsing = false
    private val hd = Handler(Looper.getMainLooper())
    private val adapter = A()
    private val sideAdapter = S()
    private val playlistRefresh = object : Runnable {
        override fun run() {
            val hours = Repo.s("pl_refresh_hours", "12").toLongOrNull() ?: 12L
            if (hours > 0 && Repo.configured() && !refreshingPlaylist) {
                val last = Repo.s("pl_last_refresh").toLongOrNull() ?: 0L
                if (System.currentTimeMillis() - last >= hours * 3600000L) {
                    refreshWork.submit {
                        Repo.refreshCacheInBackground()
                    }
                }
            }
            hd.postDelayed(this, 15 * 60000L)
        }
    }
    private var categoryPreviewTask: Runnable? = null
    private var categoryPreviewView: View? = null
    private var categoryEnterTask: Runnable? = null
    private val searchRun = Runnable { refresh() }
    private val tickRun = object : Runnable {
        override fun run() {
            if (!guideBrowsing) ws = winStart()
            hdr.winStart = ws; hdr.invalidate()
            if (tab == "live") refreshVisible()
            hd.postDelayed(this, 60000)
        }
    }

    private fun winStart(): Long { val t = System.currentTimeMillis(); return t - t % 1800000L }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Repo.init(this); Th.load()
        Designs.migrate()
        Th.load()
        val cv = Updater.currentVersion(this)
        if (Repo.s("lastVer") != cv) { Repo.put("lastVer", cv); Thread { try { java.io.File(cacheDir, "updates").deleteRecursively() } catch (e: Exception) { } }.start() }
        wide = resources.displayMetrics.widthPixels / resources.displayMetrics.density >= 600
        uiStyle = Repo.s("ui", "cinema"); liveStyle = if (wide && uiStyle == "aurora") "triple" else "timeline"
        val navigation = Repo.s(HomePreferences.key(uiStyle, "navigation"))
        railMode = when (navigation) {
            "side" -> wide
            "top" -> false
            else -> wide && uiStyle != "gunners"
        }
        applied = appliedKey()
        val baseTabs = listOf(
            Triple("live", R.string.live, R.drawable.ic_tv), Triple("movie", R.string.movies, R.drawable.ic_movie),
            Triple("series", R.string.series, R.drawable.ic_series), Triple("list", R.string.my_list, R.drawable.ic_bookmark))
        tabs = if (reference && !HomePreferences.custom(uiStyle)) baseTabs else listOf(Triple("home", R.string.home, R.drawable.ic_home)) +
            if (uiStyle == "gunners") baseTabs.take(1) + Triple("sports", R.string.gunners_sports, R.drawable.ic_n_trophy) + baseTabs.drop(1)
            else baseTabs
        tab = if (reference && !HomePreferences.custom(uiStyle)) "live" else "home"
        b?.getBundle("browse-return")?.takeIf { it.getString("playlist") == Repo.active()?.id }?.let {
            browseReturn = it; restoringBrowse = true
            tab = it.getString("tab", tab); cat = it.getString("category", "")
        }
        if (b == null && !Repo.resumed && Repo.s("startupDestination") == "category") {
            tab = "live"
            openingLastCategory = true
            Repo.active()?.let { playlist ->
                val item = Repo.s("startupChannel:" + playlist.id)
                cat = Repo.s("startupCategory:" + playlist.id)
                browseReturn = Bundle().apply {
                    putString("playlist", playlist.id)
                    putString("tab", "live")
                    putString("category", cat)
                    putString("item", item)
                }
                restoringBrowse = true
            }
        }
        ws = winStart()
        val frame = FrameLayout(this).apply { layoutDirection = resources.configuration.layoutDirection }
        val root = LinearLayout(this).apply { orientation = if (railMode) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL; background = if (uiStyle == "studio") getDrawable(R.drawable.studio_room) else Th.bg(); clipChildren = false }
        if (uiStyle == "studio") {
            studioRoot = root
            studioHomeArt = root.background
            studioBrowseArt = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(col("#050F20"), col("#101530"), col("#29164C")))
        }
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        val colRoot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }

        buildDesignShell(root, colRoot)

        body = LinearLayout(this).apply { clipChildren = false; setPadding(dp(12), dp(4), dp(12), dp(8)) }
        body.layoutDirection = resources.configuration.layoutDirection
        if (wide) {
            val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "category-panel"; layoutDirection = resources.configuration.layoutDirection }
            categoryPanel = panel
            val side = RecyclerView(this)
            side.layoutManager = LinearLayoutManager(this)
            side.adapter = sideAdapter
            side.itemAnimator = null
            side.background = if (uiStyle == "aurora") auroraGlass(radius = 20) else if (uiStyle == "cinema") GradientDrawable().apply { setColor(Th.card); cornerRadius = dp(16).toFloat() } else Th.shape(this, Th.card, false, 28)
            side.setPadding(dp(3), dp(8), dp(3), dp(8)); side.clipToPadding = false
            sideRv = side
            panel.addView(side, LinearLayout.LayoutParams(-1, 0, 1f))
            body.addView(panel, LinearLayout.LayoutParams(0, -1, 26f).apply { marginEnd = dp(14) })
        }
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; tag = "content-panel"; layoutDirection = resources.configuration.layoutDirection }
        head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = TextView(this).apply { setTextColor(Th.fg); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        metaTv = TextView(this).apply { setTextColor(Th.mut); textSize = 14f; maxLines = 1 }
        tcol.addView(titleTv); tcol.addView(metaTv)
        head.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f))
        search = EditText(this).apply {
            hint = getString(R.string.search); setTextColor(Th.fg); setHintTextColor(Th.mut); textSize = 14f
            maxLines = 1; inputType = InputType.TYPE_CLASS_TEXT; setPadding(dp(16), 0, dp(16), 0)
            background = ModernDialogs.searchBackground()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { filterGeneration++; filterWork.cancel(); hd.removeCallbacks(searchRun); hd.postDelayed(searchRun, 250) }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        if (wide) {
            search.tag = "channel-search"
            search.hint = getString(R.string.ref_search_hint)
            search.typeface = ReferenceLook.font
            search.background = Th.shape(this, Th.card, false, 18)
            categorySearchHeader = TextView(this).apply {
                text = getString(R.string.ref_search_channels); textSize = 13f; typeface = ReferenceLook.font
                setTextColor(Th.fg); setPadding(dp(10), 0, dp(10), dp(5))
            }
            categoryPanel?.addView(categorySearchHeader, 0, LinearLayout.LayoutParams(-1, -2))
            categoryPanel?.addView(search, 1, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(10) })
            if (reference) searchBtn = search
        }
        if (!wide) head.addView(search, LinearLayout.LayoutParams(dp(150), dp(40)))
        main.addView(head)
        if (uiStyle == "studio") {
            val filters = LinearLayout(this).apply { visibility = View.GONE }
            for ((key, label) in listOf("" to R.string.all, "k:live" to R.string.live,
                "k:movie" to R.string.movies, "k:series" to R.string.series)) {
                val button = TextView(this).apply {
                    setText(label)
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    isFocusable = true
                    isClickable = true
                    setOnFocusChangeListener { _, _ -> paintStudioFilters() }
                    setOnClickListener { cat = key; focusPos = 0; rv.scrollToPosition(0); refresh() }
                }
                studioFilters[key] = button
                filters.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
            }
            main.addView(filters, LinearLayout.LayoutParams(-1, -2))
        }
        contBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; clipChildren = false; setPadding(0, dp(2), 0, dp(4)) }
        contBox.addView(TextView(this).apply { setText(R.string.cont_watch); setTextColor(Th.fg); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(6), 0, dp(6), dp(4)) })
        contRv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = contAdapter; itemAnimator = null; clipChildren = false; clipToPadding = false
        }
        contBox.addView(contRv, LinearLayout.LayoutParams(-1, dp(172)))
        main.addView(contBox)

        // live-tv header: preview player + now playing + time scale
        liveBox = LinearLayout(this).apply { tag = "channel-preview-row"; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE; setPadding(0, dp(2), 0, dp(6)) }
        dateTv = TextView(this).apply { setTextColor(Th.fg); textSize = 15f; typeface = Typeface.DEFAULT_BOLD }
        hdr = EpgHeader(this)
        epgHdrRow = LinearLayout(this).apply { tag = "channel-timeline-header"; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE; setPadding(dp(14), 0, dp(14), dp(2)) }
        infoNum = TextView(this).apply {
            setTextColor(Th.bt); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(12), dp(2), dp(12), dp(2)); background = Th.shape(this@MainActivity, Th.acc, false, 14)
        }
        infoName = TextView(this).apply { setTextColor(Th.fg); textSize = 16f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        infoNow = TextView(this).apply { setTextColor(Th.fg); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        infoTime = TextView(this).apply { setTextColor(Th.mut); textSize = 14f }
        infoDesc = TextView(this).apply { setTextColor(Th.mut); textSize = 13f; maxLines = 3; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0) }
        guideBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        prevFrame = FrameLayout(this).apply { tag = "channel-preview" }
        infoCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rightPane = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; clipChildren = false }
        if (wide) {
            prevFrame.background = Th.shape(this, Color.BLACK, false, 18); prevFrame.clipToOutline = true
            val p = PlayerView(this); p.useController = false; pvw = p
            p.setBackgroundColor(Th.bgFrom)
            videoHost = FrameLayout(this).apply {
                visibility = View.INVISIBLE
                setBackgroundColor(Color.BLACK)
                addView(p, FrameLayout.LayoutParams(-1, -1))
            }
            if (wide) {
                val placeholder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = ReferenceLook.selection(this@MainActivity, false, false) }
                previewLogo = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
                placeholder.addView(previewLogo, LinearLayout.LayoutParams(dp(110), dp(68)))
                placeholder.addView(TextView(this).apply { text = getString(R.string.ref_preview_unavailable); typeface = ReferenceLook.font; textSize = 12f; setTextColor(Th.mut); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                previewPlaceholder = placeholder
                videoHost?.addView(placeholder, FrameLayout.LayoutParams(-1, -1))
            }
            val nrow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            nrow.addView(infoNum, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
            nrow.addView(infoName, LinearLayout.LayoutParams(0, -2, 1f))
            infoCol.addView(nrow); infoCol.addView(infoNow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            infoCol.addView(infoTime); infoCol.addView(infoDesc)
            main.addView(liveBox)
            epgHdrRow.addView(dateTv, LinearLayout.LayoutParams(0, -2, 10f))
            epgHdrRow.addView(hdr, LinearLayout.LayoutParams(0, dp(22), 12f))
            main.addView(epgHdrRow)
        }
        if (!wide) {
            val sp = Spinner(this)
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (restoringBrowse || groupedPlaylistsEnabled()) return
                    if (pos < cats.size) {
                        val ct = cats[pos]
                        if (ct.header || !ownCategory(ct)) { enterCategory(ct); return }
                        if (ct.key.startsWith("lock:")) { askPin(R.string.pin_enter) { Repo.unlock(tab, ct.label); cat = ct.label; refresh() }; updateSpinner() }
                        else if (ct.key != cat) { cat = ct.key; refresh() }
                    }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            sp.setOnTouchListener { _, event ->
                if (groupedPlaylistsEnabled()) {
                    if (event.action == android.view.MotionEvent.ACTION_UP) showGroupedCategories()
                    true
                } else false
            }
            sp.setOnKeyListener { _, key, event ->
                if (groupedPlaylistsEnabled() && key in listOf(KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER)) {
                    if (event.action == KeyEvent.ACTION_UP) showGroupedCategories()
                    true
                } else false
            }
            spin = sp
            main.addView(sp, LinearLayout.LayoutParams(-1, -2))
        }
        status = TextView(this).apply { setTextColor(Th.mut); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        catalogueProgress = android.widget.ProgressBar(this).apply {
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Th.acc)
            visibility = View.GONE
        }
        val loadCard = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(catalogueProgress, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(10) })
            addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        }
        status.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(text: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(text: CharSequence?, start: Int, before: Int, count: Int) {
                val loading = text?.startsWith(getString(R.string.loading)) == true
                catalogueProgress.visibility = if (loading) View.VISIBLE else View.GONE
                loadCard.visibility = if (text.isNullOrBlank()) View.GONE else View.VISIBLE
                loadCard.background = if (loading) Th.shape(this@MainActivity, Th.card, false, 12) else null
            }
            override fun afterTextChanged(text: android.text.Editable?) = Unit
        })
        loadCard.visibility = View.GONE
        main.addView(loadCard)
        rv = ChannelRecyclerView(this).apply {
            channelNavigation = wide && tab == "live"
            onGridNeedMore = { if (!isComputingLayout) appendPage() }
            onGridTop = { contBox.visibility == View.VISIBLE && contRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() == true }
            onHorizontalKey = { key ->
                val focused = findFocus()
                when {
                    wide && tab == "live" && epgRows() && focused is EpgView -> {
                        if (key == KeyEvent.KEYCODE_DPAD_RIGHT) shiftGuide(1)
                        else if (ws > winStart()) shiftGuide(-1)
                        else findContainingViewHolder(focused)?.itemView?.requestFocus()
                        true
                    }
                    wide && tab == "live" && epgRows() && key == keyToMain() -> {
                        val position = focused?.let { findContainingViewHolder(it)?.bindingAdapterPosition } ?: focusPos
                        findViewHolderForAdapterPosition(position)?.itemView?.findViewWithTag<View>("epg-cell")?.requestFocus() == true
                    }
                    wide && key == keyToSide() && (tab == "live" || focused === this) -> { focusSide(); true }
                    else -> false
                }
            }
        }; rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(view: RecyclerView, state: Int) {
                if (state == RecyclerView.SCROLL_STATE_IDLE) prefetchPosters()
                else clearPrefetch()
            }
            override fun onScrolled(view: RecyclerView, dx: Int, dy: Int) {
                val manager = view.layoutManager as? LinearLayoutManager ?: return
                if (manager.findLastVisibleItemPosition() >= data.size - 24 && !pageAppendPosted) {
                    pageAppendPosted = true
                    view.post { pageAppendPosted = false; if (!isDestroyed) appendPage() }
                }
            }
        }); rv.tag = "channel-list"; rv.adapter = adapter; rv.itemAnimator = null; rv.clipChildren = false; rv.clipToPadding = false
        main.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))
        home = if (uiStyle == "aurora" && !HomePreferences.custom(uiStyle)) AuroraHomeView(this, { selectTab(it, true) }, { open(it) },
            { openSeriesDetails(it, true) }, { selectTab("series", true, "recent") })
        else if (HomePreferences.custom(uiStyle)) DesignHomeView(
            this, uiStyle, { open(it) }, { if (it.kind == "series") open(it) else play(it) },
            { menu(it) }, { selectTab(it, true) }, { openSettings() }, openMatch = { match -> showMatchSchedule(match) },
            resumeSeries = { openSeriesDetails(it, true) }, moreSeries = { selectTab("series", true, "recent") }
        ) else when (uiStyle) {
            "gunners" -> GunnersHomeView(this, { selectTab(it, true) }, { play(it) })
            "spotlight" -> SpotlightHomeView(this, { open(it) }, { if (it.kind == "series") open(it) else play(it) }, { menu(it) }, { openSettings() }, { selectTab(it, true) })
            else -> DesignHomeView(this, uiStyle, { open(it) }, { if (it.kind == "series") open(it) else play(it) }, { menu(it) }, { selectTab(it, true) }, { openSettings() })
        }
        home.root.visibility = View.GONE
        main.addView(home.root, LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(main, LinearLayout.LayoutParams(0, -1, if (wide) 74f else 100f))
        if (wide) {
            body.addView(rightPane, LinearLayout.LayoutParams(0, -1, 0.01f))
            if (uiStyle == "aurora") {
                val compact = resources.configuration.screenHeightDp < 500
                auroraArtwork = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = false
                }
                auroraTitle = TextView(this).apply { textSize = if (compact) 16f else 22f; setTextColor(Th.fg); maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                auroraMeta = TextView(this).apply { textSize = if (compact) 11f else 14f; setTextColor(Th.mut); maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                auroraDescription = TextView(this).apply { textSize = if (compact) 11f else 14f; setTextColor(Th.fg); maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                auroraProgress = TextView(this).apply { textSize = if (compact) 11f else 14f; setTextColor(Th.acc); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                auroraMedia = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                    background = auroraGlass()
                    clipToOutline = true
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                    addView(auroraArtwork, LinearLayout.LayoutParams(-1, 0, 1f))
                    addView(auroraTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                    addView(auroraMeta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
                    addView(auroraDescription, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                    addView(auroraProgress, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                    addView(Designs.action(this@MainActivity, getString(R.string.aurora_details), R.drawable.ic_n_info, true) {
                        auroraSelection?.let(::open)
                    }, LinearLayout.LayoutParams(-1, dp(if (compact) 39 else 49)).apply { topMargin = dp(8) })
                }
                body.addView(auroraMedia, LinearLayout.LayoutParams(0, -1, 0f).apply { marginStart = dp(8) })
            }
        }
        colRoot.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(colRoot, if (railMode) LinearLayout.LayoutParams(0, -1, 1f) else LinearLayout.LayoutParams(-1, -1))
        setContentView(frame)
        if (reference && railMode) {
            referenceRail?.let { frame.addView(it.root, FrameLayout.LayoutParams(dp(72), -1, Gravity.START)) }
        }
        cinemaShell?.let { frame.addView(it.root, FrameLayout.LayoutParams(dp(72), -1, Gravity.START)) }
        videoHost?.let { host ->
            frame.addView(host, 1, FrameLayout.LayoutParams(1, 1, Gravity.TOP or Gravity.LEFT))
            frame.viewTreeObserver.addOnPreDrawListener {
                updateVideoHost(frame, host)
                true
            }
        }
        if (b == null) tabBtns[tab]?.requestFocus()
        browseReturn?.let { search.setText(it.getString("query", "")); hd.removeCallbacks(searchRun) }

        if (Repo.b("welcome", true) && !Repo.splashShown) {
            Repo.splashShown = true
            val sp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = Th.bg(); isClickable = true }
            sp.addView(ImageView(this).apply { setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(190), dp(190)))
            sp.addView(TextView(this).apply {
                text = getString(if (Repo.configured()) R.string.welcome_back else R.string.welcome_new)
                textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Th.fg); gravity = Gravity.CENTER; setPadding(dp(20), dp(24), dp(20), 0)
            })
            frame.addView(sp, FrameLayout.LayoutParams(-1, -1))
            hd.postDelayed({ sp.animate().alpha(0f).setDuration(450).withEndAction { frame.removeView(sp) }.start() }, 1800)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (inlineFullscreen) {
                    if (inlineInfo?.controlsFocused == true) inlineInfo?.hide()
                    else setInlineFullscreen(false)
                    return
                }
                val guide = rv.findFocus() as? EpgView
                if (tab == "live" && guide != null) {
                    guideBrowsing = false; ws = winStart(); redrawGuide()
                    rv.findContainingViewHolder(guide)?.itemView?.requestFocus(); return
                }
                if (referenceCategoryReveal() && referenceCategoriesHidden && rv.hasFocus()) {
                    focusSide()
                    return
                }
                if (tabs.any { it.first == "home" } && tab != "home") { selectTab("home"); return }
                if (Repo.b("back2", true))
                    ModernDialogs.confirmExit(this@MainActivity) { finish() }
                else finish()
            }
        })
    }

    // Unified TV search: non-blocking filtering, categories, recent searches and remote focus.
    private fun openPremiumSearch() {
        val searchWork = LatestWork()
        val dialog = android.app.Dialog(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
            background = ModernDialogs.searchBackground()
        }
        val heading = TextView(this).apply {
            text = "⌕   البحث في ABO MISK"
            textSize = 23f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        }
        panel.addView(heading)
        val input = EditText(this).apply {
            hint = "ابحث عن قناة أو فيلم أو مسلسل..."
            setSingleLine(true); textSize = 18f
            setTextColor(Color.WHITE); setHintTextColor(0xFFAAB2CD.toInt())
            background = ModernDialogs.searchBackground()
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        panel.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        val filters = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val types = listOf("" to "الكل", "live" to "القنوات", "movie" to "الأفلام", "series" to "المسلسلات")
        var selectedType = ""
        val filterButtons = mutableListOf<Button>()
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val resultScroll = android.widget.ScrollView(this).apply { isFillViewport = false }
        resultScroll.addView(results)
        val hint = TextView(this).apply { textSize = 14f; setTextColor(0xFFB5BBD0.toInt()) }
        val history = Repo.s("search_history_v44").split("\n").filter { it.isNotBlank() }.take(6)
        val mainHandler = Handler(Looper.getMainLooper())
        var request = 0
        fun render(query: String) {
            val token = ++request
            val kind = selectedType
            results.removeAllViews()
            if (query.isBlank()) {
                hint.text = "عمليات البحث الأخيرة"
                history.forEach { previous ->
                    val b = Th.btn(this, "◷  $previous")
                    b.setOnClickListener { input.setText(previous); input.setSelection(previous.length) }
                    results.addView(b, LinearLayout.LayoutParams(-1, dp(48)))
                }
                return
            }
            hint.text = "جارٍ البحث..."
            val snapshot = Repo.searchItems()
            searchWork.submit {
                val q = query.trim().lowercase(Locale.ROOT)
                val matches = ArrayList<Item>(100)
                var total = 0
                for (item in snapshot) {
                    if (Thread.currentThread().isInterrupted) return@submit
                    if (kind.isNotEmpty() && item.kind != kind) continue
                    if (item.name.lowercase(Locale.ROOT).contains(q)) {
                        total++
                        if (matches.size < 100) matches.add(item)
                    }
                }
                mainHandler.post {
                    if (token != request || !dialog.isShowing) return@post
                    results.removeAllViews()
                    hint.text = "النتائج: $total" + if (total > 100) " (عرض أول 100)" else ""
                    if (matches.isEmpty()) {
                        results.addView(TextView(this).apply {
                            text = "لا توجد نتائج مطابقة"; textSize = 18f; setTextColor(Color.WHITE)
                            setPadding(dp(12), dp(20), 0, dp(20))
                        })
                    }
                    matches.forEach { item ->
                        val symbol = when (item.kind) { "live" -> "▣"; "movie" -> "▶"; else -> "▤" }
                        val b = Th.btn(this, "$symbol   ${item.name}")
                        b.isAllCaps = false
                        b.gravity = Gravity.CENTER_VERTICAL or Gravity.START
                        b.setOnClickListener {
                            val saved = (listOf(query.trim()) + Repo.s("search_history_v44")
                                .split("\n")).filter { it.isNotBlank() }.distinct().take(8)
                            Repo.put("search_history_v44", saved.joinToString("\n"))
                            dialog.dismiss()
                            play(item)
                        }
                        results.addView(b, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(5) })
                    }
                }
            }
        }
        types.forEach { (type, title) ->
            val b = Th.btn(this, title)
            filterButtons.add(b)
            b.setOnClickListener {
                selectedType = type
                filterButtons.forEachIndexed { index, btn -> Th.paint(btn, types[index].first == type) }
                render(input.text.toString())
            }
            filters.addView(b, LinearLayout.LayoutParams(0, dp(45), 1f).apply { marginEnd = dp(7) })
        }
        panel.addView(filters, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
        panel.addView(hint, LinearLayout.LayoutParams(-1, dp(28)).apply { topMargin = dp(8) })
        panel.addView(resultScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                mainHandler.removeCallbacksAndMessages(null)
                mainHandler.postDelayed({ render(q) }, 220)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        dialog.setContentView(panel)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout((resources.displayMetrics.widthPixels * .82).toInt(),
                (resources.displayMetrics.heightPixels * .88).toInt())
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(.8f)
        }
        dialog.setOnDismissListener { searchWork.close(); request++; mainHandler.removeCallbacksAndMessages(null) }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * .82).toInt(),
            (resources.displayMetrics.heightPixels * .88).toInt())
        filterButtons.first().requestFocus()
        Th.paint(filterButtons.first(), true)
        render("")
    }


    private fun refreshPlaylistNow(button: View) {
        if (refreshingPlaylist) return
        if (!Repo.configured()) {
            Toast.makeText(this, "أضف قائمة تشغيل أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        refreshingPlaylist = true
        button.isEnabled = false
        Toast.makeText(this, "جارٍ تحديث القائمة الحالية دون إيقاف البث", Toast.LENGTH_SHORT).show()
        refreshWork.submit {
            val ok = Repo.refreshCacheInBackground()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                refreshingPlaylist = false
                button.isEnabled = true
                Toast.makeText(this, if (ok) "تم تحديث القائمة؛ ستظهر عند إعادة فتحها" else "فشل التحديث؛ تم الاحتفاظ بالقائمة السابقة", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openSettings() {
        if (Repo.hasPin() && Repo.b("pinSettings", false) && !Repo.settingsOk)
            askPin(R.string.pin_enter) { Repo.settingsOk = true; startActivity(Intent(this, SettingsActivity::class.java)) }
        else startActivity(Intent(this, SettingsActivity::class.java))
    }

    private var matchSchedule: GunnersHomeView? = null

    private fun showMatchSchedule(match: GunnersMatch? = null) {
        val dialog = android.app.Dialog(this)
        val schedule = GunnersHomeView(this,
            { dialog.dismiss(); selectTab(it, true) }, { dialog.dismiss(); play(it) },
            closeDetails = if (match != null) ({ dialog.dismiss() }) else null)
        matchSchedule = schedule
        dialog.setContentView(schedule.root)
        dialog.setOnDismissListener {
            schedule.destroy()
            if (matchSchedule === schedule) matchSchedule = null
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val width = if (match == null) .92f else .76f
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * width).toInt(),
            if (match == null) (resources.displayMetrics.heightPixels * .9f).toInt() else -2)
        if (match != null) schedule.openMatch(match) else schedule.render()
        schedule.start()
    }

    private fun buildDesignShell(root: LinearLayout, colRoot: LinearLayout) {
        root.layoutDirection = resources.configuration.layoutDirection
        colRoot.layoutDirection = resources.configuration.layoutDirection
        if (reference && railMode) {
            val rail = ReferenceRail(this, tabs, { selectTab(it, true) }, { openSettings() }, { focusSide() })
            referenceRail = rail
            tabBtns.putAll(rail.buttons)
            settingsBtn = rail.settings
            root.addView(View(this).apply { tag = "rail-space" }, LinearLayout.LayoutParams(dp(72), -1))
            rail.select(tab)
            return
        }
        val shell = DesignShell(this, uiStyle, railMode, tabs,
            { key ->
                if (key == "sports") {
                    if (tab != "home") selectTab("home", true)
                    val sportsHome = home as? GunnersHomeView
                    if (sportsHome != null) sportsHome.focusSchedule() else showMatchSchedule()
                } else selectTab(key, true)
            }, { openSettings() }, { openPremiumSearch() }, { refreshPlaylistNow(it) }, {
                if (tab == "home") {
                    val target = home.root.findViewWithTag<View>("hero-play") ?: home.root.getFocusables(View.FOCUS_FORWARD).firstOrNull { it !== home.root }
                    target?.requestFocus()
                } else {
                    if (uiStyle == "studio" && tab != "list") categoryPanel?.visibility = View.VISIBLE
                    focusSide()
                }
            }, { expanded ->
                if (uiStyle == "studio" && tab !in listOf("home", "list") && !referenceCategoriesHidden) {
                    categoryPanel?.visibility = if (expanded) View.INVISIBLE else View.VISIBLE
                }
            })
        tabBtns.putAll(shell.buttons)
        settingsBtn = shell.settings
        searchBtn = shell.search
        if (railMode && HomePreferences.overlayRail(uiStyle)) {
            cinemaShell = shell
            root.addView(View(this).apply { tag = "cinema-rail-space" }, LinearLayout.LayoutParams(dp(72), -1))
        } else if (railMode) root.addView(shell.root, LinearLayout.LayoutParams(dp(if (uiStyle == "spotlight") 150 else 166), -1))
        else colRoot.addView(shell.root, LinearLayout.LayoutParams(-1, -2))
        shell.select(tab)
    }

    private var pendingNavigationFocus: String? = null

    private fun selectTab(k: String) = selectTab(k, false)

    private fun selectTab(k: String, focusCategories: Boolean, category: String = "") {
        referenceCategoriesHidden = false; hideCategoriesOnEntry = false
        pendingNavigationFocus = if (focusCategories && k != "home") k else null
        clearBrowseReturn()
        cancelCategoryPreview()
        categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
        openingLastCategory = false
        if (k != tab) { cancelPreviewRequest(); cancelAuroraMetadata(); auroraSelection = null }
        tab = k; cat = category; styleTabs(); cinemaShell?.select(k); refresh()
        if (Repo.s("anim", "fade") != "none") { val v: View = if (tab == "home") home.root else rv; v.alpha = 0f; v.animate().alpha(1f).setDuration(190).start() }
    }

    override fun onStart() {
        super.onStart(); started = true
        Repo.onEpg = { runOnUiThread {
            if (tab == "live") refreshVisible()
            if (tab == "home") { (home as? GunnersHomeView)?.onGuideUpdated(); matchSchedule?.onGuideUpdated() }
        } }
        Repo.onNamesReset = { hd.post {
            if (started && !isFinishing && !switchingPlaylist) refreshEditedCatalogue()
        } }
        hd.removeCallbacks(tickRun); hd.post(tickRun)
        hd.removeCallbacks(playlistRefresh); hd.postDelayed(playlistRefresh, 30000L)
        if (tab == "live") maybeAutoPreview()
        if (tab == "home") home.start()
    }

    override fun onStop() {
        cancelAuroraMetadata(); auroraSelection = null
        super.onStop(); pendingNavigationFocus = null; started = false; filtering = false; filterGeneration++; filterWork.cancel(); clearPrefetch()
        cancelCategoryPreview()
        browseRestoreTask?.let { hd.removeCallbacks(it) }; browseRestoreTask = null
        categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
        hd.removeCallbacks(tickRun); hd.removeCallbacks(playlistRefresh); Repo.onEpg = null; Repo.onNamesReset = null; stopPreview(); home.stop()
    }

    override fun onDestroy() {
        auroraMetadataWork.close()
        super.onDestroy(); favouriteQueueWork.close(); playlistCategoryWork.close(); filterGeneration++; filterWork.close(); loadGeneration++; loadWork.close(); refreshWork.close(); clearPrefetch(); hd.removeCallbacksAndMessages(null); stopPreview(); LivePlayerHandoff.discardSource(pvw); home.destroy()
        if (isFinishing) { Repo.unlocked.clear(); Repo.settingsOk = false }
    }

    override fun onResume() {
        super.onResume()
        browseReturn?.let {
            if (it.getString("playlist") != Repo.active()?.id) clearBrowseReturn()
            else {
                restoringBrowse = true; cancelCategoryPreview()
                tab = it.getString("tab", tab); cat = it.getString("category", "")
                val query = it.getString("query", "")
                if (search.text.toString() != query) search.setText(query)
                hd.removeCallbacks(searchRun)
                styleTabs(); cinemaShell?.select(tab); referenceRail?.select(tab)
            }
        }
        val cr = Repo.s("crash")
        if (cr.isNotEmpty()) {
            Repo.put("crash", "")
            showExitReport(cr)
        }
        inspectPreviousExit(showReport = cr.isEmpty())
        Th.load()
        if (appliedKey() != applied) { recreate(); return }
        autoUpdateCheck()
        if (Repo.dirty) {
            if (!Repo.configured()) {
                if (!asked) { asked = true; startActivity(Intent(this, AddPlaylistActivity::class.java)) }
            } else load()
        } else { updateCounts(); refresh(); resumeLast() }
    }

    private fun inspectPreviousExit(showReport: Boolean) {
        if (checkedPreviousExit || android.os.Build.VERSION.SDK_INT < 30) return
        checkedPreviousExit = true
        val owner = applicationContext
        Thread {
            val manager = owner.getSystemService(android.app.ActivityManager::class.java)
            val last = runCatching { manager?.getHistoricalProcessExitReasons(owner.packageName, 0, 4) }
                .getOrNull()?.firstOrNull { it.processName == owner.packageName } ?: return@Thread
            val reason = when (last.reason) {
                android.app.ApplicationExitInfo.REASON_ANR -> R.string.exit_anr
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> R.string.exit_memory
                android.app.ApplicationExitInfo.REASON_CRASH -> R.string.exit_crash
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> R.string.exit_native
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> R.string.exit_resource
                else -> return@Thread
            }
            runOnUiThread {
                if (isFinishing || isDestroyed || last.timestamp <= (Repo.s("lastReportedExit").toLongOrNull() ?: 0L)) return@runOnUiThread
                if (System.currentTimeMillis() - last.timestamp > 24 * 60 * 60_000L) return@runOnUiThread
                Repo.put("lastReportedExit", last.timestamp.toString())
                if (showReport) showExitReport(getString(reason) + "\n" +
                    java.text.DateFormat.getDateTimeInstance().format(java.util.Date(last.timestamp)))
            }
        }.start()
    }

    private fun showExitReport(report: String) {
        AlertDialog.Builder(this).setTitle(R.string.crash_title).setMessage(report)
            .setPositiveButton(R.string.done, null)
            .setNeutralButton(R.string.diag_copy) { _, _ ->
                getSystemService(android.content.ClipboardManager::class.java)?.setPrimaryClip(
                    android.content.ClipData.newPlainText(getString(R.string.crash_title), report)
                )
            }.show()
    }

    private fun styleTabs() { for ((k, bt) in tabBtns) { if (bt is ReferenceNav) bt.paint(k == tab) else if (bt is DesignNav) bt.paint(k == tab) else if (bt is Button) Th.paint(bt, k == tab) } }

    private fun updateCounts() {
        for (k in listOf("live", "movie", "series")) counts[k] = Repo.list(k).size
        counts["list"] = Repo.favs().size
        referenceRail?.counts(counts)
        if (!railMode) for ((k, r, _) in tabs) (tabBtns[k] as? Button)?.text = getString(r) + if (wide && (counts[k] ?: 0) > 0) "   ${counts[k]}" else ""
    }

    private fun load() {
        switchingPlaylist = false
        if (Repo.b("playlistVisibilityManaged", false) && Repo.visiblePlaylists().isEmpty()) {
            Repo.dirty = false; status.text = getString(R.string.no_visible_playlists)
            updateCounts(); refresh(); return
        }
        val token = ++loadGeneration
        val playlist = Repo.active() ?: return
        Repo.dirty = false
        status.text = getString(R.string.loading)
        Repo.onStage = { k ->
            runOnUiThread {
                if (isDestroyed || token != loadGeneration || Repo.active()?.id != playlist.id) return@runOnUiThread
                status.text = getString(R.string.loading) + "  " + getString(if (k == "live") R.string.live else if (k == "movie") R.string.movies else R.string.series)
            }
        }
        loadWork.submit {
            val ok = Repo.load(pl = playlist)
            runOnUiThread {
                if (isFinishing || isDestroyed || token != loadGeneration || Repo.active()?.id != playlist.id) return@runOnUiThread
                Repo.onStage = null
                status.text = if (ok) "" else getString(R.string.loadfail) + (if (Repo.err.isNotEmpty()) "\n" + Repo.err else "")
                updateCounts(); refresh()
                if (ok) { Repo.loadEpg(); resumeLast() }
            }
        }
    }

    private fun resumeLast() {
        if (Repo.resumed) return
        Repo.resumed = true
        if (Repo.s("startupDestination", if (Repo.b("resume", false)) "channel" else "home") != "channel") return
        val it = Repo.find(Repo.s("lastLive")) ?: return
        if (it.kind == "live") play(it)
    }

    private fun allRes() = when (tab) { "live" -> R.string.all_live; "movie" -> R.string.all_movies; else -> R.string.all_series }

    private fun groupedPlaylistsEnabled() = Repo.groupedPlaylists() && tab in listOf("live", "movie", "series")
    private fun showGroupedCategories() {
        val entries = cats.toList()
        AlertDialog.Builder(this).setItems(entries.map { if (it.header) (if (it.n == 1) "▾ " else "▸ ") + it.label else if (it.n < 0) "    ${it.label}" else "    ${it.label} (${it.n})" }.toTypedArray()) { _, index ->
            enterCategory(entries[index])
        }.show()
    }

    private data class CachedCategories(val stamp: String, val revision: Int, val rows: List<Cat>)
    private val playlistCategories = java.util.concurrent.ConcurrentHashMap<String, CachedCategories>()
    private val playlistCategoryWork = SerialWork()
    private var switchingPlaylist = false
    private val loadingPlaylistCategories = HashSet<String>()

    private fun cachedCategories(id: String, kind: String): List<Cat>? =
        playlistCategories["$id|$kind"]?.takeIf {
            it.stamp == Repo.s("st:$id") && it.revision == Repo.catalogueEditsRevision
        }?.rows

    private fun expandedPlaylists(kind: String): Set<String> = Repo.sp.getStringSet("expandedPlaylists:$kind", null)
        ?: setOfNotNull(Repo.active()?.id)
    private fun categoryIdentity(c: Cat) = if (c.header) c.key else if (c.playlist.isEmpty()) c.key else "${c.playlist.length}:${c.playlist}:${c.key}"
    private fun ownCategory(c: Cat) = c.playlist.isEmpty() || c.playlist == Repo.active()?.id
    private fun groupedCats(base: List<Item>, kind: String): List<Cat> {
        val active = Repo.active()?.id
        val expanded = expandedPlaylists(kind)
        return Repo.visiblePlaylists().filter { if (kind == "live") it.live else it.vod }.flatMap { p ->
            val open = p.id in expanded
            val header = Cat("playlist:${p.id}", p.name, if (open) 1 else 0, p.id, true, open && p.id != active && cachedCategories(p.id, kind) == null)
            val key = "${p.id}|$kind"
            if (p.id == active) {
                val stamp = Repo.s("st:${p.id}")
                val revision = Repo.catalogueEditsRevision
                playlistCategories[key] = CachedCategories(stamp, revision, plainCats(base, kind).map { it.copy(playlist = p.id) })
            }
            val children = if (open) cachedCategories(p.id, kind).orEmpty() else emptyList()
            listOf(header) + children
        }
    }
    private fun togglePlaylist(c: Cat) {
        cancelCategoryPreview()
        val kind = tab
        val expanded = expandedPlaylists(kind).toMutableSet()
        val opening = expanded.add(c.playlist)
        if (!opening) expanded.remove(c.playlist)
        Repo.sp.edit().putStringSet("expandedPlaylists:$kind", expanded).apply()
        sideFocusKey = c.key
        val side = sideRv
        val index = cats.indexOfFirst { it.key == c.key }
        if (index >= 0) side?.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
        updatePlaylistRows(c.playlist, kind)
        if (opening) requestPlaylistCategories(c, kind)
    }
    private fun updatePlaylistRows(id: String, kind: String) {
        if (tab != kind || switchingPlaylist) return
        if (renderedTab != kind) return
        val index = cats.indexOfFirst { it.header && it.playlist == id }
        if (index < 0) return
        val header = cats[index]
        val open = id in expandedPlaylists(kind)
        val cached = cachedCategories(id, kind)
        val next = header.copy(n = if (open) 1 else 0, busy = open && cached == null)
        val rows = if (open) visibleCategoryRows(cached.orEmpty(), kind) else emptyList()
        var end = index + 1
        while (end < cats.size && !cats[end].header) end++
        val removed = end - index - 1
        if (next == header && cats.subList(index + 1, end) == rows) return
        cats = cats.take(index) + next + rows + cats.drop(end)
        sideAdapter.notifyItemChanged(index)
        if (removed > 0) sideAdapter.notifyItemRangeRemoved(index + 1, removed)
        if (rows.isNotEmpty()) sideAdapter.notifyItemRangeInserted(index + 1, rows.size)
        updateSpinner()
    }
    private fun requestPlaylistCategories(c: Cat, kind: String) {
        val key = "${c.playlist}|$kind"
        if (ownCategory(c) || cachedCategories(c.playlist, kind) != null || !loadingPlaylistCategories.add(key)) return
        val p = Repo.visiblePlaylists().firstOrNull { it.id == c.playlist } ?: run { loadingPlaylistCategories.remove(key); return }
        val stamp = Repo.s("st:${p.id}")
        val revision = Repo.catalogueEditsRevision
        playlistCategoryWork.submit {
            val indexed = Repo.playlistCategoryNames(p, kind)
            val children = if (indexed != null) {
                val hidden = Repo.hiddenCats(kind)
                val locked = Repo.lockedNow(kind)
                val order = Repo.order("cat|$kind").withIndex().associate { it.value to it.index }
                val allLabel = when (kind) { "live" -> R.string.all_live; "movie" -> R.string.all_movies; else -> R.string.all_series }
                listOf(Cat("fav", getString(R.string.fav), -1, p.id),
                    Cat("recent", getString(R.string.recent), -1, p.id),
                    Cat("", getString(allLabel), -1, p.id)) +
                    indexed.filterNot { it in hidden || it in locked }
                        .sortedBy { order[it] ?: Int.MAX_VALUE }.map { Cat(it, it, -1, p.id) } +
                    indexed.filter { it in locked && it !in hidden }.map { Cat("lock:$it", it, 0, p.id) }
            } else {
                val snapshot = try { Repo.playlistSnapshot(p) } catch (_: Exception) { null }
                snapshot?.let { all ->
                    val hidden = Repo.hidden(); val hc = Repo.hiddenCats(kind); val locked = Repo.lockedNow(kind)
                    val base = all.filter { it.kind == kind && it.id !in hidden && it.grp !in hc && it.grp !in locked }
                    plainCats(base, kind).filter { !it.key.startsWith("lock:") || all.any { item -> item.kind == kind && item.grp == it.label } }.map { it.copy(playlist = p.id) }
                }
            }
            runOnUiThread {
                loadingPlaylistCategories.remove(key)
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (!Repo.isPlaylistVisible(p.id)) return@runOnUiThread
                if (stamp != Repo.s("st:${p.id}") || revision != Repo.catalogueEditsRevision) {
                    if (p.id in expandedPlaylists(kind)) requestPlaylistCategories(c, kind)
                    return@runOnUiThread
                }
                if (children != null) playlistCategories[key] = CachedCategories(stamp, revision, children)
                else {
                    val open = expandedPlaylists(kind).toMutableSet(); open.remove(p.id)
                    Repo.sp.edit().putStringSet("expandedPlaylists:$kind", open).apply()
                    Toast.makeText(this, R.string.playlist_refresh_retained, Toast.LENGTH_LONG).show()
                }
                if (p.id != Repo.active()?.id) updatePlaylistRows(p.id, kind)
            }
        }
    }
    private fun activateCategory(c: Cat, enter: Boolean) {
        val p = Repo.visiblePlaylists().firstOrNull { it.id == c.playlist } ?: return
        cancelCategoryPreview()
        categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
        clearBrowseReturn(); stopPreview()
        val kind = tab; val token = ++loadGeneration
        switchingPlaylist = true; filtering = true
        status.text = getString(R.string.loading)
        filterGeneration++; filterWork.cancel()
        loadWork.submit {
            val ok = Repo.selectPlaylist(p)
            runOnUiThread {
                if (isFinishing || isDestroyed || token != loadGeneration) return@runOnUiThread
                switchingPlaylist = false; filtering = false
                if (ok) {
                    Repo.dirty = !started
                    status.text = ""; focusPos = 0; cat = if (tab == kind) c.key else ""
                    previewId = ""
                    updateCounts()
                    if (tab == kind) {
                        sideFocusKey = categoryIdentity(c)
                        refresh(restoreCategoryFocus = !enter)
                        if (enter && started) enterCategory(c)
                    } else refresh()
                    Repo.loadEpg()
                } else {
                    status.text = getString(R.string.loadfail)
                    refresh(); Toast.makeText(this, R.string.playlist_refresh_retained, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    private fun visibleCategoryRows(rows: List<Cat>, kind: String): List<Cat> =
        if (kind == "list" || Repo.showAllCategory(kind)) rows else rows.filter { it.header || it.key.isNotEmpty() }

    private fun buildCats(base: List<Item>, kind: String): List<Cat> {
        val rows = if (Repo.groupedPlaylists() && kind in listOf("live", "movie", "series")) groupedCats(base, kind)
            else plainCats(base, kind)
        return visibleCategoryRows(rows, kind)
    }

    private fun plainCats(base: List<Item>, kind: String): List<Cat> {
        val l = ArrayList<Cat>()
        if (kind == "list") {
            l.add(Cat("", getString(R.string.all), base.size))
            for ((k, r) in listOf("live" to R.string.live, "movie" to R.string.movies, "series" to R.string.series)) {
                val n = base.count { it.kind == k }
                if (n > 0) l.add(Cat("k:$k", getString(r), n))
            }
        } else {
            val f = Repo.favs(); val rs = Repo.recent().toSet()
            l.add(Cat("fav", getString(R.string.fav), base.count { it.id in f }))
            l.add(Cat("recent", getString(R.string.recent), base.count { it.id in rs }))
            l.add(Cat("", getString(when (kind) { "live" -> R.string.all_live; "movie" -> R.string.all_movies; else -> R.string.all_series }), base.size))
            val m = LinkedHashMap<String, Int>()
            for (i in base) { ListUpdates.checkCancelled(); if (i.grp.isNotBlank()) m[i.grp] = (m[i.grp] ?: 0) + 1 }
            val co = Repo.order("cat|$kind")
            val ents = if (co.isEmpty()) m.entries.toList() else { val pos = HashMap<String, Int>(); for ((i, nm) in co.withIndex()) pos[nm] = i; m.entries.sortedBy { pos[it.key] ?: Int.MAX_VALUE } }
            for (e in ents) l.add(Cat(e.key, e.key, e.value))
            val lk = Repo.lockedNow(kind)
            if (lk.isNotEmpty()) { val ac = Repo.categories(kind).toHashSet(); for (g in lk) if (g in ac) l.add(Cat("lock:$g", g, 0)) }
        }
        return l
    }

    private var renderedCategory = ""
    private var renderedTab = ""
    private var renderedPlaylist: String? = null
    private var renderedQuery = ""
    private var filteringCategoryPreview = false

    private fun decorations(items: List<Item>, preview: String): List<String> {
        val favourites = Repo.favs()
        return items.map {
            ListUpdates.checkCancelled()
            "${it.id in favourites}|${if (it.kind == "live") "" else Repo.progressOf(it)}|${it.id == preview}"
        }
    }

    private fun refresh(updateCategories: Boolean = true, restoreCategoryFocus: Boolean = true, categoryPreview: Boolean = false) {
        if (switchingPlaylist) return
        val token = ++filterGeneration
        filterWork.cancel()
        filtering = true; filteringCategoryPreview = categoryPreview
        if (Repo.b("playlistVisibilityManaged", false) && Repo.visiblePlaylists().isEmpty()) status.text = getString(R.string.no_visible_playlists)
        else if (status.text.toString() == getString(R.string.no_visible_playlists)) status.text = ""
        (rv as? ChannelRecyclerView)?.apply {
            channelNavigation = wide && tab == "live"
            gridNavigation = wide && tab in listOf("movie", "series", "list")
        }
        if (tab == "home") { filtering = false; showHomeMode(true); home.render(); home.start(); return }
        val expectedTab = tab; val requestedCategory = cat
        val query = search.text.toString().trim().lowercase(Locale.ROOT)
        val playlist = Repo.active()?.id
        val oldData = data; val oldCategories = cats; val oldCont = cont
        val oldKeys = renderKeys; val oldContKeys = continuationKeys
        val oldScope = pageScope
        val keep = !restoringBrowse && rv.hasFocus()
        val keepPos = focusPos; val keepId = oldData.getOrNull(focusPos)?.id
        val keepSide = !restoringBrowse && restoreCategoryFocus && sideRv?.hasFocus() == true
        val sidePosition = sideRv?.findFocus()?.let { sideRv?.findContainingViewHolder(it)?.bindingAdapterPosition }
        val keptSideKey = sideFocusKey ?: sidePosition?.let { cats.getOrNull(it)?.let(::categoryIdentity) }
        val returnItem = browseReturn?.getString("item")
        val preview = previewId
        fun compute() {
            val base by lazy(LazyThreadSafetyMode.NONE) { if (expectedTab == "list") Repo.favItems() else Repo.list(expectedTab) }
            val categories = if (updateCategories) buildCats(base, expectedTab) else oldCategories
            val showAll = expectedTab == "list" || Repo.showAllCategory(expectedTab)
            val available = if (expectedTab == "list") categories else {
                val own = categories.filter { !it.header && (it.playlist.isEmpty() || it.playlist == playlist) }
                if (own.isNotEmpty() || playlist == null) own else cachedCategories(playlist, expectedTab).orEmpty()
            }
            val category = requestedCategory.takeIf { key ->
                if (expectedTab == "list") categories.any { it.key == key } || uiStyle == "studio" && key in studioFilters
                else if (key.isEmpty()) showAll
                else key == "fav" || key == "recent" || available.any { it.key == key && !it.key.startsWith("lock:") }
            } ?: if (showAll) "" else available.firstOrNull {
                it.key.isNotEmpty() && it.key != "fav" && it.key != "recent" && !it.key.startsWith("lock:")
            }?.key ?: "fav"
            val continuation = if (expectedTab in listOf("movie", "series") && category.isEmpty() && query.isEmpty()) buildCont(base) else emptyList()
            var filtered: List<Item> = when {
                expectedTab == "list" -> if (category.startsWith("k:")) base.filter { it.kind == category.substring(2) } else base
                category == "fav" -> { val f = Repo.favs(); if (f.isEmpty()) emptyList() else base.filter { ListUpdates.checkCancelled(); it.id in f } }
                category == "recent" -> {
                    val m = HashMap<String, Item>()
                    for (item in base) { ListUpdates.checkCancelled(); m[item.id] = item }
                    Repo.recent().mapNotNull { m[it] }
                }
                category.isEmpty() -> base
                else -> Repo.list(expectedTab, category)
            }
            if (query.isNotEmpty()) filtered = filtered.filter {
                if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException()
                it.name.lowercase(Locale.ROOT).contains(query)
            }
            if (Thread.currentThread().isInterrupted) return
            if (query.isEmpty() && category != "recent") filtered = Repo.applyOrder(expectedTab + "|" + category, filtered)
            val scope = "$playlist|$expectedTab|$category|$query"
            val anchor = if (returnItem != null) filtered.indexOfFirst { it.id == returnItem } else -1
            val limit = if (expectedTab == "live") filtered.size else ListUpdates.limit(filtered.size, if (scope == oldScope) oldData.size else 0, anchor)
            val page = filtered.take(limit)
            val keys = decorations(page, preview); val contKeys = decorations(continuation, preview)
            val contentDiff = if (scope != oldScope) ListUpdates.replace(oldData.size, page.size) else ListUpdates.diff(oldData, page, { x, y -> x.id == y.id }) { x, y -> oldData[x] == page[y] && oldKeys.getOrNull(x) == keys[y] }
            val categoryDiff = if (oldCategories === categories) ListUpdates.unchanged() else ListUpdates.diff(oldCategories, categories, { x, y -> categoryIdentity(x) == categoryIdentity(y) })
            val contDiff = ListUpdates.diff(oldCont, continuation, { x, y -> x.id == y.id }) { x, y -> oldCont[x] == continuation[y] && oldContKeys.getOrNull(x) == contKeys[y] }
            if (Thread.currentThread().isInterrupted) return
            val all = filtered
            val apply = Runnable {
                if (isFinishing || isDestroyed || token != filterGeneration || tab != expectedTab || cat != requestedCategory || Repo.active()?.id != playlist) return@Runnable
                filtering = false
                showHomeMode(false)
                categorySearchHeader?.visibility = if (reference || tab == "live") View.VISIBLE else View.GONE
                if (wide) search.visibility = if (reference || tab == "live") View.VISIBLE else View.GONE
                val sidebarChanged = cats !== oldCategories
                cat = category
                paintStudioFilters()
                if (!sidebarChanged) cats = categories
                fullList = all; data = page; cont = continuation
                renderedCategory = category; renderedTab = expectedTab; renderedPlaylist = playlist; renderedQuery = query
                pageScope = scope; renderKeys = keys; continuationKeys = contKeys
                contBox.visibility = if (cont.isNotEmpty()) View.VISIBLE else View.GONE
                val live = tab == "live"
                val showLive = live && wide
                val tri = showLive && liveStyle == "triple"
                liveBox.visibility = if (showLive && !tri) View.VISIBLE else View.GONE
                epgHdrRow.visibility = if (showLive && !tri) View.VISIBLE else View.GONE
                rightPane.visibility = if (tri) View.VISIBLE else View.GONE
                auroraMedia?.visibility = if (auroraMediaPanel()) View.VISIBLE else View.GONE
                if (wide) layoutBody(tri)
                if (showLive) placeLive()
                tcol.visibility = if (showLive) View.INVISIBLE else View.VISIBLE
                head.visibility = if (showLive) View.GONE else View.VISIBLE
                (searchBtn as? Button)?.let { Th.paint(it, query.isNotEmpty()) }
                if (showLive) { dateTv.text = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(ws)) + if (guideBrowsing) " · " + hm(ws) else ""; hdr.winStart = ws; hdr.invalidate() }
                val want = if (live) "row" else if (auroraMediaPanel()) "media-grid" else "grid"
                val changedLayout = lm != want
                if (lm != want) {
                    lm = want
                    val w = resources.displayMetrics.widthPixels * (if (wide) 0.7 else 1.0)
                    rv.layoutManager = if (want == "row") LinearLayoutManager(this) else GridLayoutManager(this, if (auroraMediaPanel()) 3 else if (wide && uiStyle == "cinema") 5 else maxOf(2, (w / dp(if (wide) 150 else 118)).toInt()))
                }
                if (!live) stopPreview()
                if (changedLayout) adapter.notifyDataSetChanged() else contentDiff.dispatchUpdatesTo(adapter)
                if (!sidebarChanged) categoryDiff.dispatchUpdatesTo(sideAdapter)
                contDiff.dispatchUpdatesTo(contAdapter)
                updateSpinner(); repaintCategories()
                val selected = data.firstOrNull { it.id == keepId } ?: data.firstOrNull()
                if (selected != null) showHeader(selected) else { if (auroraMediaPanel()) showAuroraMedia(null); titleTv.text = ""; metaTv.text = if (status.text.isEmpty()) getString(R.string.none) else "" }
                if (showLive) maybeAutoPreview()
                if (keep && data.isNotEmpty() && !rv.hasFocus()) restoreFocus(data.indexOfFirst { it.id == keepId }.takeIf { it >= 0 } ?: keepPos)
                if (pendingNavigationFocus == expectedTab) {
                    pendingNavigationFocus = null
                    sideFocusKey = cat
                    (studioFilters[""]?.takeIf { expectedTab == "list" } ?: sideRv)?.post { if (started && tab == expectedTab) focusSide() }
                } else if (keepSide) { sideFocusKey = keptSideKey; sideRv?.post { focusSide() } }
                if (Repo.groupedPlaylists()) cats.filter { it.header && it.n == 1 && !ownCategory(it) }.forEach { requestPlaylistCategories(it, expectedTab) }
                if (restoringBrowse) restoreBrowseReturn()
            }
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) apply.run() else hd.post(apply)
        }
        if (Repo.items.size >= 1000 || query.isNotEmpty()) filterWork.submit { compute() } else compute()
    }

    private fun clearPrefetch() {
        preloads.forEach { com.bumptech.glide.Glide.with(applicationContext).clear(it) }
        preloads.clear(); preloadScope = ""
    }
    private fun prefetchPosters() {
        if (tab !in listOf("movie", "series", "list") || !started) return
        val manager = rv.layoutManager as? LinearLayoutManager ?: return
        val last = manager.findLastVisibleItemPosition()
        val key = "$pageScope|$last"
        if (last < 0 || preloadScope == key) return
        clearPrefetch(); preloadScope = key
        val visible = rv.findViewHolderForAdapterPosition(last) as? A.VH
        val width = visible?.img?.width?.takeIf { it > 0 } ?: dp(140)
        val height = visible?.img?.height?.takeIf { it > 0 } ?: dp(190)
        for (item in fullList.drop(last + 1).take(2)) Img.prefetch(this, item.logo, width, height)?.let { preloads.add(it) }
    }

    private fun appendPage() {
        if (filtering || tab == "live" || tab == "home" || data.size >= fullList.size) return
        val old = data.size
        data = fullList.take(minOf(fullList.size, old + ListUpdates.PAGE))
        renderKeys = renderKeys + decorations(data.drop(old), previewId)
        adapter.notifyItemRangeInserted(old, data.size - old)
    }

    private fun updateSpinner() {
        val sp = spin ?: return
        val labels = cats.map { "${it.label}  (${it.n})" }
        if (labels != lastLabels) { lastLabels = labels; sp.adapter = Th.spinnerAdapter(this, labels) }
        val idx = cats.indexOfFirst { !it.header && ownCategory(it) && it.key == cat }
        if (idx >= 0 && sp.selectedItemPosition != idx) sp.setSelection(idx)
    }

    private fun appliedKey() = Th.name + Repo.s("lang", "sys") + Repo.s("ts", "1.0") + Repo.s("ft", "sys") + Repo.s("ui", "cinema") + Repo.s("livestyle", "timeline") + Repo.s("referencePalette", "slate") + Repo.s("liveLatency", "fast") + Repo.s("liveFormat", "ts") + "|playlists=" + Repo.playlistVisibilitySignature() + "|managed=" + Repo.s("playlistVisibilityManaged", "0") + "|ua=" + RequestIdentity.userAgent() +
        listOf("navigation", "navText", "navIcons", "railMode", "navLabelPosition", "custom").joinToString("|") { Repo.s(HomePreferences.key(Repo.s("ui", "cinema"), it)) } +
        "|leagues=" + Repo.s("gunnersLeagues")

    private fun shiftGuide(direction: Int) {
        val now = winStart()
        ws = (ws + direction * 1800000L).coerceIn(now, now + 10 * 3600000L)
        guideBrowsing = ws != now
        redrawGuide()
    }
    private fun redrawGuide() {
        hdr.winStart = ws; hdr.invalidate()
        dateTv.text = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(ws)) + if (guideBrowsing) " · " + hm(ws) else ""
        dateTv.contentDescription = getString(R.string.epg_programme_anchor, hm(ws))
        for (n in 0 until rv.childCount) {
            val holder = rv.getChildViewHolder(rv.getChildAt(n)) as? A.VH ?: continue
            holder.cur?.let { holder.epgV?.bind(Repo.progs(it), ws) }
        }
    }

    private fun epgRows() = wide && liveStyle != "triple"

    private fun paintStudioFilters() {
        studioFilters.forEach { (key, button) ->
            button.isSelected = key == cat
            button.background = ReferenceLook.selection(this, button.isSelected, button.hasFocus())
        }
    }

    private fun showHomeMode(on: Boolean) {
        if (tab == "live" && !referenceCategoryReveal()) {
            referenceCategoriesHidden = false
            hideCategoriesOnEntry = false
        }
        val showFilters = !on && uiStyle == "studio" && tab == "list"
        (studioFilters.values.firstOrNull()?.parent as? View)?.visibility = if (showFilters) View.VISIBLE else View.GONE
        studioRoot?.let { root ->
            val art = if (on) studioHomeArt else studioBrowseArt
            if (root.background !== art) root.background = art
        }
        home.root.visibility = if (on) View.VISIBLE else View.GONE
        rv.visibility = if (on) View.GONE else View.VISIBLE
        categoryPanel?.visibility = if (on || showFilters || referenceCategoryReveal() && referenceCategoriesHidden) View.GONE else View.VISIBLE
        spin?.visibility = if (on) View.GONE else View.VISIBLE
        if (on) {
            // The home dashboard occupies the full canvas; category sidebar belongs to content screens.
            if (uiStyle in Designs.ids) {
                (main.layoutParams as? LinearLayout.LayoutParams)?.weight = 100f
                (rightPane.layoutParams as? LinearLayout.LayoutParams)?.weight = 0f
                body.setPadding(dp(22), dp(14), dp(22), dp(12))
            }
            head.visibility = View.GONE; contBox.visibility = View.GONE; liveBox.visibility = View.GONE
            epgHdrRow.visibility = View.GONE; rightPane.visibility = View.GONE; auroraMedia?.visibility = View.GONE
            stopPreview(); layoutBody(false)
            if (uiStyle in Designs.ids) {
                (main.layoutParams as? LinearLayout.LayoutParams)?.weight = 100f
                body.requestLayout()
            }
        } else {
            home.stop()
            if (uiStyle in Designs.ids) body.setPadding(dp(12), dp(4), dp(12), dp(8))
        }
    }

    private fun layoutBody(tri: Boolean) {
        var changed = false
        fun weight(view: View?, value: Float) {
            val params = view?.layoutParams as? LinearLayout.LayoutParams ?: return
            if (params.weight != value) { params.weight = value; changed = true }
        }
        val hidden = referenceCategoryReveal() && referenceCategoriesHidden
        weight(categoryPanel, if (uiStyle == "aurora" || auroraMediaPanel()) 18f else if (tri) 22f else 26f)
        weight(main, if (auroraMediaPanel()) 51f else if (hidden) 100f else if (tri && uiStyle == "aurora") 51f else if (tri) 38f else 74f)
        weight(rightPane, if (tri && uiStyle == "aurora") 31f else if (tri) 40f else .01f)
        weight(auroraMedia, if (auroraMediaPanel()) 31f else 0f)
        if (changed) body.requestLayout()
    }

    /** Puts the preview / channel info where the chosen Live TV design wants them. */
    private fun placeLive() {
        if (placed == liveStyle) return
        placed = liveStyle
        for (v in listOf<View>(prevFrame, infoCol, guideBox)) (v.parent as? ViewGroup)?.removeView(v)
        liveBox.removeAllViews(); rightPane.removeAllViews()
        when (liveStyle) {
            "triple" -> {
                rightPane.addView(prevFrame, LinearLayout.LayoutParams(-1, dp(if (uiStyle == "aurora") 148 else 190)))
                rightPane.addView(infoCol, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
                rightPane.addView(guideBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
                if (uiStyle == "aurora") {
                    rightPane.setPadding(dp(10), dp(8), dp(4), dp(8))
                    rightPane.background = auroraGlass()
                    rightPane.addView(Designs.action(this, getString(R.string.aurora_fullscreen), R.drawable.ic_n_play, true) {
                        (data.firstOrNull { it.id == previewId } ?: data.getOrNull(focusPos))?.let(::play)
                    })
                }
            }
            "guide" -> liveBox.addView(infoCol, LinearLayout.LayoutParams(0, -2, 1f))
            else -> {
                liveBox.addView(prevFrame, LinearLayout.LayoutParams(dp(if (uiStyle == "studio") 280 else 280), dp(if (uiStyle == "studio") 158 else 158)).apply { marginEnd = dp(14) })
                liveBox.addView(infoCol, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
    }

    private fun fillGuide(i: Item) {
        guideBox.removeAllViews()
        val now = System.currentTimeMillis()
        for ((k, p) in Repo.progs(i).filter { it.stop > now }.take(if (uiStyle == "aurora") 2 else 5).withIndex()) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8))
                background = Th.shape(this@MainActivity, if (k == 0) Th.card else col("#00000000"), false, 12)
            }
            r.addView(TextView(this).apply { text = hm(p.start) + " — " + hm(p.stop); setTextColor(if (k == 0) Th.acc else Th.mut); textSize = 12f })
            r.addView(TextView(this).apply { text = p.title; setTextColor(Th.fg); textSize = 14f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
            guideBox.addView(r, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) })
        }
    }

    private fun fmt(r: Double) = String.format(Locale.US, "%.1f", r)

    private fun showHeader(i: Item) {
        if (tab == "live") {
            if (rv.hasFocus()) Repo.active()?.let { playlist ->
                val key = "startupChannel:" + playlist.id
                val categoryKey = "startupCategory:" + playlist.id
                if (Repo.s(key) != i.id || Repo.s(categoryKey) != cat) {
                    Repo.sp.edit().putString(key, i.id).putString(categoryKey, cat).apply()
                }
            }
            if (wide) showLiveInfo(i)
            return
        }
        if (auroraMediaPanel()) showAuroraMedia(i)
        titleTv.text = i.name
        val r = i.rate.toDoubleOrNull() ?: 0.0
        metaTv.text = listOfNotNull(if (r > 0) "★ " + fmt(r) else null, i.year.takeIf { it.isNotBlank() }, i.dur.takeIf { uiStyle == "cinema" && it.isNotBlank() }, i.grp.takeIf { it.isNotBlank() }).joinToString("   •   ")
    }

    private fun showLiveInfo(i: Item) {
        val idx = data.indexOfFirst { it.id == i.id }
        infoNum.text = (idx + 1).toString()
        infoName.text = i.name
        previewLogo?.let { if (it.tag != i.logo) Img.load(it, i.logo) }
        val np = Repo.nowOn(i)
        if (np != null) { infoNow.text = np.title; infoTime.text = hm(np.start) + " - " + hm(np.stop); infoDesc.text = np.desc }
        else { infoNow.text = getString(R.string.no_prog); infoTime.text = ""; infoDesc.text = "" }
        if (liveStyle == "triple") fillGuide(i)
    }

    // ----- preview player -----
    private var previewListener: androidx.media3.common.Player.Listener? = null
    private var previewBridge: VideoFrameBridge? = null
    private var returnPreviewToken: String? = null
    private fun detachPreviewObserver(p: ExoPlayer) {
        previewListener?.let { p.removeListener(it) }; previewListener = null
        previewBridge?.close(); previewBridge = null
    }
    private var pendingPreview: Item? = null
    private var previewRequestedAt = 0L
    private var firstFrameStartedAt: Long? = null
    private val previewRequest = Runnable {
        val channel = pendingPreview ?: return@Runnable
        pendingPreview = null
        if (started && !switchingPlaylist && tab == "live") startPreview(channel, previewRequestedAt)
    }

    private fun cancelPreviewRequest() {
        hd.removeCallbacks(previewRequest)
        pendingPreview = null
    }

    private fun queuePreview(channel: Item) {
        cancelPreviewRequest()
        pendingPreview = channel
        previewRequestedAt = android.os.SystemClock.elapsedRealtime()
        hd.postDelayed(previewRequest, 120L)
    }

    private fun selectPreview(channel: Item) {
        if (pendingPreview?.id == channel.id) previewRequest.run()
        if (previewId == channel.id && prev != null) {
            cancelPreviewRequest()
            expandPreview(channel)
        } else queuePreview(channel)
    }

    private fun startPreview(i: Item, requestedAt: Long = android.os.SystemClock.elapsedRealtime()) {
        cancelPreviewRequest()
        val v = pvw ?: return
        val oldId = previewId
        previewItem = i
        if (oldId != i.id) inlineInfo?.apply { hide(); reset() }
        if (oldId.isNotEmpty() && oldId != i.id) previousPreviewId = oldId
        previewId = i.id
        val transfer = if (prev == null) LivePlayerHandoff.take(i.id, LivePlayerHandoff.Destination.PREVIEW, returnPreviewToken) else null
        val p = prev ?: (transfer?.player ?: makePlayer(this, live = true)).also { p ->
            prev = p
            val listener = object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    previewPlaceholder?.visibility = if (state == androidx.media3.common.Player.STATE_READY) View.GONE else View.VISIBLE
                    inlineInfo?.state(state)
                }
                override fun onRenderedFirstFrame() {
                    previewPlaceholder?.visibility = View.GONE
                    firstFrameStartedAt?.let {
                        val elapsed = android.os.SystemClock.elapsedRealtime() - it
                        android.util.Log.i("AbomiskPreview", "Preview first frame in ${elapsed}ms")
                    }
                    firstFrameStartedAt = null
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) { previewPlaceholder?.visibility = View.VISIBLE }
            }
            previewListener = listener; p.addListener(listener)
            if (transfer != null) {
                returnPreviewToken = null; previewPlaceholder?.visibility = View.GONE
                previewBridge = transfer.attach(v)
            } else {
                val effects = PictureSettings.load().effects()
                if (effects.isNotEmpty()) p.setVideoEffects(effects)
                v.player = p
            }
        }
        if (transfer != null) {
            if (p.playbackState == androidx.media3.common.Player.STATE_IDLE) p.prepare()
            p.playWhenReady = true
        } else if (oldId != i.id || p.currentMediaItem == null) {
            firstFrameStartedAt = requestedAt
            p.setMediaItem(PlaybackPolicy.mediaItem(i.url, true)); p.prepare(); p.playWhenReady = true
        }
        if (Repo.s("lastLive") != i.id) Repo.put("lastLive", i.id)
        showLiveInfo(i)
        if (oldId != i.id) {
            changed(oldId)
            if (inlineFullscreen) showInlineInfo(focusControls = false, channelChanged = true)
        }
        changed(i.id)
    }

    private fun updateVideoHost(frame: FrameLayout, host: FrameLayout) {
        val visible = tab == "live" && prevFrame.isShown
        val mode = if (visible) View.VISIBLE else View.INVISIBLE
        if (host.visibility != mode) host.visibility = mode
        if (!visible) return
        val width = if (inlineFullscreen) frame.width else prevFrame.width
        val height = if (inlineFullscreen) frame.height else prevFrame.height
        if (!inlineFullscreen) {
            prevFrame.getLocationInWindow(previewPosition)
            frame.getLocationInWindow(hostPosition)
        }
        host.translationX = if (inlineFullscreen) 0f else (previewPosition[0] - hostPosition[0]).toFloat()
        host.translationY = if (inlineFullscreen) 0f else (previewPosition[1] - hostPosition[1]).toFloat()
        val params = host.layoutParams
        if (width > 0 && height > 0 && (params.width != width || params.height != height)) {
            params.width = width
            params.height = height
            host.layoutParams = params
        }
    }

    private fun setInlineFullscreen(fullscreen: Boolean) {
        inlineFullscreen = fullscreen
        if (!fullscreen) {
            inlineInfo?.hide()
        }
        videoHost?.let { host ->
            val frame = host.parent as? FrameLayout ?: return
            host.translationZ = if (fullscreen) dp(24).toFloat() else 0f
            updateVideoHost(frame, host)
        }
    }

    private fun stopPreview() {
        cancelPreviewRequest()
        firstFrameStartedAt = null
        if (inlineFullscreen) setInlineFullscreen(false)
        prev?.let { p -> detachPreviewObserver(p); if (pvw?.player === p) pvw?.player = null; p.release() }
        prev = null
        previewItem = null
        inlineInfo?.reset()
        if (!LivePlayerHandoff.owns(pvw)) pvw?.player = null
    }

    private fun expandPreview(i: Item) {
        if (cat == "fav") { play(i); return }
        if (prev == null || videoHost == null || tab != "live") return
        rememberBrowseReturn(i)
        setInlineFullscreen(true)
    }

    private fun maybeAutoPreview() {
        if (openingLastCategory || restoringBrowse || switchingPlaylist || !wide || tab != "live" || liveStyle == "guide" || !started || prev != null) return
        val id = if (previewId.isNotEmpty()) previewId else Repo.s("lastLive")
        if (id.isEmpty()) return
        if (!Repo.b("autoPrev", true) && !LivePlayerHandoff.hasPending(id, LivePlayerHandoff.Destination.PREVIEW, returnPreviewToken)) return
        val it = Repo.list("live").firstOrNull { it.id == id } ?: return
        if (it.kind == "live") startPreview(it)
    }

    private fun open(i: Item) {
        rememberBrowseReturn(i)
        when {
            i.kind == "series" && i.url.isEmpty() -> openSeriesDetails(i)
            i.kind == "movie" && (i.sid.isNotEmpty() || uiStyle == "aurora") -> { stopPreview(); startActivity(Intent(this, SeriesActivity::class.java).putExtra("id", i.id)) }
            else -> play(i)
        }
    }

    private fun openSeriesDetails(item: Item, resume: Boolean = false) {
        stopPreview()
        startActivity(Intent(this, SeriesActivity::class.java)
            .putExtra("id", item.id).putExtra("resume-episode", resume))
    }

    private fun play(i: Item) {
        openingLastCategory = false
        val favouriteScope = i.kind == "live" && (tab == "list" || tab == "live" && cat == "fav")
        if (favouriteScope) {
            val active = Repo.active()?.id
            val sourceTab = tab
            val sourceCategory = cat
            val favourites = Repo.favs()
            val local = data.filter { it.kind == "live" && it.id in favourites }
            favouriteQueueWork.submit {
                val remaining = Repo.list("live").filter { it.id in favourites }
                val other = Repo.cachedLiveFavourites(active, favourites)
                hd.post {
                    if (!started || isFinishing || Repo.active()?.id != active || tab != sourceTab || cat != sourceCategory) return@post
                    playQueued(i, (local + i + remaining + other).distinctBy { it.url })
                }
            }
            return
        }
        if (tab == "live" && i.kind == "live" && previewId == i.id && prev != null) { expandPreview(i); return }
        playQueued(i)
    }

    private fun playQueued(i: Item, favourites: List<Item>? = null, previewMenu: PreviewMenu? = null) {
        val reuse = i.kind == "live" && LivePlayerHandoff.hasPending(i.id, LivePlayerHandoff.Destination.FULLSCREEN)
        rememberBrowseReturn(i)
        if (!reuse) stopPreview()
        Repo.zap = favourites ?: when {
            i.kind != "live" -> emptyList()
            tab == "live" && data.isNotEmpty() -> data
            tab == "home" -> (listOf(i) + Repo.list("live").filter { it.id != i.id })
            else -> data.filter { it.kind == "live" }.ifEmpty { Repo.list("live") }
        }
        launchPlayer(Intent(this, PlayerActivity::class.java)
            .putExtra("url", i.url).putExtra("name", i.name).putExtra("live", i.kind == "live").putExtra("rid", i.id).putExtra("reusePreview", reuse)
            .putExtra("previewMenu", previewMenu?.name))
    }

    private fun launchPlayer(playbackIntent: Intent) {
        val token = java.util.UUID.randomUUID().toString()
        returnPreviewToken = null
        playbackIntent.putExtra("returnPreviewAllowed", wide && tab == "live" && pvw != null && (playbackIntent.getBooleanExtra("reusePreview", false) || Repo.b("autoPrev", true)))
        browseReturn?.putString(PlayerActivity.RETURN_TOKEN, token)
        playbackIntent.putExtra(PlayerActivity.RETURN_TOKEN, token)
            .putExtra(PlayerActivity.RETURN_PLAYLIST, Repo.active()?.id)
        playerLauncher.launch(playbackIntent)
    }

    private fun consumeLiveReturn(result: Intent?) {
        val snapshot = browseReturn ?: return
        if (result == null || snapshot.getString("tab") != "live") return
        val token = snapshot.getString(PlayerActivity.RETURN_TOKEN) ?: return
        if (result.getStringExtra(PlayerActivity.RETURN_TOKEN) != token ||
            result.getStringExtra(PlayerActivity.RETURN_PLAYLIST) != snapshot.getString("playlist") ||
            snapshot.getString("playlist") != Repo.active()?.id) return
        val id = result.getStringExtra(PlayerActivity.RETURN_CHANNEL) ?: return
        val item = Repo.list("live").firstOrNull { it.id == id } ?: return
        returnPreviewToken = token
        snapshot.remove(PlayerActivity.RETURN_TOKEN)
        if (snapshot.getString("item") == id) return
        val category = snapshot.getString("category", "")
        val staysInCategory = when (category) {
            "" -> true
            "fav" -> Repo.isFav(id)
            "recent" -> id in Repo.recent()
            else -> category == item.grp
        }
        if (!staysInCategory) {
            snapshot.putString("category", item.grp.takeIf { it.isNotBlank() } ?: "")
            snapshot.remove("category-scroll")
        }
        val query = snapshot.getString("query", "")
        if (query.isNotEmpty() && !item.name.contains(query, ignoreCase = true)) snapshot.putString("query", "")
        snapshot.putString("item", id)
        snapshot.putInt("index", data.indexOfFirst { it.id == id }.coerceAtLeast(0))
        snapshot.remove("content-scroll")
        stopPreview(); previewId = id
        restoringBrowse = true
    }

    private fun changed(id: String) {
        if (id.isEmpty()) return
        if (rv.isComputingLayout) {
            rv.post { changed(id) }
            return
        }
        val p = data.indexOfFirst { it.id == id }
        if (p >= 0) adapter.notifyItemChanged(p, liveMarkerPayload)
    }

    private fun refreshVisible() {
        val m = rv.layoutManager as? LinearLayoutManager ?: return
        val f = m.findFirstVisibleItemPosition(); val l = m.findLastVisibleItemPosition()
        val last = l.coerceAtMost(data.lastIndex)
        if (f >= 0 && last >= f && !rv.isComputingLayout) adapter.notifyItemRangeChanged(f, last - f + 1, liveGuidePayload)
    }

    private fun restoreFocus(pos: Int) {
        rv.post {
            if (data.isEmpty()) return@post
            val p = pos.coerceIn(0, data.size - 1)
            rv.scrollToPosition(p)
            rv.post { rv.findViewHolderForAdapterPosition(p)?.itemView?.requestFocus() }
        }
    }

    private fun captureBrowseReturn(item: Item): Bundle? {
        if (tab == "home") return null
        val index = data.indexOfFirst { it.id == item.id }
        if (index < 0) return null
        return Bundle().apply {
            putString("playlist", Repo.active()?.id ?: "")
            putString("tab", tab); putString("category", cat); putString("query", search.text.toString())
            putString("item", item.id); putInt("index", index)
            putParcelable("content-scroll", rv.layoutManager?.onSaveInstanceState())
            putParcelable("category-scroll", sideRv?.layoutManager?.onSaveInstanceState())
        }
    }

    private fun rememberBrowseReturn(item: Item) {
        if (browseReturn?.getString("item") == item.id && restoringBrowse) return
        val snapshot = captureBrowseReturn(item) ?: return
        cancelCategoryPreview()
        categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
        browseReturn = snapshot; restoringBrowse = true
    }

    private fun clearBrowseReturn() {
        browseRestoreTask?.let { hd.removeCallbacks(it) }; browseRestoreTask = null
        browseReturn = null; restoringBrowse = false
    }

    override fun onSaveInstanceState(out: Bundle) {
        val snapshot = browseReturn ?: data.getOrNull(focusPos.coerceAtLeast(0))?.let { captureBrowseReturn(it) }
        snapshot?.let { out.putBundle("browse-return", it) }
        super.onSaveInstanceState(out)
    }

    private fun restoreBrowseReturn() {
        val snapshot = browseReturn ?: return
        if (snapshot.getString("playlist") != Repo.active()?.id || snapshot.getString("tab") != tab) {
            clearBrowseReturn(); return
        }
        if (data.isEmpty()) { clearBrowseReturn(); return }
        browseRestoreTask?.let { hd.removeCallbacks(it) }
        cancelCategoryPreview()
        val index = data.indexOfFirst { it.id == snapshot.getString("item") }.takeIf { it >= 0 }
            ?: snapshot.getInt("index").coerceIn(0, data.lastIndex)
        rv.layoutManager?.onRestoreInstanceState(snapshot.getParcelable("content-scroll"))
        val categoryScroll = snapshot.getParcelable<android.os.Parcelable>("category-scroll")
        if (cat == snapshot.getString("category") && categoryScroll != null)
            sideRv?.layoutManager?.onRestoreInstanceState(categoryScroll)
        else sideRv?.scrollToPosition(cats.indexOfFirst { !it.header && ownCategory(it) && it.key == cat }.coerceAtLeast(0))
        var attempts = 0
        val task = object : Runnable {
            override fun run() {
                if (!started || isFinishing || browseReturn !== snapshot) { browseRestoreTask = null; return }
                val target = rv.findViewHolderForAdapterPosition(index)?.itemView
                if (target != null && target.requestFocus()) {
                    focusPos = index; showHeader(data[index])
                    cancelCategoryPreview(); clearBrowseReturn(); repaintCategories()
                    if (tab == "live") maybeAutoPreview()
                    return
                }
                if (++attempts < 30) { rv.scrollToPosition(index); hd.postDelayed(this, 16) }
                else { clearBrowseReturn() }
            }
        }
        browseRestoreTask = task
        rv.post(task)
    }

    private fun isRtl() = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
    private fun keyToSide() = if (isRtl()) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
    private fun keyToMain() = if (isRtl()) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT

    private fun focusSide() {
        hideCategoriesOnEntry = false
        if (referenceCategoryReveal() && referenceCategoriesHidden) {
            referenceCategoriesHidden = false
            categoryPanel?.visibility = View.VISIBLE
            layoutBody(false)
        }
        if (uiStyle == "studio" && tab == "list") {
            (studioFilters[cat] ?: studioFilters[""])?.requestFocus()
            return
        }
        val sr = sideRv ?: return
        val target = sideFocusKey ?: cat; sideFocusKey = null
        val idx = maxOf(0, cats.indexOfFirst { categoryIdentity(it) == target || (!it.header && ownCategory(it) && it.key == target) })
        val v = sr.findViewHolderForAdapterPosition(idx)?.itemView
        if (v != null) v.requestFocus()
        else { sr.scrollToPosition(idx); sr.post { sr.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() } }
    }

    private fun cancelCategoryPreview() {
        categoryPreviewTask?.let { hd.removeCallbacks(it) }
        categoryPreviewTask = null; categoryPreviewView = null
    }

    private fun scheduleCategoryPreview(view: View, category: Cat) {
        cancelCategoryPreview()
        if (!Repo.b("categoryPreviewOnFocus", false) || restoringBrowse || switchingPlaylist ||
            categoryEnterTask != null || category.header) return
        if (category.key.startsWith("lock:")) return
        // Stop obsolete work immediately; the debounce below decides what should run next.
        if (filtering && filteringCategoryPreview && renderedTab == tab && renderedPlaylist == Repo.active()?.id &&
            renderedQuery == search.text.toString().trim().lowercase(Locale.ROOT)) {
            filterGeneration++; filterWork.cancel(); filtering = false
            cat = renderedCategory
            repaintCategories()
        }
        if (!switchingPlaylist && ownCategory(category) && category.key == cat && !filtering) return
        val expectedTab = tab
        categoryPreviewView = view
        categoryPreviewTask = Runnable {
            categoryPreviewTask = null; categoryPreviewView = null
            if (Repo.b("categoryPreviewOnFocus", false) && view.hasFocus() && started && tab == expectedTab && !isFinishing) {
                if (switchingPlaylist || !ownCategory(category)) { activateCategory(category, false); return@Runnable }
                cat = category.key; focusPos = 0
                refresh(updateCategories = false, restoreCategoryFocus = false, categoryPreview = true)
                rv.scrollToPosition(0)
                repaintCategories()
            }
        }.also { hd.postDelayed(it, 180) }
    }

    private fun repaintCategories() {
        val side = sideRv ?: return
        for (index in 0 until side.childCount) {
            val holder = side.getChildViewHolder(side.getChildAt(index)) as? S.VH ?: continue
            val category = cats.getOrNull(holder.bindingAdapterPosition) ?: continue
            sideAdapter.paint(holder, category, holder.itemView.hasFocus())
        }
    }

    private fun enterCategory(category: Cat) {
        if (category.header) { togglePlaylist(category); return }
        if (switchingPlaylist || !ownCategory(category)) { activateCategory(category, true); return }
        if (restoringBrowse) clearBrowseReturn()
        cancelCategoryPreview()
        if (category.key.startsWith("lock:")) {
            askPin(R.string.pin_enter) {
                Repo.unlock(tab, category.label); cat = category.label; focusPos = 0
                refresh(); rv.scrollToPosition(0); enterCategoryContent()
            }
        } else {
            if (cat != category.key || filtering) {
                cat = category.key; focusPos = 0
                refresh(updateCategories = false, restoreCategoryFocus = false)
                repaintCategories()
            }
            rv.scrollToPosition(0)
            enterCategoryContent()
        }
    }

    private fun enterCategoryContent() {
        categoryEnterTask?.let { hd.removeCallbacks(it) }
        if (data.isEmpty() && !filtering) return
        val expectedTab = tab; val expectedCategory = cat
        var attempts = 0
        categoryEnterTask = object : Runnable {
            override fun run() {
                if (categoryEnterTask !== this) return
                if (!started || tab != expectedTab || cat != expectedCategory || isFinishing) {
                    categoryEnterTask = null; return
                }
                if (filtering) { hd.postDelayed(this, 16); return }
                val first = if (!rv.hasPendingAdapterUpdates() && !rv.isComputingLayout) rv.findViewHolderForAdapterPosition(0)?.itemView else null
                if (first != null && first.requestFocus()) {
                    categoryEnterTask = null
                    if (hideCategoriesOnEntry && referenceCategoryReveal()) {
                        hideCategoriesOnEntry = false
                        referenceCategoriesHidden = true
                        categoryPanel?.visibility = View.GONE
                        layoutBody(false)
                    }
                    return
                }
                if (++attempts < 30) { rv.scrollToPosition(0); hd.postDelayed(this, 16) }
                else categoryEnterTask = null
            }
        }.also { rv.post(it) }
    }

    private fun focusMain() {
        if (contBox.visibility == View.VISIBLE && contRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() == true) return
        val m = rv.layoutManager as? LinearLayoutManager
        var p = m?.findFirstCompletelyVisibleItemPosition() ?: -1
        if (p < 0) p = m?.findFirstVisibleItemPosition() ?: 0
        if (p < 0) p = 0
        val v = rv.findViewHolderForAdapterPosition(p)?.itemView
        if (v != null) v.requestFocus() else rv.requestFocus()
    }

    /** Key handling on a channel / poster: hold OK = options, left/right edge = jump to the category list. */
    private fun itemKey(vh: A.VH, kc: Int, ev: KeyEvent): Boolean {
        if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER) {
            val it = vh.cur ?: return false
            if (ev.action == KeyEvent.ACTION_DOWN) {
                if (ev.repeatCount == 0) { vh.longDone = false; return false }
                if (!vh.longDone && ev.eventTime - ev.downTime >= 500) { vh.longDone = true; menu(it) }
                return true
            }
            if (ev.action == KeyEvent.ACTION_UP && vh.longDone) { vh.longDone = false; return true }
            return false
        }
        if (ev.action == KeyEvent.ACTION_DOWN && wide && kc == keyToSide()) {
            val span = (rv.layoutManager as? GridLayoutManager)?.spanCount ?: 1
            if (tab == "live" || vh.adapterPosition % span == 0) { focusSide(); return true }
        }
        return false
    }

    private fun menu(i: Item) {
        val now = System.currentTimeMillis()
        if (now - lastMenu < 800) return
        lastMenu = now
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        labels.add(getString(if (Repo.isFav(i.id)) R.string.fav_rm else R.string.fav_add)); acts.add { Repo.toggleFav(i.id); updateCounts(); refresh() }
        labels.add(getString(R.string.rename)); acts.add { renameDlg(i) }
        labels.add(getString(R.string.move)); acts.add { moveDlg(i) }
        if (tab != "home" && search.text.isNullOrBlank() && cat != "recent") {
            if (tab == "live" && i.kind == "live" && fullList.size > 1) {
                labels.add(getString(R.string.grab_move)); acts.add { grabChannel(i) }
            }
            labels.add(getString(R.string.move_up)); acts.add { moveItem(i, "up") }
            labels.add(getString(R.string.move_down)); acts.add { moveItem(i, "down") }
            labels.add(getString(R.string.move_top)); acts.add { moveItem(i, "top") }
            labels.add(getString(R.string.move_bottom)); acts.add { moveItem(i, "bottom") }
            labels.add(getString(R.string.move_pos)); acts.add {
                askText(R.string.move_pos, "1 - " + fullList.size, "") { n ->
                    val num = n.filter { it.isDigit() }.toIntOrNull()
                    if (num != null && num > 0) moveItem(i, "pos:$num")
                }
            }
        }
        labels.add(getString(R.string.hide)); acts.add { Repo.hide(i.id); updateCounts(); refresh() }
        if (Repo.hasOvr(i.id)) { labels.add(getString(R.string.reset_item)); acts.add { editCatalogue { Repo.clearOvr(i.id) } } }
        ModernDialogs.options(this, i.name, labels, acts)
    }

    private fun focusedItem(): Item? {
        var v: View? = currentFocus
        while (v != null) {
            val p = v.parent
            if (p === rv) return (rv.getChildViewHolder(v) as? A.VH)?.cur
            if (p === contRv) return (contRv.getChildViewHolder(v) as? C.VH)?.cur
            v = p as? View
        }
        return null
    }

    private fun focusedCat(): Cat? {
        val sr = sideRv ?: return null
        var v: View? = currentFocus
        while (v != null) {
            val p = v.parent
            if (p === sr) return cats.getOrNull(sr.getChildAdapterPosition(v))
            v = p as? View
        }
        return null
    }

    /** Remote buttons chosen by the user for browsing (Settings > Remote control). */
    private fun browseAction(a: String): Boolean {
        when (a) {
            "b_search" -> { val s = searchBtn; if (s != null) s.performClick() else search.requestFocus(); return true }
            "b_settings" -> { settingsBtn?.performClick(); return true }
            "b_menu" -> {
                val it = focusedItem()
                if (it != null) menu(it) else focusedCat()?.let { c -> catMenu(c) }
                return true
            }
            "b_fav" -> { focusedItem()?.let { Repo.toggleFav(it.id); updateCounts(); refresh() }; return true }
            "b_pgup", "b_pgdn" -> {
                val dy = (rv.height * 0.8f).toInt() * (if (a == "b_pgup") -1 else 1)
                if (tab == "home") (home.root as? android.widget.ScrollView)?.smoothScrollBy(0, dy) else rv.smoothScrollBy(0, dy)
                return true
            }
            "b_home" -> { if (tabBtns.containsKey("home")) selectTab("home"); return true }
            "b_live" -> { selectTab("live"); return true }
            "b_movies" -> { selectTab("movie"); return true }
            "b_series" -> { selectTab("series"); return true }
            "b_list" -> { selectTab("list"); return true }
        }
        return false
    }

    private fun togglePreviewFavourite() {
        val id = previewItem?.id ?: return
        Repo.toggleFav(id)
        changed(id)
        inlineInfo?.updateFavourite(Repo.isFav(id))
    }

    private fun openPreviewMenu(menu: PreviewMenu) {
        val channel = previewItem ?: return
        val player = prev ?: return
        cancelPreviewRequest()
        setInlineFullscreen(false)
        detachPreviewObserver(player)
        prev = null
        LivePlayerHandoff.offerFullscreen(channel.id, player, pvw)
        playQueued(channel, previewMenu = menu)
    }

    private fun showInlineInfo(focusControls: Boolean, channelChanged: Boolean = false) {
        val channel = previewItem ?: return
        val player = prev ?: return
        val host = videoHost ?: return
        val info = inlineInfo ?: InlinePlaybackInfo(this, host, ::togglePreviewFavourite, ::openPreviewMenu)
            .also { inlineInfo = it }
        if (!channelChanged && !focusControls && info.isShowing) info.hide()
        else {
            if (channelChanged || !info.isShowing) {
                info.show(player, channel, data.indexOfFirst { it.id == channel.id } + 1, channelChanged)
            }
            if (focusControls) info.focusControls()
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (inlineFullscreen && e.keyCode != KeyEvent.KEYCODE_BACK) {
            if (inlineInfo?.handleControls(e) == true) return true
            val action = Remote.resolve("live", e.keyCode)
            if (action == null && e.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) showInlineInfo(focusControls = true)
                return true
            }
            when (action) {
                "l_prev", "l_next" -> {
                    if (e.action == KeyEvent.ACTION_DOWN && data.isNotEmpty()) {
                        val currentId = pendingPreview?.id ?: previewId
                        val index = data.indexOfFirst { it.id == currentId }.coerceAtLeast(0)
                        val offset = if (action == "l_next") 1 else -1
                        val next = data[(index + offset).coerceIn(data.indices)]
                        if (next.id != currentId) queuePreview(next)
                    }
                    return true
                }
                "l_info" -> {
                    if (e.action == KeyEvent.ACTION_UP) showInlineInfo(focusControls = false)
                    return true
                }
                "l_last" -> {
                    if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                        data.firstOrNull { it.id == previousPreviewId }?.let { startPreview(it) }
                    }
                    return true
                }
                "l_fav" -> {
                    if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) togglePreviewFavourite()
                    return true
                }
                "l_list" -> {
                    if (e.action == KeyEvent.ACTION_UP) setInlineFullscreen(false)
                    return true
                }
                "l_menu" -> {
                    if (e.action == KeyEvent.ACTION_UP) openPreviewMenu(PreviewMenu.SETTINGS)
                    return true
                }
                else -> if (e.keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT) return true
            }
        }
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && currentFocus !is android.widget.EditText) {
            val a = Remote.resolve("browse", e.keyCode)
            if (a != null && browseAction(a)) return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun grabChannel(item: Item) {
        cancelCategoryPreview()
        categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
        val expectedTab = tab; val expectedCategory = cat
        val entries = fullList.map { ReorderEntry(it.id, it.name, it.logo) }
        if (entries.size < 2 || entries.none { it.id == item.id }) return
        GrabReorderDialog(this, entries, item.id) { ids, index ->
            Repo.setOrder("$expectedTab|$expectedCategory", ids)
            if (!isFinishing && tab == expectedTab && cat == expectedCategory) {
                focusPos = index; refresh(); restoreFocus(index)
            }
        }.show()
    }

    private fun grabCategory(category: Cat) {
        cancelCategoryPreview()
        categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
        val expectedTab = tab
        val entries = cats.filter { !it.header && ownCategory(it) && it.key.isNotEmpty() && it.key != "fav" && it.key != "recent" && !it.key.startsWith("lock:") && !it.key.startsWith("k:") }
            .map { ReorderEntry(it.key, it.label) }
        if (entries.size < 2 || entries.none { it.id == category.key }) return
        GrabReorderDialog(this, entries, category.key) { ids, _ ->
            Repo.setOrder("cat|$expectedTab", ids)
            if (!isFinishing && tab == expectedTab) {
                sideFocusKey = category.key; refresh(); sideRv?.post { focusSide() }
            }
        }.show()
    }

    /** Moves a channel / movie / series inside the list that is on screen (first 500 entries). */
    private fun moveItem(i: Item, how: String) {
        val ids = ArrayList(fullList.map { it.id })
        var idx = ids.indexOf(i.id)
        if (idx < 0) { ids.add(0, i.id); idx = 0 }
        when (how) {
            "up" -> if (idx > 0) { java.util.Collections.swap(ids, idx, idx - 1); idx-- }
            "down" -> if (idx < ids.size - 1) { java.util.Collections.swap(ids, idx, idx + 1); idx++ }
            "top" -> { ids.removeAt(idx); ids.add(0, i.id); idx = 0 }
            else -> if (how.startsWith("pos:")) {
                val n = (how.removePrefix("pos:").toIntOrNull() ?: 1).coerceIn(1, ids.size)
                ids.removeAt(idx); ids.add(n - 1, i.id); idx = n - 1
            } else { ids.removeAt(idx); ids.add(i.id); idx = ids.size - 1 }
        }
        Repo.setOrder(tab + "|" + cat, ids)
        focusPos = idx
        refresh()
    }

    private fun moveCat(key: String, how: String) {
        val names = ArrayList(cats.filter { !it.header && ownCategory(it) && it.key.isNotEmpty() && it.key != "fav" && it.key != "recent" && !it.key.startsWith("lock:") && !it.key.startsWith("k:") }.map { it.key })
        var idx = names.indexOf(key)
        if (idx < 0) return
        when (how) {
            "up" -> if (idx > 0) { java.util.Collections.swap(names, idx, idx - 1); idx-- }
            "down" -> if (idx < names.size - 1) { java.util.Collections.swap(names, idx, idx + 1); idx++ }
            "top" -> { names.removeAt(idx); names.add(0, key); idx = 0 }
            else -> { names.removeAt(idx); names.add(key); idx = names.size - 1 }
        }
        Repo.setOrder("cat|$tab", names)
        sideFocusKey = key
        refresh()
    }

    /** Hold OK on a category: move, rename, hide, lock. */
    private fun catMenu(ct: Cat) {
        if (ct.header || !ownCategory(ct)) return
        if (tab == "home" || tab == "list" || ct.key.isEmpty() || ct.key == "fav" || ct.key == "recent" || ct.key.startsWith("lock:") || ct.key.startsWith("k:")) return
        val now = System.currentTimeMillis()
        if (now - lastMenu < 800) return
        lastMenu = now
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.grab_move)); acts.add { grabCategory(ct) }
        labels.add(getString(R.string.move_up)); acts.add { moveCat(ct.key, "up") }
        labels.add(getString(R.string.move_down)); acts.add { moveCat(ct.key, "down") }
        labels.add(getString(R.string.move_top)); acts.add { moveCat(ct.key, "top") }
        labels.add(getString(R.string.move_bottom)); acts.add { moveCat(ct.key, "bottom") }
        labels.add(getString(R.string.rename)); acts.add {
            askText(R.string.rename, getString(R.string.rename), ct.key) { n ->
                if (n.isNotBlank() && n != ct.key) { if (cat == ct.key) cat = n; sideFocusKey = n; val kind = tab; editCatalogue { Repo.renameCat(kind, ct.key, n) } }
            }
        }
        labels.add(getString(R.string.hide)); acts.add {
            val hc = Repo.hiddenCats(tab); hc.add(ct.key); Repo.setHiddenCats(tab, hc)
            if (cat == ct.key) cat = ""
            updateCounts(); refresh()
        }
        val locked = Repo.lockedCats(tab).contains(ct.key)
        labels.add(getString(if (locked) R.string.unlock_cat else R.string.lock_cat)); acts.add { lockCat(ct.key, locked) }
        if (Repo.hasCatRename(tab, ct.key)) { labels.add(getString(R.string.reset_cat)); acts.add { if (cat == ct.key) cat = ""; val kind = tab; editCatalogue { Repo.renameCat(kind, ct.key, "") } } }
        ModernDialogs.options(this, ct.label, labels, acts)
    }

    private fun lockCat(name: String, locked: Boolean) {
        if (!Repo.hasPin()) { Toast.makeText(this, R.string.pin_first, Toast.LENGTH_LONG).show(); return }
        val doIt = {
            val lc = Repo.lockedCats(tab)
            if (locked) lc.remove(name) else { lc.add(name); Repo.unlocked.remove(tab + "|" + name); if (cat == name) cat = "" }
            Repo.setLockedCats(tab, lc); updateCounts(); refresh()
        }
        if (locked) askPin(R.string.pin_enter) { doIt() } else doIt()
    }

    private fun askText(title: Int, hint: String, init: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { this.hint = hint; setText(init); setSingleLine(true); setSelection(text.length) }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton(R.string.save) { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton(R.string.no, null).show()
    }

    private fun refreshEditedCatalogue() {
        updateCounts()
        refresh()
    }

    private fun editCatalogue(edit: () -> Unit) {
        Repo.catalogueEdits.submit {
            edit()
            runOnUiThread {
                if (isFinishing || isDestroyed || !started || switchingPlaylist) return@runOnUiThread
                refreshEditedCatalogue()
            }
        }
    }

    private fun renameDlg(i: Item) {
        askText(R.string.rename, getString(R.string.rename), i.name) { n ->
            editCatalogue { Repo.setOvr(i.id, if (n == i.name) null else n, null) }
        }
    }

    private fun moveDlg(i: Item) {
        val list = Repo.categories(i.kind)
        val labels = ArrayList<String>(); labels.add("+  " + getString(R.string.new_cat)); labels.addAll(list)
        AlertDialog.Builder(this).setTitle(R.string.move).setItems(labels.toTypedArray()) { _, w ->
            if (w == 0) askText(R.string.new_cat, getString(R.string.cat_name), "") { n ->
                if (n.isNotEmpty()) { editCatalogue { Repo.setOvr(i.id, null, n) } }
            } else { editCatalogue { Repo.setOvr(i.id, null, list[w - 1]) } }
        }.show()
    }

    private fun paintRow(v: A.VH, f: Boolean) {
        val c = v.itemView.context; val i = v.cur
        val bgc = if (v.row) (if (i != null && i.id == previewId) ((Th.acc and 0xFFFFFF) or (0x99 shl 24)) else Th.card) else col("#00000000")
        v.itemView.background = if (uiStyle == "aurora") c.auroraGlass(f, 12) else if (uiStyle in listOf("studio", "cinema") || wide && v.row) ReferenceLook.selection(c, i != null && i.id == previewId, f) else Th.shape(c, bgc, f, 16)
        if (!v.row) scaleFx(v.itemView, f)
    }

    private fun scaleFx(v: View, f: Boolean) {
        if (!Repo.b("focusFx", true) || Repo.s("anim", "fade") == "none") return
        v.animate().scaleX(if (f) 1.06f else 1f).scaleY(if (f) 1.06f else 1f).setDuration(120).start()
        v.translationZ = if (f) 12f else 0f
    }

    /** progress (0-100) and the "S1E5" label of what was watched last for a movie / series. */
    private fun progressOf(i: Item): Pair<Int, String> {
        if (i.kind == "series") {
            val lu = Repo.s("le:" + i.id)
            return if (lu.isEmpty()) Pair(0, "") else Pair(maxOf(1, Repo.pct(lu)), Repo.s("lt:" + i.id))
        }
        return Pair(Repo.pct(i.url), "")
    }

    private fun buildCont(base: List<Item>): List<Item> {
        val ids = Repo.recent().take(60)
        if (ids.isEmpty()) return emptyList()
        val set = ids.toHashSet(); val found = HashMap<String, Item>()
        for (i in base) { ListUpdates.checkCancelled(); if (i.id in set) found[i.id] = i }
        val out = ArrayList<Item>()
        for (id in ids) {
            val i = found[id] ?: continue
            val p = progressOf(i).first
            if ((i.kind == "series" && p >= 1) || (i.kind != "series" && p in 1..94)) out.add(i)
            if (out.size >= 15) break
        }
        return out
    }

    inner class C : RecyclerView.Adapter<C.VH>() {
        override fun onViewRecycled(holder: VH) { Img.clear(holder.img); super.onViewRecycled(holder) }
        inner class VH(v: View, val img: ImageView, val t: TextView, val bar: WatchBar, val badge: TextView) : RecyclerView.ViewHolder(v) { var cur: Item? = null }
        override fun getItemCount() = cont.size
        override fun onCreateViewHolder(p: ViewGroup, vt: Int): VH {
            val c = p.context
            val root = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(4)); isFocusable = true; isClickable = true
                layoutParams = RecyclerView.LayoutParams(c.dp(104), -2).apply { setMargins(c.dp(4), 0, c.dp(4), 0) }
            }
            val fl = FrameLayout(c)
            val img = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = Th.shape(c, col("#33000000"), false, 12); clipToOutline = true }
            fl.addView(img, FrameLayout.LayoutParams(-1, c.dp(116)))
            val badge = TextView(c).apply { setTextColor(Color.WHITE); textSize = 10f; setPadding(c.dp(5), c.dp(1), c.dp(5), c.dp(1)); background = Th.shape(c, col("#CC5B5BFF"), false, 8) }
            fl.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(c.dp(5), 0, 0, c.dp(5)) })
            root.addView(fl)
            val bar = WatchBar(c)
            root.addView(bar, LinearLayout.LayoutParams(-1, c.dp(4)).apply { topMargin = c.dp(4) })
            val t = TextView(c).apply { setTextColor(Th.fg); textSize = 11f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            root.addView(t)
            val vh = VH(root, img, t, bar, badge)
            root.background = Th.shape(c, col("#00000000"), false, 14)
            root.setOnFocusChangeListener { v, f -> v.background = Th.shape(c, col("#00000000"), f, 14); scaleFx(v, f) }
            root.setOnClickListener { vh.cur?.let { open(it) } }
            root.setOnKeyListener { _, kc, ev ->
                if (ev.action == KeyEvent.ACTION_DOWN && wide && kc == keyToSide() && vh.adapterPosition == 0) { focusSide(); true } else false
            }
            return vh
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val i = cont[pos]; h.cur = i
            Img.load(h.img, i.logo); h.t.text = i.name
            val pr = progressOf(i)
            h.bar.pct = pr.first; h.bar.invalidate()
            h.badge.text = if (pr.second.isNotEmpty()) "▶ " + pr.second else pr.first.toString() + "%"
        }
    }

    inner class S : RecyclerView.Adapter<S.VH>() {
        inner class VH(v: View, val l: TextView, val n: TextView) : RecyclerView.ViewHolder(v) { var longDone = false }
        override fun getItemCount() = cats.size
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val c = p.context
            val row = LinearLayout(c).apply {
                gravity = Gravity.CENTER_VERTICAL; layoutDirection = resources.configuration.layoutDirection
                setPadding(c.dp(if (wide && tab == "live") 12 else 16), c.dp(if (wide && tab == "live") 7 else 12), c.dp(if (wide && tab == "live") 12 else 16), c.dp(if (wide && tab == "live") 7 else 12))
                isFocusable = true; isClickable = true
                layoutParams = RecyclerView.LayoutParams(-1, if (wide && tab == "live") c.dp(40) else -2).apply { setMargins(0, c.dp(2), 0, c.dp(2)) }
            }
            val l = TextView(c).apply { textSize = if (wide) 14f else 16f; if (wide) typeface = ReferenceLook.font; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; if (uiStyle == "cinema" || reference) { textDirection = View.TEXT_DIRECTION_LOCALE; gravity = Gravity.START or Gravity.CENTER_VERTICAL } }
            val n = TextView(c).apply { textSize = if (wide && tab == "live") 11f else 13f; if (wide && tab == "live") typeface = ReferenceLook.font }
            row.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(n, LinearLayout.LayoutParams(-2, -2).apply { if (uiStyle == "cinema" || reference) marginStart = dp(10) })
            return VH(row, l, n)
        }
        fun paint(h: VH, category: Cat, focused: Boolean) {
            val selected = !category.header && ownCategory(category) && category.key == cat
            val context = h.itemView.context
            if (uiStyle == "aurora") {
                h.l.setTextColor(Th.fg)
                h.n.setTextColor(if (selected || focused) Th.acc else Th.mut)
                h.itemView.background = if (selected || focused) context.auroraGlass(true, 12) else context.auroraGlass(radius = 12)
                return
            }
            h.l.setTextColor(if (uiStyle == "studio") Color.WHITE else if (selected) (if (uiStyle == "cinema") Th.acc else if (reference) Th.fg else Th.bt) else Th.fg)
            h.n.setTextColor(if (uiStyle == "studio" && (selected || focused)) Color.WHITE else if (selected && uiStyle != "cinema" && !reference) Th.bt else Th.mut)
            h.itemView.background = if (uiStyle in listOf("cinema", "studio") || wide && tab == "live") ReferenceLook.selection(context, selected, focused)
                else Th.shape(context, if (selected) Th.acc else Color.TRANSPARENT, focused, 22)
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val ct = cats[pos]; val c = h.itemView.context
            val locked = ct.key.startsWith("lock:")
            h.itemView.contentDescription = if (ct.header) ct.label + ", " + getString(if (ct.n == 1) R.string.playlist_expanded else R.string.playlist_collapsed) else ct.label
            h.itemView.tag = if (ct.header) "playlist:${ct.playlist}" else "category:${ct.key}"
            h.l.text = (if (ct.playlist.isNotEmpty() && !ct.header) "    " else "") + ct.label; h.n.text = if (ct.header) { (if (ct.n == 1) "▾" else if (isRtl()) "◂" else "▸") + (if (ct.busy) " …" else "") } else if (locked || ct.n < 0) "" else ct.n.toString()
            h.n.compoundDrawablePadding = 0
            h.n.setCompoundDrawablesRelativeWithIntrinsicBounds(if (locked) Th.icon(c, R.drawable.ic_lock, Th.mut) else null, null, null, null)
            paint(h, ct, h.itemView.hasFocus())
            h.itemView.setOnFocusChangeListener { view, focused ->
                paint(h, ct, focused)
                if (focused) scheduleCategoryPreview(view, ct)
                else if (categoryPreviewView === view) cancelCategoryPreview()
            }
            h.itemView.setOnClickListener { enterCategory(ct) }
            h.itemView.setOnKeyListener { _, kc, ev ->
                if (ev.action == KeyEvent.ACTION_DOWN && kc in listOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN)) {
                    categoryEnterTask?.let { hd.removeCallbacks(it) }; categoryEnterTask = null
                }
                if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER) {
                    if (ev.action == KeyEvent.ACTION_DOWN) {
                        if (ev.repeatCount == 0) { h.longDone = false; false }
                        else { if (!h.longDone && ev.eventTime - ev.downTime >= 500) { h.longDone = true; catMenu(ct) }; true }
                    } else if (ev.action == KeyEvent.ACTION_UP && h.longDone) { h.longDone = false; true } else false
                } else if (ev.action == KeyEvent.ACTION_DOWN && kc == keyToMain()) {
                    if (!Repo.b("categoryPreviewOnFocus", false) && (ct.header || !ownCategory(ct) || cat != ct.key)) {
                        enterCategoryContent()
                        return@setOnKeyListener true
                    }
                    hideCategoriesOnEntry = referenceCategoryReveal() && !ct.header && !ct.key.startsWith("lock:")
                    if (hideCategoriesOnEntry) sideFocusKey = categoryIdentity(ct)
                    enterCategory(ct); true
                }
                else if (ev.action == KeyEvent.ACTION_DOWN && kc == keyToSide() && (reference || cinemaShell != null)) {
                    if (reference) referenceRail?.focusSelected() else cinemaShell?.focusSelected()
                    true
                } else false
            }
            h.itemView.setOnLongClickListener { catMenu(ct); true }
        }
    }

    inner class A : RecyclerView.Adapter<A.VH>() {
        override fun onViewRecycled(holder: VH) { Img.clear(holder.img); super.onViewRecycled(holder) }
        inner class VH(v: View, val img: ImageView, val t: TextView, val pb: WatchBar?, val badge: TextView?, val sub: TextView?, val epgV: EpgView?, val row: Boolean) : RecyclerView.ViewHolder(v) {
            var cur: Item? = null
            var longDone = false
        }

        override fun getItemCount() = data.size
        override fun getItemViewType(position: Int) = if (tab == "live") 1 else if (auroraMediaPanel()) 2 else 0

        override fun onCreateViewHolder(p: ViewGroup, vt: Int): VH {
            val c = p.context
            if (vt == 1) {
                val root = LinearLayout(c).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4)); isFocusable = true; isClickable = true
                    layoutParams = RecyclerView.LayoutParams(-1, c.dp(if (wide && uiStyle == "aurora") 64 else if (wide) 44 else if (liveStyle == "triple") 62 else if (liveStyle == "guide") 56 else if (wide) 50 else 64)).apply { setMargins(c.dp(4), c.dp(3), c.dp(4), c.dp(3)) }
                }
                val left = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
                val num = TextView(c).apply { setTextColor(Th.mut); textSize = 14f; gravity = Gravity.CENTER }
                left.addView(num, LinearLayout.LayoutParams(c.dp(if (wide) 30 else 40), -2))
                val img = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(col("#22888888")) }
                left.addView(img, LinearLayout.LayoutParams(c.dp(if (wide && uiStyle == "aurora") 64 else if (wide) 44 else 64), c.dp(if (wide && uiStyle == "aurora") 40 else if (wide) 30 else 44)).apply { marginEnd = c.dp(12) })
                val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
                val t = TextView(c).apply { setTextColor(Th.fg); textSize = if (wide) 14f else 16f; if (wide) typeface = ReferenceLook.font; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                val sub = TextView(c).apply { setTextColor(Th.mut); textSize = 12f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; visibility = if (epgRows()) View.GONE else View.VISIBLE }
                box.addView(t); box.addView(sub)
                left.addView(box, LinearLayout.LayoutParams(0, -2, 1f))
                root.addView(left, LinearLayout.LayoutParams(0, -2, if (wide) 10f else if (liveStyle == "guide") 6f else 9f))
                var ev: EpgView? = null
                if (epgRows()) {
                    ev = EpgView(c)
                    root.addView(ev, LinearLayout.LayoutParams(0, -1, if (wide) 12f else 13f))
                }
                val vh = VH(root, img, t, null, num, sub, ev, true)
                ev?.setOnFocusChangeListener { _, focused ->
                    paintRow(vh, root.hasFocus())
                    if (focused) { focusPos = vh.bindingAdapterPosition; vh.cur?.let { showHeader(it) } }
                }
                ev?.setOnClickListener { root.performClick() }
                ev?.setOnLongClickListener { root.performLongClick() }
                root.setOnFocusChangeListener { _, f -> paintRow(vh, f); if (f) { focusPos = vh.adapterPosition; vh.cur?.let { showHeader(it) } } }
                root.setOnKeyListener { _, kc, ev -> itemKey(vh, kc, ev) }
                return vh
            }
            val root = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.START
                setPadding(c.dp(6), c.dp(6), c.dp(6), c.dp(6)); isFocusable = true; isClickable = true
                layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(c.dp(4), c.dp(4), c.dp(4), c.dp(4)) }
            }
            val img = ImageView(c)
            val badge = TextView(c).apply { setTextColor(Color.WHITE); textSize = 11f }
            val t = TextView(c).apply { setTextColor(Th.fg); textSize = 12f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
            val pb = WatchBar(c).apply { visibility = View.GONE }
            val fl = if (vt == 2) object : FrameLayout(c) {
                override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                    val width = MeasureSpec.getSize(widthMeasureSpec)
                    super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(width * 3 / 2, MeasureSpec.EXACTLY))
                }
            } else FrameLayout(c)
            img.scaleType = if (vt != 2 && uiStyle in listOf("studio", "cinema")) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
            img.background = Th.shape(c, col("#33000000"), false, 14); img.clipToOutline = true
            fl.addView(img, FrameLayout.LayoutParams(-1, if (vt == 2) -1 else c.dp(190)))
            badge.setPadding(c.dp(6), c.dp(2), c.dp(6), c.dp(2)); badge.background = Th.shape(c, col("#CC5B5BFF"), false, 10)
            fl.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(c.dp(6), 0, 0, c.dp(6)) })
            root.addView(fl)
            root.addView(t, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
            root.addView(pb, LinearLayout.LayoutParams(-1, c.dp(5)))
            val vh = VH(root, img, t, pb, badge, null, null, false)
            root.setOnFocusChangeListener { _, f -> paintRow(vh, f); if (f) { focusPos = vh.adapterPosition; vh.cur?.let { showHeader(it) } } }
                root.setOnKeyListener { _, kc, ev -> itemKey(vh, kc, ev) }
            return vh
        }

        private fun bindLiveMarker(h: VH, i: Item) {
            h.t.text = i.name + (if (h.row && Repo.isFav(i.id)) "  ★" else "") +
                (if (h.row && i.kind == "live" && i.id == previewId && prev != null) "  ▶ تشاهد الآن" else "")
        }

        private fun bindLiveGuide(h: VH, i: Item) {
            if (epgRows()) h.epgV?.bind(Repo.progs(i), ws)
            else h.sub?.text = Repo.nowOn(i)?.title.orEmpty()
        }

        override fun onBindViewHolder(h: VH, pos: Int, payloads: MutableList<Any>) {
            val item = data[pos]
            if (!h.row || h.cur != item || payloads.isEmpty() ||
                payloads.any { it !== liveMarkerPayload && it !== liveGuidePayload }) {
                super.onBindViewHolder(h, pos, payloads)
                return
            }
            if (liveMarkerPayload in payloads) {
                bindLiveMarker(h, item)
                paintRow(h, h.itemView.hasFocus())
            }
            if (liveGuidePayload in payloads) bindLiveGuide(h, item)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val i = data[pos]; h.cur = i
            bindLiveMarker(h, i)
            Img.load(h.img, i.logo, if (uiStyle in listOf("studio", "cinema") && !h.row) 3 else 2)
            if (h.row) {
                h.badge?.text = (pos + 1).toString()
                bindLiveGuide(h, i)
            } else {
                var p = 0; var lab = ""
                if (i.kind == "series") {
                    val lu = Repo.s("le:" + i.id)
                    if (lu.isNotEmpty()) { p = Repo.pct(lu); lab = Repo.s("lt:" + i.id) }
                } else p = Repo.pct(i.url)
                val r = i.rate.toDoubleOrNull() ?: 0.0
                val bt = when {
                    lab.isNotEmpty() -> "▶ " + lab + (if (p > 0) "  $p%" else "")
                    p >= 95 -> "✓"
                    p > 0 -> (if (r > 0) "★ " + fmt(r) + "  " else "") + "$p%"
                    r > 0 -> "★ " + fmt(r)
                    else -> ""
                }
                val playingPreview = i.kind == "live" && i.id == previewId && prev != null
                h.badge?.visibility = if (bt.isEmpty() && !playingPreview) View.GONE else View.VISIBLE
                h.badge?.text = if (playingPreview) "● تشاهد الآن" else bt
                h.pb?.visibility = if (p > 0) View.VISIBLE else View.GONE; h.pb?.pct = p; h.pb?.invalidate()
            }
            paintRow(h, false)
            h.itemView.setOnClickListener click@ {
                if (filtering) return@click
                if (i.kind == "live" && wide && tab == "live" && liveStyle != "guide" && (prev != null || previewId != i.id || pendingPreview != null)) selectPreview(i)
                else open(i)
            }
            h.itemView.setOnLongClickListener { menu(i); true }
        }
    }
}
