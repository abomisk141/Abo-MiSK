package com.sultv.app

import android.content.Context
import android.view.View

internal object HomePreferences {
    val rows = listOf("live", "movie", "series", "recent", "list", "matches")
    val sources = listOf("auto", "movie", "series", "live", "list", "matches", "continueSeries", "none")
    fun key(style: String, name: String) = "home:$style:$name"
    fun railMode(style: String) = Repo.s(key(style, "railMode"), "default")
    fun overlayRail(style: String) = style in listOf("studio", "cinema", "spotlight", "aurora") || railMode(style) != "default"

    fun custom(style: String) = Repo.b(key(style, "custom"), false)
    fun rows(style: String) = Repo.s(key(style, "rows"), rows.joinToString(","))
        .split(',').filter { it in rows }.distinct()

    fun bannerCount(style: String) = Repo.s(key(style, "bannerCount"), "1").toIntOrNull()?.coerceIn(1, 3) ?: 1
    fun bannerKey(style: String, index: Int, field: String) = key(style, if (index == 0) field else "$field${index + 1}")
    fun bannerSource(style: String, index: Int): String = Repo.s(bannerKey(style, index, "banner"),
        if (index == 1) "matches" else if (index == 2) "series" else "auto")
    fun bannerHeight(style: String, index: Int, normal: Int): Int =
        when (Repo.s(bannerKey(style, index, "bannerSize"), "auto")) {
            "small" -> (normal * .75f).toInt().coerceIn(110, 180)
            "large" -> 350
            else -> normal
        }
    fun seriesView(style: String) = Repo.s(key(style, "seriesView"), "modern")
    fun shortcutPosition(style: String) = Repo.s(key(style, "shortcuts"), if (style == "gunners") "beside" else "below")

    fun shortcutArtwork(style: String, section: String): Int = when (style) {
        "gunners" -> when (section) {
            "live" -> R.drawable.home_gunners_live
            "movie" -> R.drawable.home_gunners_movie
            else -> R.drawable.home_gunners_series
        }
        "spotlight" -> when (section) {
            "live" -> R.drawable.home_spotlight_live
            "movie" -> R.drawable.home_spotlight_movie
            else -> R.drawable.home_spotlight_series
        }
        else -> when (section) {
            "live" -> R.drawable.home_cinema_live
            "movie" -> R.drawable.home_cinema_movie
            else -> R.drawable.home_cinema_series
        }
    }

    private val channelName = Regex("""\b(?:beIN|V[ .-]*SPORT)\b""", RegexOption.IGNORE_CASE)

    fun canResume(item: Item): Boolean {
        if (item.kind == "series") return true
        if (item.kind != "movie" || item.epg.isNotBlank()) return false
        val path = item.u.substringBefore('?').substringBefore('#').lowercase(java.util.Locale.ROOT)
        val extension = item.ext.lowercase(java.util.Locale.ROOT)
        return "/live/" !in path && extension !in setOf("ts", "m3u8") &&
            !path.endsWith(".ts") && !path.endsWith(".m3u8") &&
            (item.year.isNotBlank() || !channelName.containsMatchIn(item.name))
    }

    fun matches(fixtures: List<GunnersMatch>, leagueIds: Set<Int>, team: String) =
        GunnersData.filter(fixtures, leagueIds, team)

    fun label(context: Context, id: String): String = when (id) {
        "live" -> context.getString(R.string.live)
        "movie" -> context.getString(R.string.movies)
        "series" -> context.getString(R.string.series)
        "recent" -> context.getString(R.string.cont_watch)
        "list" -> context.getString(R.string.my_list)
        "continueSeries" -> text(context, "أكمل مشاهدة المسلسلات", "Continue watching series")
        "matches" -> context.getString(R.string.gunners_today)
        "none" -> context.getString(R.string.off)
        else -> text(context, "تلقائي", "Automatic")
    }

    fun text(context: Context, arabic: String, english: String) =
        if (context.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL) arabic else english
}
