package com.sultv.app

import android.content.Context
import android.content.SharedPreferences
import android.util.JsonReader
import android.util.JsonToken
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.GZIPInputStream

data class Item(
    val id: String, val name: String, val logo: String, val grp: String, val kind: String,
    val u: String = "", val sid: String = "", val show: String = "", val ep: String = "", val rate: String = "",
    val epg: String = "", val year: String = "", val dur: String = "", val ext: String = ""
) {
    val epgKey = epg.lowercase()
    val url: String get() = if (u.isNotEmpty() || ext.isEmpty()) u else Repo.xurl(this)
    override fun toString() = name
}

data class AudioChannel(val item: Item, val playlistId: String, val playlistName: String)

data class Info(val plot: String, val cast: String, val genre: String, val rating: String, val year: String, val back: String = "", val tmdb: String = "")
data class Prog(val start: Long, val stop: Long, val title: String, val desc: String = "")
data class Playlist(val id: String, val name: String, val mode: String, val m3u: String, val xs: String, val xu: String, val xp: String, val live: Boolean = true, val vod: Boolean = true)

object Repo {
    val info = java.util.concurrent.ConcurrentHashMap<String, Info>()
    lateinit var sp: SharedPreferences
    private lateinit var app: Context
    @Volatile var items: List<Item> = emptyList()
    @Volatile private var rawItems: List<Item> = emptyList()
    private val ovr = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()
    private val catRen = java.util.concurrent.ConcurrentHashMap<String, String>()
    var updChecked = false
    @Volatile var shows: List<Item> = emptyList()
    @Volatile private var byKind: Map<String, List<Item>> = emptyMap()
    @Volatile private var byCategory: Map<String, Map<String, List<Item>>> = emptyMap()
    val eps = java.util.concurrent.ConcurrentHashMap<String, List<Item>>()
    @Volatile var catalogueVersion = 0; private set
    var dirty = true
    var zap: List<Item> = emptyList()
    var splashShown = false
    val unlocked = HashSet<String>()
    var settingsOk = false
    var epQueue: List<Item> = emptyList()
    var resumed = false
    private var m3uEpg = ""
    private val downloadedEpg = ThreadLocal<String>()
    @Volatile var epg: Map<String, List<Prog>> = emptyMap()
    @Volatile var epgState = 0
    var onEpg: (() -> Unit)? = null
    var onStage: ((String) -> Unit)? = null
    @Volatile var err = ""
    @Volatile private var cp: Playlist? = null

    private val reGrp = Regex("group-title=\"([^\"]*)\"")
    private val reLogo = Regex("tvg-logo=\"([^\"]*)\"")
    private val reTid = Regex("tvg-id=\"([^\"]*)\"")
    private val reTvg = Regex("(?:url-tvg|x-tvg-url)=\"([^\"]*)\"", RegexOption.IGNORE_CASE)
    private val reSeriesUrl = Regex("/series/", RegexOption.IGNORE_CASE)
    private val reSE = Regex("S\\d+\\s*E\\d+", RegexOption.IGNORE_CASE)
    private val reSeriesGrp = Regex("مسلسل|series", RegexOption.IGNORE_CASE)
    private val reMovieUrl = Regex("/movie/", RegexOption.IGNORE_CASE)
    private val reMovieGrp = Regex("فيلم|فلم|أفلام|افلام|movie|vod", RegexOption.IGNORE_CASE)
    private val reEp = Regex("^(.*?)\\s*[-_ ]*S(\\d+)\\s*E(\\d+)", RegexOption.IGNORE_CASE)
    private val tf = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)

    fun init(c: Context) {
        val context = c.applicationContext
        if (!::sp.isInitialized || !::app.isInitialized || app !== context) {
            app = context
            sp = app.getSharedPreferences("sul", 0)
            migrate()
        }
    }

    private fun migrate() {
        if (sp.getString("pls", null) == null && (s("m3u").isNotBlank() || s("xs").isNotBlank())) {
            val p = Playlist("p1", "Playlist 1", if (s("mode") == "xt") "xt" else "m3u", s("m3u"), s("xs"), s("xu"), s("xp"))
            savePlaylists(listOf(p)); put("act", "p1")
        }
    }

    fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun b(k: String, d: Boolean): Boolean = s(k, if (d) "1" else "0") == "1"
    fun putB(k: String, v: Boolean) = put(k, if (v) "1" else "0")

    /** Rebuild from restored accounts rather than retaining the previous device's catalogue. */
    @Synchronized fun afterBackupRestore() {
        catalogueVersion++
        playlists().forEach { invalidate(it) }
        cp = null; items = emptyList(); rawItems = emptyList(); shows = emptyList(); byKind = emptyMap(); byCategory = emptyMap()
        info.clear(); eps.clear(); ovr.clear(); catRen.clear()
        epg = emptyMap(); epgState = 0; m3uEpg = ""; zap = emptyList(); epQueue = emptyList()
        unlocked.clear(); settingsOk = false; resumed = false; dirty = true
    }

    // ---------- playlists ----------
    fun playlists(): List<Playlist> {
        val out = ArrayList<Playlist>()
        try {
            val a = JSONArray(s("pls", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Playlist(o.optString("id"), o.optString("name"), o.optString("mode"), o.optString("m3u"), o.optString("xs"), o.optString("xu"), o.optString("xp"), o.optBoolean("live", true), o.optBoolean("vod", true)))
            }
        } catch (e: Exception) { }
        return out
    }

    fun savePlaylists(l: List<Playlist>) {
        val a = JSONArray()
        for (p in l) a.put(JSONObject().put("id", p.id).put("name", p.name).put("mode", p.mode).put("m3u", p.m3u).put("xs", p.xs).put("xu", p.xu).put("xp", p.xp).put("live", p.live).put("vod", p.vod))
        put("pls", a.toString())
    }

    fun active(): Playlist? { val l = playlists(); return l.firstOrNull { it.id == s("act") } ?: l.firstOrNull() }

    fun isPlaylistVisible(id: String) = b("playlistVisible:$id", true)
    fun visiblePlaylists(): List<Playlist> = playlists().filter { isPlaylistVisible(it.id) }
    fun groupedPlaylists(): Boolean = visiblePlaylists().size > 1
    fun playlistVisibilitySignature() = playlists().joinToString("|") { it.id + ":" + isPlaylistVisible(it.id) }
    fun setPlaylistVisible(id: String, visible: Boolean) {
        require(playlists().any { it.id == id })
        putB("playlistVisible:$id", visible)
        putB("playlistVisibilityManaged", true)
        val current = active()
        if (current != null && !isPlaylistVisible(current.id)) {
            visiblePlaylists().firstOrNull()?.let { next ->
                put("act", next.id)
                dirty = true
            }
        }
    }
    /** Hiding never erases saved media. Do not display a previous account during a failed switch. */
    private fun contentVisible(): Boolean = !b("playlistVisibilityManaged", false) ||
        (cp?.id == active()?.id && cp?.id?.let(::isPlaylistVisible) == true)

    fun configured(): Boolean {
        val p = active() ?: return false
        return if (p.mode == "xt") p.xs.isNotBlank() && p.xu.isNotBlank() && p.xp.isNotBlank() else p.m3u.isNotBlank()
    }

    // ---------- favorites / hidden / recent ----------
    fun find(id: String): Item? = shows.firstOrNull { it.id == id } ?: items.firstOrNull { it.id == id }
    fun favs(): MutableSet<String> = HashSet(sp.getStringSet("fav", emptySet()) ?: emptySet())
    fun isFav(id: String) = sp.getStringSet("fav", null)?.contains(id) == true
    fun toggleFav(id: String): Boolean {
        val favourites = favs()
        val on = favourites.add(id)
        if (!on) favourites.remove(id)
        val edit = sp.edit().putStringSet("fav", favourites)
        val sourceKey = "favSource:$id"
        if (!on) edit.remove(sourceKey)
        else active()?.let { edit.putString(sourceKey, it.id) }
        edit.apply()
        return on
    }
    fun recent(): List<String> = s("rw").split("\n").filter { it.isNotEmpty() }
    fun touch(id: String) { val l = ArrayList(recent()); l.remove(id); l.add(0, id); put("rw", l.take(60).joinToString("\n")) }
    fun clearRecent() = put("rw", "")
    fun searchItems(): List<Item> = if (contentVisible()) items else emptyList()
    fun favItems(): List<Item> {
        if (!contentVisible()) return emptyList()
        val f = favs(); if (f.isEmpty()) return emptyList(); val h = hidden()
        return (shows.asSequence() + items.asSequence().filter { it.kind != "series" }).filter { it.id in f && it.id !in h && !isLocked(it) }.toList()
    }

    fun hidden(): MutableSet<String> = HashSet(sp.getStringSet("hid", emptySet()) ?: emptySet())
    fun hide(id: String) { val h = hidden(); h.add(id); sp.edit().putStringSet("hid", h).apply() }
    fun showAllCategory(kind: String): Boolean = b("showAllCategory:$kind", true)
    fun clearHidden() {
        val edit = sp.edit().putStringSet("hid", emptySet())
        for (kind in listOf("live", "movie", "series")) {
            edit.putStringSet("hc_$kind", emptySet())
            edit.remove("showAllCategory:$kind")
        }
        edit.apply()
    }
    fun hiddenCats(kind: String): MutableSet<String> = HashSet(sp.getStringSet("hc_$kind", emptySet()) ?: emptySet())
    fun setHiddenCats(kind: String, v: Set<String>) { sp.edit().putStringSet("hc_$kind", HashSet(v)).apply() }

    // ---------- parental control ----------
    fun hasPin() = s("pinh").isNotEmpty()
    private fun hashPin(v: String): String = java.security.MessageDigest.getInstance("SHA-256").digest(v.toByteArray()).joinToString("") { "%02x".format(it) }
    fun setPin(p: String) { val salt = java.util.UUID.randomUUID().toString(); put("pins", salt); put("pinh", hashPin(salt + p)) }
    fun checkPin(p: String): Boolean = hasPin() && hashPin(s("pins") + p) == s("pinh")
    fun clearPin() { put("pinh", ""); put("pins", ""); unlocked.clear(); settingsOk = false }
    fun lockedCats(kind: String): MutableSet<String> = HashSet(sp.getStringSet("lc_$kind", emptySet()) ?: emptySet())
    fun setLockedCats(kind: String, v: Set<String>) { sp.edit().putStringSet("lc_$kind", HashSet(v)).apply() }
    /** Locked categories that are still locked in this session. */
    fun lockedNow(kind: String): Set<String> =
        if (!hasPin()) emptySet() else lockedCats(kind).filter { "$kind|$it" !in unlocked }.toSet()
    fun unlock(kind: String, g: String) { unlocked.add("$kind|$g") }
    fun isLocked(i: Item): Boolean = hasPin() && i.grp in lockedCats(i.kind) && "${i.kind}|${i.grp}" !in unlocked

    private fun base(kind: String): List<Item> = if (kind == "series") shows else (byKind[kind] ?: emptyList())
    fun categories(kind: String): List<String> = byCategory[kind].orEmpty().keys.filter { it.isNotBlank() }
    fun hasCategory(kind: String, group: String) = byCategory[kind]?.containsKey(group) == true
    fun list(kind: String): List<Item> = visibleItems(kind, base(kind))
    fun list(kind: String, group: String): List<Item> = visibleItems(kind, byCategory[kind]?.get(group).orEmpty())
    private fun visibleItems(kind: String, source: List<Item>): List<Item> {
        ListUpdates.checkCancelled()
        if (!contentVisible()) return emptyList()
        val h = hidden(); val hc = hiddenCats(kind); val lk = lockedNow(kind)
        return if (h.isEmpty() && hc.isEmpty() && lk.isEmpty()) source else source.filter {
            ListUpdates.checkCancelled()
            it.id !in h && it.grp !in hc && it.grp !in lk
        }
    }

    // ---------- rename / move (stored by item id, original data stays untouched) ----------
    private fun loadOvr() {
        ovr.clear(); catRen.clear()
        try {
            val o = JSONObject(s("ovr", "{}"))
            for (k in o.keys()) { val x = o.getJSONObject(k); ovr[k] = Pair(x.optString("n"), x.optString("g")) }
        } catch (e: Exception) { }
        try {
            val o = JSONObject(s("catren", "{}"))
            for (k in o.keys()) catRen[k] = o.optString(k)
        } catch (e: Exception) { }
    }
    private fun saveCatRen() {
        val o = JSONObject()
        for ((k, v) in catRen) o.put(k, v)
        put("catren", o.toString())
    }
    private fun saveOvr() {
        val o = JSONObject()
        for ((k, v) in ovr) o.put(k, JSONObject().put("n", v.first).put("g", v.second))
        put("ovr", o.toString())
    }
    private fun ov(i: Item): Item {
        val o = ovr[i.id]; val cg = catRen[i.kind + "|" + i.grp]
        if (o == null && cg == null) return i
        var n = i.name; var g = i.grp
        if (cg != null) g = cg
        if (o != null) { if (o.first.isNotBlank()) n = o.first; if (o.second.isNotBlank()) g = o.second }
        return i.copy(name = n, grp = g)
    }
    val catalogueEdits = SerialWork()
    @Volatile var onNamesReset: (() -> Unit)? = null
    @Volatile var catalogueEditsRevision = 0; private set
    private fun reapply() {
        val started = android.os.SystemClock.elapsedRealtime()
        items = if (ovr.isEmpty() && catRen.isEmpty()) rawItems else rawItems.map { ov(it) }
        build()
        catalogueEditsRevision++
        val elapsed = android.os.SystemClock.elapsedRealtime() - started
        android.util.Log.i("AbomiskCatalogue", "Rebuilt catalogue of ${items.size} items in ${elapsed}ms")
    }
    fun hasOvr(id: String) = ovr.containsKey(id)
    /** name / grp: null = keep current value, "" = clear it */
    @Synchronized fun setOvr(id: String, name: String?, grp: String?) {
        val cur = ovr[id] ?: Pair("", "")
        val n = Pair(name ?: cur.first, grp ?: cur.second)
        if (n.first.isBlank() && n.second.isBlank()) ovr.remove(id) else ovr[id] = n
        saveOvr(); reapply()
    }
    @Synchronized fun clearOvr(id: String) { ovr.remove(id); saveOvr(); reapply() }
    @Synchronized fun clearAllOvr() { ovr.clear(); catRen.clear(); saveOvr(); saveCatRen(); reapply() }

    // ---------- category rename + custom order ----------
    fun hasCatRename(kind: String, shown: String): Boolean = catRen.any { it.key.startsWith("$kind|") && it.value == shown }

    /** newName blank = go back to the original name. `shown` is the name currently on screen. */
    @Synchronized fun renameCat(kind: String, shown: String, newName: String) {
        val orig = catRen.entries.firstOrNull { it.key.startsWith("$kind|") && it.value == shown }?.key?.substring(kind.length + 1) ?: shown
        val target = if (newName.isBlank() || newName == orig) orig else newName
        if (target == orig) catRen.remove("$kind|$orig") else catRen["$kind|$orig"] = target
        if (target != shown) {
            val hc = hiddenCats(kind); if (hc.remove(shown)) { hc.add(target); setHiddenCats(kind, hc) }
            val lc = lockedCats(kind); if (lc.remove(shown)) { lc.add(target); setLockedCats(kind, lc) }
            val co = order("cat|$kind")
            if (co.isNotEmpty()) setOrder("cat|$kind", co.map { if (it == shown) target else it })
            val old = order("$kind|$shown")
            if (old.isNotEmpty()) { setOrder("$kind|$target", old); setOrder("$kind|$shown", emptyList()) }
        }
        saveCatRen(); reapply()
    }

    fun order(scope: String): List<String> = s("ord:$scope").split("\n").filter { it.isNotEmpty() }
    fun setOrder(scope: String, ids: List<String>) = put("ord:$scope", ids.joinToString("\n"))
    fun clearOrders() {
        val e = sp.edit()
        for (k in sp.all.keys) if (k.startsWith("ord:")) e.remove(k)
        e.apply()
    }

    /** Puts the items the user moved first, in the order he chose; everything else keeps its normal order. */
    fun applyOrder(scope: String, l: List<Item>): List<Item> {
        val o = order(scope)
        if (o.isEmpty()) return l
        val pos = HashMap<String, Int>(o.size * 2)
        for ((i, id) in o.withIndex()) { ListUpdates.checkCancelled(); pos[id] = i }
        return l.sortedWith(Comparator { a, b ->
            ListUpdates.checkCancelled()
            (pos[a.id] ?: Int.MAX_VALUE).compareTo(pos[b.id] ?: Int.MAX_VALUE)
        })
    }

    // ---------- progress ----------
    /** progress (0-100) and the "S1E5" label of what was watched last for a movie / series. */
    fun progressOf(i: Item): Pair<Int, String> {
        if (i.kind == "series") {
            val lu = s("le:" + i.id)
            return if (lu.isEmpty()) Pair(0, "") else Pair(maxOf(1, pct(lu)), s("lt:" + i.id))
        }
        return Pair(pct(i.url), "")
    }

    fun saveProg(url: String, pos: Long, dur: Long) = sp.edit().putString("p:$url", "$pos|$dur").apply()
    fun prog(url: String): Pair<Long, Long>? {
        val p = sp.getString("p:$url", null)?.split("|") ?: return null
        return try { Pair(p[0].toLong(), p[1].toLong()) } catch (e: Exception) { null }
    }
    fun pct(url: String): Int {
        val p = prog(url) ?: return 0
        return if (p.second > 0) minOf(100, (p.first * 100 / p.second).toInt()) else 0
    }

    // ---------- network ----------
    fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 25000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", RequestIdentity.userAgent())
        NetworkWork.track(c)
        return try { c.inputStream.bufferedReader().use { it.readText() } } finally { NetworkWork.finish(c) }
    }

    fun xurl(i: Item): String = cp?.let { playlistUrl(i, it) } ?: ""
    fun playlistUrl(i: Item, p: Playlist): String {
        if (i.u.isNotEmpty() || i.ext.isEmpty()) return i.u
        val extension = if (i.kind == "live") PlaybackPolicy.xtreamLiveExtension() else i.ext
        return "${srv(p)}/${if (i.kind == "live") "live" else "movie"}/${p.xu}/${p.xp}/${i.id.substring(2)}.$extension"
    }

    // ---------- on-disk cache: the playlist is downloaded once, then read from the phone/TV storage ----------
    private const val CACHE_V = 3
    private fun sig(p: Playlist) = (p.mode + "|" + p.m3u + "|" + p.xs + "|" + p.xu + "|" + p.xp + "|" + p.live + "|" + p.vod).hashCode()
    private fun cacheFile(p: Playlist) = File(app.filesDir, "pl_" + p.id + ".bin")

    fun stat(id: String): List<String>? { val l = s("st:$id").split("|"); return if (l.size == 4) l else null }

    /** Forget the saved copy so the next load downloads the playlist again. */
    fun invalidate(p: Playlist) { try { android.util.AtomicFile(cacheFile(p)).delete() } catch (e: Exception) { }; put("st:" + p.id, "") }

    private fun categoryFile(p: Playlist) = File(app.filesDir, "pl_" + p.id + ".categories")

    private fun saveCategoryIndex(p: Playlist, entries: List<Item>) {
        val groups = HashMap<String, LinkedHashSet<String>>()
        for (item in entries) {
            if (item.grp.isNotBlank()) groups.getOrPut(item.kind) { linkedSetOf() }.add(item.grp.take(20000))
        }
        val cache = cacheFile(p)
        val file = android.util.AtomicFile(categoryFile(p))
        runCatching {
            val stream = file.startWrite()
            try {
                val output = DataOutputStream(BufferedOutputStream(stream))
                output.writeInt(sig(p))
                output.writeLong(cache.lastModified())
                output.writeLong(cache.length())
                for (kind in listOf("live", "movie", "series")) {
                    val names = groups[kind].orEmpty()
                    output.writeInt(names.size)
                    names.forEach { output.writeUTF(it) }
                }
                output.flush()
                file.finishWrite(stream)
            } catch (error: Exception) {
                file.failWrite(stream)
            }
        }
    }

    fun playlistCategoryNames(p: Playlist, kind: String): List<String>? {
        if (hidden().isNotEmpty()) return null
        val overrides = runCatching { JSONObject(s("ovr", "{}")) }.getOrNull() ?: return null
        if (overrides.keys().asSequence().any { overrides.optJSONObject(it)?.optString("g").orEmpty().isNotBlank() }) return null
        val renames = runCatching { JSONObject(s("catren", "{}")) }.getOrNull() ?: return null
        val cache = cacheFile(p)
        val file = categoryFile(p)
        return runCatching {
            DataInputStream(BufferedInputStream(file.inputStream())).use { input ->
                if (input.readInt() != sig(p) || input.readLong() != cache.lastModified() ||
                    input.readLong() != cache.length() || !cache.exists()) return null
                for (section in listOf("live", "movie", "series")) {
                    val count = input.readInt()
                    require(count in 0..1000000)
                    val names = List(count) { input.readUTF() }
                    if (section == kind) return names.map { renames.optString("$kind|$it", it) }.distinct()
                }
                null
            }
        }.getOrNull()
    }

    private fun writeCache(p: Playlist, l: List<Item>) {
            val atomic = android.util.AtomicFile(cacheFile(p))
            val stream = atomic.startWrite()
            try {
            val o = DataOutputStream(BufferedOutputStream(stream, 65536))
                o.writeInt(CACHE_V); o.writeInt(sig(p)); o.writeUTF(downloadedEpg.get() ?: m3uEpg); o.writeInt(l.size)
                for (i in l) {
                    if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
                    wr(o, i.id); wr(o, i.name); wr(o, i.logo); wr(o, i.grp); wr(o, i.kind); wr(o, i.u); wr(o, i.sid)
                    wr(o, i.show); wr(o, i.ep); wr(o, i.rate); wr(o, i.epg); wr(o, i.year); wr(o, i.dur); wr(o, i.ext)
                }
            o.flush(); atomic.finishWrite(stream)
            } catch (e: Exception) { atomic.failWrite(stream); throw e }
            saveCategoryIndex(p, l)
    }
    private fun wr(o: DataOutputStream, v: String) { o.writeUTF(if (v.length > 20000) v.substring(0, 20000) else v) }

    private fun readCache(p: Playlist): List<Item>? {
        val f = cacheFile(p)
        if (!f.exists() && !File(f.path + ".bak").exists()) return null
        return try {
            DataInputStream(java.io.BufferedInputStream(android.util.AtomicFile(f).openRead(), 65536)).use { i ->
                if (i.readInt() != CACHE_V || i.readInt() != sig(p)) return null
                val guide = i.readUTF()
                if (downloadedEpg.get() != null) downloadedEpg.set(guide) else m3uEpg = guide
                val n = i.readInt()
                require(n in 0..1000000)
                val pool = HashMap<String, String>()
                val out = ArrayList<Item>(n)
                for (k in 0 until n) {
                    val id = i.readUTF(); val name = i.readUTF(); val logo = i.readUTF()
                    val grp = i.readUTF().let { x -> pool.getOrPut(x) { x } }; val kind = i.readUTF().let { x -> pool.getOrPut(x) { x } }
                    val u = i.readUTF(); val sid = i.readUTF(); val show = i.readUTF(); val ep = i.readUTF()
                    val rate = i.readUTF().let { x -> pool.getOrPut(x) { x } }; val epgId = i.readUTF()
                    val year = i.readUTF().let { x -> pool.getOrPut(x) { x } }; val dur = i.readUTF().let { x -> pool.getOrPut(x) { x } }
                    val ext = i.readUTF().let { x -> pool.getOrPut(x) { x } }
                    out.add(Item(id, name, logo, grp, kind, u, sid, show, ep, rate, epgId, year, dur, ext))
                }
                out
            }
        } catch (e: Throwable) { null }
    }

    /** Read another account without changing the active catalogue, guide or metadata. */
    @Synchronized fun playlistSnapshot(p: Playlist): List<Item>? {
        if (p == cp) return items
        downloadedEpg.set("")
        return try {
            var raw = readCache(p)
            if (raw == null) {
                if (!refreshCache(p)) return null
                downloadedEpg.set("")
                raw = readCache(p) ?: return null
            }
            if (!categoryFile(p).exists()) saveCategoryIndex(p, raw)
            val mapped = raw.map { ov(it) }
            val series = HashSet<String>()
            mapped.filter { it.kind != "series" || it.sid.isNotEmpty() || series.add(it.show.ifBlank { it.name }) }
        } finally { downloadedEpg.remove() }
    }

    /** Resolve another playlist's audio URLs without changing the video's active account. */
    @Synchronized fun audioChannels(p: Playlist, cachedOnly: Boolean = false): List<AudioChannel>? {
        if (!p.live || !isPlaylistVisible(p.id)) return emptyList()
        val snapshot = (if (cachedOnly) {
            if (p == cp) items else readCache(p)?.map(::ov)
        } else playlistSnapshot(p)) ?: return null
        val hidden = hidden(); val groups = hiddenCats("live"); val locked = lockedNow("live")
        return snapshot.asSequence().filter { it.kind == "live" && it.id !in hidden && it.grp !in groups && it.grp !in locked }
            .map { AudioChannel(it.copy(u = playlistUrl(it, p)), p.id, p.name) }.toList()
    }

    fun cachedLiveFavourites(excludePlaylist: String?, favouriteIds: Set<String>): List<Item> {
        if (favouriteIds.isEmpty()) return emptyList()
        val known = visiblePlaylists().flatMap { playlist ->
            audioChannels(playlist, cachedOnly = true).orEmpty().filter { it.item.id in favouriteIds }
        }
        return known.groupBy { it.item.id }.values.flatMap { candidates ->
            val saved = s("favSource:" + candidates.first().item.id)
            when {
                saved.isNotBlank() -> candidates.filter { it.playlistId == saved }
                candidates.size == 1 -> candidates
                else -> emptyList()
            }
        }.filter { it.playlistId != excludePlaylist && it.item.url.isNotBlank() }.map { it.item }
    }

    /** force = download again; pl = load a playlist that is not saved yet (add-playlist wizard). */
    @Synchronized fun load(force: Boolean = false, pl: Playlist? = null): Boolean {
        err = ""
        var stage = "Download"
        val oldEpg = m3uEpg
        downloadedEpg.set("")
        return try {
            val p = pl ?: active() ?: return false
            var raw: List<Item>? = if (force) null else readCache(p)
            var fresh = false
            if (raw == null) {
                val l = if (p.mode == "xt") loadX(p) else loadM3u(p.m3u)
                raw = l.filter { (it.kind == "live" && p.live) || (it.kind != "live" && p.vod) }
                fresh = true
            }
            val list: List<Item> = raw
            if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
            if (list.isEmpty()) throw java.io.IOException("Empty playlist")
            if (list.any { it.id.isBlank() || it.name.isBlank() }) throw java.io.IOException("Invalid playlist entries")
            // Stage and persist the complete replacement before publishing any new catalogue.
            if (fresh) { stage = "Save to storage"; writeCache(p, list) }
            else if (!categoryFile(p).exists()) saveCategoryIndex(p, list)
            stage = "Index library"
            if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
            if (cp != p) info.clear()
            catalogueVersion++
            cp = p; m3uEpg = downloadedEpg.get().orEmpty(); epg = emptyMap(); epgState = 0
            rawItems = list; loadOvr()
            items = if (ovr.isEmpty() && catRen.isEmpty()) list else list.map { ov(it) }
            build()
            if (fresh && list.isNotEmpty()) {
                put("st:" + p.id, "${byKind["live"]?.size ?: 0}|${byKind["movie"]?.size ?: 0}|${shows.size}|${System.currentTimeMillis()}")
            }
            if (items.isEmpty() && err.isEmpty()) err = "Empty playlist"
            items.isNotEmpty()
        } catch (e: Throwable) {
            m3uEpg = oldEpg
            val causes = generateSequence(e) { it.cause }.take(8).toList()
            val known = setOf("Invalid catalogue response", "Empty playlist", "Invalid playlist entries", "Invalid channels", "Invalid movies", "Invalid series", "Live catalogue failed", "Movie catalogue failed", "Series catalogue failed", "get_live_categories", "get_vod_categories", "get_series_categories")
            val details = causes.mapNotNull { it.message?.takeIf(known::contains) }.distinct()
            err = (listOf(stage) + details + causes.last().javaClass.simpleName).joinToString(" · ")
            false
        } finally { downloadedEpg.remove() }
    }

    /** Commit account and catalogue together, including when the selecting screen is stopped. */
    @Synchronized fun selectPlaylist(p: Playlist): Boolean {
        if (!isPlaylistVisible(p.id) || !load(pl = p)) return false
        if (!isPlaylistVisible(p.id)) { dirty = true; return false }
        put("act", p.id)
        dirty = true
        return true
    }

    /** Refresh only the disk snapshot; keep the active player and visible list untouched.
     * The new snapshot is applied on the next normal playlist load. */
    fun refreshCacheInBackground(playlist: Playlist? = active()): Boolean =
        if (playlist == null) false else SingleFlight.run("refresh" to playlist) { refreshCache(playlist) }

    @Synchronized private fun refreshCache(playlist: Playlist): Boolean {
        val p = playlist ?: return false
        val oldEpg = m3uEpg
        downloadedEpg.set("")
        return try {
            val downloaded = if (p.mode == "xt") loadX(p) else loadM3u(p.m3u)
            val fresh = downloaded.filter { (it.kind == "live" && p.live) || (it.kind != "live" && p.vod) }
            if (fresh.isEmpty()) return false
            if (fresh.any { it.id.isBlank() || it.name.isBlank() }) return false
            writeCache(p, fresh)
            put("st:" + p.id, "${fresh.count { it.kind == "live" }}|${fresh.count { it.kind == "movie" }}|${fresh.count { it.kind == "series" }}|${System.currentTimeMillis()}")
            put("pl_last_refresh", System.currentTimeMillis().toString())
            true
        } catch (_: Exception) { false } finally { downloadedEpg.remove() }
    }

    private fun kindOf(name: String, grp: String, url: String): String = when {
        reSeriesUrl.containsMatchIn(url) || reSE.containsMatchIn(name) || reSeriesGrp.containsMatchIn(grp) -> "series"
        reMovieUrl.containsMatchIn(url) || reMovieGrp.containsMatchIn(grp) -> "movie"
        else -> "live"
    }

    private fun loadM3u(u: String): List<Item> {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 25000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", RequestIdentity.userAgent())
        NetworkWork.track(c)
        return try {
            c.inputStream.bufferedReader().use { parseM3u(it) }
        } finally {
            NetworkWork.finish(c)
        }
    }

    fun parseM3u(rd: BufferedReader): List<Item> {
        val out = ArrayList<Item>()
        var name = ""; var grp = ""; var logo = ""; var tid = ""; var has = false
        for (raw in rd.lineSequence()) {
            if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
            val l = raw.trim()
            if (l.startsWith("#EXTM3U")) {
                val m = reTvg.find(l); if (m != null) {
                    val guide = m.groupValues[1].substringBefore(',').trim()
                    if (downloadedEpg.get() != null) downloadedEpg.set(guide) else m3uEpg = guide
                }
            } else if (l.startsWith("#EXTINF")) {
                name = l.substringAfterLast(',').trim()
                grp = reGrp.find(l)?.groupValues?.get(1) ?: ""
                logo = reLogo.find(l)?.groupValues?.get(1) ?: ""
                tid = reTid.find(l)?.groupValues?.get(1) ?: ""
                has = true
            } else if (has && l.startsWith("http")) {
                val k = kindOf(name, grp, l)
                val m = reEp.find(name)
                out.add(Item(l, name, logo, grp, k, l, "", if (k == "series" && m != null) m.groupValues[1].trim() else "",
                    if (m != null) "S${m.groupValues[2]}E${m.groupValues[3]}" else "", "", tid))
                has = false
            }
        }
        return out
    }

    private fun JSONObject.str(k: String): String { val v = optString(k); return if (v == "null") "" else v }

    private fun srv(p: Playlist): String {
        var u = p.xs.trim().trimEnd('/')
        if (!u.startsWith("http")) u = "http://$u"
        return u
    }
    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")
    private fun api(p: Playlist, a: String) = "${srv(p)}/player_api.php?username=${enc(p.xu)}&password=${enc(p.xp)}&action=$a"

    private val want = hashSetOf("stream_id", "name", "stream_icon", "category_id", "category_name", "epg_channel_id", "container_extension",
        "rating", "year", "releaseDate", "release_date", "releasedate", "series_id", "cover")
    private val yearKeys = listOf("year", "releaseDate", "release_date", "releasedate")

    /** Streams a big JSON array item by item, so 100k+ entries never sit in memory as one string. */
    private fun stream(u: String, each: (HashMap<String, String>) -> Unit) {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 25000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", RequestIdentity.userAgent())
        NetworkWork.track(c)
        try { JsonReader(BufferedReader(InputStreamReader(c.inputStream, "UTF-8"), 65536)).use { r ->
            if (r.peek() != JsonToken.BEGIN_ARRAY) throw java.io.IOException("Invalid catalogue response")
            r.beginArray()
            while (r.hasNext()) {
                if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
                if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                val m = HashMap<String, String>(16)
                r.beginObject()
                while (r.hasNext()) {
                    val k = r.nextName()
                    val t = r.peek()
                    if (k in want && (t == JsonToken.STRING || t == JsonToken.NUMBER)) m[k] = r.nextString() else r.skipValue()
                }
                r.endObject()
                each(m)
            }
            r.endArray()
        }
        } finally { NetworkWork.finish(c) }
    }

    private fun cats(p: Playlist, a: String): Map<String, String> {
        val m = HashMap<String, String>()
        try { stream(api(p, a)) { o ->
            val id = o["category_id"]?.takeIf { it.isNotBlank() } ?: return@stream
            m[id] = o["category_name"] ?: ""
        } } catch (e: Exception) { throw java.io.IOException(a, e) }
        return m
    }

    private fun yr(o: Map<String, String>): String {
        for (k in yearKeys) { val v = o[k] ?: continue; if (v.length >= 4 && v.take(4).all { it.isDigit() }) return v.take(4) }
        return ""
    }

    private fun loadVodRows(p: Playlist, action: String, categories: Map<String, String>,
                            out: ArrayList<Item>, consume: (HashMap<String, String>) -> Unit) {
        val endpoint = api(p, action)
        val start = out.size
        try {
            stream(endpoint, consume)
            return
        } catch (failure: java.io.IOException) {
            if (Thread.currentThread().isInterrupted || categories.isEmpty()) throw failure
            // Discard any partially received rows before retrying by category.
            out.subList(start, out.size).clear()
        }
        val seen = HashSet<String>()
        val key = if (action == "get_series") "series_id" else "stream_id"
        for (category in categories.keys) {
            if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
            stream(endpoint + "&category_id=" + enc(category)) { row ->
                if (seen.add(row[key].orEmpty())) consume(row)
            }
        }
    }

    private fun loadX(p: Playlist): List<Item> {
        val out = ArrayList<Item>()
        if (p.live) onStage?.invoke("live")
        val lc = if (p.live) cats(p, "get_live_categories") else emptyMap()
        if (p.live) try {
            stream(api(p, "get_live_streams")) { o ->
                if (o["stream_id"].isNullOrBlank()) throw java.io.IOException("Invalid channels")
                out.add(Item(id = "xl" + (o["stream_id"] ?: ""), name = o["name"]?.takeIf { it.isNotBlank() } ?: o["stream_id"].orEmpty(), logo = o["stream_icon"] ?: "", grp = lc[o["category_id"] ?: ""] ?: "",
                    kind = "live", epg = o["epg_channel_id"] ?: "", ext = "m3u8"))
            }
        } catch (e: Exception) { throw java.io.IOException("Live catalogue failed", e) }
        if (p.vod) onStage?.invoke("movie")
        val vc = if (p.vod) cats(p, "get_vod_categories") else emptyMap()
        if (p.vod) try {
            loadVodRows(p, "get_vod_streams", vc, out) { o ->
                val id = o["stream_id"] ?: ""
                if (id.isBlank()) return@loadVodRows
                out.add(Item(id = "xm$id", name = o["name"]?.takeIf { it.isNotBlank() } ?: id, logo = o["stream_icon"] ?: "", grp = vc[o["category_id"] ?: ""] ?: "",
                    kind = "movie", sid = id, rate = o["rating"] ?: "", year = yr(o), ext = (o["container_extension"] ?: "").ifBlank { "mp4" }))
            }
        } catch (e: Exception) { throw java.io.IOException("Movie catalogue failed", e) }
        if (p.vod) onStage?.invoke("series")
        val sc = if (p.vod) cats(p, "get_series_categories") else emptyMap()
        if (p.vod) try {
            loadVodRows(p, "get_series", sc, out) { o ->
                val id = o["series_id"] ?: ""
                if (id.isBlank()) return@loadVodRows
                out.add(Item(id = "xs$id", name = o["name"]?.takeIf { it.isNotBlank() } ?: id, logo = o["cover"] ?: "", grp = sc[o["category_id"] ?: ""] ?: "",
                    kind = "series", sid = id, rate = o["rating"] ?: "", year = yr(o)))
            }
        } catch (e: Exception) { throw java.io.IOException("Series catalogue failed", e) }
        return out
    }

    private fun build() {
        eps.clear()
        val sh = ArrayList<Item>(); val groups = LinkedHashMap<String, MutableList<Item>>()
        val bk = HashMap<String, ArrayList<Item>>()
        for (i in items) {
            bk.getOrPut(i.kind) { ArrayList() }.add(i)
            if (i.kind == "series") {
                if (i.sid.isNotEmpty()) sh.add(i)
                else { val n = i.show.ifBlank { i.name }; groups.getOrPut(n) { ArrayList() }.add(i) }
            }
        }
        for ((n, l) in groups) { val id = "s:$n"; sh.add(ov(Item(id, n, l[0].logo, l[0].grp, "series"))); eps[id] = l }
        val categoryIndex = HashMap<String, Map<String, List<Item>>>()
        for ((kind, entries) in bk) {
            val buckets = LinkedHashMap<String, MutableList<Item>>()
            for (entry in if (kind == "series") sh else entries) buckets.getOrPut(entry.grp) { ArrayList() }.add(entry)
            categoryIndex[kind] = buckets
        }
        byKind = bk; shows = sh; byCategory = categoryIndex
    }

    fun episodes(sh: Item): List<Item> {
        val version = catalogueVersion
        return SingleFlight.run(Triple("episodes", version, sh.id)) { fetchEpisodes(sh, version) }
    }
    private fun fetchEpisodes(sh: Item, version: Int): List<Item> {
        eps[sh.id]?.let { return it }
        if (sh.sid.isEmpty()) return emptyList()
        val p = active() ?: return emptyList()
        return try {
            val r = JSONObject(http(api(p, "get_series_info&series_id=${sh.sid}")))
            r.optJSONObject("info")?.let { inf ->
                if (version != catalogueVersion || Thread.currentThread().isInterrupted) return@let
                info[sh.id] = Info(inf.str("plot"), inf.str("cast"), inf.str("genre"), inf.str("rating"),
                    inf.str("releaseDate").take(4).ifBlank { inf.str("release_date").take(4) }, inf.optJSONArray("backdrop_path")?.optString(0) ?: "",
                    inf.str("tmdb").ifBlank { inf.str("tmdb_id") })
            }
            val e = r.optJSONObject("episodes") ?: return emptyList()
            val out = ArrayList<Item>(); val sv = srv(p)
            for (k in e.keys()) {
                val a = e.optJSONArray(k) ?: continue
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i); val id = o.optString("id")
                    val ext = o.optString("container_extension").ifBlank { "mp4" }
                    val episodeInfo = o.optJSONObject("info")
                    val secs = episodeInfo?.optInt("duration_secs", 0) ?: 0
                    val still = sequenceOf(episodeInfo?.str("movie_image"), episodeInfo?.str("still_path"), o.str("movie_image"))
                        .filterNotNull().firstOrNull { it.startsWith("https://") || it.startsWith("http://") }.orEmpty()
                    out.add(Item("xe$id", o.optString("title"), still, "", "series", "$sv/series/${p.xu}/${p.xp}/$id.$ext", "", sh.name,
                        "S${o.optString("season")}E${o.optString("episode_num")}", dur = if (secs > 0) (secs / 60).toString() else ""))
                }
            }
            if (version == catalogueVersion && !Thread.currentThread().isInterrupted) eps[sh.id] = out
            out
        } catch (ex: Exception) { emptyList() }
    }

    fun loadMovieInfo(m: Item) {
        val version = catalogueVersion
        SingleFlight.run(Triple("movie-info", version, m.id)) { fetchMovieInfo(m, version) }
    }
    private fun fetchMovieInfo(m: Item, version: Int) {
        if (info.containsKey(m.id) || m.sid.isEmpty()) return
        val p = active() ?: return
        try {
            val r = JSONObject(http(api(p, "get_vod_info&vod_id=${m.sid}")))
            val inf = r.optJSONObject("info") ?: return
            if (version != catalogueVersion || Thread.currentThread().isInterrupted) return
            info[m.id] = Info(inf.str("plot").ifBlank { inf.str("description") }, inf.str("cast").ifBlank { inf.str("actors") }, inf.str("genre"), inf.str("rating"),
                inf.str("releasedate").ifBlank { inf.str("release_date") }.take(4), inf.optJSONArray("backdrop_path")?.optString(0) ?: "",
                inf.str("tmdb_id").ifBlank { inf.str("tmdb") })
        } catch (ex: Exception) { }
    }

    // ---------- TV guide (XMLTV) ----------
    fun epgUrl(): String {
        val c = s("epgUrl").trim()
        if (c.isNotEmpty()) return c
        val p = active() ?: return ""
        return if (p.mode == "xt") "${srv(p)}/xmltv.php?username=${enc(p.xu)}&password=${enc(p.xp)}" else m3uEpg
    }

    @Synchronized
    fun guideChannelSnapshot(): Pair<List<AudioChannel>, Map<String, List<Prog>>> {
        val playlist = active() ?: return emptyList<AudioChannel>() to emptyMap()
        val guide = epg
        if (guide.isEmpty() || !b("epgOn", true) || cp?.id != playlist.id || !isPlaylistVisible(playlist.id))
            return emptyList<AudioChannel>() to emptyMap()
        val channels = list("live").mapNotNull { item ->
            if (item.epg.isBlank() || !guide.containsKey(item.epgKey)) return@mapNotNull null
            val url = playlistUrl(item, playlist)
            if (url.isBlank()) return@mapNotNull null
            AudioChannel(item.copy(u = url), playlist.id, playlist.name)
        }
        return channels to guide
    }

    fun progs(ch: Item): List<Prog> = if (ch.epg.isEmpty()) emptyList() else (epg[ch.epgKey] ?: emptyList())
    fun nowOn(ch: Item): Prog? { val t = System.currentTimeMillis(); return progs(ch).firstOrNull { it.start <= t && it.stop > t } }

    fun loadEpg(force: Boolean = false) {
        if (!b("epgOn", true) || epgState == 1) return
        if (!force && epgState == 2) return
        val u = epgUrl()
        if (u.isBlank()) { epgState = 3; return }
        val version = catalogueVersion
        val channels = byKind["live"].orEmpty()
        epgState = 1
        Thread {
            val parsed = try {
                val want = channels.mapNotNull { it.epgKey.takeIf(String::isNotBlank) }.toHashSet()
                if (want.isEmpty()) emptyMap() else downloadEpg(u, want)
            } catch (_: Exception) { null }
            synchronized(this) {
                if (version != catalogueVersion) return@Thread
                if (parsed != null) { epg = parsed; epgState = 2 } else epgState = 3
            }
            onEpg?.invoke()
        }.start()
    }

    private fun downloadEpg(u: String, want: Set<String>): Map<String, List<Prog>> {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 120000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", RequestIdentity.userAgent())
        return try {
            BufferedInputStream(c.inputStream, 65536).use { raw ->
                raw.mark(2); val b1 = raw.read(); val b2 = raw.read(); raw.reset()
                val ins: InputStream = if (b1 == 0x1f && b2 == 0x8b) GZIPInputStream(raw, 65536) else raw
                val off = (s("epgOff", "0").toIntOrNull() ?: 0) * 3600000L
                ins.use { parseEpg(it, want, System.currentTimeMillis(), off) }
            }
        } finally { c.disconnect() }
    }

    private fun ptime(s: String?): Long {
        if (s == null || s.length < 14) return 0L
        return try { synchronized(tf) { tf.parse(if (s.length > 14 && s.contains(' ')) s else s.take(14) + " +0000")?.time ?: 0L } } catch (e: Exception) { 0L }
    }

    private fun parseEpg(ins: InputStream, want: Set<String>, now: Long, off: Long): Map<String, List<Prog>> {
        val p = Xml.newPullParser()
        p.setInput(ins, null)
        val tmp = HashMap<String, MutableList<Prog>>()
        var ch = ""; var st = 0L; var en = 0L; var title = ""; var desc = ""; var inProg = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                if (p.name == "programme") {
                    ch = (p.getAttributeValue(null, "channel") ?: "").lowercase()
                    inProg = ch in want
                    if (inProg) {
                        st = ptime(p.getAttributeValue(null, "start")); en = ptime(p.getAttributeValue(null, "stop"))
                        inProg = en > now - 3600000L && st < now + 43200000L
                        title = ""; desc = ""
                    }
                } else if (p.name == "title" && inProg && title.isEmpty()) {
                    title = p.nextText().trim()
                } else if (p.name == "desc" && inProg && desc.isEmpty()) {
                    desc = p.nextText().trim().take(400)
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "programme") {
                if (inProg) tmp.getOrPut(ch) { ArrayList() }.add(Prog(st + off, en + off, title, desc))
                inProg = false
            }
            ev = p.next()
        }
        val out = HashMap<String, List<Prog>>()
        for ((k, v) in tmp) out[k] = v.sortedBy { it.start }
        return out
    }
}
