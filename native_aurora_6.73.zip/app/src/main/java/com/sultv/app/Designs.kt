package com.sultv.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.concurrent.Executors

interface HomeLike {
    val root: View
    fun start()
    fun stop()
    fun render()
    fun destroy() { stop() }
}

object Designs {
    fun hideLiveCategoriesByDefault(style: String) = style == "reference" || style == "studio"

    val ids = listOf("cinema", "spotlight", "gunners", "aurora")
    /** Night-blue rail designs that share the Spotlight layout engine. */
    fun night(s: String) = s == "spotlight" || s == "aurora"
    fun migrate() {
        val saved = Repo.s("ui")
        if (saved !in ids) Repo.put("ui", "cinema")
        if (!Repo.b("referenceLayoutV52", false)) Repo.putB("referenceLayoutV52", true)
        // The three new designs own their palette; legacy theme settings no longer apply.
        Repo.put("th", Repo.s("ui"))
    }
    fun palette(id: String): Pal = when (id) {
        "reference" -> when (Repo.s("referencePalette", "slate")) {
            "midnight" -> Pal(col("#F5F7FF"), col("#B0BDD4"), col("#19263D"), col("#79B2FF"), col("#0A1933"), col("#080F20"), col("#153D73"))
            "copper" -> Pal(col("#FFF5ED"), col("#D2B4AC"), col("#342128"), col("#E4AD79"), col("#241711"), col("#210F1B"), col("#6C3E2B"))
            else -> Pal(col("#EFF5FB"), col("#A3B5C9"), col("#15263A"), col("#70C7F2"), col("#071421"), col("#081320"), col("#172D45"))
        }
        "studio" -> Pal(col("#F3F8FC"), col("#B6CBDB"), col("#E6102233"), col("#99D6ED"), col("#091B2A"), col("#071421"), col("#0A1A29"))
        "gunners" -> Pal(col("#F7F8FD"), col("#B4BDD3"), col("#131E35"), col("#FA3A54"), col("#090F20"), col("#121F38"), col("#0A1328"))
        "aurora" -> Pal(col("#F0F4FF"), col("#96A2BE"), col("#1FFFFFFF"), col("#2DE2C8"), col("#080C18"), col("#0B2233"), col("#1C0F3C"))
        "spotlight" -> Pal(col("#F2F6FF"), col("#A9B4CE"), col("#16213A"), col("#7FA8FF"), col("#0A0F1A"), col("#16223D"), col("#0A0F1A"))
        else -> Pal(col("#FAF7F0"), col("#BEB9AF"), col("#191919"), col("#DFC178"), col("#151008"), col("#0A0A0A"), col("#131313"))
    }
    fun panel(c: Context, color: Int = Th.card, focus: Boolean = false, radius: Int = 10) =
        GradientDrawable().apply {
            setColor(color); cornerRadius = c.dp(radius).toFloat()
            setStroke(c.dp(if (focus) 3 else 1), if (focus) Th.acc else col("#22FFFFFF"))
        }
    fun label(c: Context, value: String, size: Float, muted: Boolean = false) = TextView(c).apply {
        text = value; textSize = size; setTextColor(if (muted) Th.mut else Th.fg)
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
    }
    fun action(c: Context, title: String, icon: Int, primary: Boolean = false, click: () -> Unit): Button =
        Th.tabBtn(c, title, icon, primary).apply {
            textSize = 14f; contentDescription = title
            setOnClickListener { click() }
        }
}

/** Real vector icons, a persistent selected state, and a separate remote focus outline. */
class DesignNav(c: Context, title: String, icon: Int, private var compact: Boolean, private val railIconsOnly: Boolean = false) : LinearLayout(c) {
    private val image = ImageView(c)
    private val label = Designs.label(c, title, if (compact) 10f else 14f)
    private var selectedTab = false
    private val navStyle = Repo.s("ui", "cinema")
    private val textOption = Repo.s(HomePreferences.key(navStyle, "navText"))
    private val iconOption = Repo.s(HomePreferences.key(navStyle, "navIcons"))
    private val labelPosition = Repo.s(HomePreferences.key(navStyle, "navLabelPosition"))
    private val noLabels = railIconsOnly || textOption == "never"
    private fun applyNavSizes(normalSize: Float) {
        label.textSize = if (textOption == "small") normalSize * .82f else normalSize
        if (noLabels) label.visibility = View.GONE
        else if (textOption == "icons") label.visibility = if (hasFocus()) View.VISIBLE else View.GONE
        if (labelPosition == "under" || labelPosition == "beside") {
            val under = labelPosition == "under"
            orientation = if (under) VERTICAL else HORIZONTAL
            if (under) setPadding(paddingLeft, context.dp(2), paddingRight, context.dp(2))
            label.layoutParams = LayoutParams(-2, -2).apply {
                if (under) topMargin = context.dp(2) else marginStart = context.dp(5)
            }
            if (!noLabels && textOption != "icons") label.visibility = View.VISIBLE
        }
        if (iconOption == "small") image.layoutParams = LayoutParams(context.dp(17), context.dp(17))
    }
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if ((Th.name == "cinema" || Th.name == "spotlight") && selectedTab) {
            marker.color = Th.acc
            val edge = if (layoutDirection == View.LAYOUT_DIRECTION_RTL) width - context.dp(3).toFloat() else 0f
            canvas.drawRoundRect(RectF(edge, context.dp(8).toFloat(), edge + context.dp(3), height - context.dp(8).toFloat()), context.dp(2).toFloat(), context.dp(2).toFloat(), marker)
        }
    }
    init {
        id = View.generateViewId(); isFocusable = true; isClickable = true
        orientation = if (compact) VERTICAL else HORIZONTAL
        gravity = Gravity.CENTER; layoutDirection = c.resources.configuration.layoutDirection
        setPadding(c.dp(10), c.dp(7), c.dp(10), c.dp(7))
        contentDescription = title
        label.visibility = if (Th.name == "cinema" && compact) View.GONE else View.VISIBLE
        image.setImageResource(icon)
        addView(image, LayoutParams(c.dp(22), c.dp(22)))
        addView(label, LayoutParams(-2, -2).apply { if (compact) topMargin = c.dp(4) else marginStart = c.dp(9) })
        applyNavSizes(if (compact) 10f else 14f)
        setOnFocusChangeListener { _, focused ->
            if (!noLabels && textOption == "icons") label.visibility = if (focused) View.VISIBLE else View.GONE
            paint(selectedTab)
        }
        paint(false)
    }
    fun textOnly() { image.visibility = View.GONE; label.layoutParams = LayoutParams(-2, -2) }
    fun iconOnly() { label.visibility = View.GONE }
    fun compact(value: Boolean) {
        compact = value
        label.visibility = if (Th.name in listOf("cinema", "studio", "spotlight", "aurora") && value) View.GONE else View.VISIBLE
        orientation = if (value) VERTICAL else HORIZONTAL
        if (Th.name == "studio") {
            gravity = if (value) Gravity.CENTER else Gravity.START or Gravity.CENTER_VERTICAL
            label.typeface = Typeface.DEFAULT_BOLD
            image.layoutParams = LayoutParams(context.dp(26), context.dp(26))
        }
        setPadding(context.dp(if (value) 6 else 10), context.dp(if (value) 2 else 7), context.dp(if (value) 6 else 10), context.dp(if (value) 2 else 7))
        label.layoutParams = LayoutParams(-2, -2).apply { if (value) topMargin = context.dp(2) else marginStart = context.dp(9) }
        applyNavSizes(if (value) 10f else if (Th.name == "studio") 17f else 14f)
    }
    fun paint(on: Boolean) {
        selectedTab = on; isSelected = on
        val cinema = Th.name == "cinema"
        val live = Th.name == "live"
        val spotlight = Designs.night(Th.name)
        background = if (cinema || live || spotlight) GradientDrawable().apply {
            setColor(if (on) (if (live) Th.acc else if (spotlight) col("#2A3F6B") else col("#243040")) else Color.TRANSPARENT); cornerRadius = context.dp(12).toFloat()
            if (hasFocus()) setStroke(context.dp(2), if (live && on) Th.fg else Th.acc)
        } else Designs.panel(context, if (on) Th.acc else Color.TRANSPARENT, hasFocus(), 9)
        if (!cinema && !spotlight && on && hasFocus()) (background as GradientDrawable).setStroke(context.dp(3), Th.fg)
        val ink = if (on) (if (cinema) Th.acc else if (spotlight) Th.fg else Th.bt) else Th.fg
        image.imageTintList = android.content.res.ColorStateList.valueOf(ink); label.setTextColor(ink)
        if (Th.name == "gunners") {
            background = if (on || hasFocus()) GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(col("#B6203D"), col("#4E0E24"))).apply {
                cornerRadius = context.dp(10).toFloat()
                setStroke(context.dp(if (hasFocus()) 2 else 1), if (hasFocus()) Color.WHITE else Th.acc)
            } else null
            image.imageTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            label.setTextColor(Color.WHITE)
        }
        if (Th.name == "studio") {
            background = if (on || hasFocus()) ReferenceLook.selection(context, on, hasFocus())
                else null
            image.imageTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            label.setTextColor(Color.WHITE)
        }
        if (Th.name == "aurora") {
            background = GradientDrawable().apply {
                cornerRadius = context.dp(18).toFloat()
                setColor(if (on) Th.acc else if (hasFocus()) col("#33FFFFFF") else Color.TRANSPARENT)
                if (hasFocus()) setStroke(context.dp(3), if (on) Th.fg else Th.acc)
            }
            val auroraInk = if (on) Th.bt else if (hasFocus()) Th.fg else Th.mut
            image.imageTintList = android.content.res.ColorStateList.valueOf(auroraInk); label.setTextColor(auroraInk)
        }
        animate().scaleX(if (hasFocus()) 1.035f else 1f).scaleY(if (hasFocus()) 1.035f else 1f).setDuration(120).start()
    }
}

private class SidebarOverlayLayout(c: Context) : LinearLayout(c) {
    var onPointerChanged: ((Boolean) -> Unit)? = null
    override fun dispatchHoverEvent(event: android.view.MotionEvent): Boolean {
        when (event.action) {
            android.view.MotionEvent.ACTION_HOVER_ENTER, android.view.MotionEvent.ACTION_HOVER_MOVE -> onPointerChanged?.invoke(true)
            android.view.MotionEvent.ACTION_HOVER_EXIT -> onPointerChanged?.invoke(false)
        }
        return super.dispatchHoverEvent(event)
    }
}

class DesignShell(
    c: Context, style: String, rail: Boolean, tabs: List<Triple<String, Int, Int>>,
    navigate: (String) -> Unit, settingsClick: () -> Unit, searchClick: () -> Unit, refresh: (View) -> Unit,
    exitToContent: (() -> Unit)? = null,
    onRailExpanded: (Boolean) -> Unit = {}
) {
    val root: LinearLayout = SidebarOverlayLayout(c)
    val buttons = linkedMapOf<String, View>()
    private var selectedKey = "home"
    private val railIconsOnly = rail && HomePreferences.railMode(style) == "icons"
    private val expandsOnFocus = !railIconsOnly
    val settings = DesignNav(c, c.getString(R.string.settings), if (style == "aurora") R.drawable.ic_au_settings else if (style == "live") R.drawable.ic_cinema_profile else R.drawable.ic_settings, true, railIconsOnly)
    val search = DesignNav(c, c.getString(R.string.search), if (style == "aurora") R.drawable.ic_au_search else R.drawable.ic_search, true, railIconsOnly)
    init {
        val floatingRail = rail && style in listOf("studio", "cinema")
        val collapsible = rail && HomePreferences.overlayRail(style)
        if (collapsible) root.tag = "cinema-rail"
        var brand: TextView? = null
        root.orientation = if (rail) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        root.layoutDirection = c.resources.configuration.layoutDirection
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(c.dp(8), c.dp(10), c.dp(8), c.dp(10))
        root.background = Designs.panel(c, if (collapsible) Th.bgFrom else col("#99090E16"), radius = 0)
        if (style == "aurora") root.background = Designs.panel(c, col("#EB0A1424"), radius = 0)
        if (floatingRail) {
            root.background = android.graphics.drawable.InsetDrawable(
                Designs.panel(c, if (style == "cinema") col("#F2171717") else col("#F210172F"), radius = 22), c.dp(4), c.dp(8), c.dp(4), c.dp(8))
            root.setPadding(c.dp(12), c.dp(18), c.dp(12), c.dp(18))
        }
        if (style == "live" && !rail) {
            val wideHeader = c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density >= 600
            val brandRow = LinearLayout(c).apply { tag = "live-brand"; gravity = Gravity.CENTER_VERTICAL }
            brandRow.addView(ImageView(c).apply { setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = c.getString(R.string.app_name) }, LinearLayout.LayoutParams(c.dp(36), c.dp(36)))
            if (wideHeader) brandRow.addView(Designs.label(c, "ABO MISK", 18f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = c.dp(9) })
            root.addView(brandRow, LinearLayout.LayoutParams(c.dp(if (wideHeader) 150 else 44), -2))
        }
        if (style == "gunners" && !rail) {
            root.background = Designs.panel(c, col("#F2091122"), radius = 0)
            root.addView(ImageView(c).apply {
                setImageResource(R.drawable.gunners_logo)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "Gunners by ABO MISK"
            }, LinearLayout.LayoutParams(c.dp(if (rail) 112 else 145), c.dp(44)).apply { marginEnd = c.dp(12) })
        }
        if (rail && !floatingRail) {
            val badge = LinearLayout(c).apply { tag = "brand-badge"; gravity = Gravity.CENTER; orientation = if (style == "cinema" || Designs.night(style)) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
            badge.addView(ImageView(c).apply {
                setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = c.getString(R.string.app_name)
            }, LinearLayout.LayoutParams(c.dp(40), c.dp(40)))
            brand = Designs.label(c, "ABO MISK", 18f).apply {
                gravity = Gravity.CENTER_VERTICAL; setTextColor(Th.acc); typeface = Typeface.DEFAULT_BOLD
                visibility = if (collapsible) View.GONE else View.VISIBLE
            }
            badge.addView(brand, LinearLayout.LayoutParams(-2, -2).apply { if (style == "cinema" || Designs.night(style)) topMargin = c.dp(4) else marginStart = c.dp(8) })
            root.addView(badge, LinearLayout.LayoutParams(-1, c.dp(if (Designs.night(style) && !collapsible) 76 else 48)))
        }
        val nav = LinearLayout(c).apply { orientation = if (rail) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        for ((key, title, icon) in tabs) {
            val resolvedIcon = if (style == "aurora") when (key) { "home" -> R.drawable.ic_au_home; "live" -> R.drawable.ic_au_live; "movie" -> R.drawable.ic_au_movies; "series" -> R.drawable.ic_au_series; "list" -> R.drawable.ic_au_list; else -> icon }
                else if (style == "cinema") when (key) { "live" -> R.drawable.ic_n_live; "movie" -> R.drawable.ic_n_series; "series" -> R.drawable.ic_n_movie; "list" -> R.drawable.ic_ref_bookmark; else -> icon }
                else if (Designs.night(style)) when (key) { "live" -> R.drawable.ic_n_live; "movie" -> R.drawable.ic_n_movie; "series" -> R.drawable.ic_spot_series; "list" -> R.drawable.ic_ref_bookmark; else -> icon } else icon
            val item = DesignNav(c, c.getString(title), resolvedIcon, false, railIconsOnly)
            if (style == "live" && !collapsible && Repo.s(HomePreferences.key(style, "navText")) !in listOf("icons", "never") &&
                Repo.s(HomePreferences.key(style, "navLabelPosition")).isBlank() &&
                Repo.s(HomePreferences.key(style, "navIcons")).isBlank()) item.textOnly()
            item.setOnClickListener { navigate(key) }; buttons[key] = item
            nav.addView(item, if (rail) LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, c.dp(3), 0, c.dp(3)) }
                else LinearLayout.LayoutParams(0, c.dp(50), 1f).apply { marginEnd = c.dp(3) })
        }
        if (floatingRail) {
            root.addView(nav, LinearLayout.LayoutParams(-1, -1))
        } else if (rail) root.addView(nav, LinearLayout.LayoutParams(-1, 0, 1f))
        else {
            val scroll = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; isFillViewport = true }
            scroll.addView(nav, FrameLayout.LayoutParams(c.dp(if (style == "live") 420 else if (style == "gunners") 690 else 650), -2))
            root.addView(scroll, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val tools = LinearLayout(c).apply { gravity = Gravity.CENTER; orientation = if (collapsible || rail && Designs.night(style)) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
        search.setOnClickListener { searchClick() }; settings.setOnClickListener { settingsClick() }
        val sync = DesignNav(c, "تحديث", R.drawable.ic_refresh, true, railIconsOnly).apply { setOnClickListener { refresh(this) } }
        if (style == "live" && !rail && c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density >= 600) root.addView(TextClock(c).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"; textDirection = View.TEXT_DIRECTION_LTR; textSize = 16f; setTextColor(Th.fg); setPadding(c.dp(8), 0, c.dp(8), 0)
        }, LinearLayout.LayoutParams(-2, -2))
        val toolItems = if (style in listOf("cinema", "studio", "spotlight", "gunners", "aurora")) listOf(search, settings) else listOf(search, sync, settings)
        if (style == "live" && !collapsible &&
            Repo.s(HomePreferences.key(style, "navLabelPosition")).isBlank() &&
            Repo.s(HomePreferences.key(style, "navText")).isBlank()) toolItems.forEach { it.iconOnly() }
        if (Designs.night(style) && rail && !collapsible) toolItems.forEach { it.compact(false) }
        if (floatingRail) for (item in toolItems) {
            nav.addView(item, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, c.dp(3), 0, c.dp(3)) })
        } else for (item in toolItems) tools.addView(item, LinearLayout.LayoutParams(if (collapsible || rail && Designs.night(style)) -1 else c.dp(if (rail && !Designs.night(style)) 46 else 48), c.dp(if (Designs.night(style)) (48 * c.resources.configuration.fontScale.coerceAtLeast(1f)).toInt() else 48)))
        if (!floatingRail) root.addView(tools, LinearLayout.LayoutParams(if (rail) -1 else -2, -2))
        if (style == "gunners" && !rail) {
            val logo = root.getChildAt(0)
            val params = logo.layoutParams
            root.removeView(logo)
            root.addView(logo, params)
        }
        if (Designs.night(style) && rail && !collapsible) {
            val ordered = buttons.values.filterIsInstance<DesignNav>() + toolItems
            ordered.forEachIndexed { index, item ->
                item.nextFocusUpId = ordered[(index - 1).coerceAtLeast(0)].id
                item.nextFocusDownId = ordered[(index + 1).coerceAtMost(ordered.lastIndex)].id
                item.setOnKeyListener { _, key, event ->
                    when (key) {
                        android.view.KeyEvent.KEYCODE_DPAD_UP, android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (event.action == android.view.KeyEvent.ACTION_DOWN) ordered[(index + if (key == android.view.KeyEvent.KEYCODE_DPAD_DOWN) 1 else -1).coerceIn(0, ordered.lastIndex)].requestFocus()
                            true
                        }
                        (if (c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL) android.view.KeyEvent.KEYCODE_DPAD_LEFT else android.view.KeyEvent.KEYCODE_DPAD_RIGHT) -> {
                            if (event.action == android.view.KeyEvent.ACTION_DOWN) { exitToContent?.invoke(); true } else false
                        }
                        else -> false
                    }
                }
            }
        }
        if (collapsible) {
            val ordered = buttons.values.filterIsInstance<DesignNav>() + toolItems
            var expanded = false
            var hovering = false
            var suppressHover = false
            var animator: android.animation.ValueAnimator? = null
            fun expand(value: Boolean) {
                if (!expandsOnFocus || expanded == value) return
                expanded = value
                onRailExpanded(value)
                brand?.visibility = if (value && Repo.s(HomePreferences.key(style, "navText")) != "never")
                    View.VISIBLE else View.GONE
                root.findViewWithTag<View>("brand-badge")?.let { it.layoutParams = it.layoutParams.apply { height = c.dp(if (value) 76 else 48) } }
                ordered.forEach { it.compact(!value) }
                animator?.cancel()
                val params = root.layoutParams as? FrameLayout.LayoutParams ?: return
                animator = android.animation.ValueAnimator.ofInt(params.width, c.dp(if (value) 224 else 72)).apply {
                    duration = 160
                    addUpdateListener { root.layoutParams = (root.layoutParams as FrameLayout.LayoutParams).apply { width = it.animatedValue as Int } }
                    start()
                }
            }
            brand?.visibility = View.GONE
            ordered.forEachIndexed { index, item ->
                item.compact(true)
                item.nextFocusUpId = ordered[(index - 1).coerceAtLeast(0)].id
                item.nextFocusDownId = ordered[(index + 1).coerceAtMost(ordered.lastIndex)].id
                item.setOnKeyListener { _, key, event ->
                    when (key) {
                        android.view.KeyEvent.KEYCODE_DPAD_UP, android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (event.action == android.view.KeyEvent.ACTION_DOWN) ordered[(index + if (key == android.view.KeyEvent.KEYCODE_DPAD_DOWN) 1 else -1).coerceIn(0, ordered.lastIndex)].requestFocus()
                            true
                        }
                        (if (c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL) android.view.KeyEvent.KEYCODE_DPAD_LEFT else android.view.KeyEvent.KEYCODE_DPAD_RIGHT) -> {
                            if (event.action == android.view.KeyEvent.ACTION_DOWN) { exitToContent?.invoke(); true } else false
                        }
                        else -> false
                    }
                }
            }
            buttons.forEach { (key, item) -> item.setOnClickListener {
                suppressHover = hovering
                hovering = false
                navigate(key)
                expand(false)
            } }
            val focusListener = android.view.ViewTreeObserver.OnGlobalFocusChangeListener { _, focus -> expand(hovering || ordered.any { it === focus }) }
            (root as SidebarOverlayLayout).onPointerChanged = { inside ->
                if (!inside) suppressHover = false
                hovering = inside && !suppressHover
                expand(hovering || root.hasFocus())
            }
            root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) { v.viewTreeObserver.addOnGlobalFocusChangeListener(focusListener); expand(hovering || root.hasFocus()) }
                override fun onViewDetachedFromWindow(v: View) { animator?.cancel(); if (v.viewTreeObserver.isAlive) v.viewTreeObserver.removeOnGlobalFocusChangeListener(focusListener) }
            })
        }
    }
    fun select(key: String) { selectedKey = key; buttons.forEach { (k, v) -> (v as DesignNav).paint(k == key) } }
    fun focusSelected() { (buttons[selectedKey] ?: buttons.values.firstOrNull())?.requestFocus() }
}

internal fun homeShortcuts(c: Context, style: String, vertical: Boolean, navigate: (String) -> Unit) =
    LinearLayout(c).apply {
        tag = "home-shortcuts"
        orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        listOf("live" to R.drawable.ic_n_live, "movie" to R.drawable.ic_n_movie, "series" to R.drawable.ic_n_series)
            .forEachIndexed { index, (section, icon) ->
                val title = HomePreferences.label(c, section)
                val card = FrameLayout(c).apply {
                    tag = "home-shortcut:$section"
                    contentDescription = title
                    isFocusable = true
                    clipToOutline = true
                    background = Designs.panel(c)
                    addView(ImageView(c).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setImageResource(HomePreferences.shortcutArtwork(style, section))
                    }, FrameLayout.LayoutParams(-1, -1))
                    addView(View(c).apply {
                        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                            intArrayOf(Color.TRANSPARENT, col("#E0071020")))
                    }, FrameLayout.LayoutParams(-1, -1))
                    addView(Designs.label(c, title, 15f).apply {
                        typeface = Typeface.DEFAULT_BOLD
                        val glyph = Th.icon(c, icon, Th.acc)
                        glyph?.setBounds(0, 0, c.dp(18), c.dp(18))
                        setCompoundDrawablesRelative(null, null, glyph, null)
                        compoundDrawablePadding = c.dp(6)
                        gravity = Gravity.END or Gravity.CENTER_VERTICAL
                        setPadding(c.dp(8), c.dp(6), c.dp(8), c.dp(6))
                    }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
                    addView(View(c), FrameLayout.LayoutParams(-1, -1))
                    setOnFocusChangeListener { _, focused ->
                        getChildAt(childCount - 1).background = GradientDrawable().apply {
                            cornerRadius = c.dp(12).toFloat()
                            setColor(Color.TRANSPARENT)
                            if (focused) setStroke(c.dp(2), Th.acc)
                        }
                    }
                    setOnClickListener { navigate(section) }
                }
                addView(card, if (vertical) LinearLayout.LayoutParams(-1, c.dp(70)).apply {
                    if (index < 2) bottomMargin = c.dp(7)
                } else LinearLayout.LayoutParams(0, c.dp(90), 1f).apply {
                    if (index < 2) marginEnd = c.dp(8)
                })
            }
    }

/** Three distinct home compositions, populated exclusively from the configured playlists. */
internal class DesignHomeView(
    private val c: Context, private val style: String,
    private val open: (Item) -> Unit, private val play: (Item) -> Unit,
    private val menu: (Item) -> Unit, private val navigate: (String) -> Unit,
    private val account: () -> Unit = {},
    private val openMatch: ((GunnersMatch) -> Unit)? = null,
    private val fixtures: (Boolean) -> GunnersSchedule = GunnersData::fixtures
) : HomeLike {
    override val root = ScrollView(c).apply { isVerticalScrollBarEnabled = false; clipToPadding = false }
    private val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
    private val handler = Handler(Looper.getMainLooper())
    private val renderWork = LatestWork()
    private val heroWork = LatestWork()
    private val spotlightHero = if (Designs.night(style)) SpotlightHomeView(c, open, play, menu, account) else null
    private var generation = 0
    private var heroToken = 0
    private val small get() = c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density < 600
    private val heroHeight get() = ((c.resources.displayMetrics.heightPixels / c.resources.displayMetrics.density) * when (style) { "live" -> 0.39f; "spotlight", "aurora" -> 0.50f; "cinema" -> 0.36f; else -> 0.44f }).toInt().coerceIn(if (style == "live" || style == "cinema") 190 else 225, 410)
    private data class Data(val movies: List<Item>, val shows: List<Item>, val live: List<Item>, val recent: List<Item>, val fav: List<Item>)
    init { root.addView(box); box.layoutDirection = c.resources.configuration.layoutDirection; box.setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(22)) }

    override fun start() { spotlightHero?.start() }
    override fun stop() { renderWork.cancel(); heroWork.cancel(); spotlightHero?.stop(); generation++; heroToken++ }
    override fun destroy() {
        stop()
        spotlightHero?.destroy()
        renderWork.close()
        heroWork.close()
        handler.removeCallbacksAndMessages(null)
    }

    override fun render() {
        val token = ++generation
        renderWork.submit {
            if (HomePreferences.custom(style)) {
                renderCustom(token)
                return@submit
            }
            if (style == "studio") {
                val series = Repo.list("series")
                val savedEpisodes = Repo.sp.all.keys.asSequence().filter { it.startsWith("le:") }.map { it.removePrefix("le:") }
                val recent = (Repo.recent().asSequence() + savedEpisodes).distinct().toList()
                val ids = recent.toHashSet()
                val matching = series.asSequence().filter { it.id in ids }.associateBy { it.id }
                val items = recent.mapNotNull { matching[it] }.filter { Repo.s("le:" + it.id).isNotBlank() }
                handler.post { if (token == generation) studioHome(items) }
                return@submit
            }
            val movies = Repo.list("movie"); val shows = Repo.list("series"); val live = Repo.list("live")
            val recentIds = Repo.recent().take(60)
            val recentSet = recentIds.toHashSet()
            val visible = (movies.asSequence() + shows.asSequence() + live.asSequence()).filter { it.id in recentSet }.associateBy { it.id }
            val recent = recentIds.mapNotNull { visible[it] }.filter(HomePreferences::canResume).take(20)
            val data = Data(movies.take(24), shows.take(24), live.take(30), recent, Repo.favItems().take(20))
            handler.post {
                if (token == generation) show(data)
            }
        }
    }
    private fun renderCustom(token: Int) {
        val rows = HomePreferences.rows(style)
        val sources = (0 until HomePreferences.bannerCount(style)).map { index ->
            HomePreferences.bannerSource(style, index).let { if (it == "auto" && style == "gunners") "matches" else it }
        }
        val content = listOf("live", "movie", "series").associateWith { Repo.list(it) }
        val favourites = Repo.favItems()
        val recent = Repo.recent().take(40)
        val recentSet = recent.toHashSet()
        val recentItems = (content["movie"].orEmpty().asSequence() + content["series"].orEmpty().asSequence())
            .filter { it.id in recentSet && HomePreferences.canResume(it) }.associateBy { it.id }
        val data = content + mapOf("recent" to recent.mapNotNull { recentItems[it] }, "list" to favourites)
        val candidates = sources.mapIndexed { index, source ->
            val category = Repo.s(HomePreferences.bannerKey(style, index, "category"))
            when (source) {
                "auto" -> sequenceOf("movie", "series", "live").flatMap { data[it].orEmpty().asSequence() }.take(3).toList()
                "movie", "series", "live" -> (if (category.isBlank()) data[source].orEmpty() else Repo.list(source, category)).take(3)
                "list" -> favourites.take(3)
                else -> emptyList()
            }
        }
        val banners = candidates.map { it.firstOrNull() }
        val matchBanners = mutableListOf<Pair<Int, LinearLayout>>()
        var matchesSlot: LinearLayout? = null
        handler.post {
            if (token != generation) return@post
            val focused = root.findFocus()?.tag
            box.removeAllViews()
            val primary = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; tag = "home-banner:0" }
            val primaryVisible = banners[0] != null || sources[0] == "matches"
            val position = HomePreferences.shortcutPosition(style)
            fun appendShortcuts() {
                box.addView(homeShortcuts(c, style, false, navigate), LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = c.dp(8)
                })
            }
            if (position == "above" || position == "beside" && (!primaryVisible || small)) appendShortcuts()
            if (primaryVisible && position == "beside" && !small) {
                box.addView(LinearLayout(c).apply {
                    tag = "home-banner-with-shortcuts"
                    addView(primary, LinearLayout.LayoutParams(0, -2, 3f))
                    addView(homeShortcuts(c, style, true, navigate),
                        LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = c.dp(8) })
                })
            } else if (primaryVisible) box.addView(primary)
            val extras = LinearLayout(c).apply { orientation = if (small) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
            for (index in sources.indices) {
                if (banners[index] == null && sources[index] != "matches") continue
                val target = if (index == 0) primary else LinearLayout(c).apply {
                    orientation = LinearLayout.VERTICAL
                    tag = "home-banner:$index"
                    extras.addView(this, if (small) LinearLayout.LayoutParams(-1, -2)
                        else LinearLayout.LayoutParams(0, -2, 1f).apply { if (extras.childCount > 0) marginStart = c.dp(8) })
                }
                val item = banners[index]
                when {
                    item != null && index == 0 && spotlightHero != null -> spotlightHero.showBanner(target, candidates[index])
                    item != null && index == 0 -> movieHero(item, target)
                    item != null -> compactBanner(target, item)
                    sources[index] == "matches" -> {
                        target.addView(Designs.label(c, c.getString(R.string.loading), 18f))
                        matchBanners.add(index to target)
                    }
                }
            }
            if (extras.childCount > 0) box.addView(extras, LinearLayout.LayoutParams(-1, -2))
            if (position == "below") appendShortcuts()
            for (key in rows) {
                if (key == "matches") {
                    box.addView(Designs.label(c, HomePreferences.label(c, key), 19f))
                    matchesSlot = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
                    box.addView(matchesSlot)
                } else row(HomePreferences.label(c, key), data[key].orEmpty(), key in listOf("live", "recent"), if (key == "recent") "list" else key)
            }
            if (focused != null) root.findViewWithTag<View>(focused)?.requestFocus()
        }
        if ("matches" !in sources && "matches" !in rows) return
        val arabic = c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        val leagues = preferredGunnersLeagues()
        val team = Repo.s("gunnersTeam")
        val result = runCatching { fixtures(arabic).today }
        val matches = HomePreferences.matches(result.getOrDefault(emptyList()), leagues, team)
        val emptyMessage = when {
            result.isFailure -> R.string.gunners_fetch_failed
            leagues.isNotEmpty() || team.isNotBlank() -> R.string.gunners_filtered_empty
            else -> R.string.gunners_empty
        }
        handler.post {
            if (token != generation) return@post
            for ((index, container) in matchBanners) {
                container.removeAllViews()
                val leading = matches.firstOrNull { it.live } ?: matches.firstOrNull { !it.finished } ?: matches.firstOrNull()
                if (leading != null) matchTile(container, leading, true, index == 0)
                else container.addView(Designs.label(c, c.getString(emptyMessage), 16f))
            }
            matchesSlot?.let { container ->
                if (matches.isEmpty()) container.addView(Designs.label(c, c.getString(emptyMessage), 16f))
                else {
                    val cards = LinearLayout(c)
                    matches.take(18).forEach { matchTile(cards, it, false) }
                    container.addView(HorizontalScrollView(c).apply {
                        isHorizontalScrollBarEnabled = false
                        addView(cards)
                    })
                }
            }
        }
    }

    private fun compactBanner(container: LinearLayout, item: Item) {
        val banner = FrameLayout(c).apply {
            tag = "home-banner-item:${item.id}"
            isFocusable = true
            clipToOutline = true
            background = Designs.panel(c)
            setOnClickListener { play(item) }
        }
        val artwork = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        Img.load(artwork, Repo.info[item.id]?.back.orEmpty().ifBlank { item.logo }, 1)
        banner.addView(artwork, FrameLayout.LayoutParams(-1, -1))
        val title = Designs.label(c, item.name, 18f).apply {
            typeface = Typeface.DEFAULT_BOLD
            setPadding(c.dp(12), c.dp(8), c.dp(12), c.dp(8))
            background = col("#CD0B1421").let { android.graphics.drawable.ColorDrawable(it) }
        }
        banner.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val outline = View(c)
        banner.addView(outline, FrameLayout.LayoutParams(-1, -1))
        banner.setOnFocusChangeListener { _, focused ->
            outline.background = GradientDrawable().apply {
                cornerRadius = c.dp(12).toFloat(); setColor(Color.TRANSPARENT)
                if (focused) setStroke(c.dp(2), Th.acc)
            }
        }
        container.addView(banner, LinearLayout.LayoutParams(-1, c.dp(135)).apply { bottomMargin = c.dp(8) })
    }

    private fun matchTile(container: LinearLayout, match: GunnersMatch, banner: Boolean, primary: Boolean = false) {
        fun surface(focused: Boolean) = if (!banner) Designs.panel(c, Th.card, focused) else GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = c.dp(12).toFloat()
            if (focused) setStroke(c.dp(2), Th.acc)
        }
        val tile = LinearLayout(c).apply {
            tag = if (primary) "hero-play" else if (banner) "home-match-banner:${match.id}" else "home-match:${match.id}"
            contentDescription = match.title
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(12), c.dp(9), c.dp(12), c.dp(9))
            isFocusable = true
            background = surface(false)
            setOnClickListener { openMatch?.invoke(match) }
            setOnFocusChangeListener { view, focused -> view.background = surface(focused) }
        }
        val header = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        val league = ImageView(c)
        Img.load(league, match.leagueLogo)
        header.addView(league, LinearLayout.LayoutParams(c.dp(22), c.dp(22)).apply { marginEnd = c.dp(5) })
        header.addView(Designs.label(c, match.league, 12f), LinearLayout.LayoutParams(0, -2, 1f))
        val time = when {
            match.live -> c.getString(R.string.live_home_badge)
            match.finished && match.score.isNotBlank() -> match.score
            else -> hm(match.kickoff)
        }
        header.addView(Designs.label(c, time, 13f).apply { setTextColor(Th.acc) })
        tile.addView(header)
        val clubs = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        listOf(match.home, match.away).forEachIndexed { index, team ->
            if (index == 1) clubs.addView(Designs.label(c, "×", 17f))
            val club = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val badge = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            Img.load(badge, team.logo)
            val size = c.dp(if (primary) 76 else if (banner) 56 else 40)
            club.addView(badge, LinearLayout.LayoutParams(size, size))
            club.addView(Designs.label(c, team.name, if (banner) 19f else 13f).apply { maxLines = 2; gravity = Gravity.CENTER })
            clubs.addView(club, LinearLayout.LayoutParams(0, -2, 1f))
        }
        tile.addView(clubs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(5) })
        val card = if (banner) HeroBannerLayout(c, 1f).apply {
            textColumn = tile
            background = Designs.panel(c)
            clipToOutline = true
            addView(ImageView(c).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageResource(R.drawable.gunners_stadium)
            }, FrameLayout.LayoutParams(-1, -1))
            addView(View(c).apply { setBackgroundColor(col("#A50A1426")) }, FrameLayout.LayoutParams(-1, -1))
            addView(tile, FrameLayout.LayoutParams(-1, -2))
        } else tile
        container.addView(card, LinearLayout.LayoutParams(if (banner) -1 else c.dp(230), -2).apply {
            marginEnd = if (banner) 0 else c.dp(8)
            bottomMargin = c.dp(6)
        })
    }

    private fun show(d: Data) {
        val oldFocus = root.findFocus()?.tag as? String
        box.removeAllViews()
        val status = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        status.addView(Designs.label(c, when(style) { "live" -> "مباشر · LIVE"; "spotlight" -> "سبوتلايت · SPOTLIGHT"; "aurora" -> "أورورا · AURORA"; else -> "ABO MISK" }, 15f).apply { setTextColor(Th.acc) }, LinearLayout.LayoutParams(0, -2, 1f))
        status.addView(TextClock(c).apply { format24Hour = "HH:mm"; format12Hour = "HH:mm"; setTextColor(Th.fg); textSize = 18f }, LinearLayout.LayoutParams(-2, -2))
        if (style != "cinema") box.addView(status, LinearLayout.LayoutParams(-1, c.dp(32)))
        if (d.movies.isEmpty() && d.shows.isEmpty() && d.live.isEmpty()) {
            box.addView(Designs.label(c, "أضف قائمة تشغيل من الإعدادات لعرض محتواك", 19f).apply { maxLines = 3; gravity = Gravity.CENTER; setPadding(c.dp(20), c.dp(35), c.dp(20), c.dp(35)) })
            return
        }
        movieHero((d.movies + d.shows).firstOrNull() ?: d.live.first())
        if (style == "cinema") {
            box.addView(homeShortcuts(c, style, false, navigate))
            row(c.getString(R.string.cont_watch), d.recent, true, "list")
            row(c.getString(R.string.cinema_series_for_you), d.shows, true, "series")
            if (oldFocus != null) root.findViewWithTag<View>(oldFocus)?.requestFocus()
            return
        }
        if (d.recent.isNotEmpty()) row("أكمل المشاهدة", d.recent, true, "list")
        row("أبرز الأفلام", d.movies, false, "movie")
        row("المفضلة", d.fav, false, "list")
        row("مسلسلات تستحق المشاهدة", d.shows, false, "series")
        if (style in listOf("cinema", "spotlight", "aurora")) row("قنوات مباشرة", d.live, true, "live")
        if (oldFocus != null) root.findViewWithTag<View>(oldFocus)?.requestFocus()
    }
    private fun studioHome(series: List<Item>) {
        val focused = root.findFocus()?.tag as? String
        box.removeAllViews()
        val rtl = c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        box.addView(Designs.label(c, if (rtl) "أبو مسك" else "ABO MISK", 26f).apply { gravity = Gravity.START })
        val tiles = LinearLayout(c)
        box.addView(tiles, LinearLayout.LayoutParams(-1, c.dp(if (small) 142 else (heroHeight * .86f).toInt())))
        fun tile(key: String, label: Int, art: Int): FrameLayout {
            val view = FrameLayout(c).apply {
                tag = if (key == "live") "hero-play" else "studio:$key"
                contentDescription = c.getString(label); isFocusable = true; isClickable = true
                background = Designs.panel(c, col("#660A2031")); clipToOutline = true
                setOnClickListener { navigate(key) }
                setOnFocusChangeListener { _, on -> foreground = if (on) GradientDrawable().apply {
                    setColor(Color.TRANSPARENT); cornerRadius = c.dp(10).toFloat(); setStroke(c.dp(2), Color.WHITE)
                } else null }
            }
            if (key == "list") {
                val labelView = Designs.label(c, c.getString(label), 17f).apply {
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    compoundDrawablePadding = c.dp(8)
                    setCompoundDrawablesRelativeWithIntrinsicBounds(Th.icon(c, R.drawable.ic_bookmark, Color.WHITE), null, null, null)
                }
                view.addView(labelView, FrameLayout.LayoutParams(-2, -1, Gravity.CENTER))
                view.background = ReferenceLook.selection(c, false, false)
                view.setOnFocusChangeListener { _, focused -> view.background = ReferenceLook.selection(c, false, focused) }
                return view
            }
            if (art != 0) view.addView(ImageView(c).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP; setImageResource(art)
            }, FrameLayout.LayoutParams(-1, -1))
            view.addView(Designs.label(c, c.getString(label), if (key == "live") 28f else 21f).apply {
                setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(8))
                setBackgroundColor(col("#9906101D")); gravity = Gravity.START; typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            return view
        }
        fun slot(weight: Float) = LinearLayout.LayoutParams(0, -1, weight).apply { marginEnd = c.dp(8) }
        val live = tile("live", R.string.live, R.drawable.studio_live)
        tiles.addView(live, slot(1.45f))
        val movies = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val shows = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        tiles.addView(movies, slot(1f))
        tiles.addView(shows, slot(1f))
        movies.addView(tile("movie", R.string.movies, R.drawable.studio_movie), LinearLayout.LayoutParams(-1, 0, 1f))
        movies.addView(View(c), LinearLayout.LayoutParams(-1, c.dp(46)))
        shows.addView(tile("series", R.string.series, R.drawable.studio_series), LinearLayout.LayoutParams(-1, 0, 1f))
        shows.addView(tile("list", R.string.my_list, 0), LinearLayout.LayoutParams(-1, c.dp(40)).apply {
            topMargin = c.dp(6)
        })
        if (series.isEmpty()) {
            box.addView(Designs.label(c, c.getString(R.string.cont_watch), 19f))
            box.addView(Designs.label(c, c.getString(R.string.studio_no_episodes), 14f, true))
        } else row(c.getString(R.string.cont_watch), series, true, "series")
        if (focused != null) root.findViewWithTag<View>(focused)?.requestFocus()
    }

    private fun movieHero(item: Item, container: LinearLayout = box) {
        val token = ++heroToken
        val frame = HeroBannerLayout(c, if (small) .96f else if (style == "cinema") .44f else .62f).apply {
            tag = "movie-hero"; background = if (style == "cinema") GradientDrawable().apply { setColor(Th.bgFrom); cornerRadius = c.dp(16).toFloat() } else Designs.panel(c); clipToOutline = true
            minimumHeight = c.dp(heroHeight)
        }
        val image = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = if (style == "cinema") 1f else .85f }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1)); Img.load(image, item.logo, 1)
        val rightText = if (style == "cinema") c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL else !Designs.night(style)
        val fade = View(c).apply { background = GradientDrawable(if (rightText) GradientDrawable.Orientation.RIGHT_LEFT else GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Th.bgFrom, (Th.bgFrom and 0x00FFFFFF) or (0xC0 shl 24), Color.TRANSPARENT)) }
        frame.addView(fade, FrameLayout.LayoutParams(-1, -1))
        val text = LinearLayout(c).apply { tag = "hero-text"; orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(c.dp(22), c.dp(14), c.dp(22), c.dp(14)) }
        text.addView(Designs.label(c, if (style == "cinema") c.getString(R.string.cinema_featured) else if (item.kind == "live") "بث مباشر" else if (item.kind == "series") "مسلسل مميز" else "فيلم مميز", 13f).apply { setTextColor(Th.acc) })
        text.addView(Designs.label(c, item.name, if (small) 26f else 34f).apply { tag = "hero-title"; maxLines = 2; typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(7) })
        text.addView(Designs.label(c, listOf(item.year, item.dur, item.rate.takeIf { it.isNotBlank() }?.let { "★ $it" } ?: "").filter { it.isNotBlank() }.joinToString("  ·  "), 13f, true))
        val plot = Designs.label(c, Repo.info[item.id]?.plot ?: if (style == "cinema") c.getString(R.string.cinema_hero_hint) else "اكتشف تفاصيل هذا العنوان أو ابدأ المشاهدة الآن", 14f, true).apply { maxLines = if (style == "cinema") 2 else 3 }
        text.addView(plot, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(8) })
        val actions = HeroActionsLayout(c).apply { tag = "hero-actions" }
        val buttonHeight = c.dp((44 * c.resources.configuration.fontScale.coerceAtLeast(1f)).toInt())
        actions.addView(Designs.action(c, if (style == "cinema") c.getString(R.string.cinema_watch_now) else "مشاهدة الآن", R.drawable.ic_n_play, true) { play(item) }.apply { tag = "hero-play"; minimumHeight = buttonHeight }, LinearLayout.LayoutParams(-2, -2))
        actions.addView(Designs.action(c, if (style == "cinema") c.getString(R.string.cinema_details) else "التفاصيل", R.drawable.ic_n_info) { open(item) }.apply { minimumHeight = buttonHeight }, LinearLayout.LayoutParams(-2, -2))
        text.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(12) })
        frame.textColumn = text
        frame.addView(text, FrameLayout.LayoutParams(0, -2, (if (rightText) Gravity.RIGHT else Gravity.LEFT) or Gravity.CENTER_VERTICAL))
        if (style == "cinema") {
            val accountRow = LinearLayout(c).apply {
                tag = "cinema-clock-account"
                background = Designs.panel(c, col("#E60B1421"))
                gravity = Gravity.CENTER_VERTICAL
                setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(8))
            }
            accountRow.addView(TextClock(c).apply {
                format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 16f; setTextColor(Th.fg)
            }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = c.dp(10) })
            accountRow.addView(View(c).apply { setBackgroundColor(col("#55FFFFFF")) }, LinearLayout.LayoutParams(c.dp(1), c.dp(22)).apply { marginEnd = c.dp(10) })
            accountRow.addView(ImageButton(c).apply {
                tag = "cinema-account"; setImageResource(R.drawable.ic_cinema_profile)
                imageTintList = android.content.res.ColorStateList.valueOf(Th.acc)
                setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(4)); background = Designs.panel(c, col("#660B1421"), false, 18)
                contentDescription = c.getString(R.string.settings); setOnClickListener { account() }
                setOnFocusChangeListener { _, focused -> background = Designs.panel(c, col("#660B1421"), focused, 18) }
            }, LinearLayout.LayoutParams(c.dp(34), c.dp(34)))
            frame.topControls = accountRow
            frame.addView(accountRow, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        }
        container.addView(frame, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(10) })
        heroWork.submit {
            try {
                if (item.kind == "movie" && Repo.info[item.id] == null && item.sid.isNotEmpty()) Repo.loadMovieInfo(item)
                val info = Repo.info[item.id]
                val backdrop = info?.back.orEmpty().ifBlank { if (Tmdb.enabled() && item.kind != "live") Tmdb.backdrop(item.kind, info?.tmdb.orEmpty(), item.name, item.year) else "" }
                handler.post { if (heroToken == token) { if (backdrop.isNotBlank()) Img.load(image, backdrop, 1); if (!info?.plot.isNullOrBlank()) plot.text = info?.plot } }
            } catch (_: Exception) { /* Keep playlist artwork when metadata is unavailable. */ }
        }
    }
    private fun row(title: String, items: List<Item>, landscape: Boolean, destination: String) {
        if (items.isEmpty()) return
        val header = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; tag = "home-section:$destination" }
        header.addView(Designs.label(c, title, 19f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        if (style !in listOf("cinema", "spotlight", "studio", "aurora"))
            header.addView(Designs.action(c, "عرض الكل", R.drawable.ic_n_chev) { navigate(destination) }, LinearLayout.LayoutParams(-2, c.dp(38)))
        box.addView(header, LinearLayout.LayoutParams(-1, if (style == "cinema") -2 else c.dp(48)).apply { if (style == "cinema") { topMargin = c.dp(14); bottomMargin = c.dp(8) } })
        val scroll = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false; setPadding(c.dp(3), c.dp(5), c.dp(3), c.dp(8)) }
        val cards = LinearLayout(c).apply { clipChildren = false }
        for (item in items.take(20)) cards.addView(card(item, landscape), LinearLayout.LayoutParams(c.dp(if (style == "cinema") { if (landscape) 250 else 150 } else if (landscape) 230 else if (Designs.night(style)) 158 else 136), -2).apply { marginEnd = c.dp(if (style == "cinema") 12 else 10) })
        scroll.addView(cards); box.addView(scroll)
    }
    private fun cinemaCard(item: Item, landscape: Boolean): View {
        fun surface(focused: Boolean) = GradientDrawable().apply {
            setColor(Th.card); cornerRadius = c.dp(12).toFloat()
            if (focused) setStroke(c.dp(2), Th.acc)
        }
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; isFocusable = true; isClickable = true
            tag = "item:${item.id}"; contentDescription = item.name
            clipToOutline = true; background = surface(false)
            setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(2))
            setOnClickListener { open(item) }; setOnLongClickListener { menu(item); true }
            setOnFocusChangeListener { _, focused -> background = surface(focused); alpha = if (focused) 1f else .96f }
        }
        val artwork = FrameLayout(c).apply { clipToOutline = true; background = surface(false) }
        artwork.addView(VisiblePosterView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setPoster(item.logo) }, FrameLayout.LayoutParams(-1, -1))
        card.addView(artwork, LinearLayout.LayoutParams(-1, c.dp(if (landscape) 80 else 112)))
        val labels = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(8)) }
        labels.addView(Designs.label(c, item.name, 14f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2))
        if (landscape) {
            artwork.addView(View(c).apply { background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(col("#E60B1421"), Color.TRANSPARENT)) }, FrameLayout.LayoutParams(-1, -1))
            labels.addView(Designs.label(c, if (style == "studio") Repo.progressOf(item).second.ifBlank { c.getString(R.string.series) } else c.getString(if (item.kind == "series") R.string.series else R.string.movies), 11f, true))
            artwork.addView(labels, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        } else card.addView(labels)
        val progress = Repo.progressOf(item).first.coerceIn(0, 100)
        if (landscape && progress > 0) card.addView(WatchBar(c).apply { pct = progress }, LinearLayout.LayoutParams(-1, c.dp(3)))
        return card
    }

    private fun card(item: Item, landscape: Boolean): View {
        if (style in listOf("cinema", "studio")) return cinemaCard(item, landscape)
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; isFocusable = true; isClickable = true
            tag = "item:${item.id}"; contentDescription = item.name
            background = Designs.panel(c); clipToOutline = true
            setOnClickListener { open(item) }; setOnLongClickListener { menu(item); true }
            setOnFocusChangeListener { _, focused ->
                background = Designs.panel(c, focus = focused)
                setPadding(c.dp(if (focused) 3 else 1), c.dp(if (focused) 3 else 1), c.dp(if (focused) 3 else 1), c.dp(if (focused) 3 else 1))
                animate().alpha(if (focused) 1f else 0.92f).setDuration(100).start()
            }
            setPadding(c.dp(1), c.dp(1), c.dp(1), c.dp(1))
        }
        val image = VisiblePosterView(c).apply { scaleType = if (item.kind == "live") ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP; background = Designs.panel(c) }
        card.addView(image, LinearLayout.LayoutParams(-1, c.dp(if (landscape) 90 else if (Designs.night(style)) 184 else 158))); image.setPoster(item.logo)
        card.addView(Designs.label(c, item.name, 14f).apply { setPadding(c.dp(9), c.dp(7), c.dp(9), c.dp(7)); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, c.dp(36)))
        val progress = Repo.progressOf(item).first.coerceIn(0, 100)
        if (progress > 0 && item.kind != "live") {
            card.addView(ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; this.progress = progress; progressTintList = android.content.res.ColorStateList.valueOf(Th.acc) }, LinearLayout.LayoutParams(-1, c.dp(4)))
        }
        return card
    }
}

/** Small previews in the appearance picker, including the retained player/detail controls. */
class StyleSketch(c: Context, private val kind: String) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val palette = Designs.palette(if (kind in Designs.ids) kind else Repo.s("ui", "cinema"))
        fun rect(l: Float, t: Float, r: Float, b: Float, color: Int) {
            paint.color = color
            canvas.drawRoundRect(RectF(l * width, t * height, r * width, b * height), 5f, 5f, paint)
        }
        rect(0f, 0f, 1f, 1f, palette.from)
        if (Designs.night(kind)) {
            rect(.02f, .04f, .17f, .96f, palette.card)
            rect(.04f, .18f, .15f, .24f, palette.acc)
            rect(.20f, .05f, .97f, .50f, palette.card)
            rect(.24f, .13f, .57f, .18f, palette.acc)
            rect(.24f, .37f, .39f, .43f, palette.acc)
            for (n in 0..2) rect(.76f, .10f + n * .12f, .94f, .19f + n * .12f, palette.from)
            for (n in 0..2) rect(.20f + n * .26f, .56f, .44f + n * .26f, .70f, palette.card)
            for (n in 0..4) rect(.20f + n * .16f, .78f, .34f + n * .16f, .96f, palette.card)
            return
        }
        if (kind == "cinema") {
            rect(.02f, .04f, .12f, .96f, palette.card)
            rect(.045f, .12f, .095f, .19f, palette.acc)
            rect(.15f, .05f, .97f, .46f, palette.card)
            rect(.19f, .15f, .44f, .20f, palette.acc)
            rect(.19f, .33f, .34f, .39f, palette.acc)
            for (n in 0..2) rect(.15f + n * .28f, .51f, .40f + n * .28f, .66f, palette.card)
            for (n in 0..4) rect(.15f + n * .17f, .73f, .30f + n * .17f, .95f, palette.card)
            return
        }
        if (kind == "live") {
            rect(.04f, .05f, .96f, .14f, palette.card)
            rect(.04f, .20f, .58f, .58f, palette.card); rect(.63f, .23f, .94f, .30f, palette.acc)
            rect(.63f, .46f, .85f, .55f, palette.acc)
            for (n in 0..4) rect(.04f + n * .185f, .65f, .205f + n * .185f, .76f, palette.card)
            rect(.04f, .83f, .96f, .96f, palette.card)
            return
        } else {
            val compact = Designs.night(kind)
            rect(if (compact) .88f else .77f, .05f, .98f, .95f, palette.card)
            rect(.04f, .08f, if (compact) .84f else .73f, .60f, palette.acc)
            rect(.1f, .4f, .4f, .45f, palette.from)
        }
        for (n in 0..3) rect(.04f + n * .18f, .76f, .19f + n * .18f, .96f, palette.card)
    }
}
