package com.sultv.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

internal data class GunnersStation(val name: String, val logo: String, val markets: List<Int>)
internal data class GunnersTeam(val name: String, val slug: String, val logo: String, val id: Int = 0) {
    val key: String get() = if (id > 0) id.toString() else slug.ifBlank { GunnersData.normalize(name) }
}
internal data class GunnersSchedule(val today: List<GunnersMatch>, val choices: List<GunnersMatch>)
internal data class GunnersMatch(
    val id: Int, val competitionId: Int, val league: String, val home: GunnersTeam, val away: GunnersTeam,
    val kickoff: Long, val live: Boolean, val finished: Boolean, val score: String, val leagueLogo: String
) {
    val title get() = "${home.name} × ${away.name}"
}

internal object GunnersData {
    private const val imageBase = "https://imagecache.365scores.com/image/upload/f_png,w_96,h_96,c_limit/"
    private const val scheduleUrl = "https://www.thesportsdb.com/api/v1/json/123/eventstv.php"
    val countries = listOf("MENA" to R.string.gunners_mena, "US" to R.string.gunners_us, "GB" to R.string.gunners_gb)
    private val middleEast = mapOf(
        "Saudi Arabia" to R.string.gunners_sa,
        "United Arab Emirates" to R.string.gunners_ae,
        "Qatar" to R.string.gunners_qa,
        "Egypt" to R.string.gunners_eg,
        "Morocco" to R.string.gunners_ma
    )
    private val tvRows by lazy { android.util.LruCache<String, Pair<Long, List<JSONObject>>>(20) }
    private val versus = Regex("(?i)\\s+(?:vs\\.?|v\\.|v|ضد|×)\\s+")
    private val punctuation = Regex("[^\\p{L}\\p{N}]+")
    private val marks = Regex("\\p{M}+")
    private val quality = Regex("\\b(?:sd|hd|fhd|uhd|4k|8k|720p|1080p|2160p|hevc|h265|h264)\\b")
    private val region = Regex("^\\s*(?:\\[[A-Za-z]{2}\\]|[A-Za-z]{2}\\s*[|:])\\s*")
    private val channelPrefix = Regex("^(?:sa|us|uk|gb|ar|en)\\s+(?:-\\s*)?", RegexOption.IGNORE_CASE)

    fun normalize(value: String): String = punctuation.replace(
        marks.replace(java.text.Normalizer.normalize(value.lowercase(Locale.ROOT), java.text.Normalizer.Form.NFD), ""),
        " "
    ).trim()

    fun channelKey(name: String): String = normalize(quality.replace(channelPrefix.replace(region.replace(name, ""), "").lowercase(Locale.ROOT), ""))
        .replace(" ", "")

    private fun time(value: String): Long {
        val iso = value.replace(Regex("\\.\\d+(?=Z|[+-])"), "")
            .replace(Regex("([+-]\\d{2}):(\\d{2})$"), "$1$2").replace("Z", "+0000")
        return runCatching { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).apply { isLenient = false }.parse(iso)?.time ?: 0 }.getOrDefault(0)
    }

    private fun objects(array: JSONArray?) = (0 until (array?.length() ?: 0)).mapNotNull { array?.optJSONObject(it) }

    fun day(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun leagueLogo(id: Int) = imageBase + "Competitions/$id"

    private fun team(json: JSONObject): GunnersTeam {
        val version = json.optInt("imageVersion")
        val crest = imageBase + (if (version > 0) "v$version/" else "") + "Competitors/" + json.optInt("id")
        return GunnersTeam(json.optString("name"), json.optString("nameForURL"), crest, json.optInt("id"))
    }

    fun teamsForLeague(id: Int, arabic: Boolean): List<GunnersTeam> {
        val lang = if (arabic) 27 else 1
        val response = JSONObject(Repo.http("https://webws.365scores.com/web/standings/?appTypeId=5&langId=$lang&competitions=$id"))
        return objects(response.optJSONArray("standings")).filter { it.optInt("competitionId") == id }
            .flatMap { objects(it.optJSONArray("rows")) }
            .mapNotNull { it.optJSONObject("competitor") }.map(::team)
            .filter { it.id > 0 && it.name.isNotBlank() }.distinctBy { it.id }
    }

    fun fixtures(arabic: Boolean): GunnersSchedule {
        val tz = TimeZone.getDefault()
        // The feed uses Riyadh calendar dates. Include adjacent dates before selecting the device's day.
        val now = Date()
        val riyadh = SimpleDateFormat("dd/MM/yyyy", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Riyadh") }
        val local = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }
        val start = riyadh.format(Date(now.time - 86_400_000L))
        val end = riyadh.format(Date(now.time + 86_400_000L))
        val lang = if (arabic) 27 else 1
        val response = JSONObject(Repo.http("https://webws.365scores.com/web/games/allscores/?appTypeId=5&langId=$lang&sports=1&timezoneName=Asia%2FRiyadh&startDate=$start&endDate=$end"))
        val leagues = objects(response.optJSONArray("competitions")).associateBy { it.optInt("id") }
        val today = local.format(now)
        val fixtures = objects(response.optJSONArray("games")).mapNotNull { game ->
            val kickoff = time(game.optString("startTime"))
            val home = game.optJSONObject("homeCompetitor") ?: return@mapNotNull null
            val away = game.optJSONObject("awayCompetitor") ?: return@mapNotNull null
            if (kickoff == 0L) return@mapNotNull null
            val leagueId = game.optInt("competitionId")
            val league = leagues[leagueId]?.optString("name").orEmpty().ifBlank { game.optString("competitionDisplayName") }
            val state = game.optInt("statusGroup")
            val score = if (state in 3..4 && home.has("score") && away.has("score"))
                "${home.optInt("score")} – ${away.optInt("score")}" else ""
            GunnersMatch(game.optInt("id"), leagueId, league, team(home), team(away), kickoff, state == 3, state == 4, score,
                leagueLogo(leagueId))
        }.sortedBy { it.kickoff }
        return GunnersSchedule(fixtures.filter { local.format(Date(it.kickoff)) == today }, fixtures)
    }

    fun filter(matches: List<GunnersMatch>, leagues: Set<Int>, team: String): List<GunnersMatch> =
        matches.filter { match ->
            (leagues.isEmpty() && team.isEmpty()) || match.competitionId in leagues ||
                (team.isNotEmpty() && (match.home.key == team || match.away.key == team))
        }

    private fun listings(date: String, market: String): List<JSONObject> {
        val cacheKey = "$date|$market"
        val now = System.currentTimeMillis()
        tvRows.get(cacheKey)?.let { (saved, rows) ->
            if (now - saved in 0 until 300_000) return rows
        }
        val encodedMarket = URLEncoder.encode(market, "UTF-8")
        val connection = URL("$scheduleUrl?d=$date&s=Soccer&a=$encodedMarket").openConnection() as HttpURLConnection
        connection.connectTimeout = 7_000
        connection.readTimeout = 8_000
        NetworkWork.track(connection)
        val rows = try {
            connection.inputStream.bufferedReader().use { objects(JSONObject(it.readText()).optJSONArray("tvevents")) }
        } finally {
            NetworkWork.finish(connection)
        }
        tvRows.put(cacheKey, now to rows)
        return rows
    }

    private fun teamMatches(value: String, team: GunnersTeam): Boolean {
        val name = normalize(value)
        val aliases = listOf(normalize(team.name), normalize(team.slug)).filter { it.length >= 3 }
        return aliases.any { alias -> " $name ".contains(" $alias ") || name.length >= 4 && " $alias ".contains(" $name ") }
    }

    internal fun stationsForMatch(match: GunnersMatch, market: String, label: Int, rows: List<JSONObject>): List<GunnersStation> =
        rows.mapNotNull { record ->
            if (!record.optString("strCountry").equals(market, true)) return@mapNotNull null
            val teams = record.optString("strEvent").split(versus, limit = 2)
            if (teams.size != 2 || !teamMatches(teams[0], match.home) || !teamMatches(teams[1], match.away)) return@mapNotNull null
            val kickoff = time(record.optString("strTimeStamp").replace(' ', 'T') + "Z")
            if (kickoff == 0L || kotlin.math.abs(kickoff - match.kickoff) > 45 * 60_000L) return@mapNotNull null
            val name = record.optString("strChannel").trim().takeIf(String::isNotBlank) ?: return@mapNotNull null
            val logo = record.optString("strLogo").takeIf { it.startsWith("https://") }.orEmpty()
            GunnersStation(name, logo, listOf(label))
        }

    fun broadcasters(match: GunnersMatch, country: String): List<GunnersStation> {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(match.kickoff))
        val markets = when (country) {
            "MENA" -> middleEast
            "US" -> mapOf("United States" to R.string.gunners_us)
            "GB" -> mapOf("United Kingdom" to R.string.gunners_gb)
            else -> return emptyList()
        }
        var failures = 0
        val stations = markets.flatMap { (market, label) ->
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            try {
                stationsForMatch(match, market, label, listings(date, market))
            } catch (error: java.io.IOException) {
                if (Thread.currentThread().isInterrupted) throw error
                if (++failures == markets.size) throw error
                emptyList()
            } catch (error: org.json.JSONException) {
                if (++failures == markets.size) throw error
                emptyList()
            }
        }
        return stations.groupBy { channelKey(it.name) }.values.map { listings ->
            listings.first().copy(markets = listings.flatMap { it.markets }.distinct())
        }
    }

    private val recordedProgramme = Regex(
        "(?:^| )(?:ملخص|ملخصات|اعادة|استوديو|استديو|highlights|replay|rerun|preview|pre match|post match)(?: |$)"
    )

    internal fun guideMatches(match: GunnersMatch, programme: Prog): Boolean {
        if (programme.stop <= match.kickoff || programme.stop - programme.start < 40 * 60_000L) return false
        if (programme.start !in (match.kickoff - 45 * 60_000L)..(match.kickoff + 30 * 60_000L)) return false
        val title = normalize(programme.title)
        if (recordedProgramme.containsMatchIn(title)) return false
        val homeAliases = listOf(match.home.name, match.home.slug).map(::normalize).filter { it.length >= 3 }.distinct()
        val awayAliases = listOf(match.away.name, match.away.slug).map(::normalize).filter { it.length >= 3 }.distinct()
        fun mentions(text: String): Boolean {
            val words = " $text "
            return homeAliases.any { home ->
                awayAliases.any { away -> home != away && words.contains(" $home ") && words.contains(" $away ") }
            }
        }
        return mentions(title) || mentions(normalize(programme.title + " " + programme.desc))
    }

    fun guideChannels(match: GunnersMatch): List<AudioChannel> {
        val (channels, guide) = Repo.guideChannelSnapshot()
        val checks = HashMap<String, Boolean>()
        return channels.filter { channel ->
            ListUpdates.checkCancelled()
            val guideId = channel.item.epg.lowercase()
            checks.getOrPut(guideId) {
                guide[guideId].orEmpty().asSequence()
                    .dropWhile { it.start < match.kickoff - 45 * 60_000L }
                    .takeWhile { it.start <= match.kickoff + 30 * 60_000L }
                    .any { guideMatches(match, it) }
            }
        }.distinctBy { it.item.url }
    }

    fun variants(broadcaster: String): List<AudioChannel> {
        val key = channelKey(broadcaster)
        if (key.isBlank()) return emptyList()
        return Repo.visiblePlaylists().flatMap { playlist ->
            Repo.audioChannels(playlist, cachedOnly = true).orEmpty().filter {
                channelKey(it.item.name) == key && it.item.url.isNotBlank()
            }
        }.distinctBy { it.item.url }
    }
}
