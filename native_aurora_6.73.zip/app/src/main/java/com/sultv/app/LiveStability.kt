package com.sultv.app

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

/** Uses buffer and playback events from the current live channel. */
internal class LiveStability {
    private val lowBuffer = ArrayDeque<Long>()
    private val interruptions = ArrayDeque<Long>()
    private var firstPlayingAt: Long? = null
    private var previousRebuffers = 0
    var level = 0
        private set

    fun sample(now: Long, playing: Boolean, buffering: Boolean, bufferedMs: Long, rebuffers: Int) {
        if (playing && firstPlayingAt == null) firstPlayingAt = now
        while (lowBuffer.isNotEmpty() && now - lowBuffer.first() >= 30_000) lowBuffer.removeFirst()
        while (interruptions.isNotEmpty() && now - interruptions.first() >= 30_000) interruptions.removeFirst()
        if (playing && bufferedMs < 3_000) lowBuffer.addLast(now)
        if (firstPlayingAt != null && rebuffers > previousRebuffers) {
            repeat((rebuffers - previousRebuffers).coerceAtMost(2)) { interruptions.addLast(now) }
        }
        previousRebuffers = rebuffers
        level = when {
            firstPlayingAt == null || !playing && !buffering -> 0
            interruptions.size >= 2 -> 1
            buffering || interruptions.isNotEmpty() || lowBuffer.size >= 5 -> 2
            now - (firstPlayingAt ?: now) < 5_000 -> 0
            lowBuffer.isNotEmpty() -> 3
            else -> 4
        }
    }
}

internal class LiveStabilityIcon : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val arc = RectF()
    private var opacity = 255

    override fun draw(canvas: Canvas) {
        val saved = canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        canvas.scale(bounds.width() / 24f, bounds.height() / 24f)
        val active = when (level) {
            1 -> col("#FF7882")
            2 -> col("#F7C86C")
            3 -> col("#82B6FF")
            4 -> col("#56EDAF")
            else -> col("#75839D")
        }
        for (segment in 4 downTo 2) {
            val radius = (segment - 1) * 4f
            arc.set(12f - radius, 19f - radius, 12f + radius, 19f + radius)
            paint.color = if (level >= segment) active else col("#75839D")
            paint.alpha = if (level >= segment) opacity else opacity * 2 / 3
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.3f
            canvas.drawArc(arc, 225f, 90f, false, paint)
        }
        paint.color = active
        paint.alpha = opacity
        paint.style = Paint.Style.FILL
        canvas.drawCircle(12f, 19f, 1.65f, paint)
        canvas.restoreToCount(saved)
    }

    override fun onLevelChange(level: Int): Boolean {
        invalidateSelf()
        return true
    }

    override fun setAlpha(alpha: Int) { opacity = alpha; invalidateSelf() }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter; invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
