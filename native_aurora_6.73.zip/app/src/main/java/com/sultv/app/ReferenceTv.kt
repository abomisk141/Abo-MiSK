package com.sultv.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.graphics.ColorUtils

/** Measurements are in TV dp; text still respects the user's accessibility font scale. */
object ReferenceLook {
    val font: Typeface get() = if (Th.name in listOf("cinema", "reference")) Typeface.create(when (Repo.s("ft", "sys")) {
        "light" -> "sans-serif-light"; "med" -> "sans-serif-medium"; "cond" -> "sans-serif-condensed"; "serif" -> "serif"; else -> "sans-serif"
    }, Typeface.NORMAL) else Typeface.create("sans-serif-condensed", Typeface.BOLD)
    fun selection(c: Context, selected: Boolean, focused: Boolean): GradientDrawable {
        if (Th.name == "studio") return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (focused || selected) intArrayOf(col("#075777"), col("#533493")) else intArrayOf(Th.card, Th.card)
        ).apply {
            cornerRadius = c.dp(9).toFloat()
            if (focused) setStroke(c.dp(2), col("#A6DFFA"))
        }
        if (Th.name == "aurora") return GradientDrawable().apply {
            setColor(if (selected) Th.acc else if (focused) col("#33FFFFFF") else Th.card)
            cornerRadius = c.dp(18).toFloat()
            if (focused) setStroke(c.dp(3), if (selected) Th.fg else Th.acc)
        }
        if (Th.name == "cinema") return GradientDrawable().apply {
            setColor(if (selected || focused) ColorUtils.blendARGB(Th.acc, Th.card, .90f) else Th.card)
            cornerRadius = c.dp(10).toFloat()
            if (focused) setStroke(c.dp(2), Th.acc)
        }
        if (Th.name == "reference") return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(ColorUtils.blendARGB(Th.card, Th.acc, if (selected || focused) .24f else .03f), Th.card)).apply {
            cornerRadius = c.dp(9).toFloat()
            if (focused) setStroke(c.dp(2), Th.acc)
            else if (selected) setStroke(c.dp(1), ColorUtils.setAlphaComponent(Th.acc, 110))
        }
        val active = intArrayOf(ColorUtils.blendARGB(Th.acc, Th.bgFrom, 0.2f), Th.acc)
        val idle = intArrayOf(Th.card, Th.card)
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, if (selected || focused) active else idle).apply {
            cornerRadius = c.dp(14).toFloat()
            if (focused) setStroke(c.dp(2), Th.fg)
        }
    }

}

class ReferenceNav(c: Context, val key: String, private val title: String, icon: Int) : LinearLayout(c) {
    private val image = ImageView(c)
    private val iconBox = FrameLayout(c)
    private val label = TextView(c)
    private val countLabel = TextView(c)
    private val iconsOnly = HomePreferences.railMode("reference") == "icons"
    private val textOption = Repo.s(HomePreferences.key("reference", "navText"))
    private val labelPosition = Repo.s(HomePreferences.key("reference", "navLabelPosition"))
    private val iconSize = c.dp(if (Repo.s(HomePreferences.key("reference", "navIcons")) == "small") 19 else 25)
    private var active = false
    private var expanded = false
    init {
        id = View.generateViewId(); tag = "ref-nav:$key"
        isFocusable = true; isClickable = true; contentDescription = title
        layoutDirection = c.resources.configuration.layoutDirection
        image.setImageResource(icon)
        iconBox.addView(image, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
        label.setTextColor(Color.WHITE); label.typeface = ReferenceLook.font; label.maxLines = 1
        label.ellipsize = android.text.TextUtils.TruncateAt.END
        countLabel.textSize = 11f; countLabel.typeface = ReferenceLook.font; countLabel.setTextColor(Th.mut)
        addView(iconBox); addView(label); addView(countLabel)
        setOnFocusChangeListener { _, _ -> paint(active) }
        expand(false)
    }
    fun expand(value: Boolean) {
        expanded = value
        val beside = labelPosition == "beside" || value && labelPosition != "under"
        orientation = if (beside) HORIZONTAL else VERTICAL
        gravity = if (beside) Gravity.CENTER_VERTICAL else Gravity.CENTER
        setPadding(context.dp(if (value) 9 else 3), context.dp(5), context.dp(if (value) 9 else 3), context.dp(5))
        label.text = if (!value && key == "live") context.getString(R.string.ref_live_short) else title
        label.textSize = if (textOption == "small") { if (value) 13f else 8f } else if (value) 16f else 9f
        iconBox.layoutParams = LayoutParams(context.dp(if (value) 36 else 30), context.dp(if (value) 36 else 30))
        label.layoutParams = if (beside) LayoutParams(0, -2, 1f).apply { marginStart = context.dp(9) } else LayoutParams(-2, -2).apply { topMargin = context.dp(2) }
        countLabel.visibility = if (value && beside && textOption != "never" && countLabel.text.isNotEmpty()) View.VISIBLE else View.GONE
        paint(active)
    }
    fun count(n: Int) { countLabel.text = if (n > 0) n.toString() else ""; countLabel.visibility = if (expanded && orientation == HORIZONTAL && textOption != "never" && n > 0) View.VISIBLE else View.GONE }
    fun paint(selected: Boolean) {
        active = selected; isSelected = selected
        label.visibility = if (!iconsOnly && textOption != "never" && (textOption != "icons" || hasFocus())) View.VISIBLE else View.GONE
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            if (selected) intArrayOf(ColorUtils.blendARGB(Th.card, Th.acc, .30f), Th.card)
            else intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT)).apply {
            cornerRadius = context.dp(16).toFloat()
            if (hasFocus()) setStroke(context.dp(2), Th.acc)
        }
        iconBox.background = GradientDrawable().apply {
            cornerRadius = context.dp(11).toFloat()
            setColor(if (expanded) ColorUtils.setAlphaComponent(Th.acc, if (selected) 35 else 45) else Color.TRANSPARENT)
        }
        label.setTextColor(Th.fg)
        countLabel.setTextColor(Th.mut)
        image.imageTintList = android.content.res.ColorStateList.valueOf(if (selected) Th.acc else Th.fg)
    }
}

/** Overlay expansion keeps categories and channel columns stationary, as in the reference. */
class ReferenceRail(
    private val c: Context, tabs: List<Triple<String, Int, Int>>,
    navigate: (String) -> Unit, settingsClick: () -> Unit, exitToCategories: () -> Unit
) {
    val root = LinearLayout(c)
    val buttons = linkedMapOf<String, View>()
    val settings: ReferenceNav
    var expanded = false
        private set
    private var animator: ValueAnimator? = null
    private var selected = "live"
    private val heading = LinearLayout(c)
    private val brand = LinearLayout(c)
    private val name = TextView(c)
    init {
        root.tag = "reference-rail"; root.layoutDirection = c.resources.configuration.layoutDirection
        root.orientation = LinearLayout.VERTICAL; root.setPadding(c.dp(7), c.dp(12), c.dp(7), c.dp(10))
        root.elevation = c.dp(14).toFloat()
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(ColorUtils.blendARGB(Th.bgFrom, Th.bgTo, 0.25f), Th.bgFrom)).apply {
            setStroke(c.dp(1), ColorUtils.setAlphaComponent(Th.acc, 70))
        }
        heading.gravity = Gravity.CENTER
        heading.addView(ImageView(c).apply { setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(c.dp(38), c.dp(38)))
        brand.orientation = LinearLayout.VERTICAL; brand.gravity = Gravity.CENTER
        name.text = "ABO MISK"; name.textSize = 17f; name.typeface = ReferenceLook.font; name.setTextColor(Color.WHITE)
        brand.addView(name)
        brand.addView(TextClock(c).apply { format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 12f; typeface = ReferenceLook.font; setTextColor(Th.mut) })
        heading.addView(brand)
        root.addView(heading, LinearLayout.LayoutParams(-1, c.dp(72)))
        val icons = mapOf("live" to R.drawable.ic_tv, "movie" to R.drawable.ic_ref_movie, "series" to R.drawable.ic_ref_series, "list" to R.drawable.ic_ref_bookmark)
        for ((key, res, _) in tabs) {
            val title = c.getString(if (key == "live") R.string.ref_live_sports else res)
            val item = ReferenceNav(c, key, title, icons[key] ?: R.drawable.ic_home)
            item.setOnClickListener { navigate(key); expand(false) }
            wireExit(item, exitToCategories)
            buttons[key] = item
            root.addView(item, LinearLayout.LayoutParams(-1, c.dp(64)).apply { topMargin = c.dp(5) })
        }
        root.addView(View(c), LinearLayout.LayoutParams(1, 0, 1f))
        settings = ReferenceNav(c, "settings", c.getString(R.string.settings), R.drawable.ic_settings)
        settings.setOnClickListener { settingsClick() }; wireExit(settings, exitToCategories)
        root.addView(settings, LinearLayout.LayoutParams(-1, c.dp(54)))
        val ordered = buttons.values.toList() + settings
        ordered.forEachIndexed { index, view ->
            view.nextFocusUpId = ordered[(index - 1).coerceAtLeast(0)].id
            view.nextFocusDownId = ordered[(index + 1).coerceAtMost(ordered.lastIndex)].id
        }
        val focusListener = ViewTreeObserver.OnGlobalFocusChangeListener { _, focus ->
            val inside = focus != null && (buttons.values.any { it === focus } || focus === settings)
            expand(inside)
        }
        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) { v.viewTreeObserver.addOnGlobalFocusChangeListener(focusListener) }
            override fun onViewDetachedFromWindow(v: View) { animator?.cancel(); if (v.viewTreeObserver.isAlive) v.viewTreeObserver.removeOnGlobalFocusChangeListener(focusListener) }
        })
        presentation(false)
    }
    private fun wireExit(item: View, exit: () -> Unit) {
        val towardContent = if (c.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        item.setOnKeyListener { _, code, event ->
            when (code) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (event.action == KeyEvent.ACTION_DOWN) {
                        val ordered = buttons.values.toList() + settings
                        val index = ordered.indexOf(item)
                        val next = (index + if (code == KeyEvent.KEYCODE_DPAD_DOWN) 1 else -1).coerceIn(0, ordered.lastIndex)
                        ordered[next].requestFocus()
                    }
                    true
                }
                towardContent -> if (event.action == KeyEvent.ACTION_DOWN) { exit(); true } else false
                else -> false
            }
        }
    }
    private fun presentation(value: Boolean) {
        heading.orientation = if (value) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        brand.gravity = if (value) Gravity.START else Gravity.CENTER
        brand.setPadding(c.dp(if (value) 9 else 0), 0, 0, 0)
        name.visibility = if (value && Repo.s(HomePreferences.key("reference", "navText")) != "never") View.VISIBLE else View.GONE
        buttons.values.forEach { (it as ReferenceNav).expand(value) }
        settings.expand(value)
    }
    private fun expand(value: Boolean) {
        if (HomePreferences.railMode("reference") == "icons" || expanded == value) return
        expanded = value; presentation(value)
        animator?.cancel()
        val lp = root.layoutParams as? FrameLayout.LayoutParams ?: return
        val target = c.dp(if (value) 224 else 72)
        animator = ValueAnimator.ofInt(lp.width, target).apply {
            duration = 160
            addUpdateListener { root.layoutParams = (root.layoutParams as FrameLayout.LayoutParams).apply { width = it.animatedValue as Int } }
            start()
        }
    }
    fun select(key: String) { selected = key; buttons.forEach { (k, view) -> (view as ReferenceNav).paint(k == key) } }
    fun counts(values: Map<String, Int>) { buttons.forEach { (key, view) -> (view as ReferenceNav).count(values[key] ?: 0) } }
    fun focusSelected() { (buttons[selected] ?: buttons.values.firstOrNull())?.requestFocus() }
}
