package com.sultv.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

internal class GunnersHomeView(
    private val context: Context,
    private val navigate: (String) -> Unit,
    private val play: (Item) -> Unit,
    private val closeDetails: (() -> Unit)? = null
) : HomeLike {
    override val root = ScrollView(context).apply { isFillViewport = true; isVerticalScrollBarEnabled = false }
    private val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val work = SerialWork()
    private val lookup = LatestWork()
    private val main = Handler(Looper.getMainLooper())
    private val red = if (closeDetails == null) col("#FA3A54") else Th.acc
    private val navy = if (closeDetails == null) col("#EB0B1428") else Th.bgFrom
    private val white = col("#F7F8FD")
    private var running = false
    private var loading = false
    private var failure = false
    private var games = emptyList<GunnersMatch>()
    private var updatedAt = 0L
    private var day = ""
    private var selected: GunnersMatch? = null
    private var nearbyFixtures = emptyList<GunnersMatch>()
    private var limit = 18
    private var country = "MENA"
    private var rendered = false
    private var pendingGuide: (() -> Unit)? = null
    fun onGuideUpdated() {
        val reload = pendingGuide
        pendingGuide = null
        reload?.invoke()
    }

    private val refresh = object : Runnable {
        override fun run() {
            if (!running) return
            load()
            main.postDelayed(this, 120_000)
        }
    }

    init {
        root.addView(body, FrameLayout.LayoutParams(-1, -2))
        if (closeDetails != null) {
            root.background = Designs.panel(context, Th.bgFrom, radius = 18)
            root.clipToOutline = true
            val inset = context.dp(14)
            body.setPadding(inset, inset, inset, inset)
        }
    }

    override fun start() {
        if (running) return
        running = true
        if (selected != null) draw()
        if (closeDetails == null) refresh.run()
    }

    override fun stop() {
        running = false
        main.removeCallbacks(refresh)
        lookup.cancel()
        pendingGuide = null
    }

    override fun destroy() {
        stop()
        main.removeCallbacksAndMessages(null)
        work.close()
        lookup.close()
    }

    private fun load(force: Boolean = false) {
        if (loading || !force && day == GunnersData.day() && System.currentTimeMillis() - updatedAt < 120_000) return
        loading = true
        failure = false
        if (games.isEmpty()) draw()
        val arabic = context.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        work.submit {
            val result = runCatching { GunnersData.fixtures(arabic) }
            main.post {
                loading = false
                failure = result.isFailure
                if (result.isSuccess) {
                    val currentDay = GunnersData.day()
                    day = currentDay
                    updatedAt = System.currentTimeMillis()
                    val schedule = result.getOrThrow()
                    games = schedule.today
                    nearbyFixtures = schedule.choices
                    selected = selected?.let { old -> games.firstOrNull { it.id == old.id } }
                }
                if (running && (selected == null || force || games.isEmpty())) draw()
            }
        }
    }

    override fun render() { if (!rendered) draw() }
    fun openMatch(match: GunnersMatch) {
        selected = match
        if (running) {
            draw()
            focusBroadcastCountry()
        }
    }

    fun focusSchedule() {
        root.post { body.findViewWithTag<View>("gunners-leagues")?.requestFocus() }
    }

    private fun text(value: String, size: Float, color: Int = white) = TextView(context).apply {
        text = value; textSize = size; setTextColor(color)
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun card(color: Int = navy, focus: Boolean = false) = GradientDrawable().apply {
        cornerRadius = context.dp(14).toFloat()
        colors = if (focus && closeDetails == null) intArrayOf(col("#762031"), col("#351429")) else intArrayOf(color, color)
        orientation = GradientDrawable.Orientation.TL_BR
        setStroke(context.dp(if (focus) 2 else 1), if (focus) (if (closeDetails == null) col("#FFF1F3") else Th.acc) else col("#52617D"))
    }

    private fun action(value: String, selected: Boolean = false, click: (View) -> Unit) = text(value, 15f).apply {
        gravity = Gravity.CENTER
        maxLines = 2
        minimumHeight = context.dp(43)
        typeface = Typeface.DEFAULT_BOLD
        val inset = context.dp(9)
        setPadding(inset, inset / 2, inset, inset / 2)
        isClickable = true; isFocusable = true
        val selectedColor = if (closeDetails == null) col("#B3213B") else Th.card
        background = card(if (selected) selectedColor else navy)
        setOnClickListener(click)
        setOnFocusChangeListener { view, focused ->
            view.background = card(if (selected) selectedColor else navy, focused)
            view.scaleX = if (focused) 1.025f else 1f
            view.scaleY = if (focused) 1.025f else 1f
        }
    }

    /** Backdrop layers fill the card without contributing their bitmap dimensions to its size. */
    private fun backdrop(): FrameLayout = object : FrameLayout(context) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val content = getChildAt(childCount - 1)
            if (content == null) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec)
                return
            }
            measureChildWithMargins(content, widthMeasureSpec, 0, heightMeasureSpec, 0)
            val height = resolveSize(maxOf(suggestedMinimumHeight, content.measuredHeight + paddingTop + paddingBottom), heightMeasureSpec)
            super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY))
        }
    }

    private fun shortcut(label: String, image: Int, icon: Int, tab: String): View = backdrop().apply {
        tag = "gunners-shortcut-$tab"
        background = card()
        clipToOutline = true
        addView(ImageView(context).apply {
            setImageResource(image); scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        addView(View(context).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(col("#F10B1428"), col("#880B1428")))
        }, FrameLayout.LayoutParams(-1, -1))
        addView(action(label) { navigate(tab) }.apply {
            tag = "gunners-shortcut-button-$tab"
            minimumHeight = context.dp(72)
            background = card(Color.TRANSPARENT)
            setOnFocusChangeListener { view, focused -> view.background = card(Color.TRANSPARENT, focused) }
            val glyph = Th.icon(context, icon, red)
            glyph?.setBounds(0, 0, context.dp(26), context.dp(26))
            setCompoundDrawablesRelative(glyph, null, null, null)
        }, FrameLayout.LayoutParams(-1, -2))
    }

    private fun column() = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
    private fun row() = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; clipChildren = false; clipToPadding = false }
    private fun add(parent: LinearLayout, child: View, gap: Int = 8) {
        parent.addView(child, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(gap) })
    }

    private fun team(team: GunnersTeam) = column().apply {
        gravity = Gravity.CENTER
        addView(ImageView(context).apply { scaleType = ImageView.ScaleType.FIT_CENTER; Img.load(this, team.logo) },
            LinearLayout.LayoutParams(context.dp(56), context.dp(56)))
        addView(text(team.name, 19f).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; maxLines = 2 })
    }

    private fun hero(match: GunnersMatch?, filtered: Boolean, showBroadcasts: (GunnersMatch) -> Unit): View = backdrop().apply {
        minimumHeight = context.dp(230)
        background = card()
        clipToOutline = true
        addView(ImageView(context).apply { setImageResource(R.drawable.gunners_stadium); scaleType = ImageView.ScaleType.CENTER_CROP },
            FrameLayout.LayoutParams(-1, -1))
        addView(View(context).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(col("#42101D36"), col("#EE0A1123")))
        }, FrameLayout.LayoutParams(-1, -1))
        val details = column().apply {
            val padding = context.dp(15)
            setPadding(padding, padding, padding, padding)
            val league = row().apply {
                if (match != null) addView(ImageView(context).apply { Img.load(this, match.leagueLogo) },
                    LinearLayout.LayoutParams(context.dp(28), context.dp(28)).apply { marginEnd = context.dp(6) })
                addView(text(match?.league ?: context.getString(R.string.gunners_today), 15f, col("#E8ECF8")))
            }
            add(this, league)
            if (match == null) {
                add(this, text(context.getString(if (loading) R.string.loading else if (failure) R.string.gunners_fetch_failed else if (filtered) R.string.gunners_filtered_empty else R.string.gunners_empty), 22f)
                    .apply { tag = "gunners-loading"; minHeight = context.dp(100) })
                if (failure) add(this, action(context.getString(R.string.gunners_retry)) { load(true) })
            } else {
                val clubs = row().apply {
                    addView(team(match.home), LinearLayout.LayoutParams(0, -2, 1f))
                    addView(text("×", 27f, red))
                    addView(team(match.away), LinearLayout.LayoutParams(0, -2, 1f))
                }
                add(this, clubs)
                add(this, text(matchTime(match), 21f).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD })
                add(this, action(context.getString(R.string.gunners_broadcasts), true) { showBroadcasts(match) }.apply {
                    tag = "gunners-featured"
                    val glyph = Th.icon(context, R.drawable.ic_n_live, white)
                    glyph?.setBounds(0, 0, context.dp(24), context.dp(24))
                    setCompoundDrawablesRelative(glyph, null, null, null)
                }, 0)
            }
        }
        addView(details, FrameLayout.LayoutParams(-1, -2))
    }

    private val kickoffClock = java.text.SimpleDateFormat("h:mm a", context.resources.configuration.locales[0])
    private fun matchTime(match: GunnersMatch): String {
        kickoffClock.timeZone = java.util.TimeZone.getDefault()
        val time = kickoffClock.format(java.util.Date(match.kickoff))
        return when {
            match.live -> listOf(context.getString(R.string.live_home_badge), match.score).filter(String::isNotBlank).joinToString(" · ")
            match.finished -> match.score.ifBlank { time }
            else -> time
        }
    }

    private fun leagueOptions() = gunnersLeagueOptions(context, nearbyFixtures.ifEmpty { games })

    private fun selectLeagues() {
        val choices = leagueOptions()
        if (choices.isEmpty()) return
        showGunnersPicker(context, context.getString(R.string.gunners_leagues), choices,
            preferredGunnersLeagues().map(Int::toString).toSet(), multiple = true) { picked ->
            saveGunnersLeagues(choices, picked)
            applyFilters("gunners-leagues")
        }
    }

    private fun selectTeam() {
        val savedTeam = Repo.s("gunnersTeam")
        val clear = GunnersOption("", context.getString(R.string.gunners_no_team_filter))
        val selectedLeagues = preferredGunnersLeagues()
        val leagues = leagueOptions().filter { selectedLeagues.isEmpty() || it.key.toIntOrNull() in selectedLeagues }
        val options = leagues + if (savedTeam.isNotEmpty()) listOf(clear) else emptyList()
        if (options.isEmpty()) return
        showGunnersPicker(context, context.getString(R.string.gunners_choose_league), options) { picked ->
            val key = picked.first()
            if (key.isEmpty()) saveTeam(clear)
            else leagues.firstOrNull { it.key == key }?.let(::selectLeagueTeam)
        }
    }

    private fun selectLeagueTeam(league: GunnersOption) {
        val id = league.key.toIntOrNull() ?: return
        val progress = android.widget.ProgressBar(context).apply {
            indeterminateTintList = android.content.res.ColorStateList.valueOf(red)
        }
        val loadingView = row().apply {
            setPadding(context.dp(20), context.dp(14), context.dp(20), context.dp(14))
            addView(progress, LinearLayout.LayoutParams(context.dp(26), context.dp(26)).apply { marginEnd = context.dp(12) })
            addView(text(context.getString(R.string.loading), 16f))
        }
        val wait = AlertDialog.Builder(context).setTitle(league.name).setView(loadingView)
            .setNegativeButton(android.R.string.cancel, null).show()
        val arabic = context.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        val schedule = nearbyFixtures.ifEmpty { games }
        lookup.submit {
            val standings = runCatching { GunnersData.teamsForLeague(id, arabic) }.getOrDefault(emptyList())
            val fixtures = schedule.filter { it.competitionId == id }.flatMap { listOf(it.home, it.away) }
            val teams = (standings.ifEmpty { fixtures }).filter { it.name.isNotBlank() }.distinctBy { it.key }
            main.post {
                if (!running || !wait.isShowing) return@post
                wait.dismiss()
                val choices = teams.map { GunnersOption(it.key, it.name, it.logo) }.sortedBy { it.name }
                if (choices.isEmpty()) {
                    AlertDialog.Builder(context).setTitle(league.name).setMessage(R.string.gunners_no_teams)
                        .setPositiveButton(android.R.string.ok, null).show()
                } else showGunnersPicker(context, league.name, choices, setOf(Repo.s("gunnersTeam"))) { picked ->
                    choices.firstOrNull { it.key in picked }?.let(::saveTeam)
                }
            }
        }
    }

    private fun saveTeam(option: GunnersOption) {
        Repo.sp.edit().putString("gunnersTeam", option.key)
            .putString("gunnersTeamName", option.name.takeIf { option.key.isNotEmpty() }.orEmpty()).apply()
        applyFilters("gunners-team")
    }

    private fun applyFilters(focus: String) {
        selected = null
        pendingGuide = null
        lookup.cancel()
        limit = 18
        draw()
        body.findViewWithTag<View>(focus)?.requestFocus()
    }

    private fun draw() {
        rendered = true
        val scrollY = root.scrollY
        val previousFocus = body.findFocus()?.tag
        body.removeAllViews()
        val match = selected
        if (closeDetails != null && match != null) {
            drawDetails(match)
            return
        }
        val preferred = preferredGunnersLeagues()
        val team = Repo.s("gunnersTeam")
        val filtered = preferred.isNotEmpty() || team.isNotEmpty()
        val listed = GunnersData.filter(games, preferred, team)
        val leading = match ?: listed.firstOrNull { it.live } ?: listed.firstOrNull { !it.finished } ?: listed.firstOrNull()
        val stacked = context.resources.configuration.screenWidthDp < 620
        val header = if (stacked) column() else row().apply { gravity = Gravity.TOP }
        fun width(weight: Float) = if (stacked) LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(8) }
            else LinearLayout.LayoutParams(0, -2, weight)
        val matchColumn = column()
        val schedule = if (match == null) body else matchColumn
        add(matchColumn, hero(leading, filtered) { selected = it; draw(); focusBroadcastCountry() })
        header.apply {
            addView(matchColumn, width(if (match == null) 2.2f else 1.55f).apply { marginEnd = if (stacked) 0 else context.dp(12) })
            if (match == null) {
                val shortcuts = column()
                add(shortcuts, shortcut(context.getString(R.string.live), HomePreferences.shortcutArtwork("gunners", "live"), R.drawable.ic_n_live, "live"))
                add(shortcuts, shortcut(context.getString(R.string.movies), HomePreferences.shortcutArtwork("gunners", "movie"), R.drawable.ic_n_movie, "movie"))
                add(shortcuts, shortcut(context.getString(R.string.series), HomePreferences.shortcutArtwork("gunners", "series"), R.drawable.ic_n_series, "series"), 0)
                addView(shortcuts, width(1f))
            } else addView(broadcastPanel(match), width(1f))
        }
        add(body, header, 11)
        val tools = if (stacked || match != null) column() else row()
        val heading = text(context.getString(R.string.gunners_today), 23f).apply { typeface = Typeface.DEFAULT_BOLD }
        if (stacked || match != null) add(tools, heading, 4)
        else tools.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val filters = row().apply {
            addView(action(context.getString(R.string.gunners_leagues), preferred.isNotEmpty()) { selectLeagues() }
                .apply { tag = "gunners-leagues" }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = context.dp(7) })
            val label = Repo.s("gunnersTeamName").ifBlank { context.getString(R.string.gunners_team) }
            addView(action(label, team.isNotEmpty()) { selectTeam() }.apply {
                tag = "gunners-team"
                maxWidth = context.dp(155)
            }, LinearLayout.LayoutParams(-2, -2))
        }
        tools.addView(filters, LinearLayout.LayoutParams(-2, -2))
        add(schedule, tools)
        if (!loading && listed.isEmpty() && !failure && leading != null)
            add(schedule, text(context.getString(if (filtered) R.string.gunners_filtered_empty else R.string.gunners_empty), 16f))
        val chunks = listed.take(limit).chunked(if (match == null && !stacked) 3 else 1)
        for (chunk in chunks) {
            add(schedule, row().apply {
                chunk.forEach { fixture ->
                    addView(fixtureCard(fixture, match != null) {
                        selected = fixture; draw(); focusBroadcastCountry()
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = context.dp(6) })
                }
            })
        }
        if (listed.size > limit) add(schedule, action(context.getString(R.string.gunners_more)) {
            limit += 18; draw()
        })
        root.post {
            if (body.findFocus() == null && previousFocus != null) {
                body.findViewWithTag<View>(previousFocus)?.requestFocus()
                if (root.scrollY < scrollY) root.scrollTo(0, scrollY)
            }
        }
    }

    private fun drawDetails(match: GunnersMatch) {
        val heading = row().apply {
            addView(ImageView(context).apply { Img.load(this, match.leagueLogo) },
                LinearLayout.LayoutParams(context.dp(30), context.dp(30)).apply { marginEnd = context.dp(8) })
            addView(text(match.league, 19f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
            val close = closeDetails
            addView(action(context.getString(R.string.feature_close)) { close?.invoke() })
        }
        add(body, heading)
        add(body, row().apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(team(match.home), LinearLayout.LayoutParams(0, -2, 1f))
            addView(text(matchTime(match), 21f, Th.acc).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD })
            addView(team(match.away), LinearLayout.LayoutParams(0, -2, 1f))
        }, 12)
        add(body, broadcastPanel(match), 0)
        focusBroadcastCountry()
    }

    private fun fixtureCard(fixture: GunnersMatch, strip: Boolean, click: () -> Unit): View = column().apply {
        tag = "gunners-match-${fixture.id}"
        contentDescription = "${fixture.title} · ${fixture.league} · ${matchTime(fixture)}"
        isFocusable = true
        isClickable = true
        clipToOutline = true
        background = card(if (selected?.id == fixture.id) col("#742033") else navy)
        setOnClickListener { click() }
        setOnFocusChangeListener { view, hasFocus -> view.background = card(navy, hasFocus) }
        if (!strip) addView(row().apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(col("#A6102B"), col("#141F35")))
            setPadding(context.dp(8), context.dp(3), context.dp(8), context.dp(3))
            addView(ImageView(context).apply { Img.load(this, fixture.leagueLogo) },
                LinearLayout.LayoutParams(context.dp(19), context.dp(19)).apply { marginEnd = context.dp(5) })
            addView(text(fixture.league, 12f).apply { maxLines = 1 })
        }, LinearLayout.LayoutParams(-1, -2))
        addView(row().apply {
            val inset = context.dp(7)
            setPadding(inset, inset, inset, inset)
            fun club(team: GunnersTeam) = row().apply {
                val crest = if (strip) 22 else 30
                addView(ImageView(context).apply { Img.load(this, team.logo) },
                    LinearLayout.LayoutParams(context.dp(crest), context.dp(crest)).apply { marginEnd = context.dp(3) })
                addView(text(team.name, 12f).apply { maxLines = 2 }, LinearLayout.LayoutParams(0, -2, 1f))
            }
            addView(club(fixture.home), LinearLayout.LayoutParams(0, -2, 1f))
            addView(text(matchTime(fixture), 13f).apply {
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(inset / 2, 0, inset / 2, 0)
            })
            addView(club(fixture.away), LinearLayout.LayoutParams(0, -2, 1f))
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun focusBroadcastCountry() {
        root.scrollTo(0, 0)
        body.findViewWithTag<View>("gunners-country-$country")?.requestFocus()
    }

    private fun flag(code: String) = if (code == "MENA") "🌍" else code.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")

    private fun broadcastPanel(match: GunnersMatch): View = column().apply {
        background = card()
        val padding = context.dp(10)
        setPadding(padding, padding, padding, padding)
        val head = row().apply {
            addView(text(context.getString(R.string.gunners_broadcasts), 18f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
            if (closeDetails == null) addView(action(context.getString(R.string.feature_close)) {
                selected = null; lookup.cancel(); pendingGuide = null; draw(); body.findViewWithTag<View>("gunners-featured")?.requestFocus()
            })
        }
        add(this, head)
        val result = column()
        add(this, row().apply {
            GunnersData.countries.forEach { (code, label) ->
                addView(action(flag(code) + "\n" + context.getString(label), code == country) {
                    country = code; draw(); focusBroadcastCountry()
                }.apply { tag = "gunners-country-$code" }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = context.dp(3) })
            }
        })
        add(this, result, 0)
        loadStations(match, country, result)
    }

    private fun loadStations(match: GunnersMatch, region: String, result: LinearLayout) {
        pendingGuide = null
        result.removeAllViews()
        add(result, text(context.getString(R.string.loading), 13f))
        val playlist = Repo.active()?.id
        fun current() = running && selected?.id == match.id && country == region
            && Repo.active()?.id == playlist && result.isAttachedToWindow
        lookup.submit {
            val stations = runCatching { GunnersData.broadcasters(match, region) }
            if (Thread.currentThread().isInterrupted) return@submit
            val listed = stations.getOrDefault(emptyList())
            main.post {
                if (!current()) return@post
                if (listed.isNotEmpty()) renderStations(result, listed)
                else {
                    fun findInGuide() {
                        if (!current()) return
                        lookup.submit {
                            val channels = GunnersData.guideChannels(match)
                            main.post guideResult@{
                                if (!current()) return@guideResult
                                result.removeAllViews()
                                if (channels.isNotEmpty()) {
                                    add(result, text(context.getString(R.string.gunners_from_guide), 15f).apply {
                                        typeface = Typeface.DEFAULT_BOLD
                                    })
                                    channels.forEach { entry ->
                                        add(result, action("▶  ${entry.item.name} · ${entry.playlistName}") {
                                            if (Repo.active()?.id == entry.playlistId && Repo.isPlaylistVisible(entry.playlistId)
                                                && Repo.list("live").any { it.id == entry.item.id }) play(entry.item)
                                        })
                                    }
                                } else if (stations.isSuccess) {
                                    renderStations(result, emptyList())
                                } else {
                                    add(result, text(context.getString(R.string.gunners_tv_failed), 13f))
                                    add(result, action(context.getString(R.string.gunners_retry)) { loadStations(match, region, result) })
                                }
                            }
                        }
                    }
                    if (Repo.epgState == 0) Repo.loadEpg()
                    if (Repo.epgState == 1) {
                        result.removeAllViews()
                        add(result, text(context.getString(R.string.gunners_loading_guide), 13f))
                        pendingGuide = ::findInGuide
                    } else findInGuide()
                }
            }
        }
    }

    private fun renderStations(result: LinearLayout, stations: List<GunnersStation>) {
        result.removeAllViews()
        if (stations.isEmpty()) add(result, text(context.getString(R.string.gunners_no_station), 14f))
        for (station in stations) add(result, row().apply {
            if (station.logo.isNotBlank()) addView(ImageView(context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                Img.load(this, station.logo)
            }, LinearLayout.LayoutParams(context.dp(70), context.dp(28)).apply { marginEnd = context.dp(8) })
            val markets = station.markets.joinToString(" · ") { context.getString(it) }
            addView(action("${station.name}\n$markets") { locate(result, station.name) }, LinearLayout.LayoutParams(0, -2, 1f))
        })
    }

    private fun locate(panel: LinearLayout, station: String) {
        val variantsTag = "gunners-playlist-results"
        panel.findViewWithTag<View>(variantsTag)?.let { panel.removeView(it) }
        val result = column().apply { tag = variantsTag }
        add(panel, result, 0)
        add(result, text(context.getString(R.string.loading), 13f))
        lookup.submit {
            val variants = runCatching { GunnersData.variants(station) }.getOrDefault(emptyList())
            main.post {
                if (!running || !result.isAttachedToWindow) return@post
                result.removeAllViews()
                if (variants.isEmpty()) add(result, text(context.getString(R.string.gunners_no_playlist_match), 14f))
                else {
                    add(result, text(context.getString(R.string.gunners_playlist_results), 16f).apply { typeface = Typeface.DEFAULT_BOLD })
                    variants.forEach { entry ->
                        add(result, action("▶  ${entry.playlistName} · ${entry.item.name}") { play(entry.item) })
                    }
                    result.getChildAt(1)?.requestFocus()
                }
            }
        }
    }

}
