package com.sultv.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

internal data class GunnersOption(val key: String, val name: String, val logo: String = "")

internal fun preferredGunnersLeagues(): Set<Int> =
    Repo.s("gunnersLeagues").split(',').mapNotNull(String::toIntOrNull).toSet()

internal fun gunnersLeagueOptions(context: Context, matches: List<GunnersMatch>): List<GunnersOption> {
    val saved = Repo.s("gunnersLeagueNames").lines().mapNotNull { line ->
        val parts = line.split('|', limit = 2)
        parts.first().toIntOrNull()?.let { id ->
            GunnersOption(id.toString(), parts.getOrNull(1).orEmpty(), GunnersData.leagueLogo(id))
        }
    }
    val fixtures = matches.map { GunnersOption(it.competitionId.toString(), it.league, it.leagueLogo) }
    val collation = java.text.Collator.getInstance(context.resources.configuration.locales[0])
    return (fixtures + saved).filter { it.name.isNotBlank() }.distinctBy { it.key }
        .sortedWith { a, b -> collation.compare(a.name, b.name) }
}

internal fun saveGunnersLeagues(choices: List<GunnersOption>, selected: Set<String>) {
    Repo.sp.edit().putString("gunnersLeagues", selected.joinToString(","))
        .putString("gunnersLeagueNames", choices.filter { it.key in selected }
            .joinToString("\n") { "${it.key}|${it.name}" }).apply()
}

internal fun showGunnersPicker(
    context: Context,
    title: String,
    options: List<GunnersOption>,
    selected: Set<String> = emptySet(),
    multiple: Boolean = false,
    apply: (Set<String>) -> Unit
): AlertDialog {
    val selection = selected.toMutableSet()
    val accent = col("#FF5870")
    val navy = col("#141F36")
    val list = ListView(context).apply {
        tag = "gunners-picker-list"
        divider = null
        selector = Th.shape(context, col("#703047"), false, 12)
        itemsCanFocus = false
        layoutDirection = context.resources.configuration.layoutDirection
        setPadding(context.dp(8), context.dp(4), context.dp(8), context.dp(4))
    }
    val adapter = object : BaseAdapter() {
        override fun getCount() = options.size
        override fun getItem(position: Int) = options[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = context.dp(54)
                setPadding(context.dp(12), context.dp(4), context.dp(12), context.dp(4))
                addView(ImageView(context).apply { scaleType = ImageView.ScaleType.FIT_CENTER },
                    LinearLayout.LayoutParams(context.dp(34), context.dp(34)).apply { marginEnd = context.dp(12) })
                addView(TextView(context).apply {
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    maxLines = 2
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(TextView(context).apply { setTextColor(accent); textSize = 20f; gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(context.dp(32), -2))
            }
            val option = getItem(position)
            val checked = option.key in selection
            row.background = Th.shape(context, if (checked) col("#522537") else Color.TRANSPARENT, false, 12)
            val crest = row.getChildAt(0) as ImageView
            if (option.logo.isBlank()) {
                Img.clear(crest)
                crest.setImageResource(R.drawable.ic_n_trophy)
            } else if (crest.tag != option.logo) Img.load(crest, option.logo)
            (row.getChildAt(1) as TextView).text = option.name
            (row.getChildAt(2) as TextView).text = if (checked) "✓" else if (multiple) "○" else "›"
            row.isActivated = checked
            return row
        }
    }
    list.adapter = adapter
    val heading = TextView(context).apply {
        text = title
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(context.dp(18), context.dp(14), context.dp(18), context.dp(10))
    }
    val content = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        background = Th.shape(context, navy, false, 18)
        addView(heading)
        addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    val builder = AlertDialog.Builder(context).setView(content).setNegativeButton(android.R.string.cancel, null)
    if (multiple) builder.setPositiveButton(R.string.save) { _, _ -> apply(selection.toSet()) }
    val dialog = builder.create()
    list.setOnItemClickListener { _, _, position, _ ->
        val option = options[position]
        if (multiple) {
            if (!selection.add(option.key)) selection.remove(option.key)
            adapter.notifyDataSetChanged()
            list.setSelection(position)
        } else {
            dialog.dismiss()
            apply(setOf(option.key))
        }
    }
    dialog.setOnKeyListener { _, key, event ->
        if (key != KeyEvent.KEYCODE_DPAD_RIGHT || !list.hasFocus() || options.isEmpty()) false
        else {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                list.setSelection(options.lastIndex)
                if (list.isInTouchMode) list.smoothScrollToPosition(options.lastIndex)
            }
            true
        }
    }
    dialog.show()
    val screen = context.resources.displayMetrics
    dialog.window?.setLayout(minOf(context.dp(600), (screen.widthPixels * .92f).toInt()),
        (screen.heightPixels * .82f).toInt())
    dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(accent)
    dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.WHITE)
    list.requestFocus()
    list.setSelection(options.indexOfFirst { it.key in selected }.coerceAtLeast(0))
    return dialog
}
