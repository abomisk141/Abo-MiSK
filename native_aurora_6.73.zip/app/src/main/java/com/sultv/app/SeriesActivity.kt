package com.sultv.app

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SeriesActivity : BaseActivity() {
    private val detailsWork = LatestWork()
    private val artworkWork = LatestWork()
    private var detailsGeneration = 0
    private lateinit var sh: Item
    private var movie = false
    private var eps: List<Item> = emptyList()
    private var curSeason = -1
    private val seasonBtns = ArrayList<Pair<Int, Button>>()
    private lateinit var epBox: LinearLayout
    private lateinit var seasonBar: LinearLayout
    private lateinit var metaTv: TextView
    private lateinit var plotTv: TextView
    private lateinit var castTv: TextView
    private lateinit var favBtn: Button
    private lateinit var backdrop: ImageView
    private var playBtn: Button? = null
    private var cine = false
    private lateinit var castScroll: HorizontalScrollView
    private lateinit var castRow: LinearLayout

    private val re = Regex("S(\\d+)E(\\d+)")
    private fun sn(i: Item) = re.find(i.ep)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    private fun en(i: Item) = re.find(i.ep)?.groupValues?.get(2)?.toIntOrNull() ?: 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Repo.init(this); Th.load()
        val s = Repo.find(intent.getStringExtra("id") ?: "")
        if (s == null) { finish(); return }
        sh = s; movie = s.kind == "movie"
        val wide = resources.displayMetrics.widthPixels / resources.displayMetrics.density >= 600
        cine = Repo.s("detstyle", if (Th.name == "aurora") "cinematic" else "poster") == "cinematic"
        val frame = FrameLayout(this); frame.background = Th.bg()
        backdrop = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = if (cine) 0.5f else 0.22f }
        frame.addView(backdrop, FrameLayout.LayoutParams(-1, -1))
        if (cine) {
            Img.load(backdrop, sh.logo, 1)
            frame.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(col("#33000000"), col("#99000000"), col("#F2000000"))) },
                FrameLayout.LayoutParams(-1, -1))
        }
        val root = LinearLayout(this).apply {
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(10))
        }
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; background = Th.shape(this@SeriesActivity, col("#33000000"), false, 18); clipToOutline = true
        }
        Img.load(poster, sh.logo)
        if (!cine) root.addView(poster, if (wide) LinearLayout.LayoutParams(0, -1, 26f).apply { marginEnd = dp(28); bottomMargin = dp(40) }
        else LinearLayout.LayoutParams(dp(110), dp(160)))

        val colL = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(colL)
        val titleTv = TextView(this).apply { text = sh.name; setTextColor(Th.fg); textSize = if (cine) 36f else 28f; typeface = Typeface.DEFAULT_BOLD }
        metaTv = TextView(this).apply { setTextColor(Th.mut); textSize = 16f; setPadding(0, dp(6), 0, dp(6)) }
        plotTv = TextView(this).apply { setTextColor(Th.fg); textSize = 14f; maxLines = 5 }
        castTv = TextView(this).apply { setTextColor(Th.mut); textSize = 13f; maxLines = 3; setPadding(0, dp(6), 0, dp(10)) }
        if (cine) colL.addView(View(this), LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.32f).toInt()))
        colL.addView(titleTv); colL.addView(metaTv); colL.addView(plotTv); colL.addView(castTv)
        castRow = LinearLayout(this).apply { clipChildren = false }
        castScroll = HorizontalScrollView(this).apply { visibility = View.GONE; isHorizontalScrollBarEnabled = false; clipChildren = false }
        castScroll.addView(castRow)
        colL.addView(castScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        if (movie) {
            val pb = Th.btn(this, playText(), true)
            pb.setOnClickListener { play(sh.url, sh.name, sh.id) }
            playBtn = pb
            bar.addView(pb, LinearLayout.LayoutParams(-2, dp(46)).apply { marginEnd = dp(10) })
        }
        favBtn = Th.btn(this, favText())
        favBtn.setOnClickListener { Repo.toggleFav(sh.id); favBtn.text = favText() }
        bar.addView(favBtn, LinearLayout.LayoutParams(-2, dp(46)).apply { marginEnd = dp(10) })
        seasonBar = LinearLayout(this)
        val hs = HorizontalScrollView(this); hs.addView(seasonBar)
        bar.addView(hs, LinearLayout.LayoutParams(0, -2, 1f))
        colL.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        epBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        colL.addView(epBox)
        root.addView(scroll, if (cine) LinearLayout.LayoutParams(-1, -1) else if (wide) LinearLayout.LayoutParams(0, -1, 74f) else LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(frame)
        playBtn?.requestFocus()

        val generation = ++detailsGeneration
        detailsWork.submit {
            val l = if (movie) { Repo.loadMovieInfo(sh); emptyList<Item>() } else Repo.episodes(sh)
            runOnUiThread {
                if (isFinishing || isDestroyed || generation != detailsGeneration) return@runOnUiThread
                eps = l.sortedWith(compareBy({ sn(it) }, { en(it) }))
                Repo.info[sh.id]?.let {
                    metaTv.text = listOf(if (it.rating.isNotBlank() && it.rating != "0") "★ ${it.rating}" else "", it.year, it.genre)
                        .filter { x -> x.isNotBlank() }.joinToString("   •   ")
                    plotTv.text = it.plot
                    castTv.text = if (it.cast.isNotBlank()) getString(R.string.cast_l) + " " + it.cast else ""
                    if (it.back.isNotBlank()) { Img.load(backdrop, it.back, 1); if (cine) backdrop.alpha = 1f }
                }
                if (Tmdb.needsCastPhotos() || Tmdb.needsBackdrop(Repo.info[sh.id])) {
                    val inf = Repo.info[sh.id]
                    artworkWork.submit {
                        val yr = sh.year.ifBlank { inf?.year ?: "" }
                        val l = if (Tmdb.needsCastPhotos()) Tmdb.cast(if (movie) "movie" else "series", inf?.tmdb ?: "", sh.name, yr) else emptyList()
                        val bu = if (Tmdb.needsBackdrop(inf)) Tmdb.backdrop(if (movie) "movie" else "series", inf?.tmdb ?: "", sh.name, yr) else ""
                        runOnUiThread {
                            if (isFinishing || isDestroyed || generation != detailsGeneration) return@runOnUiThread
                            if (bu.isNotEmpty()) { Img.load(backdrop, bu, 1); backdrop.alpha = if (cine) 1f else 0.3f }
                            showCast(l)
                        }
                    }
                }
                if (!movie) {
                    for (n in eps.map { sn(it) }.distinct().sorted()) {
                        val btn = Th.btn(this, getString(R.string.season, n))
                        btn.setOnClickListener { showSeason(n, false) }
                        seasonBtns.add(Pair(n, btn))
                        seasonBar.addView(btn, LinearLayout.LayoutParams(-2, dp(46)).apply { marginEnd = dp(8) })
                    }
                    if (eps.isEmpty()) metaTv.text = getString(R.string.none) else showSeason(sn(eps[0]), true)
                }
            }
        }
    }

    private fun showCast(l: List<Actor>) {
        castRow.removeAllViews()
        if (l.isEmpty()) {
            castScroll.visibility = View.GONE
            if (Tmdb.lastErr.isNotEmpty()) castTv.text = castTv.text.toString() + "\nTMDB: " + Tmdb.lastErr
            return
        }
        castTv.visibility = View.GONE
        for (a in l) {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(6)); isFocusable = true; isClickable = true
                background = Th.shape(this@SeriesActivity, col("#00000000"), false, 16)
                setOnFocusChangeListener { v, f -> v.background = Th.shape(this@SeriesActivity, col("#00000000"), f, 16) }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply { if (cine) cornerRadius = dp(14).toFloat() else shape = GradientDrawable.OVAL; setColor(col("#33FFFFFF")) }
                clipToOutline = true
            }
            Img.load(iv, a.photo)
            c.addView(iv, LinearLayout.LayoutParams(dp(if (cine) 76 else 66), dp(if (cine) 96 else 66)))
            c.addView(TextView(this).apply { text = a.name; setTextColor(Th.fg); textSize = 12f; gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(5), 0, 0) },
                LinearLayout.LayoutParams(dp(78), -2))
            if (a.role.isNotBlank()) c.addView(TextView(this).apply { text = a.role; setTextColor(Th.mut); textSize = 11f; gravity = Gravity.CENTER; maxLines = 1 },
                LinearLayout.LayoutParams(dp(78), -2))
            castRow.addView(c, LinearLayout.LayoutParams(dp(90), -2))
        }
        castScroll.visibility = View.VISIBLE
    }

    private fun playText(): String {
        val p = Repo.pct(sh.url)
        return "▶ " + getString(R.string.play) + if (p > 0) "  ($p%)" else ""
    }

    private fun playEp(e: Item) {
        Repo.put("le:" + sh.id, e.url); Repo.put("lt:" + sh.id, e.ep)
        Repo.epQueue = eps
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", e.url).putExtra("name", sh.name + " " + e.ep)
            .putExtra("live", false).putExtra("rid", sh.id).putExtra("epIdx", eps.indexOf(e)).putExtra("sid", sh.id).putExtra("show", sh.name))
    }

    private fun favText() = getString(if (Repo.isFav(sh.id)) R.string.fav_in else R.string.fav_add)

    private fun play(url: String, name: String, rid: String) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", url).putExtra("name", name).putExtra("live", false).putExtra("rid", rid))
    }

    override fun onResume() {
        super.onResume()
        if (movie) playBtn?.text = playText()
        else if (eps.isNotEmpty() && curSeason >= 0) showSeason(curSeason, false)
    }

    private fun showSeason(n: Int, focusFirst: Boolean) {
        curSeason = n
        for ((k, b) in seasonBtns) Th.paint(b, k == n)
        epBox.removeAllViews()
        if (Th.name == "aurora") { showAuroraEpisodes(n, focusFirst); return }
        for (e in eps.filter { sn(it) == n }) {
            val c = this
            val wrap = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10))
                isFocusable = true; isClickable = true
                background = Th.shape(c, Th.card, false, 14)
                setOnFocusChangeListener { v, f -> v.background = Th.shape(c, Th.card, f, 14) }
            }
            val line = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
            line.addView(TextView(c).apply { text = en(e).toString(); setTextColor(Th.mut); textSize = 16f; typeface = Typeface.DEFAULT_BOLD },
                LinearLayout.LayoutParams(dp(48), -2))
            line.addView(TextView(c).apply { text = e.name.ifEmpty { e.ep }; setTextColor(Th.fg); textSize = 15f; maxLines = 2 },
                LinearLayout.LayoutParams(0, -2, 1f))
            val p = Repo.pct(e.url)
            if (p > 0) line.addView(TextView(c).apply { text = if (p >= 95) "✓" else "$p%"; setTextColor(Th.acc); textSize = 13f; setPadding(dp(8), 0, dp(12), 0) })
            if (e.dur.isNotBlank()) line.addView(TextView(c).apply { text = getString(R.string.mins, e.dur.toIntOrNull() ?: 0); setTextColor(Th.mut); textSize = 13f })
            wrap.addView(line)
            if (p > 0) wrap.addView(WatchBar(c).apply { pct = p }, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(8) })
            wrap.setOnClickListener { playEp(e) }
            epBox.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) })
        }
        if (focusFirst) epBox.getChildAt(0)?.requestFocus()
    }
    /** Aurora Glass: two glass episode cards per row with thumbnail, progress and watched mark. */
    private fun showAuroraEpisodes(n: Int, focusFirst: Boolean) {
        val c = this
        eps.filter { sn(it) == n }.chunked(2).forEach { pair ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 2f }
            pair.forEach { e ->
                val p = Repo.pct(e.url)
                val card = LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true
                    setPadding(dp(10), dp(10), dp(14), dp(10))
                    fun glass(focused: Boolean) {
                        background = GradientDrawable().apply {
                            setColor(if (focused) col("#33FFFFFF") else Th.card); cornerRadius = dp(22).toFloat()
                            if (focused) setStroke(dp(3), Th.acc)
                        }
                    }
                    glass(false); setOnFocusChangeListener { _, focused -> glass(focused) }
                    setOnClickListener { playEp(e) }
                }
                val thumb = FrameLayout(c)
                val image = ImageView(c).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true
                    background = GradientDrawable().apply { setColor(col("#26FFFFFF")); cornerRadius = dp(16).toFloat() }
                }
                thumb.addView(image, FrameLayout.LayoutParams(-1, -1)); Img.load(image, e.logo.ifBlank { sh.logo }, 1)
                if (p in 1..94) thumb.addView(WatchBar(c).apply { pct = p }, FrameLayout.LayoutParams(-1, dp(4), Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(8), dp(6)) })
                card.addView(thumb, LinearLayout.LayoutParams(dp(112), dp(66)).apply { marginEnd = dp(12) })
                val labels = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
                labels.addView(TextView(c).apply { text = "E" + en(e).toString(); setTextColor(Th.acc); textSize = 12f; typeface = Typeface.DEFAULT_BOLD })
                labels.addView(TextView(c).apply { text = e.name.ifEmpty { e.ep }; setTextColor(Th.fg); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
                val meta = listOfNotNull(e.dur.takeIf { it.isNotBlank() }?.let { getString(R.string.mins, it.toIntOrNull() ?: 0) }, if (p in 1..94) "$p%" else null).joinToString("  •  ")
                if (meta.isNotBlank()) labels.addView(TextView(c).apply { text = meta; setTextColor(Th.mut); textSize = 12f })
                card.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
                if (p >= 95) card.addView(TextView(c).apply {
                    text = "✓"; setTextColor(Th.bt); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Th.acc) }
                }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(8) })
                row.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            if (pair.size == 1) row.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
            epBox.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        if (focusFirst) ((epBox.getChildAt(0) as? LinearLayout)?.getChildAt(0) ?: epBox.getChildAt(0))?.requestFocus()
    }
    override fun onDestroy() {
        detailsGeneration++; detailsWork.close(); artworkWork.close()
        super.onDestroy()
    }
}
