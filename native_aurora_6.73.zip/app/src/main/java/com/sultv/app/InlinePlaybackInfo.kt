package com.sultv.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

/** Shows measurements over the existing video surface. Sampling only runs while the panel is visible. */
internal class InlinePlaybackInfo(
    private val context: Context,
    host: FrameLayout,
    toggleFavourite: () -> Unit,
    openMenu: (PreviewMenu) -> Unit
) {
    private val panel = PlayerInfoPanel(
        context, "full",
        toggleFavourite,
        { openMenu(PreviewMenu.AUDIO) },
        { openMenu(PreviewMenu.SUBTITLES) },
        { openMenu(PreviewMenu.SETTINGS) },
        { openMenu(PreviewMenu.DIAGNOSTICS) }
    ).apply {
        tag = "inline-player-info"
        visibility = View.GONE
    }
    private val connection = LiveStabilityIcon().apply { setBounds(0, 0, context.dp(19), context.dp(19)) }
    private val reception = context.playerInfoChip(R.drawable.ic_n_download, "download").apply {
        setCompoundDrawablesRelative(connection, null, null, null)
    }
    private val recommended = context.playerInfoChip(R.drawable.ic_stat_bitrate, "recommended-speed")
    private val quality = context.playerInfoChip(R.drawable.ic_stat_quality, "quality")
    private val handler = Handler(Looper.getMainLooper())
    private val diagnostics = PlaybackDiagnostics()
    private var rates = ChannelRates()
    private var stability = LiveStability()
    private var player: ExoPlayer? = null
    private var lastChannel: String? = null
    private val close = object : Runnable {
        override fun run() {
            if (controlsFocused) handler.postDelayed(this, 6000) else hide()
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            val current = player ?: return
            if (!isShowing) return
            update(current)
            handler.postDelayed(this, 1000)
        }
    }

    val isShowing: Boolean get() = panel.visibility == View.VISIBLE

    val controlsFocused: Boolean get() = panel.actions.hasFocus()

    fun focusControls() = panel.focusControls()

    fun updateFavourite(favourite: Boolean) = panel.favouriteState(favourite, true)

    fun handleControls(event: KeyEvent): Boolean {
        if (!controlsFocused) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT ->
                if (down) panel.moveControl(event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                panel.controlKey(down, event.repeatCount > 0)
            KeyEvent.KEYCODE_DPAD_UP -> if (down) panel.releaseControls()
            KeyEvent.KEYCODE_DPAD_DOWN -> Unit
            else -> return false
        }
        return true
    }

    init {
        listOf(reception, recommended, quality).forEach { panel.metrics.addView(it) }
        host.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            val margin = context.dp(12)
            setMargins(margin, 0, margin, margin)
        })
    }

    fun show(current: ExoPlayer, item: Item, number: Int, channelChanged: Boolean = false) {
        hide()
        player = current
        if (lastChannel != item.id) {
            reset()
            lastChannel = item.id
        }
        panel.number.text = number.toString()
        panel.number.visibility = if (number > 0) View.VISIBLE else View.GONE
        panel.channel.text = item.name
        updateFavourite(Repo.isFav(item.id))
        if (item.logo.isBlank()) {
            Img.clear(panel.logo)
            panel.logo.setImageResource(R.drawable.logo)
        } else Img.load(panel.logo, item.logo)
        val programme = Repo.nowOn(item)
        panel.programme.text = programme?.title ?: context.getString(R.string.no_info)
        panel.timing.visibility = if (programme == null) View.GONE else View.VISIBLE
        panel.setProgrammeTimes(programme)
        panel.progress.pct = programme?.let {
            ((System.currentTimeMillis() - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt().coerceIn(0, 100)
        } ?: 0
        panel.progress.invalidate()
        state(current.playbackState)
        panel.showForPlayback(channelChanged)
        tick.run()
        handler.postDelayed(close, 6000)
    }

    fun hide() {
        panel.releaseControls()
        panel.hideAfterPlayback()
        handler.removeCallbacks(close)
        handler.removeCallbacks(tick)
        player = null
    }

    fun reset() {
        lastChannel = null
        rates = ChannelRates()
        stability = LiveStability()
        diagnostics.reset()
        connection.level = 0
    }

    fun state(state: Int) { diagnostics.state(state) }

    private fun rate(bps: Long): String =
        if (bps >= 0) String.format(Locale.US, "%.1f Mb/s", bps / 1_000_000.0) else "…"

    private fun update(current: ExoPlayer) {
        val now = SystemClock.elapsedRealtime()
        val bytes = PlaybackTraffic.bytesReceived(current)
        rates.sample(now, bytes ?: -1, bytes, current.currentPosition + current.totalBufferedDuration)
        stability.sample(now, current.isPlaying, current.playWhenReady && current.playbackState == Player.STATE_BUFFERING,
            current.totalBufferedDuration, diagnostics.rebufferCount)
        connection.level = stability.level
        val bitrate = rates.bitrate.takeIf { it > 0 } ?: listOfNotNull(current.videoFormat?.bitrate, current.audioFormat?.bitrate)
            .filter { it > 0 }.sumOf { it.toLong() }
        reception.text = context.playerInfoStat(R.string.player_current_reception, rate(rates.download))
        val recommendedRate = if (bitrate > 0) (bitrate * 1.3).toLong() else -1L
        recommended.text = context.playerInfoStat(R.string.player_recommended_speed,
            if (recommendedRate > 0) "~" + rate(recommendedRate) else "…")
        panel.setReception(rates.download, recommendedRate)
        val height = current.videoFormat?.height ?: 0
        quality.text = context.playerInfoStat(R.string.stat_quality, when {
            height >= 2160 -> "4K UHD"
            height >= 1080 -> "FHD 1080p"
            height >= 720 -> "HD 720p"
            height > 0 -> "SD ${height}p"
            else -> "…"
        })
    }
}

internal enum class PreviewMenu { AUDIO, SUBTITLES, SETTINGS, DIAGNOSTICS }
