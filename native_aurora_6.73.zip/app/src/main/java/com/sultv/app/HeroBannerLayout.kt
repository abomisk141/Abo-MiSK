package com.sultv.app

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout

/** Artwork fills the banner, while the text and top controls determine the required height. */
class HeroBannerLayout(c: Context, private val textFraction: Float) : FrameLayout(c) {
    lateinit var textColumn: View
    var topControls: View? = null
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = View.MeasureSpec.getSize(widthMeasureSpec)
        if (!::textColumn.isInitialized) { super.onMeasure(widthMeasureSpec, heightMeasureSpec); return }
        val textWidth = (width * textFraction).toInt().coerceAtLeast(1)
        textColumn.measure(View.MeasureSpec.makeMeasureSpec(textWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val controls = topControls
        controls?.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val controlsHeight = if (controls != null && textWidth + controls.measuredWidth > width)
            controls.measuredHeight else 0
        val height = resolveSize(maxOf(minimumHeight, textColumn.measuredHeight + controlsHeight), heightMeasureSpec)
        (textColumn.layoutParams as LayoutParams).width = textWidth
        setMeasuredDimension(width, height)
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child !== textColumn && child !== controls) child.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        val controls = topControls ?: return
        if (!::textColumn.isInitialized) return
        val column = textColumn
        if (column.left < controls.right && column.right > controls.left && column.top < controls.bottom) {
            column.layout(column.left, controls.bottom, column.right, controls.bottom + column.measuredHeight)
        }
    }
}

/** Button labels keep the selected font size and stack when their natural widths do not fit. */
class HeroActionsLayout(c: Context) : LinearLayout(c) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val available = View.MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
        var required = 0
        for (i in 0 until childCount) {
            getChildAt(i).measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            required += getChildAt(i).measuredWidth
        }
        val gap = context.dp(8)
        val stack = required + gap * (childCount - 1) > available
        orientation = if (stack) VERTICAL else HORIZONTAL
        for (i in 0 until childCount) {
            val lp = getChildAt(i).layoutParams as LayoutParams
            lp.width = if (stack) LayoutParams.MATCH_PARENT else LayoutParams.WRAP_CONTENT
            lp.height = LayoutParams.WRAP_CONTENT
            lp.marginStart = if (!stack && i > 0) gap else 0
            lp.topMargin = if (stack && i > 0) gap else 0
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }
}
