package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class StudioHomeTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("welcome", false); Repo.putB("autoPrev", false); Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.putB("referenceLayoutV52", true)
        Repo.put("pl_refresh_hours", "0"); Repo.put("ui", "live"); Repo.updChecked = true; Repo.splashShown = true
        Repo.savePlaylists(listOf(Playlist("live-home", "Fixture", "m3u", "https://example.test/fixture", "", "", "")))
        Repo.items = listOf("Sports", "News", "Documentaries").flatMapIndexed { groupIndex, group -> (0..3).map { n -> Item("live-$groupIndex-$n", "AM $group ${n+1}", "", group, "live", u="file:///live-$groupIndex-$n.ts", epg="guide-$groupIndex-$n") } }
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo); Repo.dirty = false
        Repo.toggleFav("live-0-0"); Repo.toggleFav("live-0-1")
        val start = System.currentTimeMillis() / 1800000L * 1800000L
        Repo.epg = Repo.items.associate { it.epg to listOf(Prog(start, start+1800000L, "Match night"), Prog(start+1800000L, start+3600000L, "Post-match analysis")) }
    }
    private fun field(a: Any, name: String) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun set(a: Any, name: String, value: Any) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.set(a, value)
    private fun views(v: View): List<View> = listOf(v) + if(v is ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
    private fun layout(a: MainActivity) {
        a.window.decorView.apply { measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY)); layout(0,0,960,540) }
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))
    }
    private fun settle(a: MainActivity, condition: () -> Boolean) {
        val end = System.nanoTime()+5_000_000_000L
        do { layout(a); Thread.sleep(3) } while(!condition() && System.nanoTime()<end)
        assertTrue(condition()); repeat(2){layout(a)}
    }
    @Test fun oldLiveOpensStudioAndRemoteDirectionsFollowLanguage() {
        for (lang in listOf("ar", "en")) {
            Repo.put("lang", lang)
            val ctl = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
            val a = ctl.get()
            try {
                val root = a.window.decorView
                settle(a) { root.findViewWithTag<View>("hero-play") != null }
                assertEquals("studio", Repo.s("ui"))
                root.findViewWithTag<View>("hero-play").performClick()
                val side = field(a, "sideRv") as androidx.recyclerview.widget.RecyclerView
                settle(a) { side.findViewHolderForAdapterPosition(2) != null }
                val row = side.findViewHolderForAdapterPosition(2)!!.itemView
                row.requestFocusFromTouch()
                val enter = if (lang == "ar") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                val back = if (lang == "ar") KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                row.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, enter))
                val panel = root.findViewWithTag<View>("category-panel")
                settle(a) { panel.visibility == View.GONE }
                a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, back))
                settle(a) { panel.visibility == View.VISIBLE && side.hasFocus() }
            } finally { ctl.pause().stop().destroy() }
        }
    }
    @Test fun customizedHomeUsesTopNavigationAndTheChosenCategoryAndRowOrder() {
        Repo.put("ui", "studio")
        val style = "studio"
        Repo.putB(HomePreferences.key(style, "custom"), true)
        Repo.put(HomePreferences.key(style, "navigation"), "top")
        Repo.put(HomePreferences.key(style, "banner"), "live")
        Repo.put(HomePreferences.key(style, "category"), "News")
        Repo.put(HomePreferences.key(style, "rows"), "list,live")
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
        val activity = controller.get()
        try {
            val root = activity.window.decorView
            settle(activity) { root.findViewWithTag<View>("home-section:live") != null }
            assertEquals(false, field(activity, "railMode"))
            val title = root.findViewWithTag<android.widget.TextView>("hero-title")
            assertEquals("AM News 1", title.text.toString())
            val sectionTags = views(root).mapNotNull { it.tag as? String }.filter { it.startsWith("home-section:") }
            assertEquals(listOf("home-section:list", "home-section:live"), sectionTags)
        } finally {
            controller.pause().stop().destroy()
        }
    }

    @Test fun iconOnlySidebarHidesLabelsEvenWhenFocused() {
        Repo.put("ui", "studio")
        Repo.put(HomePreferences.key("studio", "navigation"), "side")
        Repo.put(HomePreferences.key("studio", "railMode"), "icons")
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
        try {
            val activity = controller.get()
            val shell = field(activity, "cinemaShell") as DesignShell
            val live = shell.buttons.getValue("live")
            live.requestFocusFromTouch()
            layout(activity)
            val label = (live as ViewGroup).getChildAt(1)
            assertTrue(live.hasFocus())
            assertEquals(View.GONE, label.visibility)
            assertEquals(72, shell.root.layoutParams.width)
        } finally {
            controller.pause().stop().destroy()
        }
    }

    @Test fun labelPlacementAndVisibilitySurviveSidebarExpansion() {
        Repo.put("ui", "studio")
        Repo.put(HomePreferences.key("studio", "navLabelPosition"), "under")
        val context = RuntimeEnvironment.getApplication()
        val under = DesignNav(context, "Live", R.drawable.ic_tv, false)
        under.compact(false)
        assertEquals(android.widget.LinearLayout.VERTICAL, under.orientation)
        assertEquals(View.VISIBLE, under.getChildAt(1).visibility)

        Repo.put(HomePreferences.key("studio", "navText"), "never")
        val icons = DesignNav(context, "Live", R.drawable.ic_tv, true)
        icons.compact(false)
        assertEquals(View.GONE, icons.getChildAt(1).visibility)
    }

    @Test fun favouriteLeaguesAreSharedAndSavedOptionsSurviveFeedChanges() {
        val context = RuntimeEnvironment.getApplication()
        val first = GunnersOption("10", "First league")
        val second = GunnersOption("20", "Second league")
        saveGunnersLeagues(listOf(first, second), setOf("20"))
        assertEquals(setOf(20), preferredGunnersLeagues())
        assertEquals("Second league", gunnersLeagueOptions(context, emptyList()).single().name)
    }

    @Test fun continueWatchingRejectsChannelsEvenWhenSuppliedAsMovies() {
        val movie = Item("movie", "Drama", "", "", "movie", ext = "mp4")
        assertTrue(HomePreferences.canResume(movie))
        assertTrue(HomePreferences.canResume(movie.copy(kind = "series")))
        assertFalse(HomePreferences.canResume(movie.copy(kind = "live")))
        assertFalse(HomePreferences.canResume(movie.copy(name = "F: beIN SPORTS 1 RAW")))
        assertFalse(HomePreferences.canResume(movie.copy(u = "https://example.test/live/account/channel")))
        assertFalse(HomePreferences.canResume(movie.copy(ext = "ts")))
    }

    @Test fun nonGunnersHomeUsesMatchesForTheBannerAndRow() {
        val style = "studio"
        Repo.putB(HomePreferences.key(style, "custom"), true)
        Repo.put(HomePreferences.key(style, "banner"), "matches")
        Repo.put(HomePreferences.key(style, "rows"), "matches")
        Repo.put("gunnersLeagues", "10")
        val home = GunnersTeam("North", "north", "")
        val away = GunnersTeam("South", "south", "")
        val fixture = GunnersMatch(1, 10, "League", home, away, System.currentTimeMillis(), true, false, "", "")
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
        val activity = controller.get()
        val view = DesignHomeView(activity, style, {}, {}, {}, {}, fixtures = {
            GunnersSchedule(listOf(fixture, fixture.copy(id = 2, competitionId = 11)), emptyList())
        })
        try {
            activity.setContentView(view.root)
            view.render()
            settle(activity) { view.root.findViewWithTag<View>("home-match:1") != null }
            assertNotNull(view.root.findViewWithTag<View>("hero-play"))
            assertNull(view.root.findViewWithTag<View>("home-match:2"))
        } finally {
            view.destroy()
            controller.pause().stop().destroy()
        }
    }

    @Test fun myListShortcutFocusesFiltersThatChangeTheDisplayedFavourites() {
        val ctl = Robolectric.buildActivity(MainActivity::class.java).setup().visible()
        val activity = ctl.get()
        try {
            val root = activity.window.decorView
            settle(activity) { root.findViewWithTag<View>("studio:list") != null }
            root.findViewWithTag<View>("studio:list").requestFocusFromTouch()
            root.findViewWithTag<View>("studio:list").performClick()
            val filters = field(activity, "studioFilters") as Map<*, *>
            val all = filters[""] as View
            val movies = filters["k:movie"] as View
            val grid = root.findViewWithTag<androidx.recyclerview.widget.RecyclerView>("channel-list")
            settle(activity) { all.hasFocus() && grid.adapter?.itemCount == 2 }
            movies.performClick()
            settle(activity) { movies.isSelected && grid.adapter?.itemCount == 0 }
            all.performClick()
            settle(activity) { all.isSelected && grid.adapter?.itemCount == 2 }
        } finally { ctl.pause().stop().destroy() }
    }
}
