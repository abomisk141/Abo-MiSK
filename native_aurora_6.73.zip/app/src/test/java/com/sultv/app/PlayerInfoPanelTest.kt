package com.sultv.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],qualifiers="en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class PlayerInfoPanelTest {
    @Before fun setup(){
        Repo.init(RuntimeEnvironment.getApplication());Repo.sp.edit().clear().commit();Repo.afterBackupRestore()
        Repo.putB("referenceLayoutV52",true);Repo.put("ui","cinema");Repo.put("lang","en");Repo.put("liveplayer","full")
        Repo.savePlaylists(listOf(Playlist("panel-fixture","Fixture","m3u","https://example.test/list","","","")))
        Repo.items=(0..2).map{Item("panel-$it","AM SPORTS ${it+1}","","Sports","live",u="file:///panel-$it.ts",epg="panel-guide-$it")}
        Repo::class.java.getDeclaredMethod("build").apply{isAccessible=true}.invoke(Repo);Repo.zap=Repo.list("live");Repo.dirty=false
        val start=System.currentTimeMillis()/1800000L*1800000L
        Repo.epg=Repo.items.associate{it.epg to listOf(Prog(start,start+1800000L,"Match night · North City vs Royal United"),Prog(start+1800000L,start+3600000L,"Post-match analysis"))}
    }
    private fun field(a:Any,n:String)=a.javaClass.getDeclaredField(n).apply{isAccessible=true}.get(a)
    private fun views(v:View):List<View> = listOf(v)+if(v is ViewGroup)(0 until v.childCount).flatMap{views(v.getChildAt(it))}else emptyList()
    private fun start()=Robolectric.buildActivity(PlayerActivity::class.java,Intent(RuntimeEnvironment.getApplication(),PlayerActivity::class.java).putExtra("url",Repo.items[0].url).putExtra("name",Repo.items[0].name).putExtra("rid",Repo.items[0].id).putExtra("live",true)).create().start().resume().visible()
    private fun layout(a:PlayerActivity){val width=a.resources.displayMetrics.widthPixels;val height=a.resources.displayMetrics.heightPixels;a.window.decorView.apply{measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(height,View.MeasureSpec.EXACTLY));layout(0,0,width,height)};shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))}
    private fun key(a:PlayerActivity,k:Int){a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,k));a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP,k))}
    private fun shot(a:PlayerActivity,name:String){val root=a.window.decorView;val panel=field(a,"infoPanel") as PlayerInfoPanel;val bitmap=Bitmap.createBitmap(root.width,root.height,Bitmap.Config.ARGB_8888);root.draw(Canvas(bitmap));val crop=Bitmap.createBitmap(bitmap,0,panel.top,root.width,root.height-panel.top);File("build/player-panel-previews/$name.png").apply{parentFile!!.mkdirs()}.outputStream().use{crop.compress(Bitmap.CompressFormat.PNG,100,it)};crop.recycle();bitmap.recycle()}
    @Test fun metadataFavouriteAndNextProgrammeReflectCurrentChannel(){
        val ctl=start();val a=ctl.get();val panel=field(a,"infoPanel") as PlayerInfoPanel
        try{
            layout(a);assertEquals("AM SPORTS 1",panel.channel.text.toString());assertTrue(panel.programme.text.toString().contains("Match night"));assertEquals(View.VISIBLE,panel.timing.visibility)
            assertTrue(panel.next.text.toString().contains("Post-match analysis"));assertTrue(panel.favourite.isEnabled)
            panel.favourite.performClick();assertTrue(Repo.isFav("panel-0"));assertTrue(panel.favourite.isSelected)
            PlayerActivity::class.java.getDeclaredField("lastZapAt").apply{isAccessible=true}.setLong(a,-1000L)
            key(a,KeyEvent.KEYCODE_DPAD_DOWN);layout(a)
            assertEquals("AM SPORTS 2",panel.channel.text.toString());assertFalse(panel.favourite.isSelected)
            assertEquals(View.VISIBLE, panel.visibility)
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(220))
            shot(a, "channel-switch")
        }finally{ctl.pause().stop().destroy()}
    }
    @Test fun rightEntersControlsAndBackHidesWithoutFinishingOrZapping(){
        val ctl=start();val a=ctl.get();val panel=field(a,"infoPanel") as PlayerInfoPanel
        try{
            layout(a);key(a,KeyEvent.KEYCODE_DPAD_RIGHT);assertTrue(panel.settings.hasFocus())
            (field(a,"hideOv") as Runnable).run();assertEquals(View.VISIBLE,panel.visibility)
            key(a,KeyEvent.KEYCODE_DPAD_LEFT);assertTrue(panel.subtitles.hasFocus())
            key(a,KeyEvent.KEYCODE_DPAD_CENTER)
            val dialog=field(a,"optionsDialog") as android.app.Dialog
            assertTrue(dialog.isShowing);assertTrue(views(dialog.window!!.decorView).filterIsInstance<TextView>().any{it.text.toString()==a.getString(R.string.t_subs)})
            dialog.dismiss();key(a,KeyEvent.KEYCODE_BACK);assertFalse(a.isFinishing);assertEquals(View.GONE,panel.visibility);assertEquals(0,field(a,"idx"))
        }finally{ctl.pause().stop().destroy()}
    }
    @Test fun channelNumberEntryLeavesControlsAndCommitsWithoutOpeningSettings(){
        val ctl=start();val a=ctl.get();val panel=field(a,"infoPanel") as PlayerInfoPanel
        try{
            layout(a);key(a,KeyEvent.KEYCODE_DPAD_RIGHT);assertTrue(panel.settings.hasFocus())
            key(a,KeyEvent.KEYCODE_2);assertFalse(panel.actions.hasFocus());key(a,KeyEvent.KEYCODE_DPAD_CENTER)
            assertEquals(1,field(a,"idx"));assertNull(field(a,"optionsDialog"))
        }finally{ctl.pause().stop().destroy()}
    }
    @Test fun lastChannelButtonReturnsToPreviouslyWatchedChannel() {
        Remote.saveKeys("l_last", listOf(KeyEvent.KEYCODE_PROG_GREEN))
        val controller = start()
        val activity = controller.get()
        val panel = field(activity, "infoPanel") as PlayerInfoPanel
        try {
            layout(activity)
            assertEquals("AM SPORTS 1", panel.channel.text.toString())
            key(activity, KeyEvent.KEYCODE_3)
            key(activity, KeyEvent.KEYCODE_DPAD_CENTER)
            assertEquals("AM SPORTS 3", panel.channel.text.toString())
            key(activity, KeyEvent.KEYCODE_PROG_GREEN)
            assertEquals("AM SPORTS 1", panel.channel.text.toString())
            key(activity, KeyEvent.KEYCODE_PROG_GREEN)
            assertEquals("AM SPORTS 3", panel.channel.text.toString())
        } finally {
            controller.pause().stop().destroy()
            Remote.clearCache()
        }
    }

    @Test fun customRightMappingStillZapsInsteadOfEnteringControls(){
        Remote.saveKeys("l_next",listOf(KeyEvent.KEYCODE_DPAD_RIGHT))
        val ctl=start();val a=ctl.get();val panel=field(a,"infoPanel") as PlayerInfoPanel
        try{layout(a);PlayerActivity::class.java.getDeclaredField("lastZapAt").apply{isAccessible=true}.setLong(a,-1000L);key(a,KeyEvent.KEYCODE_DPAD_RIGHT);assertEquals(1,field(a,"idx"));assertFalse(panel.actions.hasFocus())}
        finally{ctl.pause().stop().destroy();Remote.clearCache()}
    }
    private fun verify(a:PlayerActivity){
        val panel=field(a,"infoPanel") as PlayerInfoPanel;layout(a)
        val labels=listOf("chDl","recommendedSpeed","chQuality")
        val values=listOf("8.4 Mb/s\nCurrent reception","8.1 Mb/s\nRecommended speed","1080p\nQuality")
        labels.forEachIndexed{index,n->(field(a,n) as TextView).text=values[index]}
        panel.quality.text="FHD 1080p";panel.quality.visibility=View.VISIBLE;(field(a,"recoveryBox") as View).visibility=View.GONE;layout(a)
        val rect=Rect();assertTrue(panel.top>=0)
        labels.forEach{val view=field(a,it) as TextView;assertTrue(view.getGlobalVisibleRect(rect));assertEquals(view.height,rect.height());assertEquals(view.width,rect.width());assertNotNull(view.compoundDrawablesRelative[0])}
        assertTrue(panel.progress.pct in 0..100)
    }
    @Test fun metricsAndActionsFitLargeFontsInBothLanguagesWithPreviews(){
        for(lang in listOf("en","ar"))for(size in listOf("1.0","1.3")){
            Repo.put("lang",lang);Repo.put("ts",size)
            val ctl=start();val a=ctl.get()
            try{verify(a);if(size=="1.0")shot(a,"player-panel-$lang")}finally{ctl.pause().stop().destroy()}
        }
    }
    @Test @Config(qualifiers="ar-rSA-w360dp-h640dp-port-mdpi") fun narrowScreenReflowsWithoutClippingMetrics(){
        Repo.put("lang","ar");Repo.put("ts","1.3")
        val ctl=start();try{verify(ctl.get())}finally{ctl.pause().stop().destroy()}
    }
    @Test fun glassAndMinimalKeepTheirDisplayPreferences(){
        for(style in listOf("glass","minimal")){
            Repo.put("liveplayer",style);val ctl=start();val a=ctl.get()
            try{layout(a);val panel=field(a,"infoPanel") as PlayerInfoPanel;assertEquals(View.GONE,panel.actions.visibility);assertEquals(View.GONE,panel.metrics.visibility);assertEquals(if(style=="glass")View.VISIBLE else View.GONE,panel.compactStats.visibility);assertFalse(panel.focusControls())}
            finally{ctl.pause().stop().destroy()}
        }
    }
    @Test fun longChannelNamesWrapWithoutClippingInBothLanguages() {
        val titles = mapOf(
            "en" to "AM SPORTS 1 • International Football Live HD — European Matchday Coverage and Championship Highlights",
            "ar" to "أبو مسك الرياضية ١ • بث مباريات كرة القدم الدولية ومتابعة مباشرة لأهم مباريات الجولة والبطولات الأوروبية"
        )
        for ((language, title) in titles) {
            Repo.put("lang", language)
            val controller = start()
            val activity = controller.get()
            try {
                val panel = field(activity, "infoPanel") as PlayerInfoPanel
                panel.channel.text = title
                layout(activity)
                val textLayout = panel.channel.layout
                assertTrue(textLayout.lineCount > 1)
                assertEquals(title.length, textLayout.getLineEnd(textLayout.lineCount - 1))
                assertTrue((0 until textLayout.lineCount).all { textLayout.getEllipsisCount(it) == 0 })
                val visible = Rect()
                assertTrue(panel.channel.getGlobalVisibleRect(visible))
                assertEquals(panel.channel.height, visible.height())
                shot(activity, "long-channel-name-$language")
            } finally {
                controller.pause().stop().destroy()
            }
        }
    }

    @Test fun expandedPreviewShowsFullSummaryWithoutReplacingTheMediaItem() {
        val controller = start()
        val activity = controller.get()
        val player = field(activity, "player") as androidx.media3.exoplayer.ExoPlayer
        val host = android.widget.FrameLayout(activity)
        val channel = Repo.items.first()
        var favouriteClicks = 0
        val openedMenus = mutableListOf<PreviewMenu>()
        val info = InlinePlaybackInfo(activity, host, { favouriteClicks++ }, { openedMenus.add(it) })
        try {
            val media = player.currentMediaItem
            info.show(player, channel, 1)
            val panel = host.findViewWithTag<PlayerInfoPanel>("inline-player-info")
            assertTrue(info.isShowing)
            assertEquals(channel.name, panel.channel.text.toString())
            assertEquals(3, panel.metrics.childCount)
            assertEquals(View.VISIBLE, panel.actions.visibility)
            val bar = panel.findViewWithTag<ViewGroup>("player-overlay-unified-bar")
            assertSame(bar, panel.actions.parent)
            assertSame(bar, (panel.metrics.parent as ViewGroup).parent)
            val actionNames = listOf("favourite", "audio", "subtitles", "settings", "diagnostics")
            assertEquals(actionNames.size, panel.actions.childCount)
            actionNames.forEach { action ->
                assertTrue(panel.actions.findViewWithTag<View>("player-action:$action").performClick())
            }
            assertEquals(1, favouriteClicks)
            assertEquals(PreviewMenu.values().toList(), openedMenus)
            val download = panel.metrics.getChildAt(0) as TextView
            assertTrue(download.compoundDrawablesRelative[0] is LiveStabilityIcon)
            assertEquals(media, player.currentMediaItem)
            info.hide()
            assertEquals(View.GONE, panel.visibility)
            assertEquals(media, player.currentMediaItem)
        } finally {
            info.hide()
            controller.pause().stop().destroy()
        }
    }
}
