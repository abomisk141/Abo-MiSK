package com.sultv.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GunnersDataTest {
    @Test fun channelMatchKeepsTheChannelNumber() {
        val channel = GunnersData.channelKey("beIN SPORTS 1")
        assertEquals(channel, GunnersData.channelKey("AR | beIN SPORTS 1 FHD"))
        assertEquals(channel, GunnersData.channelKey("[UK] beIN SPORTS 1 1080p"))
        assertNotEquals(channel, GunnersData.channelKey("beIN SPORTS 10"))
        assertNotEquals(channel, GunnersData.channelKey("beIN SPORTS 1 English"))
    }
    @Test fun guideFallbackChecksTeamsAndKickoffAndIgnoresReplays() {
        val kickoff = 120 * 60_000L
        val match = GunnersMatch(
            1, 1, "", GunnersTeam("أرسنال", "arsenal", ""), GunnersTeam("تشيلسي", "chelsea", ""),
            kickoff, false, false, "", ""
        )
        val start = kickoff - 15 * 60_000L
        val end = kickoff + 90 * 60_000L
        assertTrue(GunnersData.guideMatches(match, Prog(start, end, "أرسنال × تشيلسي")))
        assertTrue(GunnersData.guideMatches(match, Prog(start, end, "Premier League", "Arsenal vs Chelsea")))
        assertFalse(GunnersData.guideMatches(match, Prog(start, end, "إعادة أرسنال × تشيلسي")))
        assertFalse(GunnersData.guideMatches(match, Prog(start, end, "Arsenal vs Manchester City")))
        assertFalse(GunnersData.guideMatches(match, Prog(end, end + 90 * 60_000L, "Arsenal vs Chelsea")))
        assertFalse(GunnersData.guideMatches(match, Prog(start, kickoff, "Arsenal vs Chelsea")))
    }
    @Test fun theSelectedTeamAddsMatchesWithoutRemovingSelectedLeagues() {
        val arsenal = GunnersTeam("Arsenal", "arsenal", "", 42)
        val chelsea = GunnersTeam("Chelsea", "chelsea", "", 49)
        val premier = GunnersMatch(1, 7, "Premier League", arsenal, chelsea, 0, false, false, "", "")
        val cup = premier.copy(id = 2, competitionId = 12)
        val other = premier.copy(id = 3, home = GunnersTeam("Liverpool", "liverpool", "", 40),
            away = GunnersTeam("Everton", "everton", "", 45))
        val matches = listOf(premier, cup, other)
        assertEquals(listOf(premier, cup, other), GunnersData.filter(matches, setOf(7), arsenal.key))
        assertEquals(listOf(premier, cup), GunnersData.filter(matches, emptySet(), arsenal.key))
        assertEquals(listOf(premier, other), GunnersData.filter(matches, setOf(7), ""))
        assertEquals(listOf(cup, other), GunnersData.filter(matches, setOf(12), "40"))
    }
}
