package com.sultv.app

import android.os.Looper
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import java.net.ServerSocket
import java.time.Duration
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
class GroupedPlaylistsTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("referenceLayoutV52", true); Repo.putB("autoUpd", false); Repo.putB("autoPrev", false)
        Repo.putB("epgOn", false); Repo.putB("tmdbOn", false); Repo.put("pl_refresh_hours", "0"); Repo.put("ui", "reference")
        Repo.updChecked = true
    }
    private fun field(a: MainActivity, name: String) = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun cats(a: MainActivity): List<MainActivity.Cat> = @Suppress("UNCHECKED_CAST") (field(a, "cats") as List<MainActivity.Cat>)
    private fun layout(a: MainActivity) {
        val root = a.window.decorView
        root.measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY))
        root.layout(0, 0, 960, 540); shadowOf(Looper.getMainLooper()).idle()
    }
    private fun waitFor(a: MainActivity, condition: () -> Boolean) {
        val until = System.nanoTime() + 5_000_000_000L
        do { layout(a); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40)); Thread.sleep(3) } while (!condition() && System.nanoTime() < until)
        assertTrue("Timed out; categories=${cats(a)}", condition())
        repeat(3) { layout(a); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40)) }
    }
    private fun chooseTab(a: MainActivity, kind: String) {
        MainActivity::class.java.getDeclaredMethod("selectTab", String::class.java).apply { isAccessible = true }.invoke(a, kind)
        waitFor(a) { field(a, "filtering") == false }
    }
    private fun click(a: MainActivity, predicate: (MainActivity.Cat) -> Boolean) {
        val side = field(a, "sideRv") as RecyclerView
        val index = cats(a).indexOfFirst(predicate); assertTrue("Missing category", index >= 0)
        side.scrollToPosition(index); layout(a)
        val row = side.findViewHolderForAdapterPosition(index)!!.itemView
        assertTrue(row.requestFocusFromTouch()); row.performClick()
    }
    private fun install(server: Fixture) {
        val one = Playlist("dino", "Dino", "m3u", server.url("Dino"), "", "", "")
        val two = Playlist("dream", "Dream", "m3u", server.url("Dream"), "", "", "")
        Repo.savePlaylists(listOf(one, two)); Repo.put("act", one.id)
        assertTrue(Repo.load()); Repo.dirty = false
    }
    @Test fun savedPlaylistsAppearTogetherWithoutDownloadingCollapsedAccounts() {
        Fixture().use { server ->
            install(server)
            Repo.putB("groupPlaylists", false) // legacy global switch no longer hides accounts
            assertTrue(Repo.groupedPlaylists())
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                chooseTab(a, "live")
                assertEquals(listOf("Dino", "Dream"), cats(a).filter { it.header }.map { it.label })
                assertTrue(cats(a).none { !it.header && it.playlist == "dream" })
                assertEquals(1, server.requests.get()); assertEquals("dino", Repo.active()!!.id)
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun bothPlaylistsExpandAndSelectionUsesCorrectSourceForEveryMediaKind() {
        Fixture().use { server ->
            install(server)
            for (kind in listOf("live", "movie", "series")) {
                Repo.put("act", "dino"); assertTrue(Repo.load()); Repo.dirty = false
                val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
                try {
                    chooseTab(a, kind)
                    assertEquals(listOf("Dino", "Dream"), cats(a).filter { it.header }.map { it.label })
                    assertTrue(cats(a).none { !it.header && it.playlist == "dream" })
                    val before = server.requests.get()
                    val guide = Repo.epgUrl()
                    val displayedItems = field(a, "data")
                    click(a) { it.header && it.playlist == "dream" }
                    waitFor(a) { cats(a).any { !it.header && it.playlist == "dream" && it.key == "Shared" } }
                    assertSame("Expanding a playlist must reuse the displayed content page", displayedItems, field(a, "data"))
                    assertEquals("Opening a header must not switch the account", "dino", Repo.active()!!.id)
                    assertEquals("Opening another account must not replace its guide", guide, Repo.epgUrl())
                    assertTrue(Repo.list(kind).all { it.name.startsWith("Dino") })
                    assertTrue(cats(a).any { !it.header && it.playlist == "dino" })
                    click(a) { !it.header && it.playlist == "dream" && it.key == "Shared" }
                    waitFor(a) { Repo.active()?.id == "dream" && field(a, "filtering") == false && (field(a, "rv") as RecyclerView).hasFocus() }
                    assertEquals("Shared", field(a, "cat"))
                    assertTrue(Repo.list(kind).all { it.name.startsWith("Dream") })
                    assertTrue(cats(a).any { !it.header && it.playlist == "dino" && it.key == "Shared" })
                    val current = Repo.items
                    click(a) { it.header && it.playlist == "dream" }
                    waitFor(a) { cats(a).none { !it.header && it.playlist == "dream" } }
                    assertEquals("Shared", field(a, "cat")); assertEquals(current, Repo.items)
                    click(a) { it.header && it.playlist == "dream" }
                    waitFor(a) { cats(a).any { !it.header && it.playlist == "dream" } }
                    assertTrue(server.requests.get() <= before + 1)
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun downloadedPlaylistKeepsASeparateCategoryIndexForEverySection() {
        Fixture().use { server ->
            install(server)
            val dream = Repo.playlists().first { it.id == "dream" }
            assertTrue(Repo.refreshCacheInBackground(dream))
            val requestCount = server.requests.get()
            server.failDream = true
            for (kind in listOf("live", "movie", "series")) {
                assertEquals(listOf("Shared"), Repo.playlistCategoryNames(dream, kind))
            }
            assertEquals(requestCount, server.requests.get())
            assertEquals("dino", Repo.active()?.id)
        }
    }
    @Test fun failedExpansionPreservesActiveCatalogueAndCollapsesFailedHeader() {
        Fixture().use { server ->
            install(server); server.failDream = true
            val previous = Repo.items
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                chooseTab(a, "live"); click(a) { it.header && it.playlist == "dream" }
                waitFor(a) { server.requests.get() == 2 && cats(a).any { it.header && it.playlist == "dream" && it.n == 0 } }
                assertEquals("dino", Repo.active()!!.id); assertEquals(previous, Repo.items)
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun expansionStateSurvivesRecreationAndAccountsCanBeHiddenIndependently() {
        Fixture().use { server ->
            install(server); Repo.put("lang", "ar"); Repo.put("ui", "cinema")
            var controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); var a = controller.get()
            chooseTab(a, "movie"); click(a) { it.header && it.playlist == "dream" }
            waitFor(a) { cats(a).any { !it.header && it.playlist == "dream" } }
            controller.pause().stop().destroy()
            controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); a = controller.get()
            try {
                chooseTab(a, "movie")
                waitFor(a) { cats(a).any { !it.header && it.playlist == "dream" } }
                assertEquals(2, server.requests.get())
                Repo.setPlaylistVisible("dream", false)
                for (kind in listOf("live", "movie", "series")) {
                    chooseTab(a, kind)
                    assertTrue("A single visible playlist has no heading or arrow", cats(a).none { it.header })
                    assertTrue(cats(a).none { it.playlist == "dream" })
                }
                Repo.setPlaylistVisible("dream", true); chooseTab(a, "series")
                assertEquals(2, cats(a).count { it.header })
                assertEquals("dino", Repo.active()!!.id)
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun rapidAccountSelectionsKeepTheLastSelectionAndSourceTogether() {
        Fixture().use { server ->
            install(server)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                chooseTab(a, "live"); click(a) { it.header && it.playlist == "dream" }
                waitFor(a) { cats(a).any { !it.header && it.playlist == "dream" } }
                click(a) { !it.header && it.playlist == "dream" && it.key == "Shared" }
                click(a) { !it.header && it.playlist == "dino" && it.key == "Shared" }
                waitFor(a) { field(a, "switchingPlaylist") == false && field(a, "filtering") == false }
                assertEquals("dino", Repo.active()!!.id)
                assertTrue(Repo.items.all { it.name.startsWith("Dino") })
                assertTrue(Repo.epgUrl().contains("Dino.xml"))
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun failedAccountSelectionKeepsThePreviousAccountAndGuide() {
        Fixture().use { server ->
            install(server)
            val previous = Repo.items; val guide = Repo.epgUrl()
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                chooseTab(a, "live"); click(a) { it.header && it.playlist == "dream" }
                waitFor(a) { cats(a).any { !it.header && it.playlist == "dream" } }
                Repo.invalidate(Repo.playlists().last()); server.failDream = true
                click(a) { !it.header && it.playlist == "dream" && it.key == "Shared" }
                waitFor(a) { field(a, "switchingPlaylist") == false && field(a, "filtering") == false }
                assertEquals("dino", Repo.active()!!.id); assertEquals(previous, Repo.items); assertEquals(guide, Repo.epgUrl())
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun hideAndShowKeepAccountsCacheFavouritesAndProgressIntact() {
        Fixture().use { server ->
            install(server)
            val original = Repo.playlists(); val raw = Repo.items
            val item = Repo.list("live").first(); Repo.toggleFav(item.id); Repo.saveProg(item.url, 5000, 20000)
            val file = java.io.File(RuntimeEnvironment.getApplication().filesDir, "pl_dino.bin"); val bytes = file.readBytes()
            Repo.setPlaylistVisible("dream", false); Repo.setPlaylistVisible("dino", false)
            assertEquals(original, Repo.playlists()); assertEquals(raw, Repo.items); assertArrayEquals(bytes, file.readBytes())
            assertEquals(emptyList<Playlist>(), Repo.visiblePlaylists())
            assertTrue(Repo.list("live").isEmpty()); assertTrue(Repo.favItems().isEmpty())
            assertTrue(Repo.isFav(item.id)); assertEquals(5000L to 20000L, Repo.prog(item.url))
            val saved = AppBackup.decode(AppBackup.export(Repo.sp, "test-password".toCharArray()), "test-password".toCharArray())
            assertEquals("0", saved.values["playlistVisible:dino"])
            Repo.setPlaylistVisible("dino", true)
            assertTrue(Repo.list("live").isNotEmpty()); assertTrue(Repo.isFav(item.id))
            assertEquals(original, Repo.playlists()); assertEquals(1, server.requests.get())
        }
    }
    @Test fun hidingAllAccountsClearsEveryBrowseSectionWithoutDeletingThem() {
        Fixture().use { server ->
            install(server); Repo.setPlaylistVisible("dream", false); Repo.setPlaylistVisible("dino", false)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                for (kind in listOf("live", "movie", "series", "list")) {
                    chooseTab(a, kind)
                    assertTrue(cats(a).none { it.header })
                    assertEquals(0, (field(a, "rv") as RecyclerView).adapter!!.itemCount)
                }
                assertEquals(2, Repo.playlists().size); assertEquals(1, server.requests.get())
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun hidingTheCurrentAccountDoesNotExposeItIfTheReplacementFails() {
        Fixture().use { server ->
            install(server); server.failDream = true
            val original = Repo.items
            Repo.setPlaylistVisible("dino", false)
            assertEquals("dream", Repo.active()!!.id); assertFalse(Repo.load())
            assertEquals(original, Repo.items)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                waitFor(a) { field(a, "filtering") == false }
                for (kind in listOf("live", "movie", "series")) {
                    chooseTab(a, kind)
                    assertTrue(cats(a).none { it.playlist == "dino" })
                    assertEquals(0, (field(a, "rv") as RecyclerView).adapter!!.itemCount)
                }
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun playlistMenuOffersHideThenShowInArabicAndEnglish() {
        Fixture().use { server ->
            install(server)
            for (lang in listOf("en", "ar")) {
                Repo.put("lang", lang)
                val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup(); val a = controller.get()
                try {
                    fun menu(label: Int): View {
                        SettingsActivity::class.java.getDeclaredMethod("plMenu", Playlist::class.java).apply { isAccessible = true }.invoke(a, Repo.playlists().last())
                        val dialog = org.robolectric.shadows.ShadowDialog.getLatestDialog()
                        fun views(v: View): List<View> = listOf(v) + if (v is android.view.ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
                        return dialog.window!!.decorView.findViewWithTag("playback-option:${a.getString(label)}")
                    }
                    val hide = menu(R.string.hide_playlist_ui)
                    hide.performClick(); assertFalse(Repo.isPlaylistVisible("dream"))
                    assertEquals(2, Repo.playlists().size)
                    val show = menu(R.string.show_playlist_ui)
                    show.performClick(); assertTrue(Repo.isPlaylistVisible("dream"))
                } finally { controller.pause().stop().destroy() }
            }
        }
    }
    @Test fun globalSearchDoesNotExposeHiddenAccountsAndWorksAgainAfterShowing() {
        Fixture().use { server ->
            install(server); Repo.setPlaylistVisible("dream", false); Repo.setPlaylistVisible("dino", false)
            val controller = Robolectric.buildActivity(MainActivity::class.java).setup().visible(); val a = controller.get()
            try {
                for (visible in listOf(false, true)) {
                    if (visible) Repo.setPlaylistVisible("dino", true)
                    chooseTab(a, "live")
                    MainActivity::class.java.getDeclaredMethod("openPremiumSearch").apply { isAccessible = true }.invoke(a)
                    val dialog = org.robolectric.shadows.ShadowDialog.getLatestDialog()
                    fun views(v: View): List<View> = listOf(v) + if (v is android.view.ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
                    views(dialog.window!!.decorView).filterIsInstance<android.widget.EditText>().single().setText("Dino")
                    val expected = if (visible) "النتائج: 3" else "النتائج: 0"
                    waitFor(a) { views(dialog.window!!.decorView).filterIsInstance<android.widget.TextView>().any { it.text.toString() == expected } }
                    dialog.dismiss()
                }
            } finally { controller.pause().stop().destroy() }
        }
    }
    private class Fixture : AutoCloseable {
        private val socket = ServerSocket(0)
        @Volatile private var running = true
        @Volatile var failDream = false
        val requests = AtomicInteger()
        fun url(name: String) = "http://127.0.0.1:${socket.localPort}/$name.m3u"
        private val thread = Thread {
            while (running) try { socket.accept().use { client ->
                val input = client.getInputStream().bufferedReader(); val first = input.readLine().orEmpty()
                while (!input.readLine().isNullOrEmpty()) { }
                requests.incrementAndGet()
                val name = if (first.contains("Dream")) "Dream" else "Dino"
                val body = "#EXTM3U url-tvg=\"https://example.test/$name.xml\"\n" + listOf("live" to "ts", "movie" to "mp4", "series" to "mp4").joinToString("") { (kind, ext) ->
                    val title = if (kind == "series") "$name Show S01E01" else "$name $kind"
                    "#EXTINF:-1 group-title=\"Shared\",$title\nhttps://example.test/$kind/$name/1.$ext\n"
                }
                val code = if (failDream && name == "Dream") "500 Failed" else "200 OK"
                client.getOutputStream().write("HTTP/1.1 $code\r\nContent-Length: ${body.toByteArray().size}\r\nConnection: close\r\n\r\n$body".toByteArray())
            } } catch (_: Exception) { }
        }.apply { isDaemon = true; start() }
        override fun close() { running = false; socket.close(); thread.interrupt(); thread.join(1000) }
    }
}
