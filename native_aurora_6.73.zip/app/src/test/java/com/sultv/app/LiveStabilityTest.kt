package com.sultv.app

import org.junit.Assert.assertEquals
import org.junit.Test

class LiveStabilityTest {
    @Test fun stablePlaybackAndInterruptionsChangeSignalLevel() {
        val monitor = LiveStability()
        monitor.sample(0, false, true, 0, 0)
        assertEquals(0, monitor.level)
        monitor.sample(1_000, true, false, 8_000, 0)
        assertEquals(0, monitor.level)
        monitor.sample(6_000, true, false, 8_000, 0)
        assertEquals(4, monitor.level)
        monitor.sample(7_000, true, false, 2_500, 0)
        assertEquals(3, monitor.level)
        monitor.sample(8_000, false, true, 0, 1)
        assertEquals(2, monitor.level)
        monitor.sample(11_000, false, true, 0, 2)
        assertEquals(1, monitor.level)
        monitor.sample(41_000, true, false, 8_000, 2)
        assertEquals(4, monitor.level)
    }
}
