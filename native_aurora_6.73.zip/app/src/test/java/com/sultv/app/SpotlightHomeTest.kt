package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],qualifiers="en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class SpotlightHomeTest {
    @Before fun setup(){
        Repo.init(RuntimeEnvironment.getApplication());Repo.sp.edit().clear().commit();Repo.afterBackupRestore()
        Repo.putB("autoUpd",false);Repo.putB("welcome",false);Repo.putB("autoPrev",false);Repo.putB("tmdbOn",false);Repo.putB("epgOn",false);Repo.putB("referenceLayoutV52",true)
        Repo.put("pl_refresh_hours","0");Repo.put("ui","spotlight");Repo.put("lang","en");Repo.updChecked=true;Repo.splashShown=true
        Repo.savePlaylists(listOf(Playlist("spot-fixture","Fixture","m3u","https://example.test/list","","","")))
        val movies=(0..4).map{Item("movie-$it",listOf("The Last Train","The Lighthouse Cove","Before the Harvest","A City of Secrets","The Desert Letter")[it],"","Movies","movie",u="file:///movie-$it.mp4",sid="$it",year="2026",rate="8.2")}
        val shows=(0..3).map{Item("show-$it","The Amber Coast $it","","Series","series",sid="show-$it",year="2026")}
        val live=Item("channel","Fixture channel","","Live","live",u="file:///live.ts")
        Repo.items=movies+shows+live;Repo::class.java.getDeclaredMethod("build").apply{isAccessible=true}.invoke(Repo);Repo.dirty=false
        movies.forEach{Repo.info[it.id]=Info("A returning traveller discovers a hidden story in a quiet coastal town.","","Mystery","8.2","2026")}
        Repo.saveProg(movies[0].url,60000,360000);Repo.touch(movies[0].id)
        Repo.put("le:show-0","file:///episode.mp4");Repo.put("lt:show-0","S1 E4");Repo.saveProg("file:///episode.mp4",90000,300000);Repo.touch("show-0");Repo.touch("channel")
    }
    private fun field(a:Any,n:String)=a.javaClass.getDeclaredField(n).apply{isAccessible=true}.get(a)
    private fun views(v:View):List<View> = listOf(v)+if(v is ViewGroup)(0 until v.childCount).flatMap{views(v.getChildAt(it))}else emptyList()
    private fun layout(a:MainActivity,width:Int=960){a.window.decorView.apply{measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(540,View.MeasureSpec.EXACTLY));layout(0,0,width,540)};shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))}
    private fun settle(a:MainActivity,ready:()->Boolean){val end=System.nanoTime()+5_000_000_000L;do{layout(a);Thread.sleep(3)}while(!ready()&&System.nanoTime()<end);assertTrue(ready());repeat(2){layout(a)}}
    private fun start()=Robolectric.buildActivity(MainActivity::class.java).setup().visible().also{ctl->settle(ctl.get()){ctl.get().window.decorView.findViewWithTag<View>("spotlight-hero")!=null}}
    private fun shot(a:MainActivity,name:String){val root=a.window.decorView;val b=Bitmap.createBitmap(root.width,root.height,Bitmap.Config.ARGB_8888);root.draw(Canvas(b));File("build/spotlight-previews/$name.png").apply{parentFile!!.mkdirs()}.outputStream().use{b.compress(Bitmap.CompressFormat.PNG,100,it)};b.recycle()}
    @Test fun shelvesContainVodOnlyAndShowSavedEpisodeAndRemainingTime(){
        val ctl=start();val a=ctl.get();val home=field(a,"home") as SpotlightHomeView
        try{
            val headers=views(home.root).filter{(it.tag as? String)?.startsWith("home-section:")==true}
            assertEquals(listOf("home-section:list","home-section:movie","home-section:series"),headers.map{it.tag})
            assertNull(home.root.findViewWithTag<View>("item:channel"))
            assertEquals(3,views(home.root).count{(it.tag as? String)?.startsWith("spot-pick:")==true})
            assertTrue(views(home.root).filterIsInstance<TextView>().any{it.text.toString().contains("S1 E4")})
            assertTrue(views(home.root).filterIsInstance<TextView>().any{it.text.toString()==a.getString(R.string.spotlight_minutes_left,5L)})
        }finally{ctl.pause().stop().destroy()}
    }
    @Test fun rapidPickFocusPublishesLatestSelectionAndPlayUsesThatTitle(){
        val ctl=start();val a=ctl.get();val root=a.window.decorView
        try{
            val first=root.findViewWithTag<View>("spot-pick:movie-0");val second=root.findViewWithTag<View>("spot-pick:movie-1");val third=root.findViewWithTag<View>("spot-pick:movie-2")
            second.requestFocusFromTouch();shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(100));third.requestFocusFromTouch();shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(190));layout(a)
            assertEquals("Before the Harvest",root.findViewWithTag<TextView>("spotlight-hero-title").text.toString())
            second.requestFocusFromTouch();first.performClick();shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(220));layout(a)
            assertEquals("The Last Train",root.findViewWithTag<TextView>("spotlight-hero-title").text.toString())
            third.performClick();root.findViewWithTag<View>("hero-play").performClick()
            assertEquals("file:///movie-2.mp4",shadowOf(a).nextStartedActivityForResult.intent.getStringExtra("url"))
        }finally{ctl.pause().stop().destroy()}
    }
    @Test fun detailsOpensSelectedTitleAndSidebarReachesSettingsWithoutLeavingIt(){
        val ctl=start();val a=ctl.get();val root=a.window.decorView
        try{
            val nav=views(root).filterIsInstance<DesignNav>();assertEquals(7,nav.size)
            val first=nav.first{it.contentDescription==a.getString(R.string.home)};first.requestFocusFromTouch()
            repeat(20){a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_DOWN))}
            assertTrue(nav.last().hasFocus());assertEquals(a.getString(R.string.settings),nav.last().contentDescription)
            a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_RIGHT));layout(a)
            assertTrue(root.findViewWithTag<View>("hero-play").hasFocus())
            root.findViewWithTag<View>("spot-pick:movie-1").performClick();root.findViewWithTag<View>("spotlight-details").performClick()
            val intent=shadowOf(a).nextStartedActivity
            assertEquals(SeriesActivity::class.java.name,intent.component!!.className);assertEquals("movie-1",intent.getStringExtra("id"))
        }finally{ctl.pause().stop().destroy()}
    }
    @Test fun heroMirrorsStacksAndFitsLargeFontsWithBilingualPreviews(){
        for(lang in listOf("en","ar"))for(size in listOf("1.0","1.3")){
            Repo.put("lang",lang);Repo.put("ts",size)
            val ctl=start();val a=ctl.get();val root=a.window.decorView
            try{
                val hero=root.findViewWithTag<SpotlightHeroLayout>("spotlight-hero")
                assertEquals(lang=="en",hero.textColumn.left<hero.picksColumn.left)
                assertTrue(hero.textColumn.top>=hero.chrome.height);assertTrue(hero.textColumn.bottom<=hero.height);assertTrue(hero.picksColumn.bottom<=hero.height)
                if(size=="1.0")shot(a,"spotlight-$lang")
                val narrowWidth = View.MeasureSpec.makeMeasureSpec(a.dp(520), View.MeasureSpec.EXACTLY)
                val height = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                hero.measure(narrowWidth, height)
                hero.layout(0, 0, hero.measuredWidth, hero.measuredHeight)
                assertEquals(a.dp(520), hero.width)
                assertTrue(hero.picksColumn.top >= hero.textColumn.bottom)
                assertTrue(hero.picksColumn.bottom <= hero.height)
            }finally{ctl.pause().stop().destroy()}
        }
    }
    @Test fun stoppedHomeRejectsPendingPickWork(){
        val ctl=start();val a=ctl.get();val home=field(a,"home") as SpotlightHomeView
        try{
            home.root.findViewWithTag<View>("spot-pick:movie-2").requestFocusFromTouch();home.stop()
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(250))
            assertEquals("The Last Train",home.root.findViewWithTag<TextView>("spotlight-hero-title").text.toString())
        }finally{ctl.pause().stop().destroy()}
    }
}
