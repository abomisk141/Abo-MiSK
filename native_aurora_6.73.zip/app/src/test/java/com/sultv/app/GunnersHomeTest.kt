package com.sultv.app

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "ar-rSA-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class GunnersHomeTest {
    @Test fun fixturesOpenTheThreeBroadcasterRegions() {
        val controller = Robolectric.buildActivity(Activity::class.java).setup().visible()
        val activity = controller.get()
        Repo.init(activity)
        Repo.sp.edit().remove("gunnersLeagues").commit()
        val home = GunnersHomeView(activity, {}, {})
        val fixtures = listOf(
            match(1, "أرسنال", "تشيلسي"),
            match(2, "ليفربول", "برايتون"),
            match(3, "مانشستر يونايتد", "أستون فيلا")
        )
        GunnersHomeView::class.java.getDeclaredField("games").apply { isAccessible = true }.set(home, fixtures)
        activity.setContentView(home.root)
        try {
            home.render()
            assertNotNull(home.root.findViewWithTag<View>("gunners-leagues"))
            capture(home.root, "gunners-home")
            val firstFixture = home.root.findViewWithTag<View>("gunners-match-1")
            assertTrue(firstFixture.getGlobalVisibleRect(android.graphics.Rect()))
            home.root.findViewWithTag<View>("gunners-featured").performClick()
            GunnersData.countries.forEach { (code, _) ->
                assertNotNull(home.root.findViewWithTag<View>("gunners-country-$code"))
            }
            capture(home.root, "gunners-broadcasters")
            assertTrue(home.root.findViewWithTag<View>("gunners-country-MENA")
                .getGlobalVisibleRect(android.graphics.Rect()))
        } finally {
            home.destroy()
            controller.pause().stop().destroy()
        }
    }

    @Test fun regionalListingsMatchBothTeamsTimeAndCountry() {
        val fixture = GunnersMatch(
            4828427, 572, "دوري أبطال أوروبا",
            GunnersTeam("ريال مدريد", "real-madrid", ""),
            GunnersTeam("آيندهوفن", "psv-eindhoven", ""),
            1_795_550_400_000L, false, false, "", ""
        )
        val listing = JSONObject().apply {
            put("strCountry", "Saudi Arabia")
            put("strEvent", "Real Madrid vs PSV Eindhoven")
            put("strTimeStamp", "2026-11-24 20:00:00")
            put("strChannel", "TOD KSA")
        }
        val stations = GunnersData.stationsForMatch(fixture, "Saudi Arabia", R.string.gunners_sa, listOf(listing))
        assertEquals(listOf(GunnersStation("TOD KSA", "", listOf(R.string.gunners_sa))), stations)
        assertTrue(GunnersData.stationsForMatch(fixture, "Qatar", R.string.gunners_qa, listOf(listing)).isEmpty())
        listing.put("strTimeStamp", "2026-11-24 22:00:00")
        assertTrue(GunnersData.stationsForMatch(fixture, "Saudi Arabia", R.string.gunners_sa, listOf(listing)).isEmpty())
    }

    @Test fun leaguePickerRetainsPriorSelectionsWhenSavingAnotherLeague() {
        val controller = Robolectric.buildActivity(Activity::class.java).setup().visible()
        val activity = controller.get()
        var saved = emptySet<String>()
        val options = listOf(GunnersOption("7", "Premier League"), GunnersOption("11", "La Liga"))
        val dialog = showGunnersPicker(activity, "Leagues", options, setOf("7"), multiple = true) { saved = it }
        try {
            val list = dialog.window!!.decorView.findViewWithTag<android.widget.ListView>("gunners-picker-list")
            assertEquals(2, list.count)
            val root = dialog.window!!.decorView
            root.measure(View.MeasureSpec.makeMeasureSpec(560, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(460, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 560, 460)
            assertTrue(list.requestFocusFromTouch())
            assertTrue(dialog.dispatchKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,
                android.view.KeyEvent.KEYCODE_DPAD_RIGHT)))
            root.requestLayout()
            root.layout(0, 0, 560, 460)
            list.performItemClick(null, 1, 1)
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick()
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
            assertEquals(setOf("7", "11"), saved)
        } finally {
            dialog.dismiss()
            controller.pause().stop().destroy()
        }
    }

    private fun match(id: Int, home: String, away: String) = GunnersMatch(
        id, 1, "الدوري الإنجليزي الممتاز", GunnersTeam(home, "", ""), GunnersTeam(away, "", ""),
        1_795_539_600_000L, false, false, "", ""
    )

    private fun capture(root: View, name: String) {
        val width = 960
        val height = 540
        root.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
        root.layout(0, 0, width, height)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        root.draw(Canvas(bitmap))
        val file = File("build/gunners-previews/$name.png").apply { parentFile?.mkdirs() }
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
    }
}
