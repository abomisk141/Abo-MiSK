package com.sultv.app

import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ScrollView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class SettingsMenuLayoutTest {
    @Before fun setup() { Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit() }
    private fun layout(a: SettingsActivity, height: Int = 540) {
        val root = a.window.decorView
        repeat(2) {
            root.measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 960, height)
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(250))
        }
    }
    @Test fun bottomSectionsRemainFullyVisibleWhenFocusedAtNormalAndLargerTextSizes() {
        for (lang in listOf("ar", "en")) for (scale in listOf("0.9", "1.0", "1.15", "1.3")) {
            Repo.put("lang", lang); Repo.put("ts", scale)
            val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup().visible()
            val a = controller.get()
            try {
                for (height in listOf(480, 540)) {
                    layout(a, height)
                    val scroll = a.window.decorView.findViewWithTag<ScrollView>("settings-menu-scroll")
                    assertNotNull(scroll)
                    for (key in listOf("backup", "about", "general")) {
                        val row = a.window.decorView.findViewWithTag<View>("settings-section:$key")
                        assertTrue(row.requestFocusFromTouch()); layout(a, height)
                        val pos = IntArray(2); val bounds = IntArray(2)
                        row.getLocationInWindow(pos); scroll.getLocationInWindow(bounds)
                        val child = scroll.getChildAt(0)
                        val message = "$lang/$scale/$height/$key row=${pos[1]}..${pos[1]+row.height} scroll=${bounds[1]}..${bounds[1]+scroll.height} y=${scroll.scrollY} rowTop=${row.top} rowBottom=${row.bottom} child=${child.height}/${child.measuredHeight} lp=${child.layoutParams.height}"
                        assertTrue(message, pos[1] >= bounds[1])
                        assertTrue(message, pos[1] + row.height <= bounds[1] + scroll.height)
                    }
                }
            } finally { controller.pause().stop().destroy() }
        }
    }
    @Test fun remoteCanTraverseEverySectionDownToAboutAndBackToGeneral() {
        Repo.put("lang", "en"); Repo.put("ts", "1.3")
        val controller = Robolectric.buildActivity(SettingsActivity::class.java).setup().visible()
        val a = controller.get()
        val keys = listOf("general", "appearance", "playlists", "manage", "playback", "remote", "guide", "parental", "backup", "about")
        try {
            layout(a)
            a.window.decorView.findViewWithTag<View>("settings-section:general").requestFocusFromTouch()
            fun press(key: Int) { a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key)); a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key)); layout(a) }
            for (key in keys.drop(1)) { press(KeyEvent.KEYCODE_DPAD_DOWN); assertEquals("settings-section:$key", a.window.decorView.findFocus()?.tag) }
            for (key in keys.dropLast(1).reversed()) { press(KeyEvent.KEYCODE_DPAD_UP); assertEquals("settings-section:$key", a.window.decorView.findFocus()?.tag) }
        } finally { controller.pause().stop().destroy() }
    }
}
