package com.sultv.app

import org.junit.Assert.*
import org.junit.Test

class LiveBufferTrimmerTest {
    @Test fun speedsUpOnlyAboveStartAndReturnsToNormalAtStop() {
        val t = LiveBufferTrimmer()
        assertEquals(1f, t.speed(0, true, true, 5000), 0f)
        assertEquals(LiveBufferTrimmer.SPEED, t.speed(1000, true, true, 12000), 0f)
        assertEquals(LiveBufferTrimmer.SPEED, t.speed(2000, true, true, 4000), 0f)
        assertEquals(1f, t.speed(3000, true, true, 3000), 0f)
        assertEquals(1f, t.speed(4000, true, true, 5000), 0f)
    }
    @Test fun neverSpeedsUpWhenDisabledOrNotPlaying() {
        val t = LiveBufferTrimmer()
        assertEquals(1f, t.speed(0, false, true, 15000), 0f)
        assertEquals(1f, t.speed(0, true, false, 15000), 0f)
    }
    @Test fun stallPausesTrimmingForCooldownThenResumes() {
        val t = LiveBufferTrimmer()
        assertEquals(LiveBufferTrimmer.SPEED, t.speed(0, true, true, 12000), 0f)
        t.onStall(1000)
        assertEquals(1f, t.speed(1500, true, true, 12000), 0f)
        assertEquals(1f, t.speed(60999, true, true, 12000), 0f)
        assertEquals(LiveBufferTrimmer.SPEED, t.speed(61000, true, true, 12000), 0f)
    }
    @Test fun resetClearsCooldownAndState() {
        val t = LiveBufferTrimmer()
        t.onStall(0); t.reset()
        assertEquals(LiveBufferTrimmer.SPEED, t.speed(1000, true, true, 12000), 0f)
    }
    @Test fun fastProfileCatchesUpFasterThanBefore() {
        assertTrue(PlaybackPolicy.liveProfile("fast").maxCatchupSpeed > 1.03f)
        assertEquals(1.03f, PlaybackPolicy.liveProfile("balanced").maxCatchupSpeed, 0f)
    }
}
