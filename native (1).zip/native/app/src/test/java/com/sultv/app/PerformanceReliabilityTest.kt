package com.sultv.app

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PerformanceReliabilityTest {
    @Before fun setup() { Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore() }
    private fun list(name: String, guide: String = "old-guide") = "#EXTM3U url-tvg=\"https://example.test/$guide.xml\"\n#EXTINF:-1 group-title=\"Live\",$name\nhttps://example.test/$name.ts\n"

    @Test fun failedAndEmptyRefreshesKeepBothCatalogueAndLastGoodDiskCopy() {
        Server().use { server ->
            server.body.set(list("Old"))
            val p = Playlist("safe", "Safe", "m3u", server.url, "", "", "")
            Repo.savePlaylists(listOf(p)); assertTrue(Repo.load(true))
            val previous = Repo.items
            val file = java.io.File(RuntimeEnvironment.getApplication().filesDir, "pl_safe.bin")
            val bytes = file.readBytes()
            val guide = Repo.epgUrl()
            server.status.set(500)
            assertFalse(Repo.refreshCacheInBackground()); assertFalse(Repo.load(true))
            assertEquals(previous, Repo.items); assertArrayEquals(bytes, file.readBytes()); assertEquals(guide, Repo.epgUrl())
            server.status.set(200); server.body.set("#EXTM3U\n")
            assertFalse(Repo.refreshCacheInBackground()); assertArrayEquals(bytes, file.readBytes())
            server.body.set(list("New", "new-guide"))
            assertTrue(Repo.refreshCacheInBackground())
            assertEquals(previous, Repo.items); assertEquals(guide, Repo.epgUrl())
            assertTrue(Repo.load()); assertEquals("New", Repo.items.single().name)
            assertTrue(Repo.epgUrl().contains("new-guide"))
        }
    }

    @Test fun concurrentRefreshesShareOneDownloadAndDoNotSwitchTheActiveAccount() {
        Server().use { server ->
            server.body.set(list("Initial"))
            val p = Playlist("one", "One", "m3u", server.url, "", "", "")
            Repo.savePlaylists(listOf(p)); assertTrue(Repo.load(true))
            val baseline = server.requests.get(); server.delay = 200
            val executor = Executors.newFixedThreadPool(2); val ready = CountDownLatch(2); val start = CountDownLatch(1)
            try {
                val calls = (1..2).map { executor.submit<Boolean> { ready.countDown(); start.await(); Repo.refreshCacheInBackground(p) } }
                assertTrue(ready.await(2, TimeUnit.SECONDS)); start.countDown()
                calls.forEach { assertTrue(it.get(5, TimeUnit.SECONDS)) }
                assertEquals(1, server.requests.get() - baseline)
                assertEquals(p.id, Repo.active()!!.id)
            } finally { executor.shutdownNow() }
        }
    }

    @Test fun partialXtreamFailuresNeverReplaceTheCompletePreviousCatalogue() {
        Server().use { server ->
            server.xtream = true
            val p = Playlist("xt-safe", "XT", "xt", "", server.url, "u", "p")
            Repo.savePlaylists(listOf(p)); assertTrue(Repo.load(true))
            assertEquals(3, Repo.items.size)
            val previous = Repo.items
            val file = java.io.File(RuntimeEnvironment.getApplication().filesDir, "pl_xt-safe.bin"); val bytes = file.readBytes()
            server.failSeries = true
            assertFalse(Repo.refreshCacheInBackground()); assertEquals(previous, Repo.items); assertArrayEquals(bytes, file.readBytes())
        }
    }

    @Test fun onlyTheNewestQueuedBackgroundResultCanRunAndCloseInterruptsOldWork() {
        val work = LatestWork(); val running = CountDownLatch(1); val finished = CountDownLatch(1)
        val result = AtomicInteger()
        work.submit { running.countDown(); Thread.sleep(10000); result.set(1) }
        assertTrue(running.await(2, TimeUnit.SECONDS))
        work.submit { result.set(2); finished.countDown() }
        assertTrue(finished.await(2, TimeUnit.SECONDS)); assertEquals(2, result.get()); work.close()
    }

    @Test fun twoConsumersOfTheSameSeriesShareOneMetadataRequest() {
        Server().use { server ->
            server.xtream = true
            val p = Playlist("metadata", "Metadata", "xt", "", server.url, "u", "p")
            Repo.savePlaylists(listOf(p)); assertTrue(Repo.load(true))
            val series = Repo.list("series").single()
            val baseline = server.requests.get(); server.delay = 200
            val executor = Executors.newFixedThreadPool(2); val start = CountDownLatch(1)
            try {
                val calls = (1..2).map { executor.submit<List<Item>> { start.await(); Repo.episodes(series) } }
                start.countDown(); calls.forEach { assertEquals(1, it.get(5, TimeUnit.SECONDS).size) }
                assertEquals(1, server.requests.get() - baseline)
            } finally { executor.shutdownNow() }
        }
    }

    @Test fun cancellingAnObsoleteRefreshDisconnectsItAndKeepsTheGoodCache() {
        Server().use { server ->
            server.body.set(list("Good"))
            val p = Playlist("cancel-safe", "Cancel", "m3u", server.url, "", "", "")
            Repo.savePlaylists(listOf(p)); assertTrue(Repo.load(true))
            val file = java.io.File(RuntimeEnvironment.getApplication().filesDir, "pl_cancel-safe.bin")
            val previous = file.readBytes(); val baseline = server.requests.get()
            server.body.set(list("Obsolete")); server.delay = 10000
            val work = LatestWork(); val done = CountDownLatch(1)
            work.submit { try { Repo.refreshCacheInBackground(p) } finally { done.countDown() } }
            val deadline = System.currentTimeMillis() + 2000
            while (server.requests.get() == baseline && System.currentTimeMillis() < deadline) Thread.sleep(5)
            assertEquals(baseline + 1, server.requests.get())
            work.close()
            assertTrue("Cancellation must not wait for the 10-second server response", done.await(2, TimeUnit.SECONDS))
            assertArrayEquals(previous, file.readBytes()); assertEquals("Good", Repo.items.single().name)
        }
    }

    @Test fun unchangedListsProduceNoGlobalRefreshAndOneChangedItemProducesOneChange() {
        val old = listOf("one", "two", "three")
        val changes = AtomicInteger()
        val callback = object : androidx.recyclerview.widget.ListUpdateCallback {
            override fun onInserted(position: Int, count: Int) { changes.addAndGet(count) }
            override fun onRemoved(position: Int, count: Int) { changes.addAndGet(count) }
            override fun onMoved(fromPosition: Int, toPosition: Int) { changes.incrementAndGet() }
            override fun onChanged(position: Int, count: Int, payload: Any?) { changes.addAndGet(count) }
        }
        ListUpdates.diff(old, old, { a, b -> a == b }).dispatchUpdatesTo(callback)
        assertEquals(0, changes.get())
        ListUpdates.diff(old, old, { a, b -> a == b }) { a, _ -> a != 1 }.dispatchUpdatesTo(callback)
        assertEquals(1, changes.get())
        assertEquals(1560, ListUpdates.limit(1800, anchor = 1501))
    }

    private class Server : AutoCloseable {
        private val socket = ServerSocket(0)
        val url = "http://127.0.0.1:${socket.localPort}"
        val body = AtomicReference(""); val status = AtomicInteger(200); val requests = AtomicInteger()
        @Volatile var delay = 0L
        @Volatile var xtream = false
        @Volatile var failSeries = false
        private val thread = Thread {
            while (!socket.isClosed) try {
                socket.accept().use { c ->
                    c.soTimeout = 5000
                    val reader = c.getInputStream().bufferedReader(); val first = reader.readLine().orEmpty()
                    while (!reader.readLine().isNullOrEmpty()) { }
                    requests.incrementAndGet(); if (delay > 0) Thread.sleep(delay)
                    val code = if (failSeries && first.contains("action=get_series&").not() && first.contains("action=get_series ")) 500 else status.get()
                    val content = if (!xtream) body.get() else when {
                        first.contains("action=get_series_info") -> "{\"info\":{\"plot\":\"Test\"},\"episodes\":{\"1\":[{\"id\":\"10\",\"title\":\"Episode 1\",\"season\":\"1\",\"episode_num\":\"1\"}]}}"
                        first.contains("categories") -> "[{\"category_id\":\"1\",\"category_name\":\"Test\"}]"
                        first.contains("get_live_streams") -> "[{\"stream_id\":1,\"name\":\"Live\",\"category_id\":\"1\"}]"
                        first.contains("get_vod_streams") -> "[{\"stream_id\":2,\"name\":\"Movie\",\"category_id\":\"1\"}]"
                        else -> "[{\"series_id\":3,\"name\":\"Series\",\"category_id\":\"1\"}]"
                    }
                    val bytes = content.toByteArray()
                    c.getOutputStream().apply { write("HTTP/1.1 $code OK\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray()); write(bytes); flush() }
                }
            } catch (_: Exception) { }
        }.apply { isDaemon = true; start() }
        override fun close() { socket.close(); thread.interrupt(); thread.join(1000) }
    }
}
