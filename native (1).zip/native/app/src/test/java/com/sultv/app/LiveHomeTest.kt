package com.sultv.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "en-rUS-w960dp-h540dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class LiveHomeTest {
    @Before fun setup() {
        Repo.init(RuntimeEnvironment.getApplication()); Repo.sp.edit().clear().commit(); Repo.afterBackupRestore()
        Repo.putB("autoUpd", false); Repo.putB("welcome", false); Repo.putB("autoPrev", false); Repo.putB("tmdbOn", false); Repo.putB("epgOn", false); Repo.putB("referenceLayoutV52", true)
        Repo.put("pl_refresh_hours", "0"); Repo.put("ui", "live"); Repo.updChecked = true; Repo.splashShown = true
        Repo.savePlaylists(listOf(Playlist("live-home", "Fixture", "m3u", "https://example.test/fixture", "", "", "")))
        Repo.items = listOf("Sports", "News", "Documentaries").flatMapIndexed { groupIndex, group -> (0..3).map { n -> Item("live-$groupIndex-$n", "AM $group ${n+1}", "", group, "live", u="file:///live-$groupIndex-$n.ts", epg="guide-$groupIndex-$n") } }
        Repo::class.java.getDeclaredMethod("build").apply { isAccessible = true }.invoke(Repo); Repo.dirty = false
        Repo.toggleFav("live-0-0"); Repo.toggleFav("live-0-1")
        val start = System.currentTimeMillis() / 1800000L * 1800000L
        Repo.epg = Repo.items.associate { it.epg to listOf(Prog(start, start+1800000L, "Match night"), Prog(start+1800000L, start+3600000L, "Post-match analysis")) }
    }
    private fun field(a: Any, name: String) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(a)
    private fun set(a: Any, name: String, value: Any) = a.javaClass.getDeclaredField(name).apply { isAccessible = true }.set(a, value)
    private fun views(v: View): List<View> = listOf(v) + if(v is ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) } else emptyList()
    private fun layout(a: MainActivity) {
        a.window.decorView.apply { measure(View.MeasureSpec.makeMeasureSpec(960, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(540, View.MeasureSpec.EXACTLY)); layout(0,0,960,540) }
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(40))
    }
    private fun settle(a: MainActivity, condition: () -> Boolean) {
        val end = System.nanoTime()+5_000_000_000L
        do { layout(a); Thread.sleep(3) } while(!condition() && System.nanoTime()<end)
        assertTrue(condition()); repeat(2){layout(a)}
    }
    private fun start() = Robolectric.buildActivity(MainActivity::class.java).setup().visible().also { ctl -> settle(ctl.get()) { ctl.get().window.decorView.findViewWithTag<View>("live-home-guide") != null } }
    private fun shot(a: MainActivity, name: String) {
        val root = a.window.decorView; val b=Bitmap.createBitmap(root.width,root.height,Bitmap.Config.ARGB_8888);root.draw(Canvas(b))
        File("build/live-home-previews/$name.png").apply { parentFile!!.mkdirs() }.outputStream().use{ b.compress(Bitmap.CompressFormat.PNG,100,it) };b.recycle()
    }
    @Test fun favouritesAndFiltersUseRealChannelsAndGuideSelectionUpdatesPreview() {
        val ctl=start();val a=ctl.get(); val root=a.window.decorView
        try {
            assertTrue(field(a,"home") is LiveHomeView)
            assertEquals(2,views(root.findViewWithTag<View>("live-home-favourites")).count{(it.tag as? String)?.startsWith("live-pick:")==true})
            val guide=root.findViewWithTag<ViewGroup>("live-home-guide");assertEquals(6,guide.childCount)
            root.findViewWithTag<View>("live-filter:News").performClick();layout(a)
            assertEquals(4,guide.childCount);assertTrue((0 until guide.childCount).all{guide.getChildAt(it).tag.toString().startsWith("live-guide:live-1-")})
            guide.getChildAt(0).requestFocusFromTouch();guide.getChildAt(0).performClick()
            assertEquals("AM News 1",root.findViewWithTag<TextView>("live-home-channel").text.toString());assertEquals("live-1-0",Repo.s("lastLive"))
            repeat(10){a.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_DOWN))}
            assertTrue(guide.hasFocus())
            (field(field(a,"home"),"tick") as Runnable).run();layout(a);assertTrue(guide.hasFocus())
            assertTrue(views(guide).filterIsInstance<EpgView>().all{it.displayedProgrammes().size==2})
        } finally {ctl.pause().stop().destroy()}
    }
    @Test fun fullscreenReleasesPreviewBeforeLaunchingAndTvGuideOpensChannels() {
        val ctl=start();val a=ctl.get();val root=a.window.decorView;val home=field(a,"home") as LiveHomeView
        try {
            val player=makePlayer(a,true);set(home,"preview",player);(field(home,"playerView") as PlayerView).player=player
            root.findViewWithTag<View>("hero-play").performClick()
            assertNull(field(home,"preview"));assertNull((field(home,"playerView") as PlayerView).player)
            val launch=shadowOf(a).nextStartedActivityForResult
            assertNotNull(launch);assertEquals(Repo.items[0].url,launch.intent.getStringExtra("url"))
            root.findViewWithTag<View>("live-home-guide-button").performClick();settle(a){field(a,"tab")=="live" && field(a,"filtering")==false}
            assertEquals(View.GONE,home.root.visibility)
        } finally {ctl.pause().stop().destroy()}
    }
    @Test fun republishingSameChannelMovesSurfaceWithoutRecreatingPlayerAndStopReleasesIt() {
        val ctl=start();val a=ctl.get();val home=field(a,"home") as LiveHomeView
        try {
            val player=makePlayer(a,true);set(home,"preview",player)
            val old=field(home,"playerView") as PlayerView;old.player=player
            home.render();settle(a){field(home,"playerView") !== old}
            assertSame(player,field(home,"preview"));assertSame(player,(field(home,"playerView") as PlayerView).player);assertNull(old.player)
            home.stop();assertNull(field(home,"preview"));assertNull((field(home,"playerView") as PlayerView).player)
        } finally {ctl.pause().stop().destroy()}
    }
    @Test fun heroMirrorsAndLargeFontsFitWithActualBilingualPreviews() {
        for(lang in listOf("en","ar"))for(size in listOf("1.0","1.3")){
            Repo.put("lang",lang);Repo.put("ts",size)
            val ctl=start();val a=ctl.get();val root=a.window.decorView
            try {
                val hero=root.findViewWithTag<LiveHeroLayout>("live-hero")
                assertEquals(lang=="en",hero.preview.left<hero.info.left)
                assertTrue(hero.info.top>=0 && hero.info.bottom<=hero.height);assertTrue(hero.preview.bottom<=hero.height)
                val actions=root.findViewWithTag<HeroActionsLayout>("live-hero-actions")
                assertTrue(actions.bottom<=hero.info.height)
                (field(field(a,"home"),"previewImage") as ImageView).setImageResource(R.drawable.logo)
                if(size=="1.0"){
                    shot(a,"live-home-$lang")
                    (field(a,"home") as HomeLike).root.let{(it as android.widget.ScrollView).fullScroll(View.FOCUS_DOWN)};layout(a);shot(a,"live-home-guide-$lang")
                }
            } finally {ctl.pause().stop().destroy()}
        }
    }
    @Test fun noFavouritesUsesAnHonestChannelShelfLabel() {
        Repo.toggleFav("live-0-0");Repo.toggleFav("live-0-1")
        val ctl=start();val a=ctl.get()
        try {assertTrue(views(a.window.decorView).filterIsInstance<TextView>().any{it.text.toString()==a.getString(R.string.live_home_channels)})}
        finally {ctl.pause().stop().destroy()}
    }
}
