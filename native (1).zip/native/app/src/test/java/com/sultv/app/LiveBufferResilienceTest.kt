package com.sultv.app

import androidx.media3.exoplayer.DefaultLoadControl
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class LiveBufferResilienceTest {
    @Test fun fastModeKeepsFetchingPastFiveSecondsWithoutWaitingLongerToStart() {
        val profile = PlaybackPolicy.liveProfile("fast")
        val control = DefaultLoadControl.Builder().setBufferDurationsMs(profile.minBufferMs,
            profile.maxBufferMs, profile.startBufferMs, profile.rebufferMs)
            .setPrioritizeTimeOverSizeThresholds(true).build()
        control.onPrepared()
        // Five and a half seconds of healthy incoming data should not stop loading as the old 5s cap did.
        assertTrue(control.shouldContinueLoading(0L, 5_500_000L, 1f))
        assertTrue(control.shouldStartPlayback(400_000L, 1f, false, androidx.media3.common.C.TIME_UNSET))
        // After a stall, accumulate a useful cushion instead of immediately stalling again.
        assertFalse(control.shouldStartPlayback(400_000L, 1f, true, androidx.media3.common.C.TIME_UNSET))
        assertTrue(control.shouldStartPlayback(1_500_000L, 1f, true, androidx.media3.common.C.TIME_UNSET))
        control.onReleased()
    }
}
