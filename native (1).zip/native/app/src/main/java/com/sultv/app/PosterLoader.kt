package com.sultv.app

import android.content.Context
import android.content.ContextWrapper
import android.app.Activity
import android.os.Looper
import android.util.Log
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.Priority
import com.bumptech.glide.Registry
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory
import com.bumptech.glide.load.engine.cache.LruResourceCache
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import com.bumptech.glide.module.GlideModule
import com.bumptech.glide.signature.ObjectKey

/** Configured through the manifest, without generated modules or an annotation processor. */
@Suppress("DEPRECATION")
class PosterGlideModule : GlideModule {
    override fun applyOptions(context: Context, builder: GlideBuilder) {
        val heap = Runtime.getRuntime().maxMemory()
        builder.setMemoryCache(LruResourceCache((heap / 12).coerceIn(6L * 1024 * 1024, 32L * 1024 * 1024)))
            .setBitmapPool(LruBitmapPool((heap / 24).coerceIn(3L * 1024 * 1024, 16L * 1024 * 1024)))
            .setDiskCache(InternalCacheDiskCacheFactory(context, "artwork", 128L * 1024 * 1024))
            .setLogLevel(Log.ERROR)
    }
    override fun registerComponents(context: Context, glide: Glide, registry: Registry) {}
}

object Img {
    fun prefetch(context: Context, url: String, width: Int, height: Int): com.bumptech.glide.request.target.Target<android.graphics.Bitmap>? {
        if (url.isBlank()) return null
        val agent = RequestIdentity.userAgent()
        return Glide.with(context).asBitmap().load(GlideUrl(sourceUrl(url, 2), LazyHeaders.Builder().setHeader("User-Agent", agent).build()))
            .signature(ObjectKey(agent)).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .priority(Priority.LOW).override(width.coerceAtLeast(24), height.coerceAtLeast(24))
            .centerCrop().timeout(5000).disallowHardwareConfig().dontAnimate().preload()
    }
    /** Only resize documented public TMDB image paths; provider URLs are left untouched. */
    fun sourceUrl(url: String, sample: Int): String {
        val prefix = "https://image.tmdb.org/t/p/"
        if (!url.startsWith(prefix)) return url
        val path = url.removePrefix(prefix); val size = path.substringBefore('/')
        val width = Regex("w(\\d+)(?:_and_h\\d+_bestv2)?").matchEntire(size)?.groupValues?.get(1)?.toIntOrNull()
        val target = if (sample == 1) 1280 else 342
        return if (size == "original" || width != null && width > target)
            prefix + "w$target/" + path.substringAfter('/') else url
    }
    fun load(iv: ImageView, url: String, sample: Int = 2) {
        if (Looper.myLooper() != Looper.getMainLooper()) { iv.post { load(iv, url, sample) }; return }
        var owner: Context = iv.context
        repeat(12) {
            if (owner is Activity) {
                val activity = owner as Activity
                if (activity.isDestroyed || activity.isFinishing) return
            }
            val base = (owner as? ContextWrapper)?.baseContext
            if (base != null && base !== owner) owner = base
        }
        iv.tag = url
        if (url.isBlank()) { clear(iv); return }
        val agent = RequestIdentity.userAgent()
        val headers = LazyHeaders.Builder().setHeader("User-Agent", agent).build()
        val dm = iv.resources.displayMetrics
        val lp = iv.layoutParams
        val fallbackHeight = if (sample == 1) dm.heightPixels else (240 * dm.density).toInt()
        val height = (iv.height.takeIf { it > 0 } ?: lp?.height?.takeIf { it > 0 } ?: fallbackHeight).coerceIn(24, 1920)
        val fallbackWidth = if (sample == 1) dm.widthPixels else height * 2 / 3
        val width = (iv.width.takeIf { it > 0 } ?: lp?.width?.takeIf { it > 0 } ?: fallbackWidth).coerceIn(24, 1920)
        Glide.with(iv).asBitmap().load(GlideUrl(sourceUrl(url, sample), headers))
            .signature(ObjectKey(agent)) // a different provider identity must not reuse another response
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .priority(if (sample == 1) Priority.HIGH else Priority.NORMAL)
            .override(width, height).timeout(10000).disallowHardwareConfig().dontAnimate()
            .into(iv)
    }
    fun clear(iv: ImageView) {
        Glide.with(iv.context.applicationContext).clear(iv)
        iv.tag = null
        iv.setImageDrawable(null)
    }
}

/** Home rows use regular horizontal layouts, so their offscreen images must be deferred explicitly. */
class VisiblePosterView(c: Context) : ImageView(c) {
    private var poster = ""
    private var active = false
    private var monitor: PosterVisibility? = null
    fun setPoster(url: String) { if (poster != url) { if (active) Img.clear(this); active = false; poster = url }; monitor?.schedule() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); monitor = PosterVisibility.watch(this) }
    override fun onDetachedFromWindow() {
        monitor?.remove(this); monitor = null
        if (active) Img.clear(this); active = false
        super.onDetachedFromWindow()
    }
    fun updatePosterVisibility() {
        val visible = width > 0 && height > 0 && isShown && getGlobalVisibleRect(android.graphics.Rect())
        if (visible && !active && poster.isNotBlank()) { active = true; Img.load(this, poster) }
        else if (!visible && active) { Img.clear(this); active = false }
    }
}

class PosterVisibility private constructor(observer: android.view.ViewTreeObserver) {
    private val tree = java.lang.ref.WeakReference(observer)
    private val views = java.util.WeakHashMap<VisiblePosterView, Boolean>()
    private val handler = android.os.Handler(Looper.getMainLooper())
    private var scheduled = false
    private val scroll = android.view.ViewTreeObserver.OnScrollChangedListener { schedule() }
    private val layout = android.view.ViewTreeObserver.OnGlobalLayoutListener { schedule() }
    init { observer.addOnScrollChangedListener(scroll); observer.addOnGlobalLayoutListener(layout) }
    fun schedule() {
        if (scheduled) return
        scheduled = true
        handler.postDelayed({ scheduled = false; views.keys.toList().forEach { it.updatePosterVisibility() } }, 16)
    }
    fun remove(view: VisiblePosterView) {
        views.remove(view)
        if (views.isEmpty()) tree.get()?.let {
            if (it.isAlive) { it.removeOnScrollChangedListener(scroll); it.removeOnGlobalLayoutListener(layout) }
            monitors.remove(it); handler.removeCallbacksAndMessages(null)
        }
    }
    companion object {
        private val monitors = java.util.WeakHashMap<android.view.ViewTreeObserver, PosterVisibility>()
        fun watch(view: VisiblePosterView): PosterVisibility {
            val tree = view.viewTreeObserver
            val monitor = monitors.getOrPut(tree) { PosterVisibility(tree) }
            monitor.views[view] = true; monitor.schedule(); return monitor
        }
    }
}
