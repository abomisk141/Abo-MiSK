package com.sultv.app

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun col(s: String) = Color.parseColor(s)

private val hmFmt = SimpleDateFormat("HH:mm", Locale.US)
fun hm(ms: Long): String = hmFmt.format(Date(ms))

class CrashH(private val c: Context, private val prev: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
    override fun uncaughtException(t: Thread, e: Throwable) {
        try {
            val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
            c.getSharedPreferences("sul", 0).edit().putString("crash", sw.toString().take(2500)).commit()
        } catch (x: Throwable) { }
        prev?.uncaughtException(t, e)
    }
}

open class BaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        if (prev !is CrashH) Thread.setDefaultUncaughtExceptionHandler(CrashH(applicationContext, prev))
        val designPrefs = applicationContext.getSharedPreferences("sul", 0)
        if (designPrefs.getString("ui", "") == "reference" || designPrefs.getString("referenceLayoutV52", "0") != "1") {
            setTheme(R.style.AppTheme_Reference)
        }
        when (applicationContext.getSharedPreferences("sul", 0).getString("ft", "sys")) {
            "light" -> setTheme(R.style.AppTheme_FontLight)
            "med" -> setTheme(R.style.AppTheme_FontMedium)
            "cond" -> setTheme(R.style.AppTheme_FontCondensed)
            "serif" -> setTheme(R.style.AppTheme_FontSerif)
        }
        super.onCreate(savedInstanceState)
        // AppCompat may install its own override while creating the activity. Reconcile
        // the app language afterwards, before any screen builds its child views.
        val lang = designPrefs.getString("lang", "sys") ?: "sys"
        @Suppress("DEPRECATION")
        val locale = if (lang == "sys") Resources.getSystem().configuration.locale else Locale(lang)
        val config = android.content.res.Configuration(resources.configuration)
        config.setLocale(locale); config.setLayoutDirection(locale)
        config.fontScale = designPrefs.getString("ts", "1.0")?.toFloatOrNull() ?: 1f
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
        window.decorView.layoutDirection = config.layoutDirection
    }

    private fun animPref() = applicationContext.getSharedPreferences("sul", 0).getString("anim", "fade") ?: "fade"

    @Suppress("DEPRECATION")
    override fun startActivity(intent: Intent?) {
        super.startActivity(intent)
        when (animPref()) {
            "none" -> {}
            "slide" -> overridePendingTransition(R.anim.slide_up_in, R.anim.fade_out_short)
            "zoom" -> overridePendingTransition(R.anim.zoom_in, R.anim.fade_out_short)
            else -> overridePendingTransition(R.anim.fade_in, R.anim.fade_out_short)
        }
    }

    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        when (animPref()) {
            "none" -> {}
            "slide" -> overridePendingTransition(R.anim.fade_in, R.anim.slide_down_out)
            "zoom" -> overridePendingTransition(R.anim.fade_in, R.anim.zoom_out)
            else -> overridePendingTransition(R.anim.fade_in, R.anim.fade_out_short)
        }
    }

    @Suppress("DEPRECATION")
    override fun attachBaseContext(base: Context) {
        val prefs = (base.applicationContext ?: base).getSharedPreferences("sul", 0)
        val lang = prefs.getString("lang", "sys") ?: "sys"
        val locale = if (lang == "sys") Resources.getSystem().configuration.locale else Locale(lang)
        Locale.setDefault(locale)
        val config = android.content.res.Configuration(base.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        config.fontScale = prefs.getString("ts", "1.0")?.toFloatOrNull() ?: 1f
        super.attachBaseContext(base.createConfigurationContext(config))
    }

}

fun makePlayer(c: Context, live: Boolean = false): ExoPlayer {
    val traffic = StreamTraffic()
    val ds = DefaultHttpDataSource.Factory().setUserAgent(RequestIdentity.userAgent()).setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
        .setTransferListener(traffic)
    val lcb = if (live) {
        val profile = PlaybackPolicy.liveProfile()
        DefaultLoadControl.Builder().setBufferDurationsMs(profile.minBufferMs, profile.maxBufferMs, profile.startBufferMs, profile.rebufferMs)
            .setPrioritizeTimeOverSizeThresholds(true)
    } else when (Repo.s("buf", "n")) {
        "l" -> DefaultLoadControl.Builder().setBufferDurationsMs(5000, 20000, 1000, 2000)
        "h" -> DefaultLoadControl.Builder().setBufferDurationsMs(30000, 120000, 2500, 5000)
        else -> DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 2500, 5000)
    }
    val rf = DefaultRenderersFactory(c).setEnableDecoderFallback(true)
    val p = ExoPlayer.Builder(c, rf).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).setLoadControl(lcb.build()).build()
    PlaybackTraffic.register(p, traffic)
    val lang = Repo.s("alang", "auto")
    if (lang != "auto") p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setPreferredAudioLanguage(lang).build()
    return p
}

class Pal(val fg: Int, val mut: Int, val card: Int, val acc: Int, val bt: Int, val from: Int, val to: Int)

object Th {
    var fg = Color.WHITE; var mut = col("#A9B0DD"); var card = col("#1FFFFFFF"); var acc = col("#7C5CFF")
    var bt = Color.WHITE; var list = false; var name = "cinema"; var bgFrom = col("#0F1233"); var bgTo = col("#2B1055")
    val order = Designs.ids

    fun pal(n: String): Pal = Designs.palette(n)

    fun load() {
        Designs.migrate()
        name = Repo.s("ui", "cinema")
        list = false
        val p = pal(name)
        fg = p.fg; mut = p.mut; card = p.card; acc = p.acc; bt = p.bt; bgFrom = p.from; bgTo = p.to
    }

    fun bg(): Drawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(bgFrom, bgTo))

    fun shape(c: Context, color: Int, focus: Boolean, r: Int = if (list) 4 else 20): Drawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = c.dp(r).toFloat()
            setStroke(c.dp(if (focus) 3 else 1), if (focus) acc else (if (name == "light") col("#22000000") else col("#26FFFFFF")))
        }

    fun icon(c: Context, res: Int, color: Int): Drawable? {
        val d = ContextCompat.getDrawable(c, res) ?: return null
        val m = d.mutate(); m.setTint(color); return m
    }

    fun paint(b: Button, on: Boolean) {
        val r = 10
        val fc = if (on) bt else fg
        b.setTextColor(fc)
        b.background = shape(b.context, if (on) acc else card, false, r)
        b.setOnFocusChangeListener { v, f -> v.background = shape(b.context, if (on) acc else card, f, r) }
        val ic = b.tag as? Int
        if (ic != null && ic != 0) b.setCompoundDrawablesRelativeWithIntrinsicBounds(icon(b.context, ic, fc), null, null, null)
    }

    fun btn(c: Context, txt: String, on: Boolean = false): Button =
        Button(c).apply { text = txt; isAllCaps = false; stateListAnimator = null; setPadding(c.dp(12), 0, c.dp(12), 0); paint(this, on) }

    fun tabBtn(c: Context, txt: String, ic: Int, on: Boolean): Button =
        Button(c).apply {
            text = txt; isAllCaps = false; stateListAnimator = null; tag = ic
            compoundDrawablePadding = c.dp(8); setPadding(c.dp(16), 0, c.dp(16), 0); paint(this, on)
        }

    fun spinnerAdapter(c: Context, l: List<String>): ArrayAdapter<String> {
        val a = object : ArrayAdapter<String>(c, android.R.layout.simple_spinner_item, l) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView; t.setTextColor(fg); return t
            }
        }
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return a
    }
}

/** Asks for a number (PIN) and hands the typed text back. */
fun AppCompatActivity.pinInput(title: Int, ok: (String) -> Unit) {
    val et = android.widget.EditText(this).apply {
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        setSingleLine(true); hint = "••••"; gravity = android.view.Gravity.CENTER; textSize = 24f
    }
    val box = android.widget.LinearLayout(this).apply { setPadding(dp(30), dp(10), dp(30), 0) }
    box.addView(et, android.widget.LinearLayout.LayoutParams(-1, -2))
    androidx.appcompat.app.AlertDialog.Builder(this).setTitle(title).setView(box)
        .setPositiveButton(R.string.ok) { _, _ -> ok(et.text.toString().trim()) }
        .setNegativeButton(R.string.cancel, null).show()
}

/** Runs ok() only if the parent types the right PIN. */
fun AppCompatActivity.askPin(title: Int, ok: () -> Unit) {
    pinInput(title) { if (Repo.checkPin(it)) ok() else android.widget.Toast.makeText(this, R.string.pin_wrong, android.widget.Toast.LENGTH_SHORT).show() }
}
