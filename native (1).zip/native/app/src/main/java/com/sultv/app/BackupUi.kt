package com.sultv.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class BackupUi(private val a: SettingsActivity) {
    private val executor = Executors.newSingleThreadExecutor()
    private var busy = false
    private var progress: AlertDialog? = null
    private val file get() = File(a.cacheDir, "backups/ABOMISK-backup.abomisk")
    private val exportRequest = 8201
    private val restoreRequest = 8202

    private fun message(id: Int) { Toast.makeText(a, id, Toast.LENGTH_LONG).show() }
    private fun <T> work(task: () -> T, done: (T) -> Unit) {
        if (busy) return
        busy = true
        progress = AlertDialog.Builder(a).setMessage(R.string.backup_working).setCancelable(false).show()
        executor.execute {
            val result = runCatching(task)
            a.runOnUiThread {
                busy = false
                progress?.dismiss(); progress = null
                if (!a.isFinishing && !a.isDestroyed) result.fold(done) {
                    message(if (it is AppBackup.InvalidBackup) R.string.backup_invalid else R.string.backup_failed)
                }
            }
        }
    }

    private fun password(export: Boolean, action: (CharArray) -> Unit) {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(8), a.dp(20), 0) }
        box.addView(TextView(a).apply { setText(if (export) R.string.backup_password_hint else R.string.backup_unlock_hint) })
        fun field(hintId: Int) = EditText(a).apply {
            setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setHint(hintId); box.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        val first = field(R.string.backup_password)
        val second = if (export) field(R.string.backup_password_confirm) else null
        val d = AlertDialog.Builder(a).setTitle(if (export) R.string.backup_export else R.string.backup_restore)
            .setView(box).setPositiveButton(R.string.done, null).setNegativeButton(R.string.no, null).create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (first.text.length < 8 || first.text.length > 256) { first.error = a.getString(R.string.backup_password_length); return@setOnClickListener }
            if (second != null && first.text.toString() != second.text.toString()) {
                second.error = a.getString(R.string.backup_password_mismatch); return@setOnClickListener
            }
            val chars = first.text.toString().toCharArray()
            first.text.clear(); second?.text?.clear(); d.dismiss()
            action(chars)
        }
    }

    fun export() {
        if (busy) return
        password(true) { chars ->
            work({
                try {
                    val bytes = AppBackup.export(Repo.sp, chars)
                    file.parentFile?.mkdirs()
                    val atomic = android.util.AtomicFile(file)
                    val out = atomic.startWrite()
                    try { out.write(bytes); atomic.finishWrite(out) }
                    catch (e: Exception) { atomic.failWrite(out); throw e }
                } finally { chars.fill('\u0000') }
            }) {
                val date = SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date())
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
                    putExtra(Intent.EXTRA_TITLE, "ABOMISK-$date.abomisk")
                }
                try { a.startActivityForResult(intent, exportRequest) }
                catch (_: ActivityNotFoundException) { share() }
            }
        }
    }

    fun share() {
        if (!file.exists()) { message(R.string.backup_create_first); return }
        val uri = FileProvider.getUriForFile(a, "${a.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"; putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newRawUri("Backup", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { a.startActivity(Intent.createChooser(intent, a.getString(R.string.backup_share))) }
        catch (_: ActivityNotFoundException) { message(R.string.backup_no_picker) }
    }

    fun restore() {
        if (busy) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        try { a.startActivityForResult(intent, restoreRequest) }
        catch (_: ActivityNotFoundException) {
            try { a.startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, restoreRequest) }
            catch (_: ActivityNotFoundException) { message(R.string.backup_no_picker) }
        }
    }

    fun result(request: Int, result: Int, data: Intent?) {
        if (result != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        when (request) {
            exportRequest -> work({
                a.contentResolver.openOutputStream(uri, "wt")?.use { out -> file.inputStream().use { it.copyTo(out) } }
                    ?: throw java.io.IOException()
            }) { message(R.string.backup_saved) }
            restoreRequest -> work({
                a.contentResolver.openInputStream(uri)?.use { AppBackup.read(it) } ?: throw java.io.IOException()
            }) { bytes ->
                password(false) { chars ->
                    work({ try { AppBackup.decode(bytes, chars) } finally { chars.fill('\u0000') } }) { snapshot -> confirm(snapshot) }
                }
            }
        }
    }

    private fun confirm(snapshot: AppBackup.Snapshot) {
        val date = android.text.format.DateFormat.getDateFormat(a).format(Date(snapshot.created))
        AlertDialog.Builder(a).setTitle(R.string.backup_restore)
            .setMessage(a.getString(R.string.backup_summary, date, snapshot.playlists, snapshot.favourites))
            .setNegativeButton(R.string.no, null)
            .setPositiveButton(R.string.backup_restore_confirm) { _, _ ->
                work({
                    AppBackup.restore(Repo.sp, snapshot)
                    Repo.afterBackupRestore()
                }) {
                    message(R.string.backup_restored)
                    a.startActivity(Intent(a, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                    a.finish()
                }
            }.show()
    }

    fun close() { progress?.dismiss(); progress = null; executor.shutdown() }
}
