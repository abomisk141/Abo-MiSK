package com.sultv.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** Live home owns one preview, with a bounded guide and real playlist-derived filters. */
class LiveHomeView(
    private val c: Context, private val play: (Item) -> Unit,
    private val menu: (Item) -> Unit, private val navigate: (String) -> Unit
) : HomeLike {
    override val root = ScrollView(c).apply { isVerticalScrollBarEnabled = false; clipToPadding = false }
    private val body = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; layoutDirection = c.resources.configuration.layoutDirection; setPadding(c.dp(4), c.dp(8), c.dp(4), c.dp(24)) }
    private val handler = Handler(Looper.getMainLooper())
    private val work = LatestWork()
    private var generation = 0
    private var running = false
    private var destroyed = false
    private var channels = emptyList<Item>()
    private var selected: Item? = null
    private var filter = ""
    private var preview: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var previewImage: ImageView? = null
    private var previewHint: TextView? = null
    private var groupText: TextView? = null
    private var programmeText: TextView? = null
    private var channelText: TextView? = null
    private var timeText: TextView? = null
    private var progress: WatchBar? = null
    private var guideBody: LinearLayout? = null
    private val guideCells = mutableListOf<Pair<Item, EpgView>>()
    private val picks = linkedMapOf<View, Item>()
    private val tick = object : Runnable {
        override fun run() {
            if (!running || destroyed) return
            updateInfo(); guideCells.forEach { (item, cell) -> cell.bind(Repo.progs(item), System.currentTimeMillis()) }
            handler.postDelayed(this, 30000)
        }
    }
    init { root.addView(body) }
    override fun start() {
        if (destroyed) return
        running = true
        channels.firstOrNull { it.id == Repo.s("lastLive") }?.let { if (selected?.id != it.id) select(it) }
        startPreview(); handler.removeCallbacks(tick); handler.post(tick)
    }
    override fun stop() {
        running = false; generation++; work.cancel(); handler.removeCallbacks(tick); releasePreview()
    }
    override fun destroy() { if (destroyed) return; stop(); destroyed = true; work.close(); handler.removeCallbacksAndMessages(null) }
    override fun render() {
        if (destroyed) return
        val token = ++generation
        work.submit {
            val visible = Repo.list("live")
            val favourites = Repo.favs()
            val pinned = visible.asSequence().filter { it.id in favourites }.take(20).toList()
            val groups = visible.asSequence().map { it.grp }.filter { it.isNotBlank() }.distinct().take(3).toList()
            handler.post { if (!destroyed && token == generation) show(visible, pinned, groups) }
        }
    }
    private fun surface(focused: Boolean = false, selected: Boolean = false) = GradientDrawable().apply {
        setColor(Th.card); cornerRadius = c.dp(12).toFloat()
        setStroke(c.dp(if (focused) 2 else 1), if (focused || selected) Th.acc else col("#20FFFFFF"))
    }
    private fun text(value: String, size: Float = 15f, muted: Boolean = false) = Designs.label(c, value, size, muted)
    private fun show(visible: List<Item>, favourites: List<Item>, groups: List<String>) {
        val focused = root.findFocus()?.tag as? String
        val oldView = playerView
        val previous = selected
        channels = visible
        selected = visible.firstOrNull { it.id == previous?.id } ?: visible.firstOrNull { it.id == Repo.s("lastLive") } ?: visible.firstOrNull()
        if (selected?.id != previous?.id || selected?.url != previous?.url) releasePreview()
        body.removeAllViews(); picks.clear(); guideCells.clear(); playerView = null
        if (visible.isEmpty()) {
            releasePreview()
            body.addView(text(c.getString(R.string.live_home_empty), 20f).apply { maxLines = 4; gravity = Gravity.CENTER; setPadding(c.dp(24), c.dp(50), c.dp(24), c.dp(50)) })
            return
        }
        hero()
        preview?.let { if (oldView !== playerView) PlayerView.switchTargetView(it, oldView, playerView) }
        channelShelf(if (favourites.isNotEmpty()) c.getString(R.string.live_home_favourites) else c.getString(R.string.live_home_channels), favourites.ifEmpty { visible.take(20) })
        guide(groups)
        selected?.let { item -> previewImage?.let { Img.load(it, item.logo) } }
        updateInfo(); startPreview()
        if (focused != null) root.findViewWithTag<View>(focused)?.requestFocus()
    }
    private fun hero() {
        val composition = LiveHeroLayout(c).apply { tag = "live-hero" }
        val screen = FrameLayout(c).apply {
            tag = "live-home-preview"; background = surface(); clipToOutline = true
            isFocusable = true; isClickable = true; contentDescription = c.getString(R.string.live_home_watch)
            setOnClickListener { selected?.let { fullscreen(it) } }
            setOnFocusChangeListener { _, focused -> background = surface(focused) }
        }
        previewImage = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        screen.addView(previewImage, FrameLayout.LayoutParams(-1, -1))
        playerView = PlayerView(c).apply {
            useController = false; isFocusable = false; isFocusableInTouchMode = false
            setShutterBackgroundColor(Color.TRANSPARENT); setBackgroundColor(Color.TRANSPARENT)
        }
        screen.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        screen.addView(text("● " + c.getString(R.string.live_home_badge), 11f).apply {
            setTextColor(col("#FFC55A")); setPadding(c.dp(9), c.dp(4), c.dp(9), c.dp(4))
            background = GradientDrawable().apply { setColor(col("#DD201A0A")); cornerRadius = c.dp(9).toFloat(); setStroke(c.dp(1), col("#CCF1B54A")) }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(c.dp(10), c.dp(10), c.dp(10), c.dp(10)) })
        val info = LinearLayout(c).apply { tag = "live-hero-info"; orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, c.dp(4), 0, c.dp(4)) }
        groupText = text("", 12f).apply { setTextColor(Th.acc); letterSpacing = .08f }; info.addView(groupText)
        programmeText = text("", 32f).apply { tag = "live-hero-title"; maxLines = 2; typeface = Typeface.DEFAULT_BOLD }
        info.addView(programmeText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(7) })
        channelText = text("", 17f).apply { tag = "live-home-channel"; maxLines = 2 }
        info.addView(channelText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
        timeText = text("", 14f, true)
        info.addView(timeText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(9) })
        progress = WatchBar(c)
        info.addView(progress, LinearLayout.LayoutParams(-1, c.dp(4)).apply { topMargin = c.dp(10); bottomMargin = c.dp(7) })
        previewHint = text("", 11f, true)
        info.addView(previewHint, LinearLayout.LayoutParams(-1, -2))
        val actions = HeroActionsLayout(c).apply { tag = "live-hero-actions" }
        val height = c.dp((44 * c.resources.configuration.fontScale.coerceAtLeast(1f)).toInt())
        actions.addView(Designs.action(c, c.getString(R.string.live_home_watch), R.drawable.ic_n_play, true) { selected?.let { fullscreen(it) } }.apply { tag = "hero-play"; minimumHeight = height }, LinearLayout.LayoutParams(-2, -2))
        actions.addView(Designs.action(c, c.getString(R.string.s_guide), R.drawable.ic_n_live) { releasePreview(); navigate("live") }.apply { tag = "live-home-guide-button"; minimumHeight = height }, LinearLayout.LayoutParams(-2, -2))
        info.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(12) })
        composition.preview = screen; composition.info = info
        composition.addView(screen); composition.addView(info)
        body.addView(composition, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(14) })
    }
    private fun updateInfo() {
        val item = selected ?: return
        val now = Repo.nowOn(item)
        groupText?.text = item.grp
        programmeText?.text = now?.title ?: item.name
        channelText?.text = item.name
        timeText?.text = now?.let { hm(it.start) + " – " + hm(it.stop) }.orEmpty()
        timeText?.visibility = if (now == null) View.GONE else View.VISIBLE
        progress?.apply { visibility = if (now == null) View.GONE else View.VISIBLE; pct = now?.let { ((System.currentTimeMillis() - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt().coerceIn(0, 100) } ?: 0; invalidate() }
        previewHint?.text = c.getString(if (!Repo.b("autoPrev", true)) R.string.live_home_preview_off else R.string.live_home_muted)
    }
    private fun channelShelf(title: String, items: List<Item>) {
        body.addView(text(title, 19f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(8) })
        val scroll = HorizontalScrollView(c).apply { tag = "live-home-favourites"; isHorizontalScrollBarEnabled = false; clipToPadding = false; setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(6)) }
        val cards = LinearLayout(c)
        items.forEach { item ->
            val card = LinearLayout(c).apply {
                tag = "live-pick:${item.id}"; gravity = Gravity.CENTER_VERTICAL; minimumHeight = c.dp(58)
                setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(8)); isFocusable = true; isClickable = true
                contentDescription = item.name; background = surface(selected = item.id == selected?.id)
                setOnClickListener { select(item) }; setOnLongClickListener { menu(item); true }
                setOnFocusChangeListener { v, focused -> v.background = surface(focused, item.id == selected?.id) }
            }
            val logo = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            card.addView(logo, LinearLayout.LayoutParams(c.dp(36), c.dp(36)).apply { marginEnd = c.dp(10) }); Img.load(logo, item.logo)
            card.addView(text(item.name, 14f).apply { maxLines = 2; typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
            cards.addView(card, LinearLayout.LayoutParams(c.dp(168), -2).apply { marginEnd = c.dp(10) }); picks[card] = item
        }
        scroll.addView(cards); body.addView(scroll, LinearLayout.LayoutParams(-1, -2))
    }
    private fun guide(groups: List<String>) {
        if (filter !in groups) filter = ""
        val heading = LinearLayout(c).apply { orientation = if (c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density < 600) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = text(c.getString(R.string.live_home_now_next), 19f).apply { typeface = Typeface.DEFAULT_BOLD }
        val filters = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(c)
        val options = listOf("" to c.getString(R.string.all)) + groups.map { it to it }
        options.forEach { (key, label) ->
            val button = Button(c).apply {
                tag = "live-filter:$key"; text = label; textSize = 13f; isAllCaps = false; maxLines = 1
                setPadding(c.dp(14), c.dp(6), c.dp(14), c.dp(6)); minimumHeight = c.dp(42)
                background = surface(selected = key == filter); setTextColor(if (key == filter) Th.acc else Th.fg)
                setOnFocusChangeListener { v, focused -> v.background = surface(focused, key == filter) }
                setOnClickListener {
                    filter = key
                    for (n in 0 until chips.childCount) (chips.getChildAt(n) as Button).apply { val on = tag == "live-filter:$key"; setTextColor(if (on) Th.acc else Th.fg); background = surface(hasFocus(), on) }
                    renderGuide()
                }
            }
            chips.addView(button, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = c.dp(6) })
        }
        filters.addView(chips)
        if (heading.orientation == LinearLayout.VERTICAL) {
            heading.addView(title); heading.addView(filters, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(6) })
        } else {
            heading.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            heading.addView(filters, LinearLayout.LayoutParams(0, -2, 1.8f))
        }
        body.addView(heading, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(12); bottomMargin = c.dp(8) })
        guideBody = LinearLayout(c).apply { tag = "live-home-guide"; orientation = LinearLayout.VERTICAL }
        body.addView(guideBody, LinearLayout.LayoutParams(-1, -2)); renderGuide()
    }
    private fun renderGuide() {
        val target = guideBody ?: return
        target.removeAllViews(); guideCells.clear()
        channels.asSequence().filter { filter.isEmpty() || it.grp == filter }.take(6).forEach { item ->
            val row = LinearLayout(c).apply {
                id = View.generateViewId(); tag = "live-guide:${item.id}"; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true
                setPadding(c.dp(9), c.dp(5), c.dp(9), c.dp(5)); minimumHeight = c.dp(60); background = surface()
                contentDescription = item.name; setOnClickListener { select(item) }; setOnLongClickListener { menu(item); true }
                setOnFocusChangeListener { v, focused -> v.background = surface(focused) }
            }
            val label = text(item.name, 13f).apply { maxLines = 2; typeface = Typeface.DEFAULT_BOLD }
            row.addView(label, LinearLayout.LayoutParams(c.dp(if (c.resources.displayMetrics.widthPixels / c.resources.displayMetrics.density < 600) 90 else 150), -2).apply { marginEnd = c.dp(8) })
            val cell = EpgView(c).apply { isFocusable = false; isClickable = false; bind(Repo.progs(item), System.currentTimeMillis()) }
            row.addView(cell, LinearLayout.LayoutParams(0, c.dp((48 * c.resources.configuration.fontScale.coerceAtLeast(1f)).toInt()), 1f))
            target.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = c.dp(7) }); guideCells += item to cell
        }
        for (index in 0 until target.childCount) {
            val row = target.getChildAt(index)
            row.nextFocusDownId = target.getChildAt((index + 1).coerceAtMost(target.childCount - 1)).id
            if (index > 0) row.nextFocusUpId = target.getChildAt(index - 1).id
        }
    }
    private fun select(item: Item) {
        if (selected?.id != item.id || selected?.url != item.url) releasePreview()
        selected = item; Repo.put("lastLive", item.id)
        previewImage?.let { Img.load(it, item.logo) }; updateInfo()
        picks.forEach { (view, entry) -> view.background = surface(view.hasFocus(), entry.id == item.id) }
        startPreview()
    }
    private fun fullscreen(item: Item) { releasePreview(); play(item) }
    private fun startPreview() {
        if (!running || destroyed || !root.isShown || preview != null || !Repo.b("autoPrev", true)) return
        val item = selected ?: return
        if (item.url.isBlank()) return
        val player = makePlayer(c, live = true); preview = player; playerView?.player = player; player.volume = 0f
        player.addListener(object : Player.Listener {
            override fun onRenderedFirstFrame() { previewImage?.visibility = View.GONE }
            override fun onPlayerError(error: PlaybackException) {
                previewHint?.text = c.getString(R.string.ref_preview_unavailable); releasePreview()
            }
        })
        player.setMediaItem(PlaybackPolicy.mediaItem(item.url, true)); player.prepare(); player.playWhenReady = true
    }
    private fun releasePreview() {
        preview?.let { if (playerView?.player === it) playerView?.player = null; it.release() }
        preview = null; previewImage?.visibility = View.VISIBLE
    }
}

/** Measures readable programme information before choosing the hero height; video stays 16:9. */
class LiveHeroLayout(c: Context) : FrameLayout(c) {
    lateinit var preview: View
    lateinit var info: View
    private var gap = 0
    private var wide = false
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (!::preview.isInitialized || !::info.isInitialized) { super.onMeasure(widthMeasureSpec, heightMeasureSpec); return }
        val width = MeasureSpec.getSize(widthMeasureSpec); gap = context.dp(18)
        wide = width >= context.dp(600)
        val previewWidth = if (wide) ((width - gap) * .58f).toInt() else width
        val infoWidth = if (wide) width - previewWidth - gap else width
        info.measure(MeasureSpec.makeMeasureSpec(infoWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val videoHeight = (previewWidth * 9 / 16).coerceAtLeast(1)
        preview.measure(MeasureSpec.makeMeasureSpec(previewWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(videoHeight, MeasureSpec.EXACTLY))
        setMeasuredDimension(width, if (wide) maxOf(videoHeight, info.measuredHeight) else videoHeight + gap + info.measuredHeight)
    }
    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        if (!::preview.isInitialized || !::info.isInitialized) return
        if (!wide) {
            preview.layout(0, 0, width, preview.measuredHeight)
            info.layout(0, preview.measuredHeight + gap, width, height)
        } else {
            val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
            val videoLeft = if (rtl) width - preview.measuredWidth else 0
            val infoLeft = if (rtl) 0 else preview.measuredWidth + gap
            val videoTop = (height - preview.measuredHeight) / 2; val infoTop = (height - info.measuredHeight) / 2
            preview.layout(videoLeft, videoTop, videoLeft + preview.measuredWidth, videoTop + preview.measuredHeight)
            info.layout(infoLeft, infoTop, infoLeft + info.measuredWidth, infoTop + info.measuredHeight)
        }
    }
}
