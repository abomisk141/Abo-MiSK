package com.sultv.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class SettingsActivity : BaseActivity() {
    private lateinit var backupUi: BackupUi
    private lateinit var subscriptionUi: PlaylistSubscriptionUi
    private val playlistWork = LatestWork()
    private var playlistMenu: android.app.Dialog? = null
    private lateinit var content: LinearLayout
    private val menu = ArrayList<Pair<String, TextView>>()
    private var cur = "general"
    private val secs = listOf(
        "general" to R.string.s_general, "appearance" to R.string.s_appearance, "playlists" to R.string.s_playlists, "manage" to R.string.s_manage,
        "playback" to R.string.s_playback, "remote" to R.string.s_remote, "guide" to R.string.s_guide, "parental" to R.string.s_parental,
        "backup" to R.string.backup_title, "about" to R.string.s_about
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cur = b?.getString("cur") ?: "general"
        Repo.init(this); Th.load()
        backupUi = BackupUi(this)
        subscriptionUi = PlaylistSubscriptionUi(this) { if (!isFinishing && !isDestroyed) show("playlists") }
        val wide = resources.displayMetrics.widthPixels / resources.displayMetrics.density >= 600
        val root = LinearLayout(this).apply {
            background = Th.bg(); setPadding(dp(16), dp(16), dp(16), dp(16))
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = Th.shape(this@SettingsActivity, Th.card, false, 26)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        left.addView(TextView(this).apply { setText(R.string.settings); setTextColor(Th.fg); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(14), dp(10), dp(14), dp(14)) })
        val menuBox = LinearLayout(this).apply { orientation = if (wide) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
        var menuScroll: ScrollView? = null
        fun revealMenuRow(tv: View) {
            menuScroll?.let { scroll ->
                if (scroll.height <= 0) return@let
                val top = tv.top - dp(2)
                val bottom = tv.bottom + dp(2)
                val viewport = scroll.height - scroll.paddingTop - scroll.paddingBottom
                val target = when {
                    top < scroll.scrollY -> top
                    bottom > scroll.scrollY + viewport -> bottom - viewport
                    else -> scroll.scrollY
                }
                scroll.scrollTo(0, target.coerceAtLeast(0))
            }
        }
        for ((k, r) in secs) {
            val tv = TextView(this).apply { id = View.generateViewId(); tag = "settings-section:$k"; setText(r); textSize = 16f; setPadding(dp(18), dp(12), dp(18), dp(12)); isFocusable = true; isClickable = true }
            tv.setOnFocusChangeListener { _, f ->
                if (f) {
                    show(k)
                    // Android may consider a partially visible row good enough for focus.
                    // Keep the whole menu row, including its focus border, in the viewport.
                    tv.post { revealMenuRow(tv) }
                }
            }
            tv.setOnClickListener { show(k) }
            menu.add(k to tv)
            menuBox.addView(tv, LinearLayout.LayoutParams(if (wide) -1 else -2, -2).apply { setMargins(0, dp(2), dp(if (wide) 0 else 6), dp(2)) })
        }
        if (wide) {
            val scroll = ScrollView(this).apply {
                tag = "settings-menu-scroll"; isFillViewport = false
                clipToPadding = false; setPadding(0, 0, 0, dp(6))
                addView(menuBox, android.widget.FrameLayout.LayoutParams(-1, -2))
            }
            menuScroll = scroll
            // Recheck after measurement: an early focus request can run before the
            // menu's full content height is known and Android clamps the scroll.
            menuBox.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                menu.firstOrNull { it.second.hasFocus() }?.second?.let { revealMenuRow(it) }
            }
            scroll.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                menu.firstOrNull { it.second.hasFocus() }?.second?.let { revealMenuRow(it) }
            }
            left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            menu.forEachIndexed { index, (_, view) ->
                view.nextFocusUpId = menu[(index - 1).coerceAtLeast(0)].second.id
                view.nextFocusDownId = menu[(index + 1).coerceAtMost(menu.lastIndex)].second.id
            }
        } else { val hs = HorizontalScrollView(this); hs.addView(menuBox, android.widget.FrameLayout.LayoutParams(-2, -2)); left.addView(hs) }

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
        val sc = ScrollView(this); sc.addView(content, android.widget.FrameLayout.LayoutParams(-1, -2))
        val right = LinearLayout(this).apply { background = Th.shape(this@SettingsActivity, Th.card, false, 26) }
        right.addView(sc, LinearLayout.LayoutParams(-1, -1))

        if (wide) {
            root.addView(left, LinearLayout.LayoutParams(0, -1, 28f).apply { marginEnd = dp(14) })
            root.addView(right, LinearLayout.LayoutParams(0, -1, 72f))
        } else {
            root.addView(left, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            root.addView(right, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
        show(cur)
        if (b != null) {
            val restored = menu.firstOrNull { it.first == cur }?.second
            restored?.post { restored.requestFocus() }
        }
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putString("cur", cur) }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        backupUi.result(requestCode, resultCode, data)
    }

    override fun onDestroy() {
        playlistMenu?.dismiss(); playlistMenu = null
        if (::backupUi.isInitialized) backupUi.close()
        if (::subscriptionUi.isInitialized) subscriptionUi.close()
        playlistWork.close()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && cur == "playlists") show(cur)
    }

    private fun show(k: String) {
        cur = k
        for ((key, tv) in menu) {
            val sel = key == cur
            tv.setTextColor(if (sel) Th.bt else Th.fg)
            tv.background = Th.shape(this, if (sel) Th.acc else col("#00000000"), false, 20)
        }
        content.removeAllViews()
        when (k) {
            "general" -> general()
            "appearance" -> appearance()
            "parental" -> parental()
            "remote" -> remote()
            "playlists" -> playlists()
            "manage" -> manage()
            "playback" -> playback()
            "guide" -> guide()
            "backup" -> backup()
            else -> about()
        }
    }

    // ---------- row helpers ----------
    private fun row(title: String, sub: String = "", value: String = "", click: (TextView) -> Unit = {}): LinearLayout {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true; setPadding(dp(18), dp(14), dp(18), dp(14)) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(this).apply { text = title; setTextColor(Th.fg); textSize = 17f })
        if (sub.isNotBlank()) box.addView(TextView(this).apply { text = sub; setTextColor(Th.mut); textSize = 13f })
        r.addView(box, LinearLayout.LayoutParams(0, -2, 1f))
        val vt = TextView(this).apply { text = value; setTextColor(Th.acc); textSize = 15f }
        r.addView(vt)
        r.background = Th.shape(this, col("#00000000"), false, 14)
        r.setOnFocusChangeListener { v, f -> v.background = Th.shape(this, col("#00000000"), f, 14) }
        r.setOnClickListener { click(vt) }
        content.addView(r, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) })
        return r
    }

    private fun onOff(v: Boolean) = getString(if (v) R.string.on else R.string.off)

    private fun toggle(title: String, sub: String, key: String, def: Boolean, after: () -> Unit = {}) {
        val tv = ToggleView(this); tv.checked = Repo.b(key, def)
        val r = row(title, sub, "") { _ ->
            val n = !Repo.b(key, def); Repo.putB(key, n); tv.checked = n; after()
        }
        r.removeViewAt(r.childCount - 1)
        r.addView(tv, LinearLayout.LayoutParams(dp(54), dp(30)))
    }

    private fun choice(title: String, key: String, opts: List<Pair<String, String>>, def: String, after: () -> Unit = {}) {
        fun lab(): String = opts.firstOrNull { it.first == Repo.s(key, def) }?.second ?: opts.first().second
        row(title, "", lab()) { vt ->
            AlertDialog.Builder(this).setTitle(title).setItems(opts.map { it.second }.toTypedArray()) { _, w ->
                Repo.put(key, opts[w].first); vt.text = lab(); after()
            }.show()
        }
    }

    // ---------- sections ----------
    private fun backup() {
        row(getString(R.string.backup_export), getString(R.string.backup_contents)) { backupUi.export() }
        row(getString(R.string.backup_restore), getString(R.string.backup_restore_hint)) { backupUi.restore() }
        row(getString(R.string.backup_share), getString(R.string.backup_share_hint)) { backupUi.share() }
    }

    private fun general() {
        choice(getString(R.string.language), "lang", listOf("sys" to getString(R.string.lang_sys), "en" to "English", "ar" to "العربية"), "sys") { recreate() }
        toggle(getString(R.string.welcome), getString(R.string.welcome_sub), "welcome", true)
        toggle(getString(R.string.resume_last), "", "resume", false)
        toggle(getString(R.string.back_twice), "", "back2", true)
        choice("البيانات الذكية / Smart Metadata", "metadataMode", listOf(
            "auto" to "تلقائي — بيانات الاشتراك أولاً",
            "iptv" to "بيانات الاشتراك فقط",
            "fill" to "إكمال البيانات الناقصة من TMDB"
        ), "auto") { }
        toggle(getString(R.string.tmdb_on), getString(R.string.tmdb_sub), "tmdbOn", true)
        row(getString(R.string.tmdb_key), getString(R.string.tmdb_key_sub), if (Tmdb.key().isNotEmpty()) "✓" else "") { vt -> tmdbKey(vt) }
    }

    private fun playlists() {
        val act = Repo.active()?.id
        for (p in Repo.playlists()) {
            val st = Repo.stat(p.id)
            val line = (if (p.mode == "xt") "Xtream" else "M3U") + (if (st != null)
                " · " + getString(R.string.stat_line, st[0].toIntOrNull() ?: 0, st[1].toIntOrNull() ?: 0, st[2].toIntOrNull() ?: 0,
                    android.text.format.DateFormat.format("yyyy/MM/dd HH:mm", st[3].toLongOrNull() ?: 0L).toString()) else "")
            row(p.name, line + "\n" + SubscriptionText.summary(this, p) + "\n" + getString(if (Repo.isPlaylistVisible(p.id)) R.string.playlist_shown else R.string.playlist_hidden), if (p.id == act) "✓ " + getString(R.string.active) else "") { plMenu(p) }.apply {
                tag = "playlist-row:${p.id}"
                setOnLongClickListener { plMenu(p); true }
            }
        }
        val hours = Repo.s("pl_refresh_hours", "12").toIntOrNull() ?: 12
        val choices = intArrayOf(0, 3, 6, 12, 24)
        row("التحديث التلقائي للقوائم", "يحدّث نسخة القوائم في الخلفية دون إيقاف البث", if (hours == 0) "معطّل" else "كل $hours ساعة") {
            val labels = arrayOf("إيقاف", "كل 3 ساعات", "كل 6 ساعات", "كل 12 ساعة", "كل 24 ساعة")
            AlertDialog.Builder(this).setTitle("مدة تحديث القوائم")
                .setSingleChoiceItems(labels, choices.indexOf(hours).coerceAtLeast(0)) { dialog, which ->
                    Repo.put("pl_refresh_hours", choices[which].toString())
                    dialog.dismiss(); show("playlists")
                }.setNegativeButton(R.string.no, null).show()
        }
        val last = Repo.s("pl_last_refresh").toLongOrNull() ?: 0L
        if (last > 0) row("آخر تحديث تلقائي", android.text.format.DateFormat.format("yyyy/MM/dd HH:mm", last).toString())
        row("+  " + getString(R.string.add_pl), getString(R.string.add_pl_sub)) { editPl(null) }
    }

    private fun plMenu(p: Playlist) {
        playlistMenu?.dismiss()
        val section = getString(R.string.playlist_actions)
        val visible = Repo.isPlaylistVisible(p.id)
        val active = Repo.active()?.id == p.id
        val status = listOf(if (p.mode == "xt") "Xtream" else "M3U",
            getString(if (visible) R.string.playlist_shown else R.string.playlist_hidden),
            if (active) getString(R.string.active) else "").filter { it.isNotBlank() }.joinToString(" · ")
        fun runAction(w: Int) {
            when (w) {
                0 -> subscriptionUi.show(p)
                1 -> { Repo.setPlaylistVisible(p.id, true); Repo.put("act", p.id); Repo.dirty = true; show("playlists") }
                2 -> {
                    Toast.makeText(this, R.string.loading, Toast.LENGTH_SHORT).show()
                    playlistWork.submit {
                        val ok = Repo.refreshCacheInBackground(p)
                        runOnUiThread {
                            if (!isFinishing && !isDestroyed) {
                                if (ok && Repo.active()?.id == p.id) Repo.dirty = true
                                show("playlists")
                                Toast.makeText(this, if (ok) R.string.done else R.string.playlist_refresh_retained, Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
                3 -> editPl(p)
                4 -> AlertDialog.Builder(this).setTitle(p.name).setMessage(R.string.delete)
                    .setPositiveButton(R.string.yes) { _, _ ->
                        Repo.invalidate(p)
                        val l = Repo.playlists().filter { it.id != p.id }
                        Repo.savePlaylists(l)
                        if (Repo.s("act") == p.id) Repo.put("act", (l.firstOrNull { Repo.isPlaylistVisible(it.id) } ?: l.firstOrNull())?.id ?: "")
                        Repo.dirty = true; show("playlists")
                    }.setNegativeButton(R.string.no, null).show()
                5 -> { Repo.setPlaylistVisible(p.id, !Repo.isPlaylistVisible(p.id)); show("playlists") }
            }
        }
        playlistMenu = PlaybackMenus.options(this, p.name, status, listOf(
            PlaybackMenus.Entry(getString(R.string.use_pl), getString(if (active) R.string.playlist_current_hint else R.string.playlist_switch_hint), section, R.drawable.ic_n_play, selected = active) { runAction(1) },
            PlaybackMenus.Entry(getString(R.string.account_info), getString(R.string.playlist_account_hint), section, R.drawable.ic_n_info) { runAction(0) },
            PlaybackMenus.Entry(getString(R.string.update_now), getString(R.string.playlist_refresh_hint), section, R.drawable.ic_refresh) { runAction(2) },
            PlaybackMenus.Entry(getString(R.string.edit), "", section, R.drawable.ic_menu_edit) { runAction(3) },
            PlaybackMenus.Entry(getString(if (visible) R.string.hide_playlist_ui else R.string.show_playlist_ui), getString(R.string.playlist_visibility_hint), section, if (visible) R.drawable.ic_menu_eye_off else R.drawable.ic_menu_eye) { runAction(5) },
            PlaybackMenus.Entry(getString(R.string.delete), getString(R.string.playlist_delete_hint), getString(R.string.playlist_remove_section), R.drawable.ic_menu_trash, destructive = true) { runAction(4) }
        ))
    }

    private fun editPl(p: Playlist?) {
        startActivity(Intent(this, AddPlaylistActivity::class.java).apply { if (p != null) putExtra("id", p.id) })
    }

    private fun manage() {
        for ((k, r) in listOf("live" to R.string.live, "movie" to R.string.movies, "series" to R.string.series))
            row(getString(r), getString(R.string.manage_cat_sub)) { catDialog(k, getString(r)) }
        row(getString(R.string.restore)) { Repo.clearHidden(); Toast.makeText(this, R.string.done, Toast.LENGTH_SHORT).show() }
        row(getString(R.string.reset_order)) { Repo.clearOrders(); Toast.makeText(this, R.string.done, Toast.LENGTH_SHORT).show() }
        row(getString(R.string.reset_names)) { Repo.clearAllOvr(); Toast.makeText(this, R.string.done, Toast.LENGTH_SHORT).show() }
        row(getString(R.string.clear_hist)) { Repo.clearRecent(); Toast.makeText(this, R.string.done, Toast.LENGTH_SHORT).show() }
    }

    private fun catDialog(kind: String, title: String) {
        val cats = Repo.categories(kind)
        if (cats.isEmpty()) { Toast.makeText(this, R.string.none, Toast.LENGTH_SHORT).show(); return }
        ModernDialogs.categoryVisibility(this, title, cats, Repo.hiddenCats(kind)) { hidden ->
            Repo.setHiddenCats(kind, hidden)
        }
    }

    private fun playback() {
        row(getString(R.string.ua_title), getString(R.string.ua_hint),
            userAgentLabel()) {
            userAgentDialog()
        }
        choice(getString(R.string.live_latency), "liveLatency", listOf(
            "fast" to getString(R.string.live_latency_fast), "balanced" to getString(R.string.live_latency_balanced),
            "stable" to getString(R.string.live_latency_stable)), "fast")
        choice(getString(R.string.live_format), "liveFormat", listOf("m3u8" to "HLS (m3u8)", "ts" to "MPEG-TS (ts)"), "ts")
        toggle(getString(R.string.live_edge_guard), getString(R.string.live_edge_guard_hint), "liveEdgeGuard", true)
        choice(getString(R.string.vod_buffer), "buf", listOf("l" to getString(R.string.buf_l), "n" to getString(R.string.buf_n), "h" to getString(R.string.buf_h)), "n")
        choice(getString(R.string.audio_lang), "alang", listOf("auto" to getString(R.string.auto), "ar" to "العربية", "en" to "English", "fr" to "Français",
            "tr" to "Türkçe", "fa" to "فارسی", "es" to "Español", "de" to "Deutsch", "ur" to "اردو"), "auto")
        toggle(getString(R.string.auto_prev), "", "autoPrev", true)
        toggle(getString(R.string.resume_vod), "", "resumeVod", true)
        toggle(getString(R.string.auto_next), "", "autoNext", true)
        choice(getString(R.string.subs) + " - " + getString(R.string.sub_size), "ss", listOf("70" to "70%", "100" to "100%", "140" to "140%", "180" to "180%"), "100")
        choice(getString(R.string.subs) + " - " + getString(R.string.sub_color), "sc", listOf("#FFFFFF" to getString(R.string.c_white), "#FFE600" to getString(R.string.c_yellow),
            "#00E5FF" to getString(R.string.c_cyan), "#7CFC00" to getString(R.string.c_green)), "#FFFFFF")
        choice(getString(R.string.subs) + " - " + getString(R.string.sub_bg), "sbg", listOf("#00000000" to getString(R.string.bg_none), "#99000000" to getString(R.string.bg_semi),
            "#FF000000" to getString(R.string.bg_black)), "#99000000")
    }

    private fun userAgentDialog() {
        val options = listOf(getString(R.string.ua_default) to "") + RequestIdentity.presets.map { it.name to it.value }
        val current = Repo.s("userAgent").trim()
        val selected = options.indexOfFirst { it.second == current }.let { if (it < 0) options.size else it }
        AlertDialog.Builder(this).setTitle(R.string.ua_title)
            .setSingleChoiceItems((options.map { it.first } + getString(R.string.ua_custom)).toTypedArray(), selected) { d, which ->
                d.dismiss()
                if (which == options.size) customUserAgentDialog()
                else {
                    Repo.put("userAgent", options[which].second)
                    show("playback")
                    Toast.makeText(this, R.string.ua_saved, Toast.LENGTH_LONG).show()
                }
            }.setNegativeButton(R.string.no, null).show()
    }

    private fun userAgentLabel(): String {
        val current = Repo.s("userAgent").trim()
        return if (current.isBlank()) getString(R.string.ua_default)
            else RequestIdentity.presets.firstOrNull { it.value == current }?.name ?: getString(R.string.ua_custom)
    }

    private fun customUserAgentDialog() {
        val et = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            hint = RequestIdentity.DEFAULT
            setText(Repo.s("userAgent"))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            addView(TextView(this@SettingsActivity).apply { text = getString(R.string.ua_hint) })
            addView(et, LinearLayout.LayoutParams(-1, -2))
        }
        val d = AlertDialog.Builder(this).setTitle(R.string.ua_title).setView(box)
            .setPositiveButton(R.string.save, null)
            .setNeutralButton(R.string.ua_default) { _, _ ->
                Repo.put("userAgent", ""); show("playback")
                Toast.makeText(this, R.string.ua_saved, Toast.LENGTH_LONG).show()
            }.setNegativeButton(R.string.no, null).create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val value = et.text.toString()
            if (!RequestIdentity.valid(value)) { et.error = getString(R.string.ua_invalid); return@setOnClickListener }
            Repo.put("userAgent", value.trim())
            d.dismiss(); show("playback")
            Toast.makeText(this, R.string.ua_saved, Toast.LENGTH_LONG).show()
        }
    }

    private fun guide() {
        toggle(getString(R.string.epg_on), "", "epgOn", true)
        val custom = Repo.s("epgUrl").isNotBlank()
        row(getString(R.string.epg_src), if (custom) Repo.s("epgUrl") else "", if (custom) "URL" else getString(R.string.epg_auto)) { vt ->
            val et = EditText(this).apply { hint = "http://.../epg.xml"; setText(Repo.s("epgUrl")); setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
            val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
            box.addView(et, LinearLayout.LayoutParams(-1, -2))
            AlertDialog.Builder(this).setTitle(R.string.epg_src).setView(box)
                .setPositiveButton(R.string.save) { _, _ -> Repo.put("epgUrl", et.text.toString().trim()); show("guide") }
                .setNeutralButton(R.string.epg_auto) { _, _ -> Repo.put("epgUrl", ""); show("guide") }
                .setNegativeButton(R.string.no, null).show()
        }
        choice(getString(R.string.epg_off), "epgOff", (-12..12).map { it.toString() to (if (it > 0) "+$it" else "$it") }, "0")
        row(getString(R.string.epg_refresh)) { Repo.loadEpg(true); Toast.makeText(this, R.string.loading, Toast.LENGTH_SHORT).show() }
        val st = when (Repo.epgState) {
            1 -> getString(R.string.epg_s1)
            2 -> getString(R.string.epg_s2, Repo.epg.size)
            3 -> getString(R.string.epg_s3)
            else -> getString(R.string.epg_s0)
        }
        row(getString(R.string.epg_status), "", st)
    }

    private val uiOpts = listOf(
        Triple("reference", R.string.design_reference, R.string.design_reference_desc),
        Triple("cinema", R.string.design_cinema, R.string.design_cinema_desc),
        Triple("live", R.string.design_live, R.string.design_live_desc),
        Triple("spotlight", R.string.design_spotlight, R.string.design_spotlight_desc))
    private val detOpts = listOf(Triple("poster", R.string.det_poster, R.string.det_poster_d), Triple("cinematic", R.string.det_cinematic, R.string.det_cinematic_d))
    private val lpOpts = listOf(Triple("full", R.string.lp_full, R.string.lp_full_d), Triple("minimal", R.string.lp_min, R.string.lp_min_d), Triple("glass", R.string.lp_glass, R.string.lp_glass_d))
    private val vpOpts = listOf(Triple("standard", R.string.vp_std, R.string.vp_std_d), Triple("minimal", R.string.vp_min, R.string.vp_min_d), Triple("detailed", R.string.vp_det, R.string.vp_det_d))

    private fun optName(opts: List<Triple<String, Int, Int>>, key: String, def: String): String {
        val cur = Repo.s(key, def)
        return getString((opts.firstOrNull { it.first == cur } ?: opts[0]).second)
    }

    private fun stylePicker(title: Int, key: String, def: String, opts: List<Triple<String, Int, Int>>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        var dlg: AlertDialog? = null
        val cur = Repo.s(key, def)
        val selBg = (Th.acc and 0xFFFFFF) or (0x55 shl 24)
        for ((k, nameRes, descRes) in opts) {
            val sel = k == cur
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true; setPadding(dp(12), dp(10), dp(12), dp(10)) }
            r.background = Th.shape(this, if (sel) selBg else Th.card, false, 18)
            r.setOnFocusChangeListener { v, f -> v.background = Th.shape(this, if (sel) selBg else Th.card, f, 18) }
            r.addView(StyleSketch(this, k), LinearLayout.LayoutParams(dp(132), dp(76)).apply { marginEnd = dp(14) })
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(TextView(this).apply { text = (if (sel) "✓  " else "") + getString(nameRes); setTextColor(Th.fg); textSize = 18f; typeface = Typeface.DEFAULT_BOLD })
            t.addView(TextView(this).apply { text = getString(descRes); setTextColor(Th.mut); textSize = 13f })
            r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            r.setOnClickListener { Repo.put(key, k); dlg?.dismiss(); recreate() }
            box.addView(r, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        val sv = ScrollView(this); sv.addView(box)
        dlg = AlertDialog.Builder(this).setTitle(title).setView(sv).create()
        dlg.show()
    }

    private fun appearance() {
        if (Repo.s("ui") == "reference") choice(getString(R.string.reference_gradient), "referencePalette", listOf(
            "slate" to getString(R.string.gradient_slate), "midnight" to getString(R.string.gradient_midnight),
            "copper" to getString(R.string.gradient_copper)), "slate") { Th.load(); recreate() }
        row(getString(R.string.ui_style), "", optName(uiOpts, "ui", "cinema")) { stylePicker(R.string.ui_style, "ui", "cinema", uiOpts) }
        row(getString(R.string.det_style), "", optName(detOpts, "detstyle", "poster")) { stylePicker(R.string.det_style, "detstyle", "poster", detOpts) }
        row(getString(R.string.live_player), "", optName(lpOpts, "liveplayer", "full")) { stylePicker(R.string.live_player, "liveplayer", "full", lpOpts) }
        row(getString(R.string.vod_player), "", optName(vpOpts, "vodplayer", "standard")) { stylePicker(R.string.vod_player, "vodplayer", "standard", vpOpts) }
        choice(getString(R.string.text_size), "ts", listOf("0.9" to getString(R.string.ts_s), "1.0" to getString(R.string.ts_n),
            "1.15" to getString(R.string.ts_l), "1.3" to getString(R.string.ts_xl)), "1.0") { recreate() }
        choice(getString(R.string.font), "ft", listOf("sys" to getString(R.string.f_sys), "light" to getString(R.string.f_light), "med" to getString(R.string.f_med),
            "cond" to getString(R.string.f_cond), "serif" to getString(R.string.f_serif)), "sys") { recreate() }
        choice(getString(R.string.anim), "anim", listOf("fade" to getString(R.string.a_fade), "slide" to getString(R.string.a_slide),
            "zoom" to getString(R.string.a_zoom), "none" to getString(R.string.off)), "fade")
        toggle(getString(R.string.focus_fx), "", "focusFx", true)
    }

    // ---------- parental control ----------
    private var parentalOk = false
    private val kinds = listOf("live" to R.string.live, "movie" to R.string.movies, "series" to R.string.series)

    private fun parental() {
        if (Repo.hasPin() && !parentalOk) {
            row(getString(R.string.parental_locked)) { askPin(R.string.pin_enter) { parentalOk = true; show("parental") } }
            return
        }
        row(getString(R.string.pin_status), "", if (Repo.hasPin()) getString(R.string.pin_set) else getString(R.string.pin_not_set)) { pinMenu() }
        if (!Repo.hasPin()) { row(getString(R.string.pin_first)); return }
        for ((k, r) in kinds) row(getString(R.string.locked_cats) + " — " + getString(r), getString(R.string.locked_sub), Repo.lockedCats(k).size.toString()) { lockDialog(k, getString(r)) }
        row(getString(R.string.auto_lock)) { autoLock() }
        toggle(getString(R.string.pin_settings), "", "pinSettings", false)
        row(getString(R.string.unlock_all)) {
            for ((k, _) in kinds) Repo.setLockedCats(k, emptySet())
            Repo.unlocked.clear(); Toast.makeText(this, R.string.done, Toast.LENGTH_SHORT).show(); show("parental")
        }
    }

    private fun pinMenu() {
        if (!Repo.hasPin()) { newPin(); return }
        AlertDialog.Builder(this).setTitle(R.string.pin_status)
            .setItems(arrayOf(getString(R.string.pin_change), getString(R.string.pin_remove))) { _, w ->
                if (w == 0) newPin() else { Repo.clearPin(); parentalOk = false; show("parental") }
            }.show()
    }

    private fun newPin() {
        pinInput(R.string.pin_new) { a ->
            if (a.length < 4 || a.length > 6) Toast.makeText(this, R.string.pin_short, Toast.LENGTH_SHORT).show()
            else pinInput(R.string.pin_confirm) { b ->
                if (a != b) Toast.makeText(this, R.string.pin_mismatch, Toast.LENGTH_SHORT).show()
                else { Repo.setPin(a); parentalOk = true; show("parental") }
            }
        }
    }

    private fun lockDialog(kind: String, title: String) {
        val cats = Repo.categories(kind)
        if (cats.isEmpty()) { Toast.makeText(this, R.string.none, Toast.LENGTH_SHORT).show(); return }
        val lk = Repo.lockedCats(kind)
        val checked = BooleanArray(cats.size) { cats[it] in lk }
        AlertDialog.Builder(this).setTitle(title)
            .setMultiChoiceItems(cats.toTypedArray(), checked) { _, i, on -> checked[i] = on }
            .setPositiveButton(R.string.save) { _, _ ->
                val s = HashSet<String>(lk.filter { it !in cats })
                for (i in cats.indices) if (checked[i]) s.add(cats[i])
                Repo.setLockedCats(kind, s)
                Repo.unlocked.removeAll { it.startsWith("$kind|") }
                show("parental")
            }.setNegativeButton(R.string.no, null).show()
    }

    private fun autoLock() {
        val re = Regex("xxx|adult|porn|sex|18\\+|\\+18|erotic|للكبار|بالغين|اباحي|إباحي", RegexOption.IGNORE_CASE)
        var n = 0
        for ((k, _) in kinds) {
            val s = Repo.lockedCats(k)
            for (c in Repo.categories(k)) if (re.containsMatchIn(c) && s.add(c)) n++
            Repo.setLockedCats(k, s)
        }
        Toast.makeText(this, getString(R.string.auto_lock_n, n), Toast.LENGTH_SHORT).show()
        show("parental")
    }

    private fun tmdbKey(vt: TextView) {
        val et = EditText(this).apply { hint = "API key / token"; setText(Tmdb.key()); setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this).setTitle(R.string.tmdb_key).setView(box)
            .setPositiveButton(R.string.save) { _, _ -> Repo.put("tmdb", et.text.toString().trim()); vt.text = if (Tmdb.key().isNotEmpty()) "✓" else "" }
            .setNeutralButton(R.string.tmdb_test) { _, _ ->
                Repo.put("tmdb", et.text.toString().trim()); vt.text = if (Tmdb.key().isNotEmpty()) "✓" else ""
                Thread {
                    val r = Tmdb.test()
                    runOnUiThread { Toast.makeText(this, if (r.isEmpty()) getString(R.string.tmdb_ok) else getString(R.string.tmdb_bad, r), Toast.LENGTH_LONG).show() }
                }.start()
            }
            .setNegativeButton(R.string.no, null).show()
    }

    private fun header(t: String) {
        content.addView(TextView(this).apply { text = t; setTextColor(Th.acc); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(18), dp(18), dp(18), dp(6)) })
    }

    private fun remote() {
        row(getString(R.string.rc_profiles), getString(R.string.rc_profiles_sub)) { presetDialog() }
        toggle(getString(R.string.rc_num), getString(R.string.rc_num_sub), "numJump", true) { Remote.clearCache() }
        row(getString(R.string.rc_test), getString(R.string.rc_test_sub)) { Remote.test(this) }
        for ((g, gr) in listOf("live" to R.string.rc_live, "vod" to R.string.rc_vod, "browse" to R.string.rc_browse)) {
            header(getString(gr))
            for (a in Remote.acts.filter { it.group == g }) row(getString(a.name), "", Remote.label(this, a.id)) { vt -> editAction(a, vt) }
        }
        header("")
        row(getString(R.string.rc_reset_all)) { Remote.clearAll(); show("remote") }
    }

    private fun presetDialog() {
        val names = arrayOf(getString(R.string.rc_p_std), getString(R.string.rc_p_color), getString(R.string.rc_p_page))
        AlertDialog.Builder(this).setTitle(R.string.rc_profiles).setItems(names) { _, w ->
            Remote.preset(if (w == 1) "color" else if (w == 2) "page" else "std")
            Toast.makeText(this, R.string.done, Toast.LENGTH_SHORT).show(); show("remote")
        }.show()
    }

    private fun editAction(a: Remote.Act, vt: TextView) {
        val ks = Remote.keys(a.id)
        fun nm(i: Int) = ks.getOrNull(i)?.let { Remote.keyName(it) } ?: getString(R.string.rc_none)
        val labels = arrayOf(getString(R.string.rc_btn1) + ":  " + nm(0), getString(R.string.rc_btn2) + ":  " + nm(1), getString(R.string.rc_clear), getString(R.string.rc_default))
        AlertDialog.Builder(this).setTitle(a.name).setItems(labels) { _, w ->
            when (w) {
                0, 1 -> Remote.capture(this, a.group) { code ->
                    val from = Remote.setSlot(a.id, w, code)
                    if (from != null) { Toast.makeText(this, getString(R.string.rc_moved, getString(from.name)), Toast.LENGTH_LONG).show(); show("remote") }
                    else vt.text = Remote.label(this, a.id)
                }
                2 -> { Remote.saveKeys(a.id, emptyList()); vt.text = Remote.label(this, a.id) }
                else -> { Remote.resetAct(a.id); vt.text = Remote.label(this, a.id) }
            }
        }.show()
    }

    private fun checkUpdate() {
        Toast.makeText(this, R.string.upd_checking, Toast.LENGTH_SHORT).show()
        Thread {
            val r = Updater.fetch(this)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (r == null) Toast.makeText(this, getString(R.string.upd_err, Updater.lastErr), Toast.LENGTH_LONG).show()
                else if (!r.newer) Toast.makeText(this, getString(R.string.upd_latest, Updater.currentVersion(this)), Toast.LENGTH_LONG).show()
                else showUpdateDialog(r)
            }
        }.start()
    }

    private fun repoDialog(vt: TextView) {
        val et = EditText(this).apply { hint = "owner/repository"; setText(Updater.repo()); setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this).setTitle(R.string.upd_repo).setView(box)
            .setPositiveButton(R.string.save) { _, _ -> Repo.put("updRepo", et.text.toString().trim()); vt.text = Updater.repo() }
            .setNegativeButton(R.string.no, null).show()
    }

    private fun about() {
        val v = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        row(getString(R.string.app_name), getString(R.string.version) + " " + v)
        row(getString(R.string.upd_check), getString(R.string.upd_check_sub)) { checkUpdate() }
        toggle(getString(R.string.upd_auto), "", "autoUpd", true)
        row(getString(R.string.upd_repo), "", Updater.repo()) { vt -> repoDialog(vt) }
        row(getString(R.string.about_text))
        row(getString(R.string.tmdb_credit))
    }
}
