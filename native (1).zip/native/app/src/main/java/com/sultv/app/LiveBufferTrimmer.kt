package com.sultv.app

/**
 * Plain MPEG-TS live has no live window, so ExoPlayer cannot catch up on its own and any stall
 * leaves the viewer permanently behind. This trims only the surplus buffer by playing slightly
 * faster, never below [STOP_MS] of cushion, and never seeks. After a stall it stays at 1x for a while.
 */
class LiveBufferTrimmer {
    companion object {
        const val START_MS = 6000L
        const val STOP_MS = 3000L
        const val SPEED = 1.08f
        const val COOLDOWN_MS = 60000L
    }
    private var fast = false
    private var pausedUntilMs = 0L
    fun reset() { fast = false; pausedUntilMs = 0L }
    fun onStall(nowMs: Long) { fast = false; pausedUntilMs = nowMs + COOLDOWN_MS }
    fun speed(nowMs: Long, enabled: Boolean, playing: Boolean, bufferedMs: Long): Float {
        if (!enabled || !playing || nowMs < pausedUntilMs) { fast = false; return 1f }
        if (!fast && bufferedMs > START_MS) fast = true
        else if (fast && bufferedMs <= STOP_MS) fast = false
        return if (fast) SPEED else 1f
    }
}
