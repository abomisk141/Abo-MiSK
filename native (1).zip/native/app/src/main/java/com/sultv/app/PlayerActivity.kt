package com.sultv.app

import android.content.Intent

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.TrafficStats
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import android.widget.ScrollView
import android.content.ClipData
import android.content.ClipboardManager
import androidx.appcompat.app.AlertDialog
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.io.IOException

class PlayerActivity : BaseActivity() {
    companion object {
        const val RETURN_CHANNEL = "live-return-channel"
        const val RETURN_PLAYLIST = "live-return-playlist"
        const val RETURN_TOKEN = "live-return-token"
    }
    private var returnPlaylistId: String? = null
    private var videoBridge: VideoFrameBridge? = null
    private var handingBack = false
    private var handoffOffered = false
    private var observedPlayer: ExoPlayer? = null
    private var playbackObserver: Player.Listener? = null
    private var analyticsObserver: AnalyticsListener? = null
    private fun publishLiveReturn() {
        if (!live) return
        val channel = cur ?: return
        setResult(RESULT_OK, Intent().putExtra(RETURN_CHANNEL, channel.id)
            .putExtra(RETURN_PLAYLIST, returnPlaylistId).putExtra(RETURN_TOKEN, intent.getStringExtra(RETURN_TOKEN)))
    }

    private lateinit var player: ExoPlayer
    private var ap: ExoPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var top: LinearLayout
    private lateinit var info: TextView
    private var syncTarget = 0
    private var syncStartMs = 0L
    private var syncBaseMs = 0L
    private var syncDirection = 0
    private var syncResume: Runnable? = null
    private var syncPlayer: Player? = null
    private var infoPanel: PlayerInfoPanel? = null
    private var overlayBackConsumed = false
    private lateinit var ov: LinearLayout
    private lateinit var ovNum: TextView
    private lateinit var ovLogo: ImageView
    private lateinit var ovName: TextView
    private lateinit var ovNow: TextView
    private lateinit var chDl: TextView
    private lateinit var chUl: TextView
    private lateinit var chLat: TextView
    private lateinit var chBr: TextView
    private lateinit var chFr: TextView
    private lateinit var chQuality: TextView
    private lateinit var panel: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var panelList: ListView
    private var panelMode = 0
    private var groupLists: List<Pair<String, List<Item>>> = emptyList()
    private val hd = Handler(Looper.getMainLooper())
    private var url = ""; private var name = ""; private var live = false; private var n = 0
    private var list: List<Item> = emptyList()
    private var idx = -1
    private var cur: Item? = null
    @Volatile private var lat = -1
    private var lastTx = -1L
    // Avoid parallel socket probes and retry storms when a stream is offline.
    private val probeRunning = AtomicBoolean(false)
    private var retryCount = 0
    private var retryEndsAt = 0L
    private var recoveryVisible = false
    private var networkPulse: android.animation.ValueAnimator? = null
    private lateinit var recoveryBox: TextView
    private var lastRenderedFrames = -1
    private var lastFrameSampleAt = 0L
    private var measuredFps = -1.0
    private var retryTask: Runnable? = null
    private var lastZapAt = 0L
    private var playbackActive = false
    private val diagnostics = PlaybackDiagnostics()
    private var diagnosticDialog: AlertDialog? = null
    private var optionsDialog: android.app.Dialog? = null
    private var audioDialog: android.app.Dialog? = null
    private var audioSourceLabel = ""
    private var audioPlaylistId = ""
    private val liveEdgeGuard = LiveEdgeGuard()
    private val liveTrimmer = LiveBufferTrimmer()
    private var trimSpeedApplied = false
    private var trimPrevState = Player.STATE_IDLE
    private var manualLivePause = false
    private var diagnosticText: TextView? = null
    private var pictureEffectsActive = false
    private var pictureFallback = false

    private var stallSince = -1L
    private var stallBufferPosition = -1L

    private var sampledState = Player.STATE_IDLE
    private var playedThisChannel = false

    private fun checkLiveStall() {
        val state = player.playbackState
        val ready = state == Player.STATE_READY
        if (!live || !playbackActive || !player.playWhenReady || manualLivePause ||
            player.playbackSuppressionReason != Player.PLAYBACK_SUPPRESSION_REASON_NONE ||
            (!ready && state != Player.STATE_BUFFERING) || retryTask != null ||
            (recoveryVisible && recoveryBox.isFocusable)) {
            stallSince = -1L
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val position = if (ready) player.currentPosition else player.bufferedPosition
        if (stallSince < 0 || state != sampledState || position != stallBufferPosition) {
            if (ready && state == sampledState && stallSince >= 0 && position > stallBufferPosition) {
                playedThisChannel = true
                if (retryCount > 0) resetStreamRecovery()
            }
            stallSince = now
            stallBufferPosition = position
            sampledState = state
        } else if (now - stallSince >= (if (ready || playedThisChannel) 8000L else 15000L)) {
            stallSince = -1L
            scheduleStreamRecovery(immediate = true)
        }
    }

    private fun cancelRetry() {
        retryTask?.let { hd.removeCallbacks(it) }
        retryTask = null
        retryEndsAt = 0L
    }

    private var weakSince = -1L
    private var weakVisible = false

    private fun clearWeakWarning() {
        weakSince = -1
        if (weakVisible) recoveryBox.visibility = View.GONE
        weakVisible = false
    }

    private fun updateWeakWarning(received: Long) {
        val required = channelBitrate()
        if (!live || !playbackActive || recoveryVisible || !player.isPlaying || !player.isLoading ||
            required <= 0 || received >= required || player.totalBufferedDuration > 8000L) {
            clearWeakWarning()
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (weakSince < 0) weakSince = now
        if (now - weakSince < 4000L) return
        weakVisible = true
        val amber = col("#FFD270")
        recoveryBox.setTextColor(amber)
        recoveryBox.compoundDrawablesRelative[0]?.setTint(amber)
        recoveryBox.text = getString(R.string.weak_stream_rate, received / 1000000.0, required / 1000000.0)
        recoveryBox.isFocusable = false
        recoveryBox.isClickable = false
        recoveryBox.visibility = View.VISIBLE
    }

    private fun showRecovery(message: String, finished: Boolean = false) {
        if (!::recoveryBox.isInitialized) return
        clearWeakWarning()
        recoveryBox.setTextColor(Color.WHITE)
        recoveryBox.compoundDrawablesRelative[0]?.setTint(col("#83D5FF"))
        recoveryVisible = true
        recoveryBox.visibility = View.VISIBLE
        recoveryBox.text = message
        networkPulse?.cancel()
        val icon = recoveryBox.compoundDrawablesRelative[0]
        icon?.alpha = 255
        if (!finished && icon != null) {
            networkPulse = android.animation.ValueAnimator.ofInt(90, 255).apply {
                duration = 700
                repeatMode = android.animation.ValueAnimator.REVERSE
                repeatCount = android.animation.ValueAnimator.INFINITE
                addUpdateListener { icon.alpha = it.animatedValue as Int; recoveryBox.invalidate() }
                start()
            }
        }
        recoveryBox.isFocusable = finished
        recoveryBox.isClickable = finished
        if (finished) {
            recoveryBox.setOnClickListener {
                resetStreamRecovery()
                showRecovery("جاري إعادة الاتصال • المحاولة 1 من 5")
                restartLiveStream()
            }
            recoveryBox.requestFocus()
        } else recoveryBox.setOnClickListener(null)
    }

    private fun hideRecovery() {
        networkPulse?.cancel(); networkPulse = null
        recoveryVisible = false
        if (::recoveryBox.isInitialized) recoveryBox.visibility = View.GONE
    }

    private fun resetStreamRecovery() {
        cancelRetry()
        clearWeakWarning()
        stallSince = -1L
        retryCount = 0
        hideRecovery()
    }

    private fun scheduleStreamRecovery() = scheduleStreamRecovery(immediate = false)

    private fun scheduleStreamRecovery(immediate: Boolean) {
        if (!live || !playbackActive) return
        if (retryTask != null) return
        if (retryCount >= 5) {
            showRecovery("تعذر تشغيل القناة بعد 5 محاولات\nاضغط OK لإعادة المحاولة", true)
            return
        }
        cancelRetry()
        val failedUrl = url
        val delay = if (immediate && retryCount == 0) 0L else minOf(30000L, 2000L * (1L shl retryCount))
        retryCount++
        retryEndsAt = android.os.SystemClock.elapsedRealtime() + delay
        if (delay == 0L) showRecovery(getString(R.string.stall_reconnect, retryCount))
        else showRecovery("مشكلة في البث • المحاولة $retryCount من 5\nإعادة الاتصال خلال ${delay / 1000} ثوانٍ")
        val task = Runnable {
            retryTask = null
            retryEndsAt = 0L
            if (!isFinishing && !isDestroyed && playbackActive && url == failedUrl) {
                restartLiveStream()
            }
        }
        retryTask = task
        hd.postDelayed(task, delay)
    }
    private fun restartLiveStream(refreshAudio: Boolean = false) {
        if (!live || !::player.isInitialized) return
        channelRates.clearMedia()
        liveEdgeGuard.reset(); liveTrimmer.reset(); manualLivePause = false
        player.setMediaItem(PlaybackPolicy.mediaItem(url, true), true)
        player.prepare(); player.playWhenReady = true
        if (refreshAudio) { cancelSync(false); syncTarget = 0; syncBaseMs = 0 }
        if (refreshAudio) ap?.let { audio ->
            audio.currentMediaItem?.let { audio.setMediaItem(it, true); audio.prepare(); audio.playWhenReady = true }
        }
    }

    private fun returnToLive() {
        resetStreamRecovery()
        restartLiveStream(refreshAudio = true)
    }

    /** Plain TS only: HLS is handled by ExoPlayer's live offset controller, and external audio would drift. */
    private fun maintainLiveBuffer() {
        if (!::player.isInitialized) return
        val eligible = live && ap == null && retryTask == null && !manualLivePause &&
            Repo.b("liveEdgeGuard", true) && Repo.s("liveLatency", "fast") == "fast" &&
            player.currentManifest !is androidx.media3.exoplayer.hls.HlsManifest
        if (!eligible) {
            if (trimSpeedApplied) { player.setPlaybackSpeed(1f); trimSpeedApplied = false }
            liveTrimmer.reset()
            return
        }
        val playing = playbackActive && player.isPlaying && player.playbackState == Player.STATE_READY
        val speed = liveTrimmer.speed(android.os.SystemClock.elapsedRealtime(), true, playing, player.totalBufferedDuration)
        if (speed != player.playbackParameters.speed) { player.setPlaybackSpeed(speed); trimSpeedApplied = speed != 1f }
    }

    private fun maintainLiveEdge() {
        if (!live || !::player.isInitialized) return
        val enabled = Repo.b("liveEdgeGuard", true) && Repo.s("liveLatency", "fast") == "fast" && ap == null && retryTask == null && !manualLivePause
        val playlist = (player.currentManifest as? androidx.media3.exoplayer.hls.HlsManifest)?.mediaPlaylist
        val offset = playlist?.let {
            PlaybackPolicy.safeCatchupOffsetMs(PlaybackPolicy.liveProfile().targetOffsetMs, it.targetDurationUs,
                it.serverControl.holdBackUs, it.partTargetDurationUs, it.serverControl.partHoldBackUs, it.trailingParts.isNotEmpty())
        }
        if (offset == null) { liveEdgeGuard.reset(); return }
        val target = liveEdgeGuard.target(android.os.SystemClock.elapsedRealtime(), enabled,
            playbackActive && player.isPlaying && player.playbackState == Player.STATE_READY,
            player.isCurrentMediaItemLive, player.isCurrentMediaItemSeekable, player.duration,
            player.currentPosition, offset)
        if (target != null) player.seekTo(target)
    }

    private var okDown = false
    private var longFired = false
    private var epList: List<Item> = emptyList()
    private var epIdx = -1
    private var lpStyle = "full"
    private var vpStyle = "standard"
    private var ovBar: ProgrammeProgressView? = null
    private var ovStat: TextView? = null
    private var numBuf = ""
    private var prevItem: Item? = null
    private lateinit var numBox: TextView
    private val numRun = Runnable { commitNumber() }
    private var sid = ""
    private var showName = ""
    private var counting = false
    private var cd = 0
    private lateinit var nextBox: TextView
    private val cdRun = object : Runnable {
        override fun run() {
            cd--
            if (cd <= 0) { counting = false; nextBox.visibility = View.GONE; playNext() }
            else { nextBox.text = getString(R.string.next_in, cd); hd.postDelayed(this, 1000) }
        }
    }
    private var started = false
    private val hideOv = object : Runnable {
        override fun run() {
            if (!::ov.isInitialized) return
            if (infoPanel?.actions?.hasFocus() == true) hd.postDelayed(this, 6000)
            else { ov.visibility = View.GONE; infoPanel?.releaseControls() }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            n++; upd(); stats()
            PlaybackTraffic.sampleBps(player)?.let { diagnostics.bandwidth(it); updateWeakWarning(it) }
            refreshDiagnostics()
            checkLiveStall()
            maintainLiveEdge()
            maintainLiveBuffer()
            if (recoveryVisible && retryEndsAt > 0 && ::recoveryBox.isInitialized) {
                val seconds = ((retryEndsAt - android.os.SystemClock.elapsedRealtime() + 999) / 1000).coerceAtLeast(0)
                recoveryBox.text = "مشكلة في البث • المحاولة $retryCount من 5\nإعادة الاتصال خلال $seconds ثوانٍ"
            }
            if (n % 5 == 0) { save(); if (live) probe() }
            if (live && n % 10 == 0) updBar()
            if (live && n % 30 == 0) cur?.let { updateOv(it) }
            hd.postDelayed(this, 1000)
        }
    }

    private fun chip(icon: Int, key: String): TextView = TextView(this).apply {
        tag = "playback-stat:$key"
        setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(dp(8), dp(5), dp(8), dp(5)); setBackgroundColor(Color.TRANSPARENT); minimumWidth = dp(112); maxWidth = dp(220)
        compoundDrawablePadding = dp(6)
        val drawable = Th.icon(this@PlayerActivity, icon, Th.acc)?.apply { setBounds(0, 0, dp(18), dp(18)) }
        setCompoundDrawablesRelative(drawable, null, null, null)
    }

    private fun statsLine(values: List<Pair<Int, String>>): CharSequence {
        val text = android.text.SpannableStringBuilder()
        values.forEachIndexed { index, (icon, value) ->
            if (index > 0) text.append("    ")
            val start = text.length; text.append("\uFFFC")
            Th.icon(this, icon, Color.WHITE)?.apply {
                setBounds(0, 0, dp(16), dp(16))
                text.setSpan(android.text.style.ImageSpan(this, android.text.style.ImageSpan.ALIGN_BASELINE), start, start + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            text.append(" ").append(value)
        }
        return text
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Repo.init(this); Th.load()
        lpStyle = Repo.s("liveplayer", "full"); vpStyle = Repo.s("vodplayer", "standard")
        url = intent.getStringExtra("url") ?: ""; name = intent.getStringExtra("name") ?: ""
        live = intent.getBooleanExtra("live", false)
        returnPlaylistId = intent.getStringExtra(RETURN_PLAYLIST) ?: Repo.active()?.id
        val restored = if (live && returnPlaylistId == Repo.active()?.id) b?.getString("playing-live-id")?.let { Repo.find(it) } else null
        val rid = restored?.id ?: intent.getStringExtra("rid") ?: ""
        if (restored != null) { url = restored.url; name = restored.name }
        epIdx = intent.getIntExtra("epIdx", -1); sid = intent.getStringExtra("sid") ?: ""; showName = intent.getStringExtra("show") ?: ""
        epList = if (epIdx >= 0) Repo.epQueue else emptyList()
        if (rid.isNotBlank()) Repo.touch(rid)
        if (live) {
            list = Repo.zap; idx = list.indexOfFirst { it.id == rid }
            cur = if (idx >= 0) list[idx] else Repo.find(rid)
            if (rid.isNotBlank()) Repo.put("lastLive", rid)
            publishLiveReturn()
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this); pv.controllerShowTimeoutMs = 4000; pv.useController = !live
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        if (!live) {
            if (vpStyle == "minimal") { pv.setShowRewindButton(false); pv.setShowFastForwardButton(false); pv.setShowNextButton(false); pv.setShowPreviousButton(false) }
            (pv.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? androidx.media3.ui.DefaultTimeBar)?.let { it.setPlayedColor(Th.acc); it.setScrubberColor(Th.acc) }
        }
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        // ----- VOD title bar -----
        top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(col("#99000000")); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; text = name }
        top.addView(info)
        val gb = Th.btn(this, "⚙  " + getString(R.string.track_menu)); gb.setOnClickListener { tracksDialog() }
        top.addView(gb, LinearLayout.LayoutParams(-2, dp(44)))
        top.visibility = if (live) View.GONE else View.VISIBLE
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> if (!live) top.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE })

        nextBox = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; visibility = View.GONE; setPadding(dp(18), dp(12), dp(18), dp(12))
            background = Th.shape(this@PlayerActivity, col("#E6101535"), true, 18)
        }
        root.addView(nextBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(24), dp(96)) })
        numBox = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 44f; typeface = Typeface.DEFAULT_BOLD; visibility = View.GONE; gravity = Gravity.CENTER
            setPadding(dp(26), dp(10), dp(26), dp(10)); background = Th.shape(this@PlayerActivity, col("#E6101535"), true, 22)
        }
        root.addView(numBox, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(40), dp(40), 0) })

        // Programme information and controls share one responsive panel.
        val liveInfo = PlayerInfoPanel(this, lpStyle,
            { favNow() }, { showTrackMenu(C.TRACK_TYPE_AUDIO) }, { showTrackMenu(C.TRACK_TYPE_TEXT) }, { tracksDialog() })
        infoPanel = liveInfo; ov = liveInfo; ov.visibility = View.GONE
        ovNum = liveInfo.number; ovLogo = liveInfo.logo; ovName = liveInfo.channel; ovNow = liveInfo.programme
        ovBar = liveInfo.progress; ovStat = if (lpStyle == "glass") liveInfo.compactStats else null
        chDl = chip(R.drawable.ic_n_download, "download"); chUl = chip(R.drawable.ic_stat_upload, "upload")
        chLat = chip(R.drawable.ic_stat_latency, "latency"); chBr = chip(R.drawable.ic_stat_bitrate, "bitrate")
        chFr = chip(R.drawable.ic_stat_frames, "frames"); chQuality = chip(R.drawable.ic_stat_quality, "quality")
        listOf(chDl, chUl, chLat, chBr, chFr, chQuality).forEach { liveInfo.metrics.addView(it) }
        root.addView(ov, if (lpStyle == "glass") FrameLayout.LayoutParams(minOf(dp(620), resources.displayMetrics.widthPixels - dp(32)), -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(16), 0, dp(16), dp(16)) }
            else FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(12)) })

        // Recovery banner is independent of the channel info overlay.
        recoveryBox = TextView(this).apply {
            textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            val wifi = Th.icon(this@PlayerActivity, R.drawable.ic_connection_bars, col("#83D5FF"))?.mutate()
            wifi?.setBounds(0, 0, dp(26), dp(26))
            setCompoundDrawablesRelative(wifi, null, null, null)
            compoundDrawablePadding = dp(10)
            background = Th.shape(this@PlayerActivity, col("#ED101F32"), false, 14)
            visibility = View.GONE
            setOnFocusChangeListener { v, focused -> v.alpha = if (focused) 1f else .92f }
        }
        root.addView(recoveryBox, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(16) })

        // ----- channel / list panel -----
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setBackgroundColor(col("#EE0B1030")); setPadding(dp(16), dp(16), dp(16), dp(16)) }
        panelTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, dp(10)) }
        panelList = ListView(this).apply { selector = ColorDrawable(col("#556B72FF")); divider = null }
        panel.addView(panelTitle); panel.addView(panelList, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(panel, FrameLayout.LayoutParams(dp(380), -1, Gravity.START))

        root.setOnClickListener { if (live) { toggleOv() } }
        setContentView(root)

        val transfer = if (live && intent.getBooleanExtra("reusePreview", false)) LivePlayerHandoff.take(rid) else null
        val reused = transfer?.player
        player = reused ?: makePlayer(this, live)
        if (transfer != null) videoBridge = transfer.attach(pv) else pv.player = player
        diagnostics.reset()
        channelRates = ChannelRates()
        PlaybackTraffic.reset(player)
        val initialEffects = PictureSettings.load().effects()
        pictureEffectsActive = initialEffects.isNotEmpty()
        if (pictureEffectsActive && reused == null) {
            // A transferred player already has its effects; keep its decoder and buffer alive.
            player.setVideoEffects(initialEffects)
        }
        val st = Repo.prog(url)
        val start = if (!live && Repo.b("resumeVod", true) && st != null && st.first > 5000 && st.first < st.second - 10000) st.first else C.TIME_UNSET
        if (reused == null) player.setMediaItem(PlaybackPolicy.mediaItem(url, live), start)
        observePlayer()
        if (reused == null || player.playbackState == Player.STATE_IDLE) player.prepare()
        diagnostics.state(player.playbackState)
        player.playWhenReady = true
        applySub()
        if (live) { val c = cur; if (c != null) updateOv(c) else { ovName.text = name; ovNow.text = getString(R.string.no_info) }; showOv(); probe() }
    }

    private fun observePlayer() {
        detachPlayerObservers()
        val analytics = object : AnalyticsListener {
            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                diagnostics.dropped(droppedFrames)
            }
            override fun onLoadError(eventTime: AnalyticsListener.EventTime, loadEventInfo: LoadEventInfo,
                mediaLoadData: MediaLoadData, error: IOException, wasCanceled: Boolean) {
                if (!wasCanceled) diagnostics.error(error)
            }
        }
        analyticsObserver = analytics; player.addAnalyticsListener(analytics)
        val listener = object : Player.Listener {
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) { channelRates.clearMedia() }
            override fun onIsPlayingChanged(isPlaying: Boolean) { if (!isPlaying) save() }
            override fun onPlaybackStateChanged(state: Int) {
                diagnostics.state(state)
                if (live && state == Player.STATE_BUFFERING && trimPrevState == Player.STATE_READY) liveTrimmer.onStall(android.os.SystemClock.elapsedRealtime())
                trimPrevState = state
                if (state == Player.STATE_READY) { cancelRetry(); hideRecovery(); stallSince = -1L }
                if (state == Player.STATE_ENDED && !live && player.duration > 0) {
                    Repo.saveProg(url, player.duration, player.duration)
                    if (epIdx >= 0 && epIdx + 1 < epList.size && Repo.b("autoNext", true)) startCountdown()
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                diagnostics.error(error)
                if (pictureEffectsActive && error.errorCode in 7000..7999 && !pictureFallback) {
                    pictureFallback = true
                    applyPicture(PictureSettings.load().copy(enabled = false))
                    Toast.makeText(this@PlayerActivity, R.string.picture_fallback, Toast.LENGTH_LONG).show()
                    return
                }
                Toast.makeText(this@PlayerActivity, R.string.play_err, Toast.LENGTH_SHORT).show()
                if (live) scheduleStreamRecovery()
            }
        }
        playbackObserver = listener; player.addListener(listener); observedPlayer = player
    }
    private fun detachPlayerObservers() {
        observedPlayer?.let { p -> playbackObserver?.let { p.removeListener(it) }; analyticsObserver?.let { p.removeAnalyticsListener(it) } }
        playbackObserver = null; analyticsObserver = null; observedPlayer = null
    }

    private fun applySub() {
        val size = (Repo.s("ss", "100").toIntOrNull() ?: 100) * 0.2f
        val fg = try { Color.parseColor(Repo.s("sc", "#FFFFFF")) } catch (e: Exception) { Color.WHITE }
        val bg = try { Color.parseColor(Repo.s("sbg", "#99000000")) } catch (e: Exception) { Color.TRANSPARENT }
        pv.subtitleView?.setStyle(CaptionStyleCompat(fg, bg, Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, Typeface.DEFAULT))
        pv.subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    }

    // ---------------- overlay ----------------
    private fun showOv() {
        if (!live) return
        ov.visibility = View.VISIBLE
        hd.removeCallbacks(hideOv); hd.postDelayed(hideOv, 6000)
    }

    private fun toggleOv() {
        if (ov.visibility == View.VISIBLE) { ov.visibility = View.GONE; infoPanel?.releaseControls(); pv.requestFocus() }
        else showOv()
    }

    private fun updateOv(i: Item) {
        ovNum.text = if (idx >= 0) (idx + 1).toString() else ""
        ovName.text = i.name
        ovNow.text = Repo.nowOn(i)?.title ?: getString(R.string.no_info)
        if (i.logo.isBlank()) { Img.clear(ovLogo); ovLogo.setImageResource(R.drawable.logo) } else Img.load(ovLogo, i.logo)
        ovNum.visibility = if (idx < 0) View.GONE else View.VISIBLE
        infoPanel?.favouriteState(Repo.isFav(i.id), true)
        updBar()
    }

    private fun updBar() {
        val panel = infoPanel ?: return
        val current = cur
        val now = current?.let { Repo.nowOn(it) }
        panel.programme.text = now?.title ?: getString(R.string.no_info)
        panel.timing.visibility = if (now == null) View.GONE else View.VISIBLE
        panel.time.text = now?.let { hm(it.start) + " – " + hm(it.stop) }.orEmpty()
        panel.progress.pct = now?.let { (((System.currentTimeMillis() - it.start) * 100) / (it.stop - it.start).coerceAtLeast(1)).toInt().coerceIn(0, 100) } ?: 0
        panel.progress.invalidate()
        val next = current?.let { GuideProgrammes.visible(Repo.progs(it), System.currentTimeMillis())[1] }
        panel.next.visibility = if (next == null || lpStyle == "minimal") View.GONE else View.VISIBLE
        panel.next.text = next?.let { getString(R.string.player_next_programme, android.text.BidiFormatter.getInstance().unicodeWrap(hm(it.start)), it.title) }.orEmpty()
    }

    private fun stat(label: Int, value: String): CharSequence = android.text.SpannableString(value + "\n" + getString(label)).apply {
        setSpan(android.text.style.StyleSpan(Typeface.BOLD), 0, value.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private var channelRates = ChannelRates()
    private fun channelBitrate(): Long {
        if (channelRates.bitrate > 0) return channelRates.bitrate
        return listOfNotNull(player.videoFormat?.bitrate, player.audioFormat?.bitrate)
            .filter { it > 0 }.sumOf { it.toLong() }
    }

    private fun stats() {
        if (!live) return
        val uidRx = TrafficStats.getUidRxBytes(Process.myUid())
        val rx = if (uidRx >= 0) uidRx else TrafficStats.getTotalRxBytes()
        channelRates.sample(android.os.SystemClock.elapsedRealtime(), rx, PlaybackTraffic.bytesReceived(player),
            player.currentPosition + player.totalBufferedDuration)
        val tx = TrafficStats.getUidTxBytes(Process.myUid())
        val ulv = if (tx >= 0 && lastTx >= 0) String.format(Locale.US, "%d kb/s", (tx - lastTx) * 8 / 1000) else "…"
        lastTx = tx
        if (ov.visibility != View.VISIBLE) return
        val dl = if (channelRates.download >= 0) String.format(Locale.US, "%.1f Mb/s", channelRates.download / 1000000.0) else "…"
        val vf = player.videoFormat
        val rate = channelBitrate()
        val br = if (rate > 0) (if (channelRates.bitrate > 0) "~" else "") + String.format(Locale.US, "%d kb/s", rate / 1000) else "…"
        val now = android.os.SystemClock.elapsedRealtime()
        val rendered = player.videoDecoderCounters?.renderedOutputBufferCount ?: -1
        if (rendered >= 0) {
            if (lastRenderedFrames >= 0 && rendered >= lastRenderedFrames && now > lastFrameSampleAt) {
                measuredFps = (rendered - lastRenderedFrames) * 1000.0 / (now - lastFrameSampleAt)
            }
            lastRenderedFrames = rendered
            lastFrameSampleAt = now
        }
        val quality = if (vf != null && vf.width > 0 && vf.height > 0) {
            val h = vf.height
            val tag = when {
                h >= 2160 -> "4K UHD"
                h >= 1080 -> "FHD 1080p"
                h >= 720 -> "HD 720p"
                else -> "SD ${h}p"
            }
            "$tag (${vf.width}×${vf.height})"
        } else "…"
        val fr = if (vf != null && vf.frameRate > 0) String.format(Locale.US, "%.0f fps", vf.frameRate)
            else if (measuredFps > 0.0 && player.isPlaying) String.format(Locale.US, "~%.0f fps", measuredFps)
            else "…"
        infoPanel?.quality?.apply { text = quality.substringBefore(" ("); visibility = if (vf != null && vf.width > 0) View.VISIBLE else View.GONE }
        when (lpStyle) {
            "minimal" -> {}
            "glass" -> ovStat?.text = statsLine(listOf(R.drawable.ic_n_download to dl,
                R.drawable.ic_stat_latency to (if (lat >= 0) "$lat ms" else "…"), R.drawable.ic_stat_bitrate to br, R.drawable.ic_stat_quality to quality))
            else -> {
                chDl.text = stat(R.string.dl, dl); chUl.text = stat(R.string.ul, ulv)
                chLat.text = stat(R.string.player_server, if (lat >= 0) "$lat ms" else "…")
                chBr.text = stat(R.string.bitrate, br); chFr.text = stat(R.string.frames, fr)
                chQuality.text = stat(R.string.stat_quality, if (vf != null && vf.width > 0 && vf.height > 0) "${vf.width}×${vf.height}" else "…")
            }
        }
    }

    private fun probe() {
        if (!probeRunning.compareAndSet(false, true)) return
        val testedUrl = url
        Thread {
            var measured = -1
            try {
                val uu = URL(testedUrl)
                val port = if (uu.port > 0) uu.port else if (uu.defaultPort > 0) uu.defaultPort else 80
                val t0 = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(uu.host, port), 3000) }
                measured = ((System.nanoTime() - t0) / 1000000).toInt()
            } catch (_: Exception) { }
            finally {
                if (url == testedUrl) lat = measured
                probeRunning.set(false)
            }
        }.start()
    }

    private fun tm(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60) else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun seekBy(ms: Long) {
        val d = player.duration
        var t = player.currentPosition + ms
        if (t < 0) t = 0
        if (d > 0 && d != C.TIME_UNSET && t > d - 1000) t = d - 1000
        player.seekTo(t); pv.showController(); upd()
    }

    private fun upd() {
        if (live) return
        if (vpStyle == "minimal") { info.text = name; return }
        val d = player.duration
        val vf = player.videoFormat
        val l2 = StringBuilder()
        if (d > 0 && d != C.TIME_UNSET) l2.append(tm(player.currentPosition)).append(" / ").append(tm(d)).append("  (").append(player.currentPosition * 100 / d).append("%)")
        if (vf != null && vf.height > 0) l2.append("   •   ").append(vf.width).append("×").append(vf.height)
        if (vf != null && vf.bitrate > 0) l2.append("   •   ").append(String.format(Locale.US, "%.1f Mb/s", vf.bitrate / 1000000.0))
        val bw = DefaultBandwidthMeter.getSingletonInstance(this).bitrateEstimate
        if (bw > 0) l2.append("   •   ").append(getString(R.string.dl)).append(" ").append(String.format(Locale.US, "%.1f Mb/s", bw / 1000000.0))
        if (vpStyle == "detailed" && d > 0 && d != C.TIME_UNSET) l2.append("   •   ").append(getString(R.string.ends_at)).append(" ").append(hm(System.currentTimeMillis() + (d - player.currentPosition)))
        info.text = name + "\n" + l2
    }

    private fun save() {
        if (live) return
        val d = player.duration
        if (d > 0 && d != C.TIME_UNSET) Repo.saveProg(url, player.currentPosition, d)
    }

    // ---------------- next episode ----------------
    private fun startCountdown() {
        counting = true; cd = 5
        nextBox.text = getString(R.string.next_in, cd); nextBox.visibility = View.VISIBLE
        hd.removeCallbacks(cdRun); hd.postDelayed(cdRun, 1000)
    }

    private fun cancelCountdown() { counting = false; hd.removeCallbacks(cdRun); nextBox.visibility = View.GONE }

    private fun playNext() {
        if (epIdx + 1 >= epList.size) return
        epIdx++
        val e = epList[epIdx]
        url = e.url; name = (if (showName.isNotEmpty()) showName + " " else "") + e.ep
        if (sid.isNotEmpty()) { Repo.put("le:$sid", e.url); Repo.put("lt:$sid", e.ep); Repo.touch(sid) }
        val st = Repo.prog(url)
        val start = if (Repo.b("resumeVod", true) && st != null && st.first > 5000 && st.first < st.second - 10000) st.first else C.TIME_UNSET
        diagnostics.reset()
        channelRates = ChannelRates()
        PlaybackTraffic.reset(player)
        player.setMediaItem(MediaItem.fromUri(url), start); player.prepare(); player.playWhenReady = true
        pv.showController(); upd()
    }

    // ---------------- channel switching ----------------
    private fun zap(d: Int) {
        if (list.isEmpty()) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastZapAt < 220L) return
        lastZapAt = now
        idx = ((if (idx < 0) 0 else idx) + d + list.size) % list.size
        switchTo(list[idx])
    }

    private fun switchTo(i: Item) {
        if (cur?.id == i.id && player.currentMediaItem != null) { closePanel(); ov.visibility = View.GONE; return }
        resetStreamRecovery()
        if (cur != null && cur?.id != i.id) prevItem = cur
        playedThisChannel = false
        cur = i; url = i.url; name = i.name; stopAudio()
        diagnostics.reset()
        channelRates = ChannelRates()
        PlaybackTraffic.reset(player)
        pictureFallback = false
        player.setMediaItem(PlaybackPolicy.mediaItem(url, true)); player.prepare(); player.playWhenReady = true
        Repo.touch(i.id); Repo.put("lastLive", i.id)
        publishLiveReturn()
        channelRates.clearMedia()
        liveEdgeGuard.reset(); liveTrimmer.reset(); manualLivePause = false
        lat = -1; updateOv(i); showOv(); probe()
    }

    private fun openPanel() { if (list.isEmpty()) return; showChannels(); panel.visibility = View.VISIBLE }

    private fun showChannels() {
        panelMode = 1; panelTitle.text = getString(R.string.all_live)
        val ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, list.mapIndexed { i, x ->
            "${i + 1}   ${x.name}" + (if (x.id == cur?.id) "   ▶ تشاهد الآن" else "")
        })
        panelList.adapter = ad
        panelList.setOnItemClickListener { _, _, pos, _ -> list.getOrNull(pos)?.let {
            idx = pos
            if (it.id == cur?.id) { closePanel(); ov.visibility = View.GONE }
            else { switchTo(it); closePanel() }
        } }
        if (idx >= 0) panelList.setSelection(idx)
        panelList.requestFocus()
    }

    private fun showGroups() {
        panelMode = 2; panelTitle.text = getString(R.string.lists)
        val all = Repo.list("live"); val f = Repo.favs()
        val gs = ArrayList<Pair<String, List<Item>>>()
        gs.add(getString(R.string.fav) to all.filter { it.id in f })
        gs.add(getString(R.string.recent) to Repo.recent().mapNotNull { id -> all.firstOrNull { it.id == id } })
        gs.add(getString(R.string.all_live) to all)
        val m = LinkedHashMap<String, MutableList<Item>>()
        for (x in all) if (x.grp.isNotBlank()) m.getOrPut(x.grp) { ArrayList() }.add(x)
        for ((g, l) in m) gs.add(g to l)
        groupLists = gs
        panelList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, gs.map { "${it.first}  (${it.second.size})" })
        panelList.setOnItemClickListener { _, _, pos, _ ->
            groupLists.getOrNull(pos)?.let { g ->
                list = g.second; idx = list.indexOfFirst { it.id == cur?.id }
                showChannels()
            }
        }
        panelList.requestFocus()
    }

    private fun closePanel() { panelMode = 0; panel.visibility = View.GONE; panelList.clearFocus() }

    private fun typeDigit(d: Int) {
        if (numBuf.length >= 4) numBuf = ""
        numBuf += d
        numBox.text = numBuf; numBox.visibility = View.VISIBLE
        hd.removeCallbacks(numRun); hd.postDelayed(numRun, 1800)
    }

    private fun commitNumber() {
        hd.removeCallbacks(numRun)
        val n = numBuf.toIntOrNull()
        numBuf = ""; numBox.visibility = View.GONE
        if (n == null) return
        if (n >= 1 && n <= list.size) { idx = n - 1; switchTo(list[idx]) }
        else Toast.makeText(this, getString(R.string.rc_no_ch, n), Toast.LENGTH_SHORT).show()
    }

    private fun lastChannel() {
        val p = prevItem ?: return
        val i2 = list.indexOfFirst { it.id == p.id }
        if (i2 >= 0) idx = i2
        switchTo(p)
    }

    private fun favNow() {
        val c = cur ?: return
        val on = Repo.toggleFav(c.id)
        infoPanel?.favouriteState(on, true)
        Toast.makeText(this, if (on) R.string.fav_added else R.string.fav_removed, Toast.LENGTH_SHORT).show()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = Remote.canon(e.keyCode)
        val down = e.action == KeyEvent.ACTION_DOWN
        if (counting) {
            if (k == KeyEvent.KEYCODE_DPAD_CENTER) { if (down && e.repeatCount == 0) { cancelCountdown(); playNext() }; return true }
            if (k == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) cancelCountdown(); return true }
        }
        if (panelMode != 0) {
            if (k == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) { if (panelMode == 2) showChannels() else closePanel() }; return true }
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) { if (down && panelMode == 1) showGroups(); return true }
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT) { if (down) { if (panelMode == 2) showChannels() else closePanel() }; return true }
            return super.dispatchKeyEvent(e)
        }
        val overlay = infoPanel
        if (live && Remote.numJump() && Remote.digit(k) >= 0) {
            if (down && e.repeatCount == 0) { overlay?.releaseControls(); pv.requestFocus(); typeDigit(Remote.digit(k)) }
            return true
        }
        if (live && numBuf.isNotEmpty() && k == KeyEvent.KEYCODE_DPAD_CENTER) { if (down && e.repeatCount == 0) commitNumber(); return true }
        if (live && panelMode == 0 && k == KeyEvent.KEYCODE_BACK && (overlay?.actions?.hasFocus() == true || overlayBackConsumed)) {
            if (down) { overlayBackConsumed = true; overlay?.releaseControls(); ov.visibility = View.GONE; pv.requestFocus() }
            else overlayBackConsumed = false
            return true
        }
        if (live && panelMode == 0 && overlay?.actions?.hasFocus() == true) {
            if (k == KeyEvent.KEYCODE_DPAD_UP) {
                if (down) { overlay.releaseControls(); pv.requestFocus(); showOv() }
                return true
            }
            if (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (down) overlay.moveControl(k == KeyEvent.KEYCODE_DPAD_RIGHT)
                return true
            }
            if (k == KeyEvent.KEYCODE_DPAD_DOWN) return true
            if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) { overlay.controlKey(down, e.repeatCount > 0); return true }
        }
        if (live && panelMode == 0 && k == KeyEvent.KEYCODE_DPAD_RIGHT && Remote.resolve("live", k) == null) {
            if (down && e.repeatCount == 0) { showOv(); overlay?.focusControls() }
            return true
        }
        if (k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) { if (down && e.repeatCount == 0) { if (player.isPlaying) { if (live) manualLivePause = true; player.pause() } else player.play() }; return true }
        if (k == KeyEvent.KEYCODE_MEDIA_PLAY) { if (down) player.play(); return true }
        if (k == KeyEvent.KEYCODE_MEDIA_PAUSE) { if (down) { if (live) manualLivePause = true; player.pause() }; return true }
        when (Remote.resolve(if (live) "live" else "vod", k)) {
            "l_next" -> { if (down) zap(1); return true }
            "l_prev" -> { if (down) zap(-1); return true }
            "l_list" -> { if (down) openPanel(); return true }
            "l_last" -> { if (down && e.repeatCount == 0) lastChannel(); return true }
            "l_fav" -> { if (down && e.repeatCount == 0) favNow(); return true }
            "l_menu", "v_menu" -> { if (down && e.repeatCount == 0) tracksDialog(); return true }
            "l_info" -> {
                if (down) {
                    if (e.repeatCount == 0) { okDown = true; longFired = false }
                    else if (okDown && !longFired && e.eventTime - e.downTime >= 600) { longFired = true; tracksDialog() }
                } else if (e.action == KeyEvent.ACTION_UP) {
                    if (okDown && !longFired) toggleOv()
                    okDown = false
                }
                return true
            }
            "v_back" -> { if (down) seekBy(if (e.repeatCount > 0) -30000L else -10000L); return true }
            "v_fwd" -> { if (down) seekBy(if (e.repeatCount > 0) 30000L else 10000L); return true }
            "v_play" -> { if (down && e.repeatCount == 0) { if (player.isPlaying) { if (live) manualLivePause = true; player.pause() } else player.play() }; return true }
            "v_next" -> { if (down && e.repeatCount == 0 && epIdx + 1 < epList.size) { cancelCountdown(); playNext() }; return true }
        }
        if (!live) {
            if (k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN) { if (!pv.isControllerFullyVisible) { if (down) pv.showController(); return true } }
            if (k == KeyEvent.KEYCODE_DPAD_CENTER) {
                if (!pv.isControllerFullyVisible) { if (down && e.repeatCount == 0) pv.showController(); return true }
                if (down && e.repeatCount > 0 && e.eventTime - e.downTime >= 600 && !longFired) { longFired = true; tracksDialog(); return true }
                if (e.action == KeyEvent.ACTION_UP && longFired) { longFired = false; return true }
            }
        } else if (k == KeyEvent.KEYCODE_DPAD_RIGHT) return true
        return super.dispatchKeyEvent(e)
    }

    // ---------------- quality / audio / subtitles ----------------
    private fun params(fn: (TrackSelectionParameters.Builder) -> Unit) {
        val b = player.trackSelectionParameters.buildUpon(); fn(b); player.trackSelectionParameters = b.build()
    }

    private fun langName(l: String?): String = if (l.isNullOrBlank() || l == "und") "" else Locale(l).displayLanguage

    private fun tracksDialog() = showTrackMenu(null)

    private fun showTrackMenu(type: Int?) {
        optionsDialog?.dismiss()
        val entries = ArrayList<PlaybackMenus.Entry>()
        fun add(title: String, detail: String, section: Int, icon: Int, selected: Boolean = false, action: () -> Unit) {
            entries.add(PlaybackMenus.Entry(title, detail, getString(section), icon, selected, action = action))
        }
        add(getString(R.string.diag_title), "", R.string.s_general, R.drawable.ic_n_info) { showDiagnostics() }
        add(getString(R.string.picture_title), "", R.string.s_general, R.drawable.ic_n_live) { showPictureControls { applyPicture(it) } }
        add(getString(R.string.q_auto), "", R.string.t_video, R.drawable.ic_n_live,
            player.trackSelectionParameters.overrides.values.none { it.type == C.TRACK_TYPE_VIDEO }) {
            params { it.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).clearOverridesOfType(C.TRACK_TYPE_VIDEO) }
        }
        var hasText = false
        for (g in player.currentTracks.groups) for (t in 0 until g.length) {
            if (!g.isTrackSupported(t)) continue
            val f = g.getTrackFormat(t)
            when (g.type) {
                C.TRACK_TYPE_VIDEO -> add(if (f.height > 0) "${f.height}p" else "#${t + 1}",
                    if (f.bitrate > 0) "${f.bitrate / 1000} kbps" else "", R.string.t_video, R.drawable.ic_n_live, g.isTrackSelected(t)) {
                    params { it.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, t)) }
                }
                C.TRACK_TYPE_AUDIO -> add((f.label ?: "").ifBlank { langName(f.language) }.ifBlank { "#${t + 1}" },
                    if (f.channelCount > 0) "${f.channelCount}ch" else "", R.string.t_audio, R.drawable.ic_audio_wave, ap == null && g.isTrackSelected(t)) {
                    stopAudio()
                    params { it.setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, t)) }
                }
                C.TRACK_TYPE_TEXT -> {
                    if (!hasText) {
                        hasText = true
                        add(getString(R.string.off), "", R.string.t_subs, R.drawable.ic_subtitles,
                            player.currentTracks.groups.none { it.type == C.TRACK_TYPE_TEXT && it.isSelected }) {
                            params { it.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true) }
                        }
                    }
                    add((f.label ?: "").ifBlank { langName(f.language) }.ifBlank { "#${t + 1}" }, "", R.string.t_subs, R.drawable.ic_subtitles, g.isTrackSelected(t)) {
                        params { it.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, t)) }
                    }
                }
            }
        }
        if (live) {
            add(getString(R.string.return_to_live), getString(R.string.return_to_live_hint), R.string.t_video, R.drawable.ic_n_live) { returnToLive() }
            add(getString(R.string.audio_other), audioSourceLabel, R.string.t_audio, R.drawable.ic_audio_wave, ap != null) { pickAudio() }
            if (ap != null) add(getString(R.string.sync_commentary), syncLabel(syncTarget), R.string.t_audio, R.drawable.ic_audio_wave) { syncMenu() }
            if (ap != null) add(getString(R.string.audio_off), "", R.string.t_audio, R.drawable.ic_audio_wave) { stopAudio() }
        }
        val section = when (type) { C.TRACK_TYPE_AUDIO -> getString(R.string.t_audio); C.TRACK_TYPE_TEXT -> getString(R.string.t_subs); else -> null }
        val shown = if (section == null) entries else entries.filter { it.section == section }
        val available = shown.ifEmpty { listOf(PlaybackMenus.Entry(getString(R.string.no_info), "", section ?: getString(R.string.s_general), if (type == C.TRACK_TYPE_TEXT) R.drawable.ic_subtitles else R.drawable.ic_audio_wave) {}) }
        optionsDialog = PlaybackMenus.options(this, section ?: getString(R.string.track_menu), listOf(name, Repo.active()?.name.orEmpty()).filter { it.isNotBlank() }.joinToString(" · "), available)
    }

    private fun refreshDiagnostics() {
        if (diagnosticDialog?.isShowing == true && ::player.isInitialized)
            diagnosticText?.text = diagnostics.report(this, player, lat)
    }

    private fun showDiagnostics() {
        if (diagnosticDialog?.isShowing == true) return
        val text = TextView(this).apply {
            textSize = 15f; setPadding(dp(20), dp(12), dp(20), dp(12)); setTextIsSelectable(true)
        }
        diagnosticText = text
        val scroll = ScrollView(this).apply { addView(text) }
        val d = AlertDialog.Builder(this).setTitle(R.string.diag_title).setView(scroll)
            .setPositiveButton(R.string.feature_close, null)
            .setNeutralButton(R.string.diag_copy, null).create()
        diagnosticDialog = d
        d.setOnDismissListener { diagnosticDialog = null; diagnosticText = null }
        d.show()
        d.window?.setLayout(dp(600), (resources.displayMetrics.heightPixels * .85f).toInt())
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val report = "ABO MISK " + packageManager.getPackageInfo(packageName, 0).versionName + "\n" + diagnostics.report(this, player, lat)
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(getString(R.string.diag_title), report))
            Toast.makeText(this, R.string.diag_copied, Toast.LENGTH_SHORT).show()
        }
        refreshDiagnostics()
    }

    private fun applyPicture(settings: PictureSettings) {
        val safe = settings.normalized()
        if (safe.enabled && player.currentTracks.groups.any { g ->
                (0 until g.length).any { g.isTrackSelected(it) && g.getTrackFormat(it).drmInitData != null }
            }) {
            Toast.makeText(this, R.string.picture_protected, Toast.LENGTH_LONG).show()
            return
        }
        val effects = safe.effects()
        cancelRetry()
        try {
            safe.save()
            rebuildPicturePlayer(effects)
        } catch (_: RuntimeException) {
            safe.copy(enabled = false).save()
            rebuildPicturePlayer(emptyList())
            Toast.makeText(this, R.string.picture_fallback, Toast.LENGTH_LONG).show()
        }
    }

    private fun rebuildPicturePlayer(effects: List<androidx.media3.common.Effect>) {
        val item = player.currentMediaItem ?: return
        val pos = player.currentPosition.coerceAtLeast(0)
        val playing = player.playWhenReady
        val tracks = player.trackSelectionParameters
        val speed = player.playbackParameters
        val volume = player.volume
        val replacement = makePlayer(this, live)
        try {
            // In Media3 1.3, even setVideoEffects(emptyList()) enables the GL pipeline.
            // A fresh renderer is required to truly restore the original, cheaper path.
            if (effects.isNotEmpty()) replacement.setVideoEffects(effects)
            replacement.trackSelectionParameters = tracks
            replacement.playbackParameters = speed
            replacement.volume = volume
        } catch (e: RuntimeException) { replacement.release(); throw e }
        detachPlayerObservers(); videoBridge?.close(); videoBridge = null
        pv.player = null
        player.release()
        player = replacement
        pictureEffectsActive = effects.isNotEmpty()
        pv.player = player
        observePlayer()
        player.setMediaItem(item, pos)
        player.prepare()
        player.playWhenReady = playing
    }

    // ---------------- audio from another channel ----------------
    private fun cancelSync(resume: Boolean) {
        syncResume?.let(hd::removeCallbacks)
        syncResume = null
        if (resume) syncPlayer?.play()
        syncPlayer = null
        syncDirection = 0
    }

    private fun setSync(seconds: Int) {
        val audio = ap ?: return
        val now = android.os.SystemClock.elapsedRealtime()
        val targetMs = seconds * 1000L
        val previousTarget = syncTarget * 1000L
        val elapsed = (now - syncStartMs).coerceAtMost(kotlin.math.abs(previousTarget - syncBaseMs))
        val applied = syncBaseMs + elapsed * syncDirection
        cancelSync(true)
        syncTarget = seconds
        if (seconds == 0) { returnToLive(); return }
        val delta = targetMs - applied
        if (delta == 0L) return
        syncStartMs = now
        syncBaseMs = applied
        syncDirection = if (delta > 0) 1 else -1
        val delayed = if (delta > 0) audio else player
        syncPlayer = delayed
        delayed.pause()
        syncResume = Runnable {
            syncBaseMs = targetMs
            cancelSync(true)
        }.also { hd.postDelayed(it, kotlin.math.abs(delta)) }
    }

    private fun syncLabel(seconds: Int): String = if (seconds == 0) getString(R.string.sync_zero)
        else getString(if (seconds > 0) R.string.sync_sound else R.string.sync_picture, kotlin.math.abs(seconds))

    private fun syncMenu() {
        val entries = ArrayList<PlaybackMenus.Entry>()
        fun option(label: String, seconds: Int) {
            entries.add(PlaybackMenus.Entry(label, "", getString(R.string.sync_commentary), R.drawable.ic_audio_wave) {
                setSync(seconds)
            })
        }
        option(getString(R.string.sync_sound, 1) + " (+1)", (syncTarget + 1).coerceAtMost(60))
        option(getString(R.string.sync_picture, 1) + " (+1)", (syncTarget - 1).coerceAtLeast(-60))
        option(getString(R.string.sync_zero), 0)
        for (seconds in listOf(5, 10, 30, 60, -5, -10, -30, -60)) option(syncLabel(seconds), seconds)
        optionsDialog = PlaybackMenus.options(this, getString(R.string.sync_commentary), syncLabel(syncTarget), entries)
    }

    private fun pickAudio() {
        audioDialog?.dismiss()
        audioDialog = PlaybackMenus.audio(this, url, ap?.currentMediaItem?.localConfiguration?.uri?.toString(),
            { selected -> startAudio(selected.item, selected.playlistName, selected.playlistId) }, { stopAudio() }, audioPlaylistId)
    }

    private fun startAudio(i: Item, source: String = Repo.active()?.name.orEmpty(), sourceId: String = Repo.active()?.id.orEmpty()) {
        stopAudio()
        audioSourceLabel = i.name + " · " + source
        audioPlaylistId = sourceId
        player.volume = 0f
        ap = makePlayer(this, live = true).also { it.setMediaItem(PlaybackPolicy.mediaItem(i.url, true)); it.prepare(); it.playWhenReady = true }

    }

    private fun stopAudio() {
        cancelSync(true); syncTarget = 0; syncBaseMs = 0
        audioSourceLabel = ""; audioPlaylistId = ""
        ap?.release(); ap = null
        if (::player.isInitialized) player.volume = 1f

    }

    override fun finish() {
        if (handingBack) return
        val id = cur?.id
        val allowed = live && ::player.isInitialized && ::pv.isInitialized && id != null && player.playerError == null &&
            intent.getBooleanExtra("returnPreviewAllowed", false) && returnPlaylistId == Repo.active()?.id &&
            Repo.list("live").any { it.id == id }
        if (!allowed) { super.finish(); return }
        handingBack = true
        VideoFrames.capture(pv) { frame ->
            if (isDestroyed) { frame?.recycle(); return@capture }
            stopAudio(); detachPlayerObservers(); videoBridge?.close(); videoBridge = null
            LivePlayerHandoff.offer(id!!, player, pv, LivePlayerHandoff.Destination.PREVIEW, intent.getStringExtra(RETURN_TOKEN), frame)
            handoffOffered = true
            super.finish()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (live) cur?.let { outState.putString("playing-live-id", it.id) }
        super.onSaveInstanceState(outState)
    }

    override fun onStart() {
        super.onStart(); playbackActive = true; hd.removeCallbacks(tick); hd.post(tick)
        if (started && live) { resetStreamRecovery(); restartLiveStream(refreshAudio = true) }
        started = true
    }
    override fun onStop() {
        playbackActive = false
        cancelSync(false)
        infoPanel?.releaseControls()
        cancelRetry()
        hd.removeCallbacks(tick)
        liveEdgeGuard.reset(); liveTrimmer.reset()
        save()
        if (live) { if (!handoffOffered) player.stop(); ap?.stop() } else { player.pause(); ap?.pause() }
        clearWeakWarning()
        super.onStop()
    }
    override fun onDestroy() {
        playbackActive = false
        cancelRetry()
        networkPulse?.cancel()
        hd.removeCallbacksAndMessages(null)
        diagnosticDialog?.dismiss(); optionsDialog?.dismiss(); audioDialog?.dismiss()
        ap?.release(); ap = null
        detachPlayerObservers(); videoBridge?.close(); videoBridge = null
        if (!LivePlayerHandoff.owns(pv)) pv.player = null
        if (!handoffOffered) player.release()
        super.onDestroy()
    }
}
