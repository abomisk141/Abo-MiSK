package com.sultv.app

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.lang.ref.WeakReference

/** Transfers the player in both directions without resetting its stream, position or decoder. */
object LivePlayerHandoff {
    enum class Destination { FULLSCREEN, PREVIEW }
    class Transfer(val player: ExoPlayer, val source: PlayerView?, private val frame: Bitmap?) {
        fun attach(target: PlayerView): VideoFrameBridge {
            val bridge = VideoFrameBridge(player, target, frame)
            // Media3 attaches the new output before clearing the old one.
            PlayerView.switchTargetView(player, source, target)
            return bridge
        }
    }
    private class Pending(val id: String, val player: ExoPlayer, source: PlayerView?, val destination: Destination,
        val token: String?, val frame: Bitmap?) {
        val source = WeakReference(source)
    }
    private var pending: Pending? = null
    private val handler = Handler(Looper.getMainLooper())
    private val expire = Runnable { clear() }
    @Synchronized fun offer(id: String, player: ExoPlayer, source: PlayerView? = null,
        destination: Destination = Destination.FULLSCREEN, token: String? = null, frame: Bitmap? = null) {
        clear(releasePlayer = pending?.player !== player)
        pending = Pending(id, player, source, destination, token, frame)
        handler.postDelayed(expire, 10000)
    }
    @Synchronized fun hasPending(id: String, destination: Destination, token: String? = null): Boolean =
        pending?.let { it.id == id && it.destination == destination && (destination != Destination.PREVIEW || it.token == token) } == true
    @Synchronized fun owns(view: PlayerView?): Boolean = view != null && pending?.source?.get() === view
    @Synchronized fun take(id: String, destination: Destination = Destination.FULLSCREEN, token: String? = null): Transfer? {
        val entry = pending ?: return null
        if (!hasPending(id, destination, token)) return null
        pending = null; handler.removeCallbacks(expire)
        return Transfer(entry.player, entry.source.get(), entry.frame)
    }
    @Synchronized fun discardSource(view: PlayerView?) { if (owns(view)) clear() }
    @Synchronized fun clear(releasePlayer: Boolean = true) {
        handler.removeCallbacks(expire)
        pending?.let { entry ->
            entry.source.get()?.let { if (it.player === entry.player) it.player = null }
            entry.frame?.let { if (!it.isRecycled) it.recycle() }
            if (releasePlayer) entry.player.release()
        }
        pending = null
    }
}
